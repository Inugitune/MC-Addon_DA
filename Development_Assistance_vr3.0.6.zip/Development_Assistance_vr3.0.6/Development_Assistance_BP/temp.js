const coarse = [];
for (let dx = 0; dx <= 1; dx++) {
    for (let dy = 0; dy <= 1; dy++) {
        for (let dz = 0; dz <= 1; dz++) {
            coarse.push(getNoiseValue(
                (baseX / CHUNK) + dx,
                (baseY / CHUNK) + dy,
                (baseZ / CHUNK) + dz
            ));
        }
    }
}

for (let x = 0; x < CHUNK; x++) {
    for (let z = 0; z < CHUNK; z++) {
        const threshold = biomeA.threshold * (1 - edgeFactor) + biomeB.threshold * edgeFactor;
        const shape = biomeA.shape * (1 - edgeFactor) + biomeB.shape * edgeFactor;

        let fillStart = null;
        let lastY = null;

        for (let y = 0; y < CHUNK; y++) {
            let value = trilinearInterpolate(
                x, y, z,
                coarse[0], coarse[4], coarse[2], coarse[6],
                coarse[1], coarse[5], coarse[3], coarse[7]
            );
            value += shape + (Math.random() - 0.5) * 0.05;
            const wx = baseX + x;
            const wy = baseY + y;
            const wz = baseZ + z;
            if (value < threshold) {
                if (fillStart === null) {
                    fillStart = wy;
                    lastY = wy;
                } else {
                    lastY = wy;
                }
                if (Math.random() < oreChance) {
                    const dir = DIRECTIONS[Math.floor(Math.random() * DIRECTIONS.length)];
                    const nx = x + dir[0];
                    const ny = y + dir[1];
                    const nz = z + dir[2];
                    if (nx >= 0 && nx < CHUNK && ny >= 0 && ny < CHUNK && nz >= 0 && nz < CHUNK) {
                        let neighborValue = trilinearInterpolate(
                            nx, ny, nz,
                            coarse[0], coarse[4], coarse[2], coarse[6],
                            coarse[1], coarse[5], coarse[3], coarse[7]
                        );
                        neighborValue += shape + (Math.random() - 0.5) * 0.05;
                    }
                }

            } else {
                if (fillStart !== null) {
                    dim.runCommand(`fill ${wx} ${fillStart} ${wz} ${wx} ${lastY} ${wz} air`);
                    fillStart = null;
                }
            }
        }
        if (fillStart !== null) {
            dim.runCommand(`fill ${baseX + x} ${fillStart} ${baseZ + z} ${baseX + x} ${lastY} ${baseZ + z} air`);
            fillStart = null;
        }
    }
}