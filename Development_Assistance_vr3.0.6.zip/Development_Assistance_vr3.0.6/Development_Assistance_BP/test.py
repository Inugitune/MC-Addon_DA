#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
find_mc_world_noarg_v2.py
改良版: .log に余計な情報や制御文字が混ざっていても
'DA_world_UUID' の直後にある UUID を安全に抽出して比較します。

使い方:
  - ファイル上部の TARGET_UUID と BASE_DIR を編集して実行してください。
  - 環境変数で一時的に上書きすることも可能:
      MC_TARGET_UUID, MC_BASE_DIR
"""

import os
import re
import sys

# -----------------------------
# 設定 (ここを編集する)
# -----------------------------
TARGET_UUID = "e9740e97-d1df-4c0c-91a6-6bf79acf818e"  # 例: "e9740e97-d1df-4c0c-91a6-6bf79acf818e"
BASE_DIR = None   # 省略すると既定の Windows パスを使用

# 環境変数で上書き（任意）
TARGET_UUID = os.environ.get("MC_TARGET_UUID", TARGET_UUID) or ""
BASE_DIR = os.environ.get("MC_BASE_DIR", BASE_DIR) or BASE_DIR
# -----------------------------

# 正規表現
UUID_RE = re.compile(
    r'([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})'
)
# 'DA_world_UUID' を見つける（$や空白や記号が入る場合も考慮）
DA_WORLD_RE = re.compile(r'DA_world_UUID', re.IGNORECASE)

# 'DA:' プレフィックスのケース（フォールバック）
DA_COLON_RE = re.compile(r'DA:?\s*' + UUID_RE.pattern, re.IGNORECASE)

def default_minecraft_worlds_path():
    userprofile = os.environ.get("USERPROFILE") or os.path.expanduser("~")
    parts = [
        userprofile, "AppData", "Local", "Packages",
        "Microsoft.MinecraftUWP_8wekyb3d8bbwe", "LocalState",
        "games", "com.mojang", "minecraftWorlds"
    ]
    return os.path.join(*parts)

def extract_uuid_after_da_world(text):
    """
    text 中の 'DA_world_UUID' の出現位置毎に、その直後に最初に現れる UUID を返す。
    見つからなければ None。
    （複数見つかればリストで返す）
    """
    uuids = []
    for m in DA_WORLD_RE.finditer(text):
        start = m.end()
        # DA_world_UUID の後ろのテキストを取り、その中から最初の UUID を探す
        tail = text[start:start+200]  # 余裕を持って先頭200文字を調べる
        mm = UUID_RE.search(tail)
        if mm:
            uuids.append(mm.group(1))
        else:
            # 200文字以内に無ければ、テキスト全体の m.end() 以降をもう一度探す（安全策）
            mm2 = UUID_RE.search(text, pos=start)
            if mm2:
                uuids.append(mm2.group(1))
    return uuids

def extract_da_colon_fallback(text):
    """
    'DA:' のような箇所から UUID を抽出（フォールバック）
    複数見つかる可能性があるのでリストで返す
    """
    found = []
    for m in DA_COLON_RE.finditer(text):
        # UUID は group(1)
        found.append(m.group(1))
    return found

def find_worlds_by_uuid(target_uuid, base_dir=None):
    if not target_uuid:
        raise ValueError("TARGET_UUID が空です。")
    target_uuid = target_uuid.strip().lower()
    if base_dir is None:
        base_dir = default_minecraft_worlds_path()

    results = []
    if not os.path.isdir(base_dir):
        raise FileNotFoundError(f"minecraftWorlds フォルダが見つかりません: {base_dir}")

    for world_name in os.listdir(base_dir):
        world_dir = os.path.join(base_dir, world_name)
        if not os.path.isdir(world_dir):
            continue
        db_dir = os.path.join(world_dir, "db")
        if not os.path.isdir(db_dir):
            continue

        for fname in os.listdir(db_dir):
            if not fname.lower().endswith(".log"):
                continue
            log_path = os.path.join(db_dir, fname)
            try:
                with open(log_path, "rb") as f:
                    raw = f.read()
                # 文字化けや制御文字を無視してテキスト化
                text = raw.decode("utf-8", errors="ignore")
            except Exception as e:
                results.append({
                    "world_folder": world_dir,
                    "log_file": log_path,
                    "error": f"read error: {e}",
                })
                continue

            matched_uuid = None
            method = None

            # まず DA_world_UUID に続く UUID を試みる
            uuids_after_da = extract_uuid_after_da_world(text)
            if uuids_after_da:
                # 先に見つかったものから比較
                for u in uuids_after_da:
                    if u and u.strip():
                        if u.lower() == target_uuid:
                            matched_uuid = u
                            method = "DA_world_UUID"
                            break
                # もし一致しなかったが見つかった UUID を記録しておく（デバッグ用）
                if matched_uuid is None:
                    found_one = uuids_after_da[0]
                else:
                    found_one = matched_uuid
            else:
                found_one = None

            # フォールバック: DA:xxxx の形で UUID があればそれも調べる
            if matched_uuid is None:
                da_colon_list = extract_da_colon_fallback(text)
                if da_colon_list:
                    for u in da_colon_list:
                        if u and u.strip():
                            if u.lower() == target_uuid:
                                matched_uuid = u
                                method = "DA: fallback"
                                break
                    if matched_uuid is None and not found_one:
                        # 見つかった最初のものをメモとして保持
                        found_one = da_colon_list[0]

            results.append({
                "world_folder": world_dir,
                "log_file": log_path,
                "found_uuid": found_one,
                "matched": bool(matched_uuid),
                "match_method": method,
            })

            # 一致したら levelname.txt を読みに行く（そのワールド分だけ）
            if matched_uuid:
                levelname_path = os.path.join(world_dir, "levelname.txt")
                if os.path.isfile(levelname_path):
                    try:
                        with open(levelname_path, "r", encoding="utf-8", errors="ignore") as lf:
                            levelname = lf.read().strip()
                    except Exception as e:
                        levelname = f"<error reading levelname.txt: {e}>"
                else:
                    levelname = None
                results[-1]["levelname"] = levelname
    return results

def main():
    world_name = None
    if not TARGET_UUID:
        print("ERROR: TARGET_UUID が設定されていません。ファイル上部の TARGET_UUID を設定してください。")
        sys.exit(1)

    try:
        hits = find_worlds_by_uuid(TARGET_UUID, base_dir=BASE_DIR)
    except FileNotFoundError as e:
        print("ERROR:", e)
        sys.exit(1)
    except ValueError as e:
        print("ERROR:", e)
        sys.exit(1)

    if not hits:
        print("一致する DA_world_UUID は見つかりませんでした。")
        return

    for entry in hits:
        print("-" * 70)
        print("world_folder:", entry.get("world_folder"))
        print("log_file   :", entry.get("log_file"))
        if "error" in entry:
            print("note       :", entry["error"])
            continue
        print("found_uuid :", entry.get("found_uuid"))
        print("matched    :", entry.get("matched"))
        if entry.get("matched"):
            print("match_method:", entry.get("match_method"))
            lvl = entry.get("levelname")
            if lvl is None:
                print("levelname.txt: (存在しないか読み取れません)")
            else:
                print("levelname.txt content:")
                print(lvl)
                world_name = lvl

        else:
            print("note: 指定 UUID と一致しません（ログ中に見つかった UUID を表示しています）")
    print("-" * 70)
    print(world_name)

if __name__ == "__main__":
    main()