function readUint32BE(datav, offset) { return (datav.getUint8(offset) << 24) | (datav.getUint8(offset + 1) << 16) | (datav.getUint8(offset + 2) << 8) | datav.getUint8(offset + 3); }
function readUint16BE(datav, offset) { return (datav.getUint8(offset) << 8) | datav.getUint8(offset + 1); }
function readVarLen(datav, off) {
    let value = 0, i = 0, b;
    do {
        b = datav.getUint8(off + i);
        value = (value << 7) | (b & 0x7F);
        i++;
    } while (b & 0x80);
    return { value, bytes: i };
}

// GMプログラム番号 → Minecraft音ブロックに近い音にマップ
function mapProgramToInstrument(prog, channel, note) {
    if (channel === 9) { // MIDIはCh.10=ドラム
        // ノート番号で分岐
        if ([35, 36].includes(note)) return "bd";        // Bass Drum
        if ([38, 40].includes(note)) return "snare";     // Snare
        if ([42, 44, 46].includes(note)) return "hat";   // Hi-hat
        if ([41, 43, 45, 47].includes(note)) return "bassattack"; // Toms →近似
        if ([49, 57].includes(note)) return "bell";      // Crash / Cymbal
        if ([56].includes(note)) return "cow_bell";      // Cowbell
        return "pling"; // fallback
    }

    // メロディ楽器
    if (prog >= 0 && prog <= 7) return "harp";          // Piano → harp
    if (prog >= 24 && prog <= 31) return "guitar";      // Guitar
    if (prog === 105) return "banjo";                   // Banjo
    if (prog >= 73 && prog <= 80) return "flute";       // Flute, Piccolo, Recorder
    if (prog === 112) return "bit";                     // Tinkle Bell → bit
    if (prog === 11) return "chime";                    // Vibraphone → chime
    if (prog === 13) return "xylophone";                // Xylophone
    if (prog === 14) return "bell";                     // Tubular Bells
    if (prog === 118) return "didgeridoo";              // Shanai → Didgeridoo

    return "pling"; // デフォルト
}

function parseMIDI(arrayBuffer) {
    const datav = new DataView(arrayBuffer);
    let ptr = 0;
    const headerSig = String.fromCharCode(...new Uint8Array(arrayBuffer.slice(0, 4)));
    if (headerSig !== 'MThd') throw new Error('Not a standard MIDI file (no MThd).');

    const headerLen = readUint32BE(datav, 4);
    const format = readUint16BE(datav, 8);
    const ntrks = readUint16BE(datav, 10);
    const division = readUint16BE(datav, 12);
    ptr = 8 + headerLen;
    let ticksPerQuarter = division;
    let events = [];
    let tempos = [{ ticks: 0, tempo: 500000 }];

    let channelPrograms = new Array(16).fill(0); // 各チャンネルのプログラム番号を保持

    for (let t = 0; t < ntrks; t++) {
        const chunk = String.fromCharCode(...new Uint8Array(arrayBuffer.slice(ptr, ptr + 4)));
        if (chunk !== 'MTrk') throw new Error('Expected MTrk chunk but got ' + chunk);
        const trackLen = readUint32BE(datav, ptr + 4);
        let off = ptr + 8;
        const end = off + trackLen;
        let absTicks = 0;
        let lastStatus = null;
        while (off < end) {
            const vl = readVarLen(datav, off);
            absTicks += vl.value;
            off += vl.bytes;
            let status = datav.getUint8(off);
            if (status < 0x80) {
                if (lastStatus === null) throw new Error('Running status without prior status');
                status = lastStatus;
            } else {
                off++;
                lastStatus = status;
            }
            if (status === 0xFF) {
                const metaType = datav.getUint8(off); off++;
                const lenobj = readVarLen(datav, off);
                const mlen = lenobj.value; off += lenobj.bytes;
                if (metaType === 0x51 && mlen === 3) {
                    const tempo = (datav.getUint8(off) << 16) | (datav.getUint8(off + 1) << 8) | (datav.getUint8(off + 2));
                    tempos.push({ ticks: absTicks, tempo });
                }
                off += mlen;
            } else if (status === 0xF0 || status === 0xF7) {
                const lenobj = readVarLen(datav, off);
                off += lenobj.bytes + lenobj.value;
            } else {
                const hi = status & 0xF0;
                const channel = status & 0x0F;
                if (hi === 0x80 || hi === 0x90) {
                    const d1 = datav.getUint8(off); const d2 = datav.getUint8(off + 1); off += 2;
                    if (hi === 0x90) {
                        if (d2 !== 0) {
                            // NOTE: include both program number (programId) and mapped instrument string
                            const programId = channelPrograms[channel]; // 0-127; for drums we'll mark later by channel
                            const instStr = mapProgramToInstrument(programId, channel, d1);
                            events.push({
                                ticks: absTicks,
                                type: 'noteOn',
                                note: d1,
                                velocity: d2,
                                channel,
                                program: programId,
                                instrumentName: instStr
                            });
                        } else {
                            events.push({ ticks: absTicks, type: 'noteOff', note: d1, velocity: d2, channel });
                        }
                    } else if (hi === 0x80) {
                        events.push({ ticks: absTicks, type: 'noteOff', note: d1, velocity: d2, channel });
                    }
                } else if (hi === 0xC0) { // Program Change
                    const prog = datav.getUint8(off); off += 1;
                    channelPrograms[channel] = prog;
                } else if (hi === 0xD0) {
                    off += 1;
                } else if (hi === 0xA0 || hi === 0xB0 || hi === 0xE0) {
                    off += 2;
                }
            }
        }
        ptr = end;
    }

    tempos.sort((a, b) => a.ticks - b.ticks);
    events.sort((a, b) => a.ticks - b.ticks);

    let curTempoIndex = 0;
    let prevTicks = 0;
    let curTime = 0;
    for (let i = 0; i < events.length; i++) {
        const e = events[i];
        while (curTempoIndex + 1 < tempos.length && tempos[curTempoIndex + 1].ticks <= e.ticks) {
            const nextTempo = tempos[curTempoIndex + 1];
            const dtTicks = nextTempo.ticks - prevTicks;
            curTime += dtTicks * (tempos[curTempoIndex].tempo / 1e6) / ticksPerQuarter;
            prevTicks = nextTempo.ticks;
            curTempoIndex++;
        }
        const dtTicks = e.ticks - prevTicks;
        const dtSeconds = dtTicks * (tempos[curTempoIndex].tempo / 1e6) / ticksPerQuarter;
        const eventTime = curTime + dtSeconds;
        prevTicks = e.ticks;
        curTime = eventTime;
        e.time = eventTime;
    }

    return { events, ticksPerQuarter, tempos };
}

const fileInput = document.getElementById('file');
const parseBtn = document.getElementById('parseBtn');
const statsDiv = document.getElementById('stats');
const visualToggle = document.getElementById('visualToggle');
const canvas = document.getElementById('pianoRoll');
const ctx = canvas.getContext('2d');

let midiDataGlobal = null;

function noteToFreq(n) { return 440 * Math.pow(2, (n - 69) / 12); }

function schedulePlayback(midiData) {
    // events already carry 'program' (number) and 'instrumentName'
    const events = midiData.events.filter(e => e.type === 'noteOn' || e.type === 'noteOff');
    const notes = [];
    for (let i = 0; i < events.length; i++) {
        const e = events[i];
        if (e.type === 'noteOn') {
            let endTime = null;
            for (let j = i + 1; j < events.length; j++) {
                const f = events[j];
                if (f.type === 'noteOff' && f.note === e.note && f.channel === e.channel) {
                    endTime = f.time; break;
                }
            }
            if (endTime === null) endTime = e.time + 0.5;
            let start = e.time;
            let dur = Math.max(0.02, endTime - start);

            // Build instrument id to encode:
            // if channel 9 (MIDI ch10) => use 128 to mark drum channel
            // otherwise store actual program number (0-127)
            const instrumentId = (e.channel === 9) ? 128 : (typeof e.program === 'number' ? e.program : 0);
            // also keep instrumentName for UI/visual if desired
            const instrumentName = e.instrumentName || mapProgramToInstrument(instrumentId, e.channel, e.note);

            notes.push({
                note: e.note,
                start,
                dur,
                velocity: e.velocity,
                instrument: instrumentId,
                instrumentName
            });
        }
    }

    midiDataGlobal = { notes, startTime: 0, endTime: 0 };
    if (notes.length) {
        midiDataGlobal.startTime = Math.min(...notes.map(n => n.start));
        midiDataGlobal.endTime = Math.max(...notes.map(n => n.start + n.dur));
    } else {
        midiDataGlobal.startTime = 0; midiDataGlobal.endTime = 1;
    }
    drawPianoRoll();
    const noteCount = notes.length;
    const uniqueNotes = new Set(notes.map(n => n.note)).size;
    const longest = notes.reduce((a, b) => a.dur > b.dur ? a : b, { dur: 0 });
    statsDiv.innerHTML = `ノート数: <b>${noteCount}</b> / 異なる音程数: <b>${uniqueNotes}</b> / 最長音長: <b>${(longest.dur || 0).toFixed(3)}s</b>`;
}

function resizeCanvas() {
    const dpr = window.devicePixelRatio || 1;
    canvas.width = canvas.clientWidth * dpr;
    canvas.height = canvas.clientHeight * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    drawPianoRoll();
}
window.addEventListener('resize', resizeCanvas);
visualToggle.addEventListener('change', () => drawPianoRoll());

function drawPianoRoll() {
    if (!visualToggle.checked) { ctx.clearRect(0, 0, canvas.width, canvas.height); return; }
    const w = canvas.clientWidth, h = canvas.clientHeight;
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = '#000036';
    ctx.fillRect(0, 0, w, h);

    if (!midiDataGlobal || midiDataGlobal.notes.length === 0) {
        ctx.fillStyle = '#999';
        ctx.font = '14px sans-serif';
        ctx.fillText('MIDI ファイルを読み込んで「解析して再生」を押してください。', 12, 28);
        return;
    }

    const notes = midiDataGlobal.notes;
    const start = midiDataGlobal.startTime;
    const end = midiDataGlobal.endTime;
    const duration = Math.max(0.001, end - start);

    const minNote = Math.min(...notes.map(n => n.note), 21);
    const maxNote = Math.max(...notes.map(n => n.note), 108);
    const pad = 10;
    const usableH = h - pad * 2;
    const usableW = w - 40;

    ctx.strokeStyle = 'rgba(255,255,255,0.06)';
    ctx.lineWidth = 1;
    const timeTicks = Math.ceil(duration / 0.5);
    for (let i = 0; i <= timeTicks; i++) {
        const x = 40 + (i / timeTicks) * usableW;
        ctx.beginPath(); ctx.moveTo(x, pad); ctx.lineTo(x, pad + usableH); ctx.stroke();
        ctx.fillStyle = 'rgba(255,255,255,0.12)';
        ctx.font = '10px sans-serif';
        ctx.fillText((start + i * (duration / timeTicks)).toFixed(2) + 's', x + 2, h - 4);
    }

    for (const n of notes) {
        const x = 40 + ((n.start - start) / duration) * usableW;
        const wRect = Math.max(2, (n.dur / duration) * usableW);
        const y = pad + ((maxNote - n.note) / (maxNote - minNote + 1)) * usableH;
        const hRect = Math.max(4, usableH / (maxNote - minNote + 1));
        const hue = Math.round(((n.note - minNote) / (maxNote - minNote + 1)) * 240);
        ctx.fillStyle = `hsla(${hue},70%,60%,0.95)`;
        ctx.fillRect(x, y, wRect, hRect - 1);
    }

    ctx.fillStyle = '#ddd';
    ctx.font = '12px sans-serif';
    for (let p = minNote; p <= maxNote; p += Math.max(1, Math.floor((maxNote - minNote) / 8))) {
        const y = pad + ((maxNote - p) / (maxNote - minNote + 1)) * usableH;
        ctx.fillText(p, 6, y + 10);
    }
}

parseBtn.addEventListener('click', async () => {
    const f = fileInput.files[0];
    if (!f) { alert('まず MIDI ファイルを選んでください'); return; }

    const ab = await f.arrayBuffer();
    let parsed;
    try {
        parsed = parseMIDI(ab);
    } catch (err) {
        alert('MIDI 解析エラー: ' + err.message);
        console.error(err);
        return;
    }
    schedulePlayback(parsed);

    // helper functions (kept local here)
    function writeVarUintToArray(val, arr) {
        while (true) {
            let byte = val & 0x7F;
            val >>>= 7;
            if (val !== 0) {
                arr.push(byte | 0x80);
            } else {
                arr.push(byte);
                break;
            }
        }
    }
    function readVarUintFromU8(u8, ptrObj) {
        let result = 0, shift = 0, b;
        let ptr = ptrObj.ptr;
        do {
            b = u8[ptr++];
            result |= (b & 0x7F) << shift;
            shift += 7;
        } while (b & 0x80);
        ptrObj.ptr = ptr;
        return result;
    }
    function uint8ToBase64(u8) {
        const CHUNK = 0x8000;
        let parts = [];
        for (let i = 0; i < u8.length; i += CHUNK) {
            const slice = u8.subarray(i, Math.min(i + CHUNK, u8.length));
            parts.push(String.fromCharCode.apply(null, slice));
        }
        return btoa(parts.join(''));
    }
    function base64ToUint8(s) {
        const bin = atob(s);
        const u8 = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
        return u8;
    }

    // compress: include instrument id byte (0-127 program, 128 for drum channel)
    function compressNotesWithStartToBase64(notes, options = {}) {
        const resolutionMs = options.resolutionMs || 10;
        if (!notes || notes.length === 0) return { base64: '', resolutionMs };
        const arr = notes.slice().sort((a, b) => a.start - b.start);
        const msArray = arr.map(n => Math.round((n.start || 0) * 1000 / resolutionMs));
        const out = [];
        let prev = 0;
        for (let i = 0; i < arr.length; i++) {
            const cur = msArray[i];
            const delta = (i === 0) ? cur : (cur - prev);
            writeVarUintToArray(delta, out);
            out.push((arr[i].note & 0x7F));
            out.push(((arr[i].velocity || 0) & 0x7F));
            // instrument: store 1 byte. we use 128 as drum-channel marker.
            out.push((arr[i].instrument || 0) & 0xFF);
            prev = cur;
        }
        const u8 = new Uint8Array(out);
        const b64 = uint8ToBase64(u8);
        return { base64: b64, resolutionMs };
    }

    const notes = midiDataGlobal.notes;
    const compressed = compressNotesWithStartToBase64(notes, { resolutionMs: 10 });
    document.querySelector('textarea').value = (`/da:d_midi "${compressed.base64}"`);
});

window.addEventListener('load', resizeCanvas);
