import os
import re
import asyncio
import json
import uuid
import websockets
from websockets.exceptions import ConnectionClosedOK, ConnectionClosedError, ConnectionClosed
import discord
from discord.ext import commands
from datetime import datetime, timedelta
import socket
import sys
import hashlib
import platform
import subprocess
import random
import time
import signal
from openai import OpenAI
from pathlib import Path
import zipfile
import shutil
import functools
world_name = None
world_UUID = None
world_path = None
Last_backup = None
AI_TYPE = None
AI_API = None
TOKEN = ""
PREFIX = "!"
CHANNEL_FILE = "connected_channels.json"
HOST = "127.0.0.1"
PORT = 6752
HOST_AI = "192.168.0.209"
PORT_AI = 6753
gpt_model = ""
ws_server = None
MC_ws = None
bot = None
bot_task = None
connected_channels = {}
re_end = {}
re_end_order = {
    "num":0
}
back_up = {
    "valid":False,
    "Interval":0
}
def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        try:
            return socket.gethostbyname(socket.gethostname())
        except Exception:
            return "127.0.0.1"

_local_ip = get_local_ip()
# SECRET_TOKEN = hashlib.sha256(_local_ip.encode("utf-8")).hexdigest()
SECRET_TOKEN = "2c445db3-12a6-4736-b04a-bd5ef9e9a3f2"

print(json.dumps({"type":"status","msg":"core_starting","secret_token":SECRET_TOKEN,"local_ip":_local_ip}), flush=True)
import logging
logger = logging.getLogger(__name__)
def ask_question(question: str,ws, loop):
    payload = f"TOKEN:{SECRET_TOKEN}\n{question}"
    async def send_aq(text):
        try:
            cmd = make_command_request(
                'tellraw @a {"rawtext":[{"text":"' + f'{text}' + '"}]}'
            )
            await ws.send(json.dumps(cmd, ensure_ascii=False))
        except Exception as e:
            print("[CONSOLE] send failed:", e)
    if AI_TYPE == "gpt":
        client = OpenAI(
            api_key=AI_API
        )

        response = client.responses.create(
        model=f"gpt-5{gpt_model}",
        input=f"{question}",
        store=True,
        )
        return response.output_text
    if AI_TYPE == "local":
        with socket.create_connection((_local_ip, 6753), timeout=10) as s:
            s.sendall(payload.encode("utf-8"))
            s.settimeout(300)
            response = ""
            while True:
                chunk = s.recv(1024)
                if not chunk:
                    break
                text = chunk.decode("utf-8", errors="replace")
                if "===END===" in text:
                    response = text.replace("===END===", "")
                    break
                asyncio.run_coroutine_threadsafe(send_aq(text), loop)
                response = text
                print("\r" + text, end="", flush=True)
            return response
    if AI_TYPE == "custom":
        try:
            with socket.create_connection((HOST_AI, PORT_AI), timeout=10) as s:
                s.sendall(payload.encode("utf-8"))
                s.settimeout(300)
                response = ""
                while True:
                    chunk = s.recv(1024)
                    if not chunk:
                        break
                    text = chunk.decode("utf-8", errors="replace")
                    if "===END===" in text:
                        response = text.replace("===END===", "")
                        break
                    asyncio.run_coroutine_threadsafe(send_aq(text), loop)
                    response = text
                    print("\r" + text, end="", flush=True)
                return response
        except ConnectionRefusedError:
            logger.error("Cannot connect to local server %s:%d (Connection refused).", HOST_AI, PORT_AI)
            try:
                send_to_ui({"type":"error","msg":"cannot_connect_local_ai","detail":f"{HOST_AI}:{PORT_AI}"})
            except Exception:
                pass
            return None
        except socket.timeout:
            logger.error("Timeout while connecting to %s:%d", HOST_AI, PORT_AI)
            try:
                send_to_ui({"type":"error","msg":"timeout_connect_local_ai","detail":f"{HOST_AI}:{PORT_AI}"})
            except Exception:
                pass
            return None
        except Exception as e:
            logger.exception("Unexpected socket error connecting to %s:%d: %s", HOST_AI, PORT_AI, e)
            try:
                send_to_ui({"type":"error","msg":"socket_error","detail":str(e)})
            except Exception:
                pass
            return None
    if AI_TYPE == "other":
        with socket.create_connection((HOST_AI, PORT_AI), timeout=10) as s:
            s.sendall(payload.encode("utf-8"))
            s.settimeout(300)
            response = ""
            while True:
                chunk = s.recv(1024)
                if not chunk:
                    break
                text = chunk.decode("utf-8", errors="replace")
                if "===END===" in text:
                    response = text.replace("===END===", "")
                    break
                asyncio.run_coroutine_threadsafe(send_aq(text), loop)
                response = text
                print("\r" + text, end="", flush=True)
            return response
    if AI_TYPE == None:
        return "zzz(椛は寝ているようだ)\n§8鯖主へ:AIを起動できていません。"


def append_json_log(file_path: str, data: dict, max_size_mb: int = 32, trim_ratio: float = 0.1):
    line = json.dumps(data, ensure_ascii=False)
    with open(file_path, "a", encoding="utf-8") as f:
        f.write(line + "\n")
    if os.path.getsize(file_path) > max_size_mb * 1024 * 1024:
        shrink_file(file_path, trim_ratio)

def shrink_file(file_path: str, trim_ratio: float):
    tmp_path = file_path + ".tmp"
    with open(file_path, "r", encoding="utf-8") as f:
        lines = f.readlines()
    trim_count = int(len(lines) * trim_ratio)
    keep_lines = lines[trim_count:]
    with open(tmp_path, "w", encoding="utf-8") as f:
        f.writelines(keep_lines)
    os.replace(tmp_path, file_path)
def safe_print(*args, **kwargs):
    try:
        print(*args, **kwargs)
    except UnicodeEncodeError:
        enc = (getattr(sys.stdout, "encoding", None) or "cp932")
        out = []
        for a in args:
            s = str(a)
            try:
                s = s.encode(enc, errors="replace").decode(enc, errors="ignore")
            except Exception:
                s = s.encode("ascii", "backslashreplace").decode("ascii")
            out.append(s)
        print(*out, **kwargs)

async def _on_ready():
    print(f"[Discord] Bot logged in as {bot.user} (id={bot.user.id})", flush=True)
    send_to_ui({"type":"status","msg":"Success_discord_bot_start"})

async def _on_message(message: discord.Message):
    global connected_channels
    if message.author == bot.user:
        return
    channel_id = None
    try:
        channel_id = connected_channels.get(TOKEN)
        if channel_id is not None:
            channel_id = int(channel_id)
    except Exception:
        channel_id = None

    if channel_id is not None and getattr(message.channel, "id", None) == channel_id:
        mc_txt = message.content
        if message.attachments:
            for attach in message.attachments:
                if getattr(attach, "content_type", None):
                    if "image" in attach.content_type:
                        mc_txt = "§3【画像】"
                    elif "video" in attach.content_type:
                        mc_txt = "§3【動画】"
        for ws in list(state.clients):
            try:
                if str(message.content).startswith("/d ") and (message.guild and message.guild.owner_id == message.author.id):
                    cmd = make_command_request(str(message.content)[3::])
                    await ws.send(json.dumps(cmd, ensure_ascii=False))
                    cmd = make_command_request('tellraw @a {"rawtext":[{"text":"[§bDiscord§r] ' + f'§7{message.author.display_name}§7 >>> /' + str(message.content)[3::] + '"}]}')
                    await ws.send(json.dumps(cmd, ensure_ascii=False))
                else:
                    cmd = make_command_request('tellraw @a {"rawtext":[{"text":"[§bDiscord§r] ' + f'<{message.author.display_name}> ' + mc_txt + '"}]}')
                    await ws.send(json.dumps(cmd, ensure_ascii=False))
            except Exception as e:
                print("[CONSOLE] send failed:", e, flush=True)
        print("[>] Sent command to clients:", flush=True)

    if str(message.content).strip() == f"{PREFIX}DAconnect":
        channel_id = message.channel.id
        connected_channels[TOKEN] = channel_id
        with open(CHANNEL_FILE, "w", encoding="utf-8") as f:
            json.dump(connected_channels, f)
        await message.channel.send("このチャンネルを接続先として登録しました！")
        return

    try:
        await bot.process_commands(message)
    except Exception:
        pass

ws_data_id = "259ad143"
async def start_bot_safely():
    global bot,connected_channels,bot_task,connected_channels
    intents = discord.Intents.default()
    intents.message_content = True
    intents.messages = True
    intents.guilds = True
    bot = commands.Bot(command_prefix="!",intents=intents)
    bot.add_listener(_on_ready, "on_ready")
    bot.add_listener(_on_message, "on_message")
    try:
        with open(CHANNEL_FILE, "r", encoding="utf-8") as f:
            connected_channels = json.load(f)
    except FileNotFoundError:
        connected_channels = {}
    print(connected_channels)
    try:
        listeners = bot._listeners
        print("=== bot._listeners keys ===", list(listeners.keys()), flush=True)
        if "on_message" in listeners:
            print("on_message handlers:", [getattr(f, "__name__", repr(f)) for f in listeners["on_message"]], flush=True)
        else:
            print("no on_message key in bot._listeners", flush=True)
    except Exception as e:
        print("failed to inspect bot._listeners:", e, flush=True)
    try:
        await bot.start(TOKEN)
    except discord.LoginFailure as e:
        send_to_ui({"type":"error","error":"invalid_discord_token","reason": str(e)})
        print("[Discord] LoginFailure: Invalid bot token. Please check TOKEN.", flush=True)
    except discord.HTTPException as e:
        send_to_ui({"type":"error","error":"discord_http_exception","reason": str(e)})
        print(f"[Discord] HTTPException while starting bot: {e}", flush=True)
    except Exception as e:
        send_to_ui({"type":"error","error":"discord_start_failed","reason": str(e)})
        print(f"[Discord] Failed to start bot: {e}", flush=True)

async def send_to_connected(message_text: str):
    global connected_channels
    if not connected_channels.get(TOKEN):
        print("[Discord] 接続チャンネルは登録されていません。")
        return
    channel_id = connected_channels[TOKEN]
    channel = bot.get_channel(channel_id)
    if channel is None:
        try:
            channel = await bot.fetch_channel(channel_id)
        except Exception as e:
            print(f"[Discord] チャンネル {channel_id} を取得できませんでした: {e}")
            return
    try:
        await channel.send(message_text)
    except Exception as e:
        print(f"[Discord] 送信エラー: {e}")

async def embed_to_connected(
    message_text: str,
    title: str | None = None,
    color: discord.Color | None = None
):
    global connected_channels
    if not connected_channels.get(TOKEN):
        print("[Discord] 接続チャンネルは登録されていません。")
        return
    channel_id = connected_channels[TOKEN]
    channel = bot.get_channel(channel_id)
    if channel is None:
        try:
            channel = await bot.fetch_channel(channel_id)
        except Exception as e:
            print(f"[Discord] チャンネル {channel_id} を取得できませんでした: {e}")
            return
    try:
        if title:
            embed = discord.Embed(
                description=message_text,
                title=title,
                color=color or discord.Color.blue()
            )
        else:
            embed = discord.Embed(
                description=message_text,
                color=color or discord.Color.blue()
            )
        await channel.send(embed=embed)
    except Exception as e:
        print(f"[Discord] 送信エラー: {e}")

def make_command_request(command: str, origin_type: str = "player"):
    return {
        "header": {
            "version": 1,
            "requestId": str(uuid.uuid4()),
            "messageType": "commandRequest",
            "messagePurpose": "commandRequest"
        },
        "body": {
            "version": 1,
            "commandLine": command,
            "origin": {"type": origin_type}
        }
    }

def make_subscribe_event(event_name: str):
    return {
        "header": {
            "version": 1,
            "requestId": str(uuid.uuid4()),
            "messageType": "commandRequest",
            "messagePurpose": "subscribe"
        },
        "body": {"eventName": event_name}
    }

class ServerState:
    def __init__(self):
        self.clients = set()

state = ServerState()

async def ping_loop(ws):
    try:
        while True:
            await asyncio.sleep(10)
            try:
                pong_waiter = await ws.ping()
                await asyncio.wait_for(pong_waiter, timeout=5)
            except Exception:
                return
    except asyncio.CancelledError:
        return

async def handler(ws, path):
    global ws_data_id,world_UUID,world_name,world_path
    peer = ws.remote_address
    print(f"[WS] 接続: {peer} path={path}")
    print("[WS] Sec-WebSocket-Protocol:", ws.subprotocol)
    try:
        headers = ws.request_headers
    except Exception:
        headers = None
    print("[WS] request_headers:", headers)

    ping_task = None

    async def process_raw_string(raw):
        global ws_data_id,world_UUID,world_name,world_path
        try:
            msg = json.loads(raw)
        except Exception:
            print("[<] raw (non-json):", raw)
            return
        header = msg.get("header", {})
        purpose = header.get("messagePurpose") or header.get("messageType")
        if purpose == "event":
            body = msg.get("body", {}) or {}
            event_name = header.get("eventName") or body.get("eventName") or ""
        elif purpose == "commandResponse":
            if "body" in msg and "statusMessage" in msg["body"]:
                if((msg["body"]["statusMessage"]).startswith("DA_wsd")):
                    ws_data_id = (str(msg["body"]["statusMessage"])[len("DA_wsd"):]).split(":",2)[0]
                    if world_UUID != (str(msg["body"]["statusMessage"])[len("DA_wsd"):]).split(":",2)[1]:
                        print(str(msg["body"]["statusMessage"])[len("DA_wsd"):])
                        world_UUID = (str(msg["body"]["statusMessage"])[len("DA_wsd"):]).split(":",2)[1]
                        this_world = search_world_name(world_UUID)
                        world_name = this_world.get("name")
                        world_path = this_world.get("path")
                        print(f"Now_connect:{world_name} as {world_path}")
                    ws_data = json.loads((str(msg["body"]["statusMessage"])[len("DA_wsd"):]).split(":",2)[2])
                    for i in range(len(ws_data)):
                        if ws_data[i]["id"] == "place" or ws_data[i]["id"] == "break" or ws_data[i]["id"] == "change":
                            print(ws_data[i])
                            append_json_log("player_place_break_log.txt",(ws_data[i]))
                        elif ws_data[i]["id"] == "chat":
                            player_name = ws_data[i]["player"]["name"]
                            chat_msg = ws_data[i]["msg"]
                            try:
                                await send_to_connected(f"<{player_name}> {chat_msg}")
                            except Exception as e:
                                print("[Discord] send_to_connected error:", e)
                        elif ws_data[i]["id"] == "leave" or ws_data[i]["id"] == "join":
                            player_name = ws_data[i]["player"]["name"]
                            dt = datetime.fromtimestamp(int(ws_data[i]["time"]) / 1000)
                            hour = dt.hour
                            minute = dt.minute
                            try:
                                if ws_data[i]["id"] == "join":
                                    await embed_to_connected(f"[+] Join {hour}時{minute}分 {player_name}",None,discord.Color.green())
                                else:
                                    await embed_to_connected(f"[-] Leave {hour}時{minute}分 {player_name}",None,discord.Color.red())
                            except Exception as e:
                                print("[Discord] send_to_connected error:", e)
                        elif ws_data[i]["id"] == "momiji":
                            async def handle_message(ws, ws_data):
                                print("=================")
                                print(ws_data)

                                loop = asyncio.get_running_loop()
                                final_answer = await loop.run_in_executor(None, ask_question, str(ws_data["msg"]), ws, loop)
                                print("===final_answer===")
                                print(final_answer)
                                try:
                                    cmd = make_command_request(
                                        'tellraw @a {"rawtext":[{"text":"' + f'§6<§f椛§6>§r {final_answer}' + '"}]}'
                                    )
                                    await ws.send(json.dumps(cmd, ensure_ascii=False))

                                    cmd = make_command_request("scriptevent da:momiji_answered")
                                    await ws.send(json.dumps(cmd, ensure_ascii=False))

                                except Exception as e:
                                    print("[CONSOLE] send failed:", e)
                            asyncio.create_task(handle_message(ws, ws_data[i]))
                if((msg["body"]["statusMessage"]).startswith("re_end")):
                    re_id = str((msg["body"]["statusMessage"])).split(":",1)[1]
                    if not ((msg["body"]["statusMessage"]).startswith("re_end_fin")):
                        asyncio.create_task(start_re_end(re_id))
                    else:
                        pass
            # print("[CMD RESP]", json.dumps(msg, ensure_ascii=False)[:1000])
        else:
            print("[MSG] purpose:", purpose, "full:", json.dumps(msg, ensure_ascii=False)[:1000])

    try:
        try:
            initial = await asyncio.wait_for(ws.recv(), timeout=1.5)
            print("[<] initial from client:", initial)
        except asyncio.TimeoutError:
            initial = None
            print("[*] no initial message from client (timeout)")

        for event in ["PlayerMessage", "BlockPlaced", "BlockBroken"]:
            subscribe_msg = make_subscribe_event(event)
            subscribe_json = json.dumps(subscribe_msg, ensure_ascii=False)
            try:
                await ws.send(subscribe_json)
                print(f"[WS] Sent subscribe {event}")
            except Exception as e:
                print(f"[WS] subscribe {event} failed:", e)


        max_attempts = 5
        for attempt in range(1, max_attempts + 1):
            try:
                await ws.send(subscribe_json)
                print(f"[WS] Sent subscribe PlayerMessage (attempt {attempt})")
                break
            except ConnectionClosed as cc:
                print(f"[WS] ConnectionClosed while sending subscribe: code={getattr(cc,'code',None)} reason={getattr(cc,'reason',None)}")
                raise
            except Exception as e:
                print(f"[WS] subscribe send failed (attempt {attempt}): {e}")
                await asyncio.sleep(0.5 * attempt)
        else:
            print("[WS] subscribe failed after retries, closing handler")
            return
        send_to_ui({"type":"status","msg":"Success_connect"})
        ping_task = asyncio.create_task(ping_loop(ws))
        if initial:
            await process_raw_string(initial)

        async for raw in ws:
            await process_raw_string(raw)

    except ConnectionClosedOK:
        print(f"[WS] 接続正常終了: {peer}")
    except ConnectionClosedError as cc:
        print(f"[WS] 接続切断: code={getattr(cc,'code',None)} reason={getattr(cc,'reason',None)}")
    except Exception as e:
        print("[WS] 例外:", repr(e))
    finally:
        if ping_task:
            ping_task.cancel()
        print("[*] handler 終了 for", peer)
        send_to_ui({"type":"status","msg":"finish_handler"})

async def start_re_end(id):
    if re_end.get(f"{id}") == None:
        return
    if len(re_end[f"{id}"]) == 0:
        return
    prefix = str(re_end[f"{id}"][:150]).replace("\"","d@$*d")
    re_end[f"{id}"] = re_end[f"{id}"][150:]
    re_len = len(re_end[f"{id}"])
    print(f"len:{re_len} {prefix}", flush=True)
    is_fin = "false"
    if re_len == 0:
        is_fin = "true"
        print("it_true")
    order = re_end_order[f"{id}"]
    mc_cmd = make_command_request(f'da:d_ws_integration_data "{id}" "{prefix}" {is_fin} {order} {re_len}')
    await MC_ws.send(json.dumps(mc_cmd, ensure_ascii=False))
    if re_len == 0:
        re_end.pop(f"{id}")




BACKUP_DIR_NAME = "backup"

_fname_re = re.compile(r'(?P<dt>\d{8}_\d{4})_(?P<world>.+)\.zip$')

def _sanitize_name(name: str) -> str:
    name = re.sub(r'["\'`\[\]\{\}]', '', name)
    name = re.sub(r'[:*?<>|/\\]', '', name)
    name = name.strip(" .")
    return name

def _parse_backup_filename(fname: str):
    m = _fname_re.search(fname)
    if not m:
        return None
    try:
        dt = datetime.strptime(m.group("dt"), "%Y%m%d_%H%M")
    except Exception:
        return None
    world = m.group("world")
    return {"dt": dt, "world": world, "name": fname}

def _make_zip_of_folder(src_folder: Path, dest_zip: Path):
    tmp = dest_zip.with_suffix(dest_zip.suffix + ".part")
    if tmp.exists():
        tmp.unlink()
    with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(src_folder):
            root_path = Path(root)
            for f in files:
                file_path = root_path / f
                arcname = file_path.relative_to(src_folder)
                zf.write(file_path, arcname)
    tmp.replace(dest_zip)

async def _zip_in_thread(src: Path, dest: Path):
    await asyncio.to_thread(_make_zip_of_folder, src, dest)

def _ensure_backup_dir(base_dir: Path) -> Path:
    backup_dir = base_dir.parent.joinpath(BACKUP_DIR_NAME)
    backup_dir.mkdir(parents=True, exist_ok=True)
    return backup_dir

def _gather_backups(backup_dir: Path):
    items = []
    for p in backup_dir.iterdir():
        if not p.is_file():
            continue
        parsed = _parse_backup_filename(p.name)
        if parsed:
            parsed["path"] = p
            items.append(parsed)
    return items

def _delete_file(p: Path):
    try:
        p.unlink()
        # print(f"Deleted {p}")
    except Exception as e:
        print(f"Failed to delete {p}: {e}")

async def _cleanup_backups(backup_dir: Path, now: datetime):
    backups = _gather_backups(backup_dir)
    three_years_ago = now - timedelta(days=3*365)
    for b in backups:
        if b["dt"] < three_years_ago:
            _delete_file(b["path"])
    backups = _gather_backups(backup_dir)
    month_cutoff = now - timedelta(days=30)
    by_month_world = {}
    for b in backups:
        if b["dt"] < month_cutoff:
            key = (b["dt"].year, b["dt"].month, b["world"])
            by_month_world.setdefault(key, []).append(b)
    for group in by_month_world.values():
        if len(group) <= 1:
            continue
        group_sorted = sorted(group, key=lambda x: x["dt"], reverse=True)
        for to_del in group_sorted[1:]:
            _delete_file(to_del["path"])

    backups = _gather_backups(backup_dir)
    day_cutoff = now - timedelta(days=1)
    by_day_world = {}
    for b in backups:
        if b["dt"] < day_cutoff:
            key = (b["dt"].year, b["dt"].month, b["dt"].day, b["world"])
            by_day_world.setdefault(key, []).append(b)
    for group in by_day_world.values():
        if len(group) <= 1:
            continue
        group_sorted = sorted(group, key=lambda x: x["dt"], reverse=True)
        for to_del in group_sorted[1:]:
            _delete_file(to_del["path"])

    backups = _gather_backups(backup_dir)
    hour_cutoff = now - timedelta(hours=1)
    for b in backups:
        if b["dt"] < hour_cutoff:
            if (b["dt"].minute % 30) != 0:
                _delete_file(b["path"])

    backups = _gather_backups(backup_dir)
    halfhour_cutoff = now - timedelta(minutes=30)
    for b in backups:
        if b["dt"] < halfhour_cutoff:
            if (b["dt"].minute % 15) != 0:
                _delete_file(b["path"])

async def ten_sec_loop():
    global world_name,world_path,Last_backup,back_up
    base_dir = Path(__file__).resolve()
    backup_dir = _ensure_backup_dir(base_dir)

    while True:
        try:
            if back_up.get("valid") and (world_path != None) and (world_name != None):
                interval = int(back_up.get("Interval", 1))
                last_iso = Last_backup
                last_backup_dt = None
                if last_iso:
                    try:
                        last_backup_dt = datetime.fromisoformat(last_iso)
                    except Exception:
                        last_backup_dt = None

                now = datetime.now()
                if interval not in (1, 3, 5, 10, 30, 60):
                    interval = 1
                should_take = False
                if interval == 60:
                    if now.minute == 0 and now.second < 10:
                        should_take = True
                else:
                    if (now.minute % interval) == 0 and now.second < 10:
                        should_take = True

                if should_take:
                    if last_backup_dt and last_backup_dt.year == now.year and last_backup_dt.month == now.month and last_backup_dt.day == now.day and last_backup_dt.hour == now.hour and last_backup_dt.minute == now.minute:
                        should_take = False
                wp_p = world_path if isinstance(world_path, Path) else Path(world_path)
                if should_take and wp_p.exists():
                    sanitized_world = _sanitize_name(world_name)
                    fname = f"{now.strftime('%Y%m%d_%H%M')}_{sanitized_world}.zip"
                    dest = backup_dir.joinpath(fname)
                    try:
                        await _zip_in_thread(wp_p, dest)
                        Last_backup = now.isoformat()
                        print(f"[{now.isoformat()}] Backup created: {dest}")
                    except Exception as e:
                        print(f"Backup failed: {e}")
                    try:
                        await _cleanup_backups(backup_dir, now)
                    except Exception as e:
                        print(f"Cleanup error: {e}")
            await asyncio.sleep(10)
        except Exception as e:
            print(f"Error in ten_sec_loop: {e}")
            await asyncio.sleep(10)






async def register_ws(ws):
    global MC_ws
    state.clients.add(ws)
    try:
        interval_data_task = asyncio.create_task(poll_custom_command(ws))
        ten_interval_data_task = asyncio.create_task(ten_sec_loop())
        MC_ws = ws
        await handler(ws, None)
    finally:
        state.clients.discard(ws)

async def console_input_loop():
    print("[CONSOLE] type 'cmd:<minecraft command>' to run server->game")
    while True:
        line = await asyncio.get_event_loop().run_in_executor(None, input, "> ")
        if not line:
            continue
        if line.startswith("cmd:"):
            cmd = line[len("cmd:"):].strip()
            payload = make_command_request(cmd)
            for ws in list(state.clients):
                try:
                    await ws.send(json.dumps(payload, ensure_ascii=False))
                except Exception as e:
                    print("[CONSOLE] send failed:", e)
            print("[>] Sent command to clients:", cmd)
        elif line == "list":
            print("clients:", len(state.clients))
        elif line in ("quit", "exit"):
            for ws in list(state.clients):
                await ws.close()
            break
        else:
            print("[?] Unknown. Use cmd:<command>")

async def poll_custom_command(ws):
    while True:
        try:
            cmd = make_command_request(f'da:d_ws_data "{ws_data_id}"')
            await ws.send(json.dumps(cmd, ensure_ascii=False))
            # print("[WS] Sent command da:d_ws_data")
            pass
        except Exception as e:
            world_UUID = None
            if str(e).find("1002") != -1:
                send_to_ui({"type":"status","msg":"1002"})
            print("[WS] Failed to send command:", e)
            break

        await asyncio.sleep(1)

_ui_shutdown_requested = False

def send_to_ui(obj: dict):
    try:
        print(json.dumps(obj, ensure_ascii=False), flush=True)
    except Exception:
        pass

async def read_stdin_loop():
    global _ui_shutdown_requested,bot_task,TOKEN,AI_TYPE,AI_API,gpt_model,PREFIX,MC_ws,re_end
    loop = asyncio.get_running_loop()
    while True:
        line = await loop.run_in_executor(None, sys.stdin.readline)
        if line == "":
            send_to_ui({"type":"status","msg":"stdin_eof_parent_gone"})
            _ui_shutdown_requested = True
            return
        line = line.strip()
        if not line:
            continue
        j = None
        try:
            j = json.loads(line)
        except Exception:
            pass
        cmd = None
        if isinstance(j, dict):
            cmd = j.get("cmd")
        else:
            if line == "stop_websocket":
                cmd = "stop_websocket"
        if cmd == "shutdown":
            send_to_ui({"type":"status","msg":"shutdown_requested_by_ui"})
            _ui_shutdown_requested = True
            return
        elif cmd == "kill_must_port":
            pids = find_pids_by_port(PORT)
            if not pids:
                send_to_ui({"type":"info","msg":"no_pids_found","port":PORT})
            else:
                results = []
                for pid in pids:
                    ok, reason = kill_pid(pid)
                    results.append({"pid":pid,"ok":ok,"reason":reason})
                send_to_ui({"type":"kill_result","port":PORT,"results":results})
        elif cmd == "stop_websocket":
            send_to_ui({"type":"status","msg":"stop_websocket_received"})
            try:
                asyncio.create_task(stop_and_restart_server())
            except Exception as e:
                send_to_ui({"type":"error","error":"stop_restart_task_failed","reason":str(e)})
        elif cmd == "connect_discord":
            pass
        elif cmd == "disconnect_discord":
            if bot_task is not None and not bot_task.done():
                await bot.close()
            send_to_ui({"type":"status","msg":"disconnect_discord"})
        elif cmd == "send":
            text = j.get("text","") if isinstance(j, dict) else ""
            send_to_ui({"type":"echo","text":text})
        elif str(cmd).startswith("AI_setting"):
            AI_TYPE = str(cmd).split("|")[1]
            if AI_TYPE == "gpt":
                gpt_model = str(cmd).split("|")[2]
                AI_API = str(cmd).split('|',3)[3]
            if AI_TYPE == "other":
                AI_API = str(cmd).split('|',2)[2]
            if AI_TYPE == "custom":
                AI_API = str(cmd).split('|',2)[2]
            if AI_TYPE == "local":
                print("requesting")
                send_to_ui({"type":"status","msg":"request_start_receive_ai"})
            if AI_TYPE == "stop":
                AI_TYPE = None
                AI_API = None
            else:
                send_to_ui({"type":"status","msg":"request_stop_receive_ai"})
        elif str(cmd).startswith("discordStart"):
            TOKEN = str(cmd).split("|")[1]
            PREFIX = str(cmd).split("|",2)[2]
            bot_task = asyncio.create_task(start_bot_safely())
            send_to_ui({"type":"status","msg":"connect_discord"})
        elif str(cmd).startswith("mcmd"):
            re_id = random.randint(0,2**32)
            re_end_order["num"]+=1
            re_end_order[f"{re_id}"] = re_end_order["num"]
            re_end[f"{re_id}"] = f'{str(cmd).split("|",1)[1]}'
            re_end_task = asyncio.create_task(start_re_end(re_id))
            await re_end_task
        elif str(cmd) == "request_stop_backup":
            back_up["valid"] = False
        elif str(cmd).startswith("request_start_backup"):
            back_up["valid"] = True
            back_up["Interval"] = int(str(cmd).split("|",1)[1])
        else:
            send_to_ui({"type":"unknown_cmd","cmd":cmd,"raw":j if j is not None else line})

def find_pids_by_port(port: int):
    system = platform.system()
    pids = []
    try:
        if system == "Windows":
            proc = subprocess.run(["netstat","-ano"], capture_output=True, text=True)
            out = proc.stdout
            for line in out.splitlines():
                if f":{port} " in line or f":{port}\t" in line:
                    parts = re.split(r"\s+", line.strip())
                    if len(parts) >= 5:
                        pid = parts[-1]
                        try:
                            pids.append(int(pid))
                        except Exception:
                            pass
        else:
            proc = subprocess.run(["which","lsof"], capture_output=True, text=True)
            if proc.returncode == 0:
                proc2 = subprocess.run(["lsof","-iTCP:%d" % port,"-sTCP:LISTEN","-t"], capture_output=True, text=True)
                out = proc2.stdout
                for line in out.splitlines():
                    try:
                        pids.append(int(line.strip()))
                    except Exception:
                        pass
            else:
                proc3 = subprocess.run(["ss","-ltnp"], capture_output=True, text=True)
                out = proc3.stdout
                for line in out.splitlines():
                    if f":{port} " in line or f":{port}\t" in line:
                        m = re.search(r"pid=(\d+),", line)
                        if m:
                            try:
                                pids.append(int(m.group(1)))
                            except Exception:
                                pass
    except Exception as e:
        send_to_ui({"type":"error","error":"find_pids_failed","reason":str(e)})
    return list(dict.fromkeys(pids))

def kill_pid(pid: int):
    system = platform.system()
    try:
        if system == "Windows":
            proc = subprocess.run(["taskkill","/PID",str(pid),"/F"], capture_output=True, text=True)
            if proc.returncode == 0:
                return True, "killed"
            else:
                return False, proc.stdout + proc.stderr
        else:
            try:
                os.kill(pid, signal.SIGTERM)
                time.sleep(0.2)
                try:
                    os.kill(pid, 0)
                    os.kill(pid, signal.SIGKILL)
                    return True, "killed_sigkill"
                except OSError:
                    return True, "killed_sigterm"
            except Exception as e:
                return False, str(e)
    except Exception as e:
        return False, str(e)

def port_is_free(host: str, port: int) -> bool:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        s.bind((host, port))
        s.close()
        return True
    except OSError:
        try:
            s.close()
        except Exception:
            pass
        return False

async def stop_and_restart_server():
    global ws_server, _ui_shutdown_requested

    if ws_server is None:
        send_to_ui({"type":"status","msg":"no_ws_server_running"})
        return
    send_to_ui({"type":"status","msg":"stopping_ws_server"})
    try:
        clients = list(state.clients)
        if clients:
            send_to_ui({"type":"status","msg":"closing_clients","count":len(clients)})
        for ws in clients:
            try:
                await ws.close()
            except Exception as e:
                send_to_ui({"type":"log","msg":"close_client_failed","reason":str(e)})
    except Exception as e:
        send_to_ui({"type":"error","error":"close_clients_failed","reason":str(e)})
    try:
        ws_server.close()
        await ws_server.wait_closed()
        send_to_ui({"type":"status","msg":"ws_server_stopped"})
    except Exception as e:
        send_to_ui({"type":"error","error":"ws_server_stop_failed","reason":str(e)})
    await asyncio.sleep(3)
    try:
        if not port_is_free(HOST, PORT):
            pids = find_pids_by_port(PORT)
            send_to_ui({"type":"error","error":"port_not_free_on_restart","port":PORT,"pids":pids})
            return
        ws_server = await websockets.serve(register_ws, HOST, PORT)
        send_to_ui({"type":"status","msg":"ws_server_restarted","host":HOST,"port":PORT})
    except Exception as e:
        send_to_ui({"type":"error","error":"ws_server_restart_failed","reason":str(e)})

UUID_RE = re.compile(
    r'([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})'
)
DA_WORLD_RE = re.compile(r'DA_world_UUID', re.IGNORECASE)
DA_COLON_RE = re.compile(r'DA:?\s*' + UUID_RE.pattern, re.IGNORECASE)

def default_minecraft_worlds_path():
    userprofile = os.environ.get("USERPROFILE") or os.path.expanduser("~")
    parts = [
        userprofile, "AppData", "Local", "Packages",
        "Microsoft.MinecraftUWP_8wekyb3d8bbwe", "LocalState",
        "games", "com.mojang", "minecraftWorlds"
    ]
    return os.path.join(*parts)

def extract_uuid_after_da_world(text):
    uuids = []
    for m in DA_WORLD_RE.finditer(text):
        start = m.end()
        tail = text[start:start+200]
        mm = UUID_RE.search(tail)
        if mm:
            uuids.append(mm.group(1))
        else:
            mm2 = UUID_RE.search(text, pos=start)
            if mm2:
                uuids.append(mm2.group(1))
    return uuids

def extract_da_colon_fallback(text):
    found = []
    for m in DA_COLON_RE.finditer(text):
        found.append(m.group(1))
    return found

def find_worlds_by_uuid(target_uuid, base_dir=None):
    if not target_uuid:
        raise ValueError("TARGET_UUID が空です。")
    target_uuid = target_uuid.strip().lower()
    if base_dir is None:
        base_dir = default_minecraft_worlds_path()

    results = []
    if not os.path.isdir(base_dir):
        raise FileNotFoundError(f"minecraftWorlds フォルダが見つかりません: {base_dir}")

    for world_name in os.listdir(base_dir):
        world_dir = os.path.join(base_dir, world_name)
        if not os.path.isdir(world_dir):
            continue
        db_dir = os.path.join(world_dir, "db")
        if not os.path.isdir(db_dir):
            continue

        for fname in os.listdir(db_dir):
            if not fname.lower().endswith(".log"):
                continue
            log_path = os.path.join(db_dir, fname)
            try:
                with open(log_path, "rb") as f:
                    raw = f.read()
                text = raw.decode("utf-8", errors="ignore")
            except Exception as e:
                results.append({
                    "world_folder": world_dir,
                    "log_file": log_path,
                    "error": f"read error: {e}",
                })
                continue

            matched_uuid = None
            method = None

            uuids_after_da = extract_uuid_after_da_world(text)
            if uuids_after_da:
                for u in uuids_after_da:
                    if u and u.strip():
                        if u.lower() == target_uuid:
                            matched_uuid = u
                            method = "DA_world_UUID"
                            break
                if matched_uuid is None:
                    found_one = uuids_after_da[0]
                else:
                    found_one = matched_uuid
            else:
                found_one = None

            if matched_uuid is None:
                da_colon_list = extract_da_colon_fallback(text)
                if da_colon_list:
                    for u in da_colon_list:
                        if u and u.strip():
                            if u.lower() == target_uuid:
                                matched_uuid = u
                                method = "DA: fallback"
                                break
                    if matched_uuid is None and not found_one:
                        found_one = da_colon_list[0]

            results.append({
                "world_folder": world_dir,
                "log_file": log_path,
                "found_uuid": found_one,
                "matched": bool(matched_uuid),
                "match_method": method,
            })

            if matched_uuid:
                levelname_path = os.path.join(world_dir, "levelname.txt")
                if os.path.isfile(levelname_path):
                    try:
                        with open(levelname_path, "r", encoding="utf-8", errors="ignore") as lf:
                            levelname = lf.read().strip()
                    except Exception as e:
                        levelname = f"<error reading levelname.txt: {e}>"
                else:
                    levelname = None
                results[-1]["levelname"] = levelname
    return results


def search_world_name(TARGET_UUID,BASE_DIR = None):
    TARGET_UUID = os.environ.get("MC_TARGET_UUID", TARGET_UUID) or ""
    BASE_DIR = os.environ.get("MC_BASE_DIR", BASE_DIR) or BASE_DIR
    if platform.system() != "Windows":
        print("ERROR: This script must be run on Windows.", file=sys.stderr)
        return
    world_name = None
    world_path = None
    if not TARGET_UUID:
        print("ERROR: TARGET_UUID が設定されていません。ファイル上部の TARGET_UUID を設定してください。")
        return

    try:
        hits = find_worlds_by_uuid(TARGET_UUID, base_dir=BASE_DIR)
    except FileNotFoundError as e:
        print("ERROR:", e)
        sys.exit(1)
    except ValueError as e:
        print("ERROR:", e)
        sys.exit(1)

    if not hits:
        print("一致する DA_world_UUID は見つかりませんでした。")
        return

    for entry in hits:
        # print("-" * 70)
        # print("world_folder:", entry.get("world_folder"))
        # print("log_file   :", entry.get("log_file"))
        # if "error" in entry:
        #     print("note       :", entry["error"])
        #     continue
        # print("found_uuid :", entry.get("found_uuid"))
        # print("matched    :", entry.get("matched"))
        if entry.get("matched"):
            print("match_method:", entry.get("match_method"))
            lvl = entry.get("levelname")
            if lvl is None:
                print("levelname.txt: (存在しないか読み取れません)")
            else:
                print("levelname.txt content:")
                print(lvl)
                world_path = entry.get("world_folder")
                world_name = lvl
                
        else:
            pass
            # print("note: 指定 UUID と一致しません（ログ中に見つかった UUID を表示しています）")
    # print("-" * 70)
    print(world_name)
    return {"name":world_name,"path":world_path}



async def main():
    global _ui_shutdown_requested, ws_server
    asyncio.create_task(read_stdin_loop())

    if not port_is_free(HOST, PORT):
        pids = find_pids_by_port(PORT)
        send_to_ui({"type":"error","error":"port_in_use","port":PORT,"pids":pids})
        send_to_ui({"type":"status","msg":"waiting_for_kill_command_or_parent_close"})
        while True:
            if _ui_shutdown_requested:
                send_to_ui({"type":"status","msg":"shutdown_while_waiting_for_port"})
                return
            if port_is_free(HOST, PORT):
                send_to_ui({"type":"status","msg":"port_now_free","port":PORT})
                break
            await asyncio.sleep(0.5)
    try:
        ws_server = await websockets.serve(register_ws, HOST, PORT)
        send_to_ui({"type":"status","msg":"server_started","host":HOST,"port":PORT})
    except Exception as e:
        send_to_ui({"type":"error","error":"server_start_failed","reason":str(e)})
        return

    print(f"[*] サーバー起動 ws://{HOST}:{PORT}", flush=True)
    print("READY_FOR_UI",flush=True)
    console_task = None
    try:
        if sys.stdin and sys.stdin.isatty():
            console_task = asyncio.create_task(console_input_loop())
        else:
            send_to_ui({"type":"status","msg":"console_input_disabled_due_to_non_tty_stdin"})
    except Exception:
        console_task = None

    try:
        while True:
            if _ui_shutdown_requested:
                send_to_ui({"type":"status","msg":"shutdown_initiated"})
                break
            await asyncio.sleep(0.5)
    except asyncio.CancelledError:
        pass
    finally:
        if console_task:
            console_task.cancel()
        if not bot_task.done():
            await bot.close()
        try:
            if ws_server:
                ws_server.close()
                await ws_server.wait_closed()
        except Exception:
            pass
        send_to_ui({"type":"status","msg":"server_closed"})
        sys.stdout.flush()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("exiting")
