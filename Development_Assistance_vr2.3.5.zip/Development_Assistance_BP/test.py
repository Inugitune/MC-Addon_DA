import numpy as np

# 元の配列
arr = np.array([[1, 2],
                [3, 4]])

n, m = arr.shape
# 回転後の配列サイズは n + m - 1（ここでは 2 + 2 - 1 = 3）
rot = np.zeros((n + m - 1, n + m - 1), dtype=int)

# 各要素を新しい位置に配置
for i in range(n):
    for j in range(m):
        # 新しい行番号は i + j
        # 新しい列番号は (m - 1 - i) + j
        rot[i + j, (m - 1 - i) + j] = arr[i, j]

print(rot)
