import { BlockVolume, TicksPerSecond, ItemTypes, Entity, StructureManager, EntityComponentTypes, BlockPermutation, world, system, BlockTypes, ScoreboardObjective, ItemStack, EntityInventoryComponent, BlockInventoryComponent, } from "@minecraft/server"
import { ActionFormData, MessageFormData, ModalFormData } from "@minecraft/server-ui";
let basic_player = null;
let loaded = false;
let tick = 0;
let use_on_block = 0;
let DA_data = {

}
let DA_save_on_world = {

}
let DA_structures = {

}
let DA_ABU = {

}
let DA_structures_num = 0;
if (world.getDynamicProperty("DA_structures") != null) {
    let str = "";
    for (let i = 0; i < 8192; i++) {
        const txt = world.getDynamicProperty(`DA_structures_${i}`);
        if (txt != undefined) {
            str += txt;
        } else {
            break;
        }
    }
    if (str != "") {
        try {
            DA_structures = JSON.parse(str);
        } catch {
            for (let i = 0; i < 8192; i++) {
                if (world.getDynamicProperty(`DA_structures_${i}`) != undefined) {
                    world.setDynamicProperty(`DA_structures_${i}`, null);
                } else {
                    break;
                }
            }
        }
    }
};
const Run_function_at_shift = {};
let This_chat_ID = 0;
if (world.getDynamicProperty("DA_save_on_world") != null) {
    if (world.getDynamicProperty("DA_save_on_world_ids") == undefined) {
        DA_save_on_world = JSON.parse(world.getDynamicProperty(`DA_save_on_world`));
    } else {
        const ids = JSON.parse(world.getDynamicProperty("DA_save_on_world_ids"));
        for (let i = 0; i < ids.length; i++) {
            DA_save_on_world[ids[i]] = JSON.parse(world.getDynamicProperty(`DA_save_on_world_${ids[i]}`));
        }
    }
};
let DA_copy_chats = [

];
let DA_is_Leave = {

}

function levenshteinDistance(str1, str2) {
    const len1 = str1.length;
    const len2 = str2.length;
    const matrix = [];
    for (let i = 0; i <= len1; i++) {
        matrix[i] = [i];
    }
    for (let j = 0; j <= len2; j++) {
        matrix[0][j] = j;
    }
    for (let i = 1; i <= len1; i++) {
        for (let j = 1; j <= len2; j++) {
            const cost = str1[i - 1] === str2[j - 1] ? 0 : 1;
            matrix[i][j] = Math.min(
                matrix[i - 1][j] + 1,
                matrix[i][j - 1] + 1,
                matrix[i - 1][j - 1] + cost
            );
        }
    }
    return matrix[len1][len2];
}
function similarityPercentage(str1, str2) {
    const distance = levenshteinDistance(str1, str2);
    const maxLength = Math.max(str1.length, str2.length);
    if (maxLength === 0) return 100;
    return ((maxLength - distance) / maxLength) * 100;
}

function JP_date(date = null) {
    let JD = date ?? new Date();
    let JDT = JD.getTime() + (9 * 60 * 60 * 1000);
    return new Date(JDT);
}

function pos_string_to_json(string_pos) {
    const split_sp = String(string_pos).split(" ");
    return { x: Number(split_sp[0]), y: Number(split_sp[1]), z: Number(split_sp[2]) };
}

function show_particle(player, string, only_me = false, options = null) {
    const string_sp = string.split(" ");
    if (!only_me) {
        run_command_player(player, string);
    } else {
        player.spawnParticle(`${string_sp[1]}`, pos_string_to_json(`${string_sp[2]} ${string_sp[3]} ${string_sp[4]}`), options);
    }
}

function save_DASOW_on_world() {
    world.setDynamicProperty(`DA_save_on_world_ids`, JSON.stringify(Object.keys(DA_save_on_world)));
    for (const key in DA_save_on_world) {
        if (Object.prototype.hasOwnProperty.call(DA_save_on_world, key)) {
            world.setDynamicProperty(`DA_save_on_world_${key}`, JSON.stringify(DA_save_on_world[key]));
        }
    }
}

function is_airs(player, x, y, z, included_liquid = false) {
    const block = player.dimension.getBlock({ x: x, y: y, z: z });
    if (block == undefined) {
        return true;
    } else if (block.typeId == "minecraft:air" || ((block.typeId == "minecraft:water" || block.typeId == "minecraft:lava") && included_liquid)) {
        return true;
    } else {
        return false;
    }
}

function getNearestPoint(target, pointA, pointB) {
    const minX = Math.min(pointA.x, pointB.x);
    const maxX = Math.max(pointA.x, pointB.x);
    const minY = Math.min(pointA.y, pointB.y);
    const maxY = Math.max(pointA.y, pointB.y);
    const minZ = Math.min(pointA.z, pointB.z);
    const maxZ = Math.max(pointA.z, pointB.z);
    const nearestX = Math.max(minX, Math.min(target.x, maxX));
    const nearestY = Math.max(minY, Math.min(target.y, maxY));
    const nearestZ = Math.max(minZ, Math.min(target.z, maxZ));

    return { x: nearestX, y: nearestY, z: nearestZ };
}

function Get_now_date(set_time = 0) {
    let JD = new Date();
    let JDT = JD.getTime() + (9 * 60 * 60 * 1000);
    JDT += (set_time * 60 * 1000);
    return new Date(JDT);
}

function wait_for_load(player, pos1, pos2) {
    return new Promise((resolve) => {
        function one_tick_loop() {
            let poss = [];
            const basic_pos = [pos1, pos2];
            const min_pos = {
                x: Math.min(pos1.x, pos2.x),
                y: Math.min(pos1.y, pos2.y),
                z: Math.min(pos1.z, pos2.z)
            }
            const max_pos = {
                x: Math.max(pos1.x, pos2.x),
                y: Math.max(pos1.y, pos2.y),
                z: Math.max(pos1.z, pos2.z)
            }
            for (let x = min_pos.x; x <= max_pos.x; x += (32 - ((DA_save_on_world[player.id]["Connect_Pass"] ?? 0) * 3))) {
                for (let z = min_pos.z; z <= max_pos.z; z += (32 - ((DA_save_on_world[player.id]["Connect_Pass"] ?? 0) * 3))) {
                    poss.push(x, (Math.floor(Math.random() * 2) == 0) ? min_pos.y : max_pos.y, z);
                }
            }
            const square = [[0, 0, 0], [1, 0, 0], [0, 0, 1], [1, 0, 1], [0, 1, 0], [1, 1, 0], [0, 1, 1], [1, 1, 1]];
            for (let g = 0; g < square.length; g++) {
                poss.push(basic_pos[square[g][0]].x, basic_pos[square[g][1]].y, basic_pos[square[g][2]].z);
            }
            let block = [];
            try {
                for (let i = 0; (i + 2) < poss.length; i += 3) {
                    block.push((player.dimension).getBlock({ x: Math.floor(Number(poss[i])), y: Math.floor(Number(poss[i + 1])), z: Math.floor(Number(poss[i + 2])) }));
                }
            } catch (e) {
                run_command_player(player, `say §cDA-Error(Please reload) => ${e}`);
            }
            if (block.indexOf(undefined) == -1 && block.indexOf(null) == -1) {
                resolve();
            } else {
                system.runTimeout(one_tick_loop, 1);
            }
        }
        one_tick_loop();
    });
}
function await_one_tick() {
    return new Promise((resolve) => {
        function one_tick_loop() {
            resolve();
        }
        system.runTimeout(one_tick_loop, 1);
    });
}

let Nob_tp_ao = 63; //63
let All_count_task_num = 0;
let DA_now_tasking = {

}
let now_task_num = {
    0: false,
    1: false
};
let debug_temp1 = false;
function check_is_success(player, x, y, z, e, taskQueue, target_block = null, is_Success = 1) {
    const block = player.dimension.getBlock({ x: x, y: y, z: z })
    is_Success = 1;
    if (block == null || block == undefined /*|| ((target_block != null && block != undefined) ? (String(block.type.id).indexOf(target_block) == -1) : false)*/ || is_Success == 0) {
        run_command_player(player, `title @s actionbar ${x} ${y} ${z}　付近を読み込めませんでした。\n実際にその座標に言って地形を読み込んでください。`);
        taskQueue.unshift(e);
        taskQueue.unshift(`wait for test block:${x} ${y} ${z}`);
        // debug_temp1 = true;
    }
}

function binomialCoefficient(n, k) {
    let coeff = 1;
    for (let i = 1; i <= k; i++) {
        coeff *= (n - i + 1) / i;
    }
    return coeff;
}

function bezierPoint(points, t) {
    const n = points.length - 1;
    let numerator = { x: 0, y: 0, z: 0 };
    let denominator = 0;
    for (let i = 0; i <= n; i++) {
        const w = points[i].weight ?? 1;
        const bin = binomialCoefficient(n, i);
        const basis = bin * Math.pow(1 - t, n - i) * Math.pow(t, i) * w;
        numerator.x += basis * points[i].x;
        numerator.y += basis * points[i].y;
        numerator.z += basis * points[i].z;
        denominator += basis;
    }
    return {
        x: numerator.x / denominator,
        y: numerator.y / denominator,
        z: numerator.z / denominator
    };
}

function GetBezierCurve(controlPoints, resolution = 100, Get_point = null) {
    if (Get_point == null) {
        const positions = [];
        for (let i = 0; i <= resolution; i++) {
            const t = i / resolution;
            const point = bezierPoint(controlPoints, t);
            positions.push({
                x: Math.round(point.x),
                y: Math.round(point.y),
                z: Math.round(point.z),
            });
        }
        return positions;
    } else {
        const t = (Get_point / resolution);
        const point = bezierPoint(controlPoints, t);
        return ({
            x: Math.round(point.x),
            y: Math.round(point.y),
            z: Math.round(point.z),
        });
    }
}

function Get_UUID() {
    let dt = new Date().getTime();
    const uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        const r = (dt + Math.random() * 16) % 16 | 0;
        dt = Math.floor(dt / 16);
        return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
    });
    return uuid;
}
function run_command(command) {
    try {
        basic_player.runCommand(command);
    } catch (e) {
        basic_player = world.getAllPlayers()[0];
        run_command(`tellraw @a{"rawtext":[{"text":"§8DA => 基準プレイヤーを変更しました ${String(basic_player.nameTag).replaceAll("\"", "").replaceAll("\'", "").replaceAll("\`", "").replaceAll("\\", "")}"}]}`)
    }
}
function run_command_player(player, command) {
    return player.runCommand(command);
}

function pseudoRandomBigInt(x, y) {
    const X = BigInt(Math.floor(x));
    const Y = BigInt(Math.floor(y));
    const n = X + Y * 57n;
    const nn = (n << 13n) ^ n;
    const c1 = 15731n, c2 = 789221n, c3 = 1376312589n;
    const resultBigInt = (nn * (nn * nn * c1 + c2) + c3) & 0x7fffffffn;
    const divisor = 1073741824n;
    const resultNumber = Number(resultBigInt) / Number(divisor);
    return 1.0 - resultNumber;
}

function smoothNoise(x, y) {
    const corners = (pseudoRandomBigInt(x - 1, y - 1) + pseudoRandomBigInt(x + 1, y - 1) + pseudoRandomBigInt(x - 1, y + 1) + pseudoRandomBigInt(x + 1, y + 1)) / 16;
    const sides = (pseudoRandomBigInt(x - 1, y) + pseudoRandomBigInt(x + 1, y) + pseudoRandomBigInt(x, y - 1) + pseudoRandomBigInt(x, y + 1)) / 8;
    const center = pseudoRandomBigInt(x, y) / 4;
    return corners + sides + center;
}

function lerp(a, b, t) {
    return a + t * (b - a);
}

function interpolatedNoise(x, y) {
    const intX = Math.floor(x);
    const fracX = x - intX;
    const intY = Math.floor(y);
    const fracY = y - intY;
    const v1 = smoothNoise(intX, intY);
    const v2 = smoothNoise(intX + 1, intY);
    const v3 = smoothNoise(intX, intY + 1);
    const v4 = smoothNoise(intX + 1, intY + 1);
    const i1 = lerp(v1, v2, fracX);
    const i2 = lerp(v3, v4, fracX);
    return lerp(i1, i2, fracY);
}

function perlinNoise(x, y) {
    let total = 0;
    const persistence = 0.5;
    const octaves = 4;
    for (let i = 0; i < octaves; i++) {
        const frequency = Math.pow(2, i);
        const amplitude = Math.pow(persistence, i);
        total += interpolatedNoise(x * frequency, y * frequency) * amplitude;
    }
    return (total + 1) / 2;
}

function get_authority_num(player) {
    const world_data = DA_save_on_world["world_data"];
    if (world_data["LUNATIC"].indexOf(player.id) != -1) {
        return 0;
    } else if (world_data["EXTRA"].indexOf(player.id) != -1) {
        return 1;
    } else if (world_data["BASIC"].indexOf(player.id) != -1) {
        return 2;
    } else {
        return 3;
    }
}

function getEdgePosition(pos_1, pos_2, t) {
    let pos1 = JSON.parse(JSON.stringify(pos_1));
    let pos2 = JSON.parse(JSON.stringify(pos_2));
    //      5       3
    if ((pos1.y - pos2.y) < 0) {
        pos2.y += 1;
    } else {
        pos1.y += 1;
    }
    const def_x = ((pos1.x - pos2.x) != 0) ? (pos1.x - pos2.x) : 1;
    const def_y = ((pos1.y - pos2.y) != 0) ? (pos1.y - pos2.y) : 1;
    const def_z = ((pos1.z - pos2.z) != 0) ? (pos1.z - pos2.z) : 1;
    return { x: pos2.x + (def_x * (t / 100)), y: pos2.y + (def_y * (t / 100)), z: pos2.z + (def_z * (t / 100)), }
}

function rotate_array(mat, rotate = 0) {
    if (rotate == 0) {
        return mat;
    } else if (rotate == 90) {
        const m = mat.length;
        const n = mat[0].length;
        const rotated = [];
        for (let j = 0; j < n; j++) {
            rotated[j] = [];
            for (let i = m - 1; i >= 0; i--) {
                rotated[j].push(mat[i][j]);
            }
        }
        return rotated;
    } else if (rotate == 180) {
        const m = mat.length;
        const n = mat[0].length;
        const rotated = [];
        for (let i = 0; i < m; i++) {
            rotated[i] = [];
            for (let j = 0; j < n; j++) {
                rotated[i][j] = mat[m - 1 - i][n - 1 - j];
            }
        }
        return rotated;
    } else if (rotate == 270) {
        const m = mat.length;
        const n = mat[0].length;
        const rotated = [];
        for (let r = 0; r < n; r++) {
            rotated[r] = [];
            for (let c = 0; c < m; c++) {
                rotated[r][c] = mat[c][n - 1 - r];
            }
        }
        return rotated;
    }
}

function flip(mat, type) {
    if (type === "x") {
        return mat.slice().reverse();
    } else if (type === "z") {
        return mat.map(row => row.slice().reverse());
    } else if (type === "xz") {
        return mat.slice().reverse().map(row => row.slice().reverse());
    }
}

function generate_now_task_text(type = "all") {
    let text = "";
    for (const key in DA_now_tasking) {
        if (Object.prototype.hasOwnProperty.call(DA_now_tasking, key)) {
            let situation = DA_now_tasking[key].situation;
            let color = "§4";
            if (situation == "Pending") {
                color = "§e";
            } else if (situation == "Running") {
                color = "§a";
            } else if (situation == "Stopping") {
                color = "§7";
            }
            const replaced_command = DA_now_tasking[key].command.replaceAll("[", "").replaceAll("]", "").replaceAll("{", "").replaceAll("}", "").replaceAll("\"", "").replaceAll("\'", "").replaceAll("\`", "");
            text += `\n${color}${situation} ID:${key} => ${replaced_command} (${DA_now_tasking[key].player_name})`;
        }
    }
    return text;
}

/**
 * EX_send_message
 * @param player - player
 * @param {string} type - group | list
 * @param {string} msg - メッセージ
 * @param {string} GL_name - グループ名 | 半径
 */

function EX_send_message(player, type, msg, GL_name) {
    const all_players = world.getAllPlayers();
    if (type == "group") {
        system.run(() => {
            if (DA_save_on_world["group_chat"][GL_name] != null) {
                for (let i = 0; i < all_players.length; i++) {
                    if (DA_save_on_world["group_chat"][GL_name].players.some(item => item.id === all_players[i].id)) {
                        run_command_player(all_players[i], `tellraw @s {"rawtext":[{"text":"${msg}"}]}`)
                    }
                }
            }
        })
    } else if (type == "list") {
        system.run(() => {
            if (DA_save_on_world["list_chat"][player.id] != null) {
                for (let i = 0; i < all_players.length; i++) {
                    if (DA_save_on_world["list_chat"][player.id].players.some(item => item.id === all_players[i].id)) {
                        run_command_player(all_players[i], `tellraw @s {"rawtext":[{"text":"${msg}"}]}`)
                    }
                }
            }
        })
    } else if (type == "range") {
        system.run(() => {
            run_command_player(player, `tellraw @a[r=${Number(GL_name)}] {"rawtext":[{"text":"${msg}"}]}`)
        })
    }
}

async function memory_delete(strength) {
    function wait_for_task_finish() {
        return new Promise((resolve) => {
            function check() {
                if (Object.keys(DA_now_tasking).length == 0) {
                    resolve();
                } else {
                    system.runTimeout(check, 2);
                }
            }
            check();
        })
    }
    await wait_for_task_finish();
    const now_ids = [];
    const All_players = world.getAllPlayers();
    for (let i = 0; i < All_players.length; i++) {
        now_ids.push(All_players[i].id);
    }
    if (strength == 0) {
        for (const key in DA_data) {
            if (Object.prototype.hasOwnProperty.call(DA_data, key)) {
                if (DA_data[key]["undo"] != undefined) {
                    for (let i = 0; i < DA_data[key]["undo"].length; i++) {
                        run_command(`structure delete "DA:${DA_data[key]["undo"][i].UUID}"`);
                        delete DA_structures[DA_data[key]["undo"][i].UUID];
                    }
                    DA_data[key]["undo"] = [];
                }
            }
        }
        for (const key in DA_ABU) {
            if (Object.prototype.hasOwnProperty.call(DA_ABU, key)) {
                if (now_ids.indexOf(key) == -1) {
                    delete DA_ABU[key];
                }
            }
        };
    }
    if (strength > 0) {
        for (const key in DA_structures) {
            if (Object.prototype.hasOwnProperty.call(DA_structures, key)) {
                run_command(`structure delete "${DA_structures[key].name}"`);
                delete DA_structures[key];
            }
        }
        for (const key in DA_data) {
            if (Object.prototype.hasOwnProperty.call(DA_data, key)) {
                DA_data[key]["undo"] = [];
            }
        }
        for (const key in DA_ABU) {
            if (Object.prototype.hasOwnProperty.call(DA_ABU, key)) {
                if (now_ids.indexOf(key) == -1) {
                    delete DA_ABU[key];
                }
            }
        };
    }
    if (strength == 2) {
        for (const key in DA_data) {
            if (Object.prototype.hasOwnProperty.call(DA_data, key)) {
                if (now_ids.indexOf(key) == -1) {
                    delete DA_data[key];
                }
            }
        };
        DA_ABU = {};
    } else if (strength == 3) {
        DA_ABU = {};
        DA_data = {}
    }
}

async function DA_command(S_player, command, ev = { cancel: false }, RES_RC_pos = null) {
    try {
        let is_any_stopper = false;
        const msg = command;
        const player = S_player;
        let this_tickingarea_index = 0;
        let player_name = String(player.nameTag).replaceAll("\"", "").replaceAll("\'", "").replaceAll("\`", "").replaceAll("\\", "");
        if (DA_data[player.id] != null) {
            const commands = msg.split(" ");
            if (String(commands[0]).startsWith("g.") || (DA_data[player.id]["GCF"] != null && !String(commands[0]).startsWith("."))) {
                player_setting_data(player);
                const group_id = (String(commands[0]).startsWith("g.")) ? commands[0].replace("g.", "") : DA_data[player.id]["GCF"];
                if (DA_save_on_world["group_chat"][group_id] != null) {
                    if (DA_save_on_world["group_chat"][group_id].players.some(item => item.id === player.id)) {
                        let content = (String(commands[0]).startsWith("g.")) ? msg.replace(`${commands[0]} `, "") : msg;
                        const skip_gcs = (DA_save_on_world["group_chat"][group_id]["skip_gcs"] ?? false);
                        system.run(() => {
                            EX_send_message(player, "group", `${((!skip_gcs) ? `§b§lグループチャット[§r${DA_save_on_world["group_chat"][group_id].name}§b§l] >> \n§r§b<` : "§l§b>>")}§r${player.nameTag}§r§b>§r ${content}`, group_id);
                        })
                        DA_save_on_world["group_chat"][group_id]["skip_gcs"] = true;
                        ev.cancel = true;
                    }
                }
            }
        }
        if (msg.indexOf(".") != -1) {
            player_setting_data(player);
            const commands = msg.split(" ");
            const RC_pos = RES_RC_pos ?? JSON.parse(JSON.stringify(get_selected_pos(player)));
            if (String(commands[0]).startsWith("l.")) {
                if (DA_save_on_world["list_chat"] != null) {
                    if (DA_save_on_world["list_chat"][player.id] != null) {
                        let content = msg.replace(`${commands[0]} `, "");
                        let members = "";
                        const lp = DA_save_on_world["list_chat"][player.id].players;
                        const All_players = world.getAllPlayers();
                        for (let i = 0; i < All_players.length; i++) {
                            if (lp.some(item => item.id === All_players[i].id)) {
                                members += `${(members == "") ? "" : "/"}${All_players[i].nameTag}`;
                            }
                        }
                        const skip_lcs = (DA_save_on_world["list_chat"][player.id]["skip_lcs"] ?? false)
                        EX_send_message(player, "list", `§e§l${(skip_lcs) ? ">>" : `リストチャット[§r${members}§e§l] >> \n§r§e<`}§r${player.nameTag}§r§e>§r ${content}`);
                        DA_save_on_world["list_chat"][player.id]["skip_lcs"] = true;
                        ev.cancel = true;
                    }
                }
            }
            if (String(commands[0]).startsWith("r.")) {
                if (Number(commands[0].replace("r.", "")) > 0) {
                    let content = msg.replace(`${commands[0]} `, "");
                    EX_send_message(player, "range", `§a§l範囲チャット[§rr=${Number(commands[0].replace("r.", ""))}§a§l(§r"},{"selector":"@a[r=${Number(commands[0].replace("r.", ""))}]"},{"text":"§r§a§l)] >> \n§r§a<§r${player.nameTag}§r§a>§r ${content}`, Number(commands[0].replace("r.", "")));
                    ev.cancel = true;
                }
            }
            if (get_authority_num(player) < 3) {
                system.run(() => {
                    run_command_player(player, `tag @s add DA_catch_announce`);
                })
                const all_commands = [
                    ".fill",
                    ".replace",
                    ".clear",
                    ".copy",
                    ".paste",
                    ".ball",
                    ".circle",
                    ".rotate",
                    ".flip",
                    ".flip2",
                    ".line",
                    ".BezierCurves",
                    ".terrain",
                    ".frame",
                    ".undo",
                    ".automatic_undo",
                ];
                const any_commands = [
                    ".fill",
                    ".replace",
                    ".clear",
                    ".copy",
                    ".paste",
                    ".ball",
                    ".circle",
                    ".rotate",
                    ".flip",
                    ".flip2",
                    ".line",
                    ".BezierCurves",
                    ".terrain",
                    ".frame",
                    ".undo",
                    ".automatic_undo",
                    ".stop",
                    ".check"
                ];
                const LUN_setting = DA_save_on_world[player.id]["LUNATIC_setting"];
                if (LUN_setting[`can_${String(commands[0]).slice(1)}`] != null && get_authority_num(player) >= 2) {
                    if (LUN_setting[`can_${String(commands[0]).slice(1)}`] == false) {
                        system.run(() => {
                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 許可されていない機能です。"}]}`)
                        })
                        ev.cancel = true;
                        return;
                    }
                } else if (get_authority_num(player) >= 2) {
                    system.run(() => {
                        run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 許可されていない機能です。"}]}`)
                    })
                    ev.cancel = true;
                    return;
                }
                if (LUN_setting[`can_use_taskmanager`] != null && get_authority_num(player) >= 2) {
                    if (LUN_setting[`can_use_taskmanager`] == false && (commands[0] == ".stop" || commands[0] == ".check")) {
                        system.run(() => {
                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 許可されていない機能です。"}]}`)
                        })
                        ev.cancel = true;
                        return;
                    }
                }
                if (LUN_setting[`can_bind`] != null && get_authority_num(player) >= 2) {
                    if (LUN_setting[`can_bind`] == false && (commands[0] == ".bind" || commands[0] == ".bindcheck" || commands[0] == ".bindCheck" || commands[0] == ".unbind")) {
                        system.run(() => {
                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 許可されていない機能です。"}]}`)
                        })
                        ev.cancel = true;
                        return;
                    }
                }
                if (get_authority_num(player) == 0 && commands[0] == ".Iconnect") {
                    const target = (player.dimension).getEntities({ name: `${String(commands[1]).replaceAll("&5a1%", " ")}` });
                    if (target.length > 0) {
                        DA_data[player.id]["Iconnect"] = {
                            flag: true,
                            target: target[0],
                            first_inventory: player.getComponent("minecraft:inventory").container,
                            first_Offhand: player.getComponent("minecraft:equippable").getEquipment("Offhand"),
                            first_Head: player.getComponent("minecraft:equippable").getEquipment("Head"),
                            first_Chest: player.getComponent("minecraft:equippable").getEquipment("Chest"),
                            first_Feet: player.getComponent("minecraft:equippable").getEquipment("Feet"),
                            first_Legs: player.getComponent("minecraft:equippable").getEquipment("Legs"),
                        }
                        system.run(() => {
                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§bDA => インベントリが共有されました。\n(.IDisconnect で共有を停止できます。)"}]}`)
                        })
                        ev.cancel = true;
                        return;
                    }
                }
                if (commands[0] == ".baritone") {
                    if (Number(commands[1]) > -Infinity && Number(commands[2]) > -Infinity && Number(commands[3]) > -Infinity) {
                        baritone(player, { x: Math.floor(Number(commands[1])), y: Math.floor(Number(commands[2])), z: Math.floor(Number(commands[3])) });
                        ev.cancel = true;
                        return;
                    } else if (commands[1] == "stop") {
                        DA_data[player.id]["baritone_stop"] = true;
                        ev.cancel = true;
                        return;
                    }
                }
                if (get_authority_num(player) != 3) {
                    if (commands[0] == ".group") {
                        player_setting_data(player);
                        if (commands[1] == "create") {
                            if (commands[2] != null) {
                                if (DA_save_on_world["group_chat"][commands[2]] == null) {
                                    const group_name = (msg.replaceAll(`${commands[0]} ${commands[1]} ${commands[2]} `, "") != "" && commands[3] != null) ? msg.replaceAll(`${commands[0]} ${commands[1]} ${commands[2]} `, "") : commands[2];
                                    const GC = DA_save_on_world["group_chat"];
                                    for (const key in GC) {
                                        if (Object.prototype.hasOwnProperty.call(GC, key)) {
                                            if (GC[key].players.length < 1) {
                                                delete GC[key];
                                            }
                                        }
                                    }
                                    DA_save_on_world["group_chat"][commands[2]] = {
                                        name: group_name,
                                        players: [{ name: player.nameTag, id: player.id }],
                                    }
                                    system.run(() => {
                                        run_command_player(player, `tellraw @a {"rawtext":[{"text":"§aDA => ${player_name}§r§a によってグループ「${commands[2]} - ${group_name}§r§a」が作成されました。"}]}`)
                                    })
                                } else {
                                    system.run(() => {
                                        run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => すでにそのIDのグループは存在します。"}]}`)
                                    })
                                };
                            } else {
                                system.run(() => {
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 無効な構文です。"}]}`)
                                })
                            }
                        } else if (commands[1] == "add") {
                            if (commands[2] != null && commands[3] != null && DA_save_on_world["group_chat"][commands[2]] != null) {
                                if (DA_save_on_world["group_chat"][commands[2]].players.some(item => item.id === player.id)) {
                                    const pn = msg.replaceAll(`${commands[0]} ${commands[1]} ${commands[2]} `, "");
                                    let target_player = null;
                                    let max_percent = 0;
                                    const all_players = world.getAllPlayers();
                                    for (let i = 0; i < all_players.length; i++) {
                                        const this_percent = similarityPercentage(all_players[i].nameTag, pn);
                                        if (this_percent > 90 && this_percent > max_percent) {
                                            max_percent = this_percent;
                                            target_player = all_players[i];
                                        };
                                    }
                                    if (target_player != null) {
                                        if (DA_save_on_world["group_chat"][commands[2]].players.some(item => item.id === target_player.id)) {
                                            system.run(() => {
                                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => すでにその人物はグループに所属しています。"}]}`)
                                            })
                                        } else {
                                            DA_save_on_world["group_chat"][commands[2]].players.push({ name: target_player.nameTag, id: target_player.id });
                                            system.run(() => {
                                                EX_send_message(player, "group", `§aDA => ${target_player.nameTag.replaceAll("\"", "").replaceAll("\'", "").replaceAll("\`", "").replaceAll("\\", "")}§r§aが${player_name}§r§aによってグループ「§r${commands[2]}§r§a」に§b追加されました。`, commands[2])
                                            })
                                        }
                                    } else {
                                        system.run(() => {
                                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => その人物は見つかりませんでした。"}]}`)
                                        })
                                    }
                                } else {
                                    system.run(() => {
                                        run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => そのグループに所属していません。"}]}`)
                                    })
                                };
                            } else {
                                system.run(() => {
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 無効な構文またはグループです。"}]}`)
                                })
                            }
                        } else if (commands[1] == "check") {
                            if (commands[2] != null && DA_save_on_world["group_chat"][commands[2]] != null) {
                                if (DA_save_on_world["group_chat"][commands[2]].players.some(item => item.id === player.id) || get_authority_num(player) == 0) {
                                    const group_chat = DA_save_on_world["group_chat"][commands[2]]
                                    let all_player_names = "";
                                    for (let i = 0; i < group_chat.players.length; i++) {
                                        all_player_names += (`${(i == 0) ? "" : " / "}${group_chat.players[i].name}§r`);
                                    }
                                    system.run(() => {
                                        run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => §b現在グループ「${group_chat.name}」は${group_chat.players.length}人所属しています。§r\n${all_player_names}"}]}`)
                                    })
                                } else {
                                    system.run(() => {
                                        run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => そのグループに所属していません。"}]}`)
                                    })
                                };
                            } else {
                                system.run(() => {
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 無効な構文またはグループです。"}]}`)
                                })
                            }
                        } else if (commands[1] == "remove") {
                            if (commands[2] != null && commands[3] != null && DA_save_on_world["group_chat"][commands[2]] != null) {
                                if (DA_save_on_world["group_chat"][commands[2]].players.some(item => item.id === player.id)) {
                                    const pn = msg.replaceAll(`${commands[0]} ${commands[1]} ${commands[2]} `, "");
                                    let target_player = null;
                                    let max_percent = 0;
                                    const all_players = world.getAllPlayers();
                                    for (let i = 0; i < all_players.length; i++) {
                                        const this_percent = similarityPercentage(all_players[i].nameTag, pn);
                                        if (this_percent > 90 && this_percent > max_percent) {
                                            max_percent = this_percent;
                                            target_player = all_players[i];
                                        };
                                    }
                                    if (target_player != null) {
                                        if (DA_save_on_world["group_chat"][commands[2]].players.some(item => item.id === target_player.id)) {
                                            system.run(() => {
                                                EX_send_message(player, "group", `§aDA => ${target_player.nameTag.replaceAll("\"", "").replaceAll("\'", "").replaceAll("\`", "").replaceAll("\\", "")}§r§aが${player_name}§r§aによってグループ「§r${commands[2]}§r§a」にから§6外されました`, commands[2])
                                                const group_players = DA_save_on_world["group_chat"][commands[2]].players;
                                                for (let u = 0; u < group_players.length; u++) {
                                                    if (group_players[u].id == target_player.id) {
                                                        group_players.splice(u, 1);
                                                        u--;
                                                    }
                                                }
                                            })
                                        } else {
                                            system.run(() => {
                                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => グループ内にその人物は見つかりませんでした。"}]}`)
                                            })
                                        }
                                    } else {
                                        system.run(() => {
                                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => その人物は見つかりませんでした。"}]}`)
                                        })
                                    }
                                } else {
                                    system.run(() => {
                                        run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => そのグループに所属していません。"}]}`)
                                    })
                                };
                            } else {
                                system.run(() => {
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 無効な構文またはグループです。"}]}`)
                                })
                            }
                        } else if (commands[1] == "delete") {
                            if (commands[2] != null && DA_save_on_world["group_chat"][commands[2]] != null) {
                                if (DA_save_on_world["group_chat"][commands[2]].players.some(item => item.id === player.id) || get_authority_num(player) == 0) {
                                    const bg = JSON.parse(JSON.stringify(DA_save_on_world["group_chat"][commands[2]]));
                                    system.run(() => {
                                        run_command_player(player, `tellraw @a {"rawtext":[{"text":"§6DA => グループ「${bg.name}」は${player.nameTag}§r§6によって§4破棄§6されました。"}]}`)
                                    })
                                    delete DA_save_on_world["group_chat"][commands[2]];
                                } else {
                                    system.run(() => {
                                        run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => そのグループに所属していません。"}]}`)
                                    })
                                };
                            } else {
                                system.run(() => {
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 無効な構文またはグループです。"}]}`)
                                })
                            }
                        } else if (commands[1] == "forced") {
                            if (commands[2] != null && DA_save_on_world["group_chat"][commands[2]] != null) {
                                if (DA_save_on_world["group_chat"][commands[2]].players.some(item => item.id === player.id)) {
                                    if (commands[3] != null) {
                                        const pn = msg.replaceAll(`${commands[0]} ${commands[1]} ${commands[2]} `, "");
                                        let target_player = null;
                                        let max_percent = 0;
                                        const all_players = world.getAllPlayers();
                                        for (let i = 0; i < all_players.length; i++) {
                                            const this_percent = similarityPercentage(all_players[i].nameTag, pn);
                                            if (this_percent > 90 && this_percent > max_percent) {
                                                max_percent = this_percent;
                                                target_player = all_players[i];
                                            };
                                        }
                                        if (target_player != null) {
                                            if (DA_save_on_world["group_chat"][commands[2]].players.some(item => item.id === target_player.id)) {
                                                player_setting_data(target_player);
                                                DA_data[target_player.id]["GCF"] = commands[2];
                                                const msg_txt = (`tellraw @s {"rawtext":[{"text":"§aDA => §r${player.nameTag}§r§aによって§r${target_player.nameTag}§r§aの\nグループチャット「§r${DA_save_on_world["group_chat"][commands[2]].name}§r§a」をデフォルトにしました。\n§r§7(.group release で解除できます。)"}]}`);
                                                system.run(() => {
                                                    run_command_player(player, msg_txt)
                                                    if (player.id != target_player.id) {
                                                        run_command_player(target_player, msg_txt)
                                                    }
                                                })
                                            } else {
                                                system.run(() => {
                                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => その人物はグループに所属していません。"}]}`)
                                                })
                                            }
                                        } else {
                                            system.run(() => {
                                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => その人物は見つかりませんでした。"}]}`)
                                            })
                                        }
                                    } else {
                                        player_setting_data(player);
                                        DA_data[player.id]["GCF"] = commands[2];
                                        system.run(() => {
                                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => グループチャット「§r${DA_save_on_world["group_chat"][commands[2]].name}§r§a」をデフォルトにしました。\n§r§7(.group release で解除できます。)"}]}`)
                                        })
                                    }
                                } else {
                                    system.run(() => {
                                        run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => そのグループに所属していません。"}]}`)
                                    })
                                };
                            } else {
                                system.run(() => {
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 無効な構文またはグループです。"}]}`)
                                })
                            }
                        } else if (commands[1] == "release") {
                            player_setting_data(player);
                            system.run(() => {
                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => デフォルト設定を解除しました。"}]}`)
                            })
                            DA_data[player.id]["GCF"] = null;
                        } else if (commands[1] == "all") {
                            let group_names = "";
                            for (const key in DA_save_on_world["group_chat"]) {
                                if (Object.prototype.hasOwnProperty.call(DA_save_on_world["group_chat"], key)) {
                                    group_names += `§r${(group_names == "") ? "" : "\n"}${key} - ${DA_save_on_world["group_chat"][key].name}`
                                }
                            }
                            system.run(() => {
                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => 現在このワールドには${Object.keys(DA_save_on_world["group_chat"]).length}個のグループが存在します。\n§b${group_names}"}]}`)
                            })
                        }
                        save_DASOW_on_world();
                        ev.cancel = true;
                        return;
                    } else if (commands[0] == ".list") {
                        player_setting_data(player);
                        if (DA_save_on_world["list_chat"][player.id] == null) {
                            DA_save_on_world["list_chat"][player.id] = {
                                players: [{ id: player.id, name: player.nameTag }],
                            }
                        }
                        if (commands[1] == "add") {
                            const pn = msg.replaceAll(`${commands[0]} ${commands[1]} `, "");
                            let target_player = null;
                            let max_percent = 0;
                            const all_players = world.getAllPlayers();
                            for (let i = 0; i < all_players.length; i++) {
                                const this_percent = similarityPercentage(all_players[i].nameTag, pn);
                                if (this_percent > 90 && this_percent > max_percent) {
                                    max_percent = this_percent;
                                    target_player = all_players[i];
                                };
                            }
                            if (target_player != null) {
                                if (DA_save_on_world["list_chat"][player.id].players.some(item => item.id === target_player.id)) {
                                    system.run(() => {
                                        run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => すでにその人物はリストチャットに所属しています。"}]}`)
                                    })
                                } else {
                                    DA_save_on_world["list_chat"][player.id].players.push({ id: target_player.id, name: target_player.nameTag })
                                    system.run(() => {
                                        run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => ${target_player.nameTag.replaceAll("\"", "").replaceAll("\'", "").replaceAll("\`", "").replaceAll("\\", "")}§r§aを§eリストチャットチャット§aに追加しました。"}]}`)
                                    })
                                }
                            } else {
                                system.run(() => {
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => その人物は見つかりませんでした。"}]}`)
                                })
                            }
                        } else if (commands[1] == "remove") {
                            const pn = msg.replaceAll(`${commands[0]} ${commands[1]} `, "");
                            let target_player = null;
                            let max_percent = 0;
                            const all_players = world.getAllPlayers();
                            for (let i = 0; i < all_players.length; i++) {
                                const this_percent = similarityPercentage(all_players[i].nameTag, pn);
                                if (this_percent > 90 && this_percent > max_percent) {
                                    max_percent = this_percent;
                                    target_player = all_players[i];
                                };
                            }
                            if (target_player != null) {
                                if (DA_save_on_world["list_chat"][player.id].players.some(item => item.id === target_player.id)) {
                                    const lpp = DA_save_on_world["list_chat"][player.id].players;
                                    for (let i = 0; i < lpp.length; i++) {
                                        if (lpp[i].id == target_player.id) {
                                            lpp.splice(i, 1);
                                            i--;
                                        }
                                    }
                                    system.run(() => {
                                        run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => ${target_player.nameTag.replaceAll("\"", "").replaceAll("\'", "").replaceAll("\`", "").replaceAll("\\", "")}§r§aを§eリストチャットチャット§aから外しました。"}]}`)
                                    })
                                } else {
                                    system.run(() => {
                                        run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => その人物はリストチャットに所属しいません。"}]}`)
                                    })
                                }
                            } else {
                                system.run(() => {
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => その人物は見つかりませんでした。"}]}`)
                                })
                            }
                        } else if (commands[1] == "check") {
                            if (DA_save_on_world["list_chat"][player.id] != null) {
                                system.run(() => {
                                    const lpp = DA_save_on_world["list_chat"][player.id].players;
                                    let players_txt = "";
                                    for (let i = 0; i < lpp.length; i++) {
                                        players_txt += `${(i == 0) ? "" : "/"}${lpp[i].name}§r§a`;
                                    }
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => §eリストチャット§aには現在${lpp.length}人所属しています。\n${players_txt}"}]}`)
                                })
                            } else {
                                system.run(() => {
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => リストチャットが作成されていません。"}]}`)
                                })
                            }
                        }
                        ev.cancel = true;
                        save_DASOW_on_world();
                        return;
                    }
                }
                if (get_authority_num(player) == 0 && commands[0] == ".IDisconnect") {
                    if (DA_data[player.id]["Iconnect"] != null) {
                        if (DA_data[player.id]["Iconnect"]["flag"]) {
                            system.run(() => {
                                const first_inventory = DA_data[player.id]["Iconnect"]["first_inventory"];
                                const first_Offhand = DA_data[player.id]["Iconnect"]["first_Offhand"];
                                const first_Head = DA_data[player.id]["Iconnect"]["first_Head"];
                                const first_Chest = DA_data[player.id]["Iconnect"]["first_Chest"];
                                const first_Feet = DA_data[player.id]["Iconnect"]["first_Feet"];
                                const first_Legs = DA_data[player.id]["Iconnect"]["first_Legs"];
                                // for (let i = 0; i < first_inventory.size; i++) {
                                //     const first_inventory_item = first_inventory.getItem(i);
                                //     player.getComponent("minecraft:inventory").container.setItem(i, first_inventory_item)
                                // }
                                // player.getComponent("minecraft:equippable").setEquipment("Offhand", first_Offhand);
                                // player.getComponent("minecraft:equippable").setEquipment("Head", first_Head);
                                // player.getComponent("minecraft:equippable").setEquipment("Chest", first_Chest);
                                // player.getComponent("minecraft:equippable").setEquipment("Feet", first_Feet);
                                // player.getComponent("minecraft:equippable").setEquipment("Legs", first_Legs);

                                DA_data[player.id]["Iconnect"] = {
                                    flag: false,
                                    target: null,
                                };
                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§6DA => インベントリの共有を終了しました。"}]}`)
                            })
                            ev.cancel = true;
                            return;
                        }
                    }
                }
                if (DA_data[player.id] != null) {
                    if (DA_data[player.id]["Next_Registration_Commands"] != null) {
                        if (DA_data[player.id]["Next_Registration_Commands"]) {
                            DA_data[player.id]["Next_Registration_Commands"] = false;
                            DA_command(player, `.bind ${DA_data[player.id]["value"]} ${DA_data[player.id]["type"]} ${msg}`);
                            return;
                        }
                    }
                }
                if (all_commands.indexOf(commands[0]) != -1 && get_authority_num(player) >= 2) {
                    const pos = JSON.parse(JSON.stringify(RC_pos));
                    let blocks_num = (Math.abs(pos.pos2.x - pos.pos1.x)) * Math.abs(pos.pos2.y - pos.pos1.y) * Math.abs(pos.pos2.z - pos.pos1.z);
                    if (commands[0] == ".ball") {
                        if (Number(commands[1]) > 0) {
                            blocks_num = Math.pow(Math.abs(commands[1] * 2), 3);
                        }
                    } else if (commands[0] == ".circle") {
                        if (Number(commands[1]) > 0) {
                            blocks_num = Math.pow(Math.abs(commands[1] * 2), 2) * (Math.abs(pos.pos2.y - pos.pos1.y) + 1);
                        }
                    }
                    if (Number(LUN_setting["can_change_num"]) < blocks_num) {
                        system.run(() => {
                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 選択したブロック数が許可されていません。(${blocks_num}>${LUN_setting["can_change_num"]})"}]}`)
                        })
                        ev.cancel = true;
                        return;
                    }
                }
                if (commands[0] == ".check") {
                    system.run(() => {
                        run_command_player(player, `tellraw @s {"rawtext":[{"text":"§b§lDA => 現在のタスク量:${Object.keys(DA_now_tasking).length}§r${generate_now_task_text()}"}]}`)
                    })
                    ev.cancel = true;
                    return;
                } else if (commands[0] == ".stop") {
                    if (DA_now_tasking[commands[1]] != null) {
                        const last_data = JSON.parse(JSON.stringify(DA_now_tasking[commands[1]]));
                        const replaced_command = last_data.command.replaceAll("[", "").replaceAll("]", "").replaceAll("{", "").replaceAll("}", "").replaceAll("\"", "").replaceAll("\'", "").replaceAll("\`", "");
                        if (DA_now_tasking[commands[1]].situation == "Waiting") {
                            system.run(() => {
                                run_command_player(player, `tellraw @a[name="${last_data.player_name}"] {"rawtext":[{"text":"§aDA => ${player_name}によって\nタスク§b${replaced_command}がキャンセルされました。"}]}`)
                            })
                            DA_now_tasking[commands[1]].situation = "Stopping";
                        } else {
                            system.run(() => {
                                run_command_player(player, `tellraw @a[name="${last_data.player_name}"] {"rawtext":[{"text":"§aDA => ${player_name}によって\nタスク§b${replaced_command}をキャンセル中です。"}]}`)
                            })
                            DA_now_tasking[commands[1]].situation = "Stopping";
                        }
                    } else {
                        system.run(() => {
                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 停止しようとしたタスクが見つかりません。"}]}`)
                        })
                    }
                    ev.cancel = true;
                    return;
                } else if (commands[0] == ".cl") {
                    let is_found = false;
                    for (let g = 0; g < DA_copy_chats.length; g++) {
                        if (DA_copy_chats[g]["ID"] == commands[1]) {
                            is_found = true;
                            Run_function_at_shift[player.id] = (() => {
                                for (let h = 0; h < DA_copy_chats.length; h++) {
                                    if (DA_copy_chats[h]["ID"] == commands[1]) {
                                        Show_Form("modal", player, {
                                            title: (`Copy the ${DA_copy_chats[h].type}`),
                                            content: [
                                                { type: "text", text: "PCのみ\n1. テキストを選択します。\n2. その状態でCTRL + Aを押し、全選択します。\n3. CTRL + C を押してコピーします。\n4.お好きな場所でCTRL + Vでペーストしてください。", value: "", default: `${DA_copy_chats[h].value}` }

                                            ]
                                        }, (value) => {

                                        })
                                        break;
                                    }
                                }
                            })
                            system.run(() => {
                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => スニークしてください。"}]}`)
                            })
                            break;
                        }
                    }
                    if (!is_found) {
                        system.run(() => {
                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => コピー元のテキストが見つかりません。"}]}`)
                        })
                    }
                    ev.cancel = true;
                }
                DA_now_tasking[All_count_task_num] = {
                    situation: "Waiting",
                    command: msg,
                    player_info: player,
                    player_name: player_name,
                }
                const this_task_id = Number(String(All_count_task_num));
                All_count_task_num++;
                if (all_commands.indexOf(commands[0]) != -1 && (now_task_num[0] && now_task_num[1])) {
                    system.run(() => {
                        run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => ${Object.keys(DA_now_tasking).length}個のタスクが渋滞中です。"}]}`);
                    })
                    const e = () => {
                        return new Promise((resolve) => {
                            async function tick_loop() {
                                if (DA_now_tasking[this_task_id].situation == "Stopping") {
                                    resolve();
                                    return;
                                } else if ((!now_task_num[0] || !now_task_num[1]) && DA_now_tasking[this_task_id].situation == "Pending") {
                                    resolve();
                                    return;
                                } else {
                                    system.run(() => {
                                        run_command_player(player, `tag @s add DA_catch_announce`);
                                    })
                                    system.runTimeout(tick_loop, 20);
                                }
                            }
                            tick_loop();
                        })
                    }
                    await e();
                } else if (all_commands.indexOf(commands[0]) != -1) {
                    ev.cancel = true;
                }
                if (DA_now_tasking[this_task_id].situation == "Stopping") {
                    is_any_stopper = true;
                    system.run(() => {
                        run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => 正常にタスクを中断しました。(${msg})"}]}`);
                    })
                    delete DA_now_tasking[this_task_id];
                    return;
                }
                if (!is_any_stopper) {
                    DA_now_tasking[this_task_id].situation = "Running";
                    if (!now_task_num[0]) {
                        now_task_num[0] = true;
                        this_tickingarea_index = 0;
                    } else {
                        now_task_num[1] = true;
                        this_tickingarea_index = 1;
                    }
                    system.runTimeout(() => {
                        run_command_player(player, `tag @s remove DA_catch_announce`);
                    }, 3)
                    if (any_commands.indexOf(commands[0]) != -1) {
                        if (Object.keys(DA_now_tasking).length > 2) {
                            system.run(() => {
                                run_command_player(player, `tellraw @a[tag=allow_DA,tag=DA_catch_announce] {"rawtext":[{"text":"§b§lDA => 現在のタスク量:${Object.keys(DA_now_tasking).length}§r${generate_now_task_text()}"}]}`)
                            })
                        }
                    }
                    function task_finish_func(index) {
                        now_task_num[index] = false;
                        if (DA_now_tasking[this_task_id].situation == "Stopping") {
                            system.run(() => {
                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => 正常にタスクが中断されました。"}]}`)
                            })
                        }
                        delete DA_now_tasking[this_task_id];
                        for (const key in DA_now_tasking) {
                            if (Object.prototype.hasOwnProperty.call(DA_now_tasking, key)) {
                                if (DA_now_tasking[key].situation == "Waiting") {
                                    DA_now_tasking[key].situation = "Pending";
                                    break;
                                }
                            }
                        }
                        run_command_player(player, `tickingarea remove DA_temp${this_tickingarea_index}`);
                    }
                    if (commands[0] == ".fill") {
                        if (check_selected_pos(player)) {
                            system.run(() => {
                                if (commands[1] == "let") {
                                    player_setting_data(player);
                                    DA_data[player.id]["let"]["RC_pos"] = RC_pos;
                                    DA_data[player.id]["let"].type = "fill";
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => fillしたいブロックを置いてください。"}]}`);
                                    task_finish_func(this_tickingarea_index);
                                } else {
                                    let plus_x = null;
                                    let plus_z = null;
                                    let this_undo_index = null;
                                    const e = (min_pos, max_pos, x, y, z, taskQueue) => {
                                        try {
                                            const plus_y = ((max_pos.y - y) < 6) ? max_pos.y - y : 6;
                                            const a = run_command_player(player, `fill ${x} ${y} ${z} ${x + plus_x} ${y + plus_y} ${z + plus_z} ${commands[1]}`);
                                            check_is_success(player, Math.floor(x + plus_x / 2), Math.floor(y + plus_y / 2), Math.floor(z + plus_z / 2), e.bind(null, min_pos, max_pos, x, y, z, taskQueue), taskQueue, commands[1].split("[")[0], a.successCount);
                                        } catch (n) {
                                            run_command_player(player, `tellraw @s { "rawtext": [{ "text": "§cDA => 指定したブロックは無効です！" }] }`)
                                            run_command_player(player, `say => §c${n.stack} ${n}`);
                                        }
                                    }
                                    run_select_change(this_task_id, player, RC_pos, () => {
                                        DA_data[player.id]["undo"].push([]);
                                        this_undo_index = DA_data[player.id]["undo"].length - 1;
                                    }, (min_pos, max_pos, x, z, taskQueue) => {
                                        plus_x = ((max_pos.x - x) < (Nob_tp_ao)) ? max_pos.x - x : (Nob_tp_ao);
                                        plus_z = ((max_pos.z - z) < (Nob_tp_ao)) ? max_pos.z - z : (Nob_tp_ao);
                                        run_command_player(player, `tickingarea add ${x} ${min_pos.y} ${z} ${x + plus_x} ${max_pos.y} ${z + plus_z} DA_temp${this_tickingarea_index} true`);
                                        taskQueue.unshift(`wait for test block:[${Math.floor(x + plus_x)} ${Math.floor((min_pos.y))} ${Math.floor(z + plus_z)} ${Math.floor(x)} ${Math.floor(max_pos.y)} ${Math.floor(z)}]`);
                                    }, (min_pos, max_pos, x, z, taskQueue) => {
                                        const UUID = Get_UUID();
                                        run_command_player(player, `structure save "DA:${UUID}" ${x} ${min_pos.y} ${z} ${x + plus_x} ${max_pos.y} ${z + plus_z}`)
                                        DA_structures[UUID] = { x: x, y: min_pos.y, z: z, size: plus_x * (max_pos.y - min_pos.y) * plus_z, name: `DA:${UUID}`, player: { id: player.id, name: player.nameTag }, date: Get_now_date() };
                                        DA_data[player.id]["undo"][this_undo_index].unshift({ UUID: UUID, pos: { mx: x, my: min_pos.y, mz: z } })
                                    }, (min_pos, max_pos, x, y, z, taskQueue) => {
                                        const plus_y = ((max_pos.y - y) < 6) ? max_pos.y - y : 6;
                                        e(min_pos, max_pos, x, y, z, taskQueue);
                                    }, (min_pos, max_pos, x, z, taskQueue) => {
                                        run_command_player(player, `tickingarea remove DA_temp${this_tickingarea_index}`);
                                    }, () => { }, () => {
                                        task_finish_func(this_tickingarea_index);
                                    })
                                }
                            })
                            ev.cancel = true;
                        } else {
                            system.run(() => {
                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 範囲が選択されていません"}]}`);
                                task_finish_func(this_tickingarea_index);
                            })
                        }
                    } else if (commands[0] == ".cut") {
                        if (check_selected_pos(player)) {
                            system.run(() => {
                                try {
                                    const e = (min_pos, max_pos, x, y, z, taskQueue) => {
                                        const plus_y = ((max_pos.y - y) < 6) ? max_pos.y - y : 6;
                                        run_command_player(player, `fill ${x} ${y} ${z} ${x + plus_x} ${y + plus_y} ${z + plus_z} air`);
                                        check_is_success(player, Math.floor(x + plus_x / 2), Math.floor(y + plus_y / 2), Math.floor(z + plus_z / 2), e, taskQueue);
                                    }
                                    let plus_x = null;
                                    let plus_z = null;
                                    let this_undo_index = null;
                                    run_select_change(this_task_id, player, RC_pos, () => {
                                        DA_data[player.id]["undo"].push([]);
                                        this_undo_index = DA_data[player.id]["undo"].length - 1;
                                    }, (min_pos, max_pos, x, z, taskQueue) => {
                                        plus_x = ((max_pos.x - x) < (Nob_tp_ao - 1)) ? max_pos.x - x : (Nob_tp_ao - 1);
                                        plus_z = ((max_pos.z - z) < (Nob_tp_ao - 1)) ? max_pos.z - z : (Nob_tp_ao - 1);
                                        run_command_player(player, `tickingarea add ${x} ${min_pos.y} ${z} ${x + plus_x} ${max_pos.y} ${z + plus_z} DA_temp${this_tickingarea_index} true`);
                                        // taskQueue.unshift(`wait for test block:[${Math.floor(x + plus_x / 2)} ${Math.floor((min_pos.y + max_pos.y) / 2)} ${Math.floor(z + plus_z / 2)} ${Math.floor(x + plus_x)} ${Math.floor((min_pos.y))} ${Math.floor(z + plus_z)} ${Math.floor(x)} ${Math.floor(max_pos.y)} ${Math.floor(z)}]`);
                                        taskQueue.unshift(`wait for test block:[${Math.floor(x + plus_x)} ${Math.floor((min_pos.y))} ${Math.floor(z + plus_z)} ${Math.floor(x)} ${Math.floor(max_pos.y)} ${Math.floor(z)}]`);
                                    }, (min_pos, max_pos, x, z, taskQueue) => {
                                        const UUID = Get_UUID();
                                        run_command_player(player, `structure save "DA:${UUID}" ${x} ${min_pos.y} ${z} ${x + plus_x} ${max_pos.y} ${z + plus_z}`)
                                        DA_structures[UUID] = { x: x, y: min_pos.y, z: z, size: plus_x * (max_pos.y - min_pos.y) * plus_z, name: `DA:${UUID}`, player: { id: player.id, name: player.nameTag }, date: Get_now_date() };
                                        DA_data[player.id]["undo"][this_undo_index].unshift({ UUID: UUID, pos: { mx: x, my: min_pos.y, mz: z } })
                                    }, (min_pos, max_pos, x, y, z, taskQueue) => {
                                        e(min_pos, max_pos, x, y, z, taskQueue)
                                    }, (min_pos, max_pos, x, z, taskQueue) => {
                                        run_command_player(player, `tickingarea remove DA_temp${this_tickingarea_index}`);
                                    }, () => { }, () => { task_finish_func(this_tickingarea_index); })
                                } catch (e) {
                                    run_command_player(player, `tellraw @s { "rawtext": [{ "text": "§cDA => 由々しきエラー" }] }`)
                                    run_command_player(player, `say => ${e}`);
                                    task_finish_func(this_tickingarea_index);
                                }
                            })
                            ev.cancel = true;
                        } else {
                            run_command_player(player, `tellraw @s { "rawtext": [{ "text": "§cDA => 範囲を選択してください" }] }`);
                            task_finish_func(this_tickingarea_index);
                        }
                    } else if (commands[0] == ".copy") {
                        if (check_selected_pos(player)) {
                            system.run(() => {
                                player_setting_data(player);
                                DA_data[player.id]["copy"] = [];
                                const raw_pos = RC_pos ?? get_selected_pos(player);
                                try {
                                    let plus_x = null;
                                    let plus_z = null;
                                    let this_undo_index = null;
                                    run_select_change(this_task_id, player, RC_pos, () => {
                                        DA_data[player.id]["undo"].push([]);
                                        this_undo_index = DA_data[player.id]["undo"].length - 1;
                                    }, (min_pos, max_pos, x, z, taskQueue) => {
                                        DA_data[player.id]["copy_data"] = { min_pos: min_pos, max_pos: max_pos, dx: raw_pos.pos1.x - min_pos.x, dy: raw_pos.pos1.y - min_pos.y, dz: (raw_pos.pos1.z - min_pos.z) };
                                        plus_x = ((max_pos.x - x) < (Nob_tp_ao - 1)) ? max_pos.x - x : (Nob_tp_ao - 1);
                                        plus_z = ((max_pos.z - z) < (Nob_tp_ao - 1)) ? max_pos.z - z : (Nob_tp_ao - 1);
                                        run_command_player(player, `tickingarea add ${x} ${min_pos.y} ${z} ${x + plus_x} ${max_pos.y} ${z + plus_z} DA_temp${this_tickingarea_index} true`);
                                        // taskQueue.unshift(`wait for test block:[${Math.floor(x + plus_x / 2)} ${Math.floor((min_pos.y + max_pos.y) / 2)} ${Math.floor(z + plus_z / 2)} ${Math.floor(x + plus_x)} ${Math.floor((min_pos.y))} ${Math.floor(z + plus_z)} ${Math.floor(x)} ${Math.floor(max_pos.y)} ${Math.floor(z)}]`);
                                        taskQueue.unshift(`wait for test block:[${Math.floor(x + plus_x)} ${Math.floor((min_pos.y))} ${Math.floor(z + plus_z)} ${Math.floor(x)} ${Math.floor(max_pos.y)} ${Math.floor(z)}]`);
                                    }, (min_pos, max_pos, x, z, taskQueue) => {
                                        const UUID = Get_UUID();
                                        run_command_player(player, `structure save "DA_Copy:${UUID}" ${x} ${min_pos.y} ${z} ${x + plus_x} ${max_pos.y} ${z + plus_z}`)
                                        DA_structures[UUID] = { x: x, y: min_pos.y, z: z, size: plus_x * (max_pos.y - min_pos.y) * plus_z, name: `DA:${UUID}`, player: { id: player.id, name: player.nameTag }, date: Get_now_date() };
                                        DA_data[player.id]["copy"].unshift({ UUID: UUID, pos: { mx: x - min_pos.x - (raw_pos.pos1.x - min_pos.x), my: min_pos.y - (raw_pos.pos1.y - min_pos.y), dy: (raw_pos.pos1.y - min_pos.y), mz: z - min_pos.z - (raw_pos.pos1.z - min_pos.z) }, plus_x: plus_x, plus_z: plus_z, plus_y: (max_pos.y - min_pos.y) })
                                    }, (min_pos, max_pos, x, y, z) => {
                                    }, (min_pos, max_pos, x, z, taskQueue) => {
                                        run_command_player(player, `tickingarea remove DA_temp${this_tickingarea_index}`);
                                    }, () => { }, () => { task_finish_func(this_tickingarea_index); })
                                } catch (e) {
                                    run_command_player(player, `tellraw @s { "rawtext": [{ "text": "§cDA => 由々しきエラー" }] }`)
                                    run_command_player(player, `say => ${e}`);
                                    task_finish_func(this_tickingarea_index);
                                }
                            })
                            ev.cancel = true;
                        } else {
                            run_command_player(player, `tellraw @s { "rawtext": [{ "text": "§cDA => 範囲を選択してください" }] }`);
                            task_finish_func(this_tickingarea_index);
                        }
                    } else if (commands[0] == ".paste") {
                        ev.cancel = true;
                        let set_pos = { x: Math.floor(player.location.x), y: Math.floor(player.location.y), z: Math.floor(player.location.z) };
                        if (commands[1] == "select") {
                            if (check_selected_pos(player)) {
                                set_pos = DA_data[player.id]["select"]["pos1"];
                            } else {
                                run_command_player(player, `tellraw @s { "rawtext": [{ "text": "§cDA => 範囲を選択してください" }] }`)
                                task_finish_func(this_tickingarea_index);
                                return;
                            }
                        } else if (commands[1] == "show") {
                            if (commands[2] == "select") {
                                if (check_selected_pos(player)) {
                                    set_pos = DA_data[player.id]["select"]["pos1"];
                                } else {
                                    run_command_player(player, `tellraw @s { "rawtext": [{ "text": "§cDA => 範囲を選択してください" }] }`)
                                    task_finish_func(this_tickingarea_index);
                                    return;
                                }
                            }
                            if (DA_data[player.id]["copy_data"] != null) {
                                const data = DA_data[player.id]["copy_data"];
                                const plus_x = data.max_pos.x - data.min_pos.x;
                                const plus_y = data.max_pos.y - data.min_pos.y;
                                const plus_z = data.max_pos.z - data.min_pos.z;
                                DA_data[player.id]["prediction"]["pos1"] = { x: set_pos.x - data.dx, y: set_pos.y - data.dy, z: set_pos.z - data.dz };
                                DA_data[player.id]["prediction"]["pos2"] = { x: set_pos.x - data.dx + plus_x, y: set_pos.y - data.dy + plus_y, z: set_pos.z - data.dz + plus_z };
                                task_finish_func(this_tickingarea_index);
                            } else {
                                run_command_player(player, `tellraw @s { "rawtext": [{ "text": "§cDA => 由々しきエラー！" }] }`)
                                task_finish_func(this_tickingarea_index);
                            }
                            return;
                        }
                        if (DA_data[player.id]["copy"].length > 0) {
                            system.run(() => {
                                const temp = DA_data[player.id]["copy"];
                                const taskQueue = [];
                                DA_data[player.id]["undo"].push([]);
                                let this_undo_index = DA_data[player.id]["undo"].length - 1;
                                for (let i = 0; i < temp.length; i++) {
                                    taskQueue.push(() => {
                                        run_command_player(player, `tickingarea add ${temp[i].pos.mx + set_pos.x} ${set_pos.y} ${temp[i].pos.mz + set_pos.z} ${temp[i].pos.mx + 64 + set_pos.x} 320 ${temp[i].pos.mz + 64 + set_pos.z} DA_temp${this_tickingarea_index} true`);
                                    })
                                    taskQueue.push(`wait for test block:${temp[i].pos.mx + set_pos.x + 32} ${set_pos.y} ${temp[i].pos.mz + set_pos.z + 32}`);
                                    taskQueue.push(() => {
                                        const dx = temp[i].pos.mx + set_pos.x;
                                        const dz = temp[i].pos.mz + set_pos.z;
                                        const UUID = Get_UUID();
                                        run_command_player(player, `structure save "DA:${UUID}" ${dx} ${set_pos.y - temp[i].pos.dy} ${dz} ${dx + temp[i].plus_x} ${set_pos.y - temp[i].pos.dy + temp[i].plus_y} ${dz + temp[i].plus_z}`)
                                        DA_structures[UUID] = { x: dx, y: set_pos.y - temp[i].pos.dy, z: dz, size: temp[i].plus_x * (temp[i].plus_y) * temp[i].plus_z, name: `DA:${UUID}`, player: { id: player.id, name: player.nameTag }, date: Get_now_date() };
                                        DA_data[player.id]["undo"][this_undo_index].push({ UUID: UUID, pos: { mx: dx, my: set_pos.y - temp[i].pos.dy, mz: dz } })
                                    })
                                    taskQueue.push(() => {
                                        run_command_player(player, `structure load "DA_Copy:${temp[i].UUID}" ${temp[i].pos.mx + set_pos.x} ${set_pos.y - temp[i].pos.dy} ${temp[i].pos.mz + set_pos.z}`);
                                        run_command_player(player, `tickingarea remove DA_temp${this_tickingarea_index}`);
                                    })
                                }
                                let message_decoration = ["---", "#--", "##-", "###", "-##", "--#", "---"];
                                function processQueue() {
                                    if (taskQueue.length === 0) {
                                        run_command_player(player, `title @s actionbar §o§b§l完了！`);
                                        task_finish_func(this_tickingarea_index);
                                        return;
                                    } else {
                                        let is_string = false;
                                        if (typeof taskQueue[0] == "string") {
                                            if (String(taskQueue[0]).indexOf("wait for test block:") != -1) {
                                                is_string = true;
                                                const [x, y, z] = String(taskQueue[0]).split("wait for test block:")[1].split(" ");
                                                let block = false;
                                                try {
                                                    block = (player.dimension).getBlock({ x: Math.floor(Number(x)), y: Math.floor(Number(y)), z: Math.floor(Number(z)) });
                                                } catch (e) {
                                                    task_finish_func(this_tickingarea_index);
                                                    run_command_player(player, `say §cDA-Error(Please reload) => ${e}`);
                                                }
                                                if (block != undefined) {
                                                    taskQueue.shift();
                                                }
                                            }
                                        }
                                        if (!is_string) {
                                            const task = taskQueue.shift();
                                            task();
                                        }
                                        const decoration_index = (taskQueue.length % message_decoration.length);
                                        if (DA_now_tasking[this_task_id].situation == "Stopping") {
                                            taskQueue.splice(0, Infinity);
                                        }
                                        run_command_player(player, `title @s actionbar §e${message_decoration[decoration_index]}§o§6残り:${taskQueue.length}個§r§e${message_decoration[decoration_index]}`);
                                        if (taskQueue.length % 100 == 0 && taskQueue.length > 10) {
                                            run_command_player(player, `title @s actionbar §o§6-=-処理待ち-=-`);
                                            system.runTimeout(processQueue, (DA_save_on_world[player.id]["Waiting_drawing"] ?? 60));
                                        } else {
                                            system.runTimeout(processQueue, (DA_save_on_world[player.id]["Connect_Pass"] ?? 1));
                                        }
                                    };
                                }
                                processQueue();
                            })
                        } else {
                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => ペーストするものが有りません。"}]}`);
                            task_finish_func(this_tickingarea_index);
                        }
                    } else if (commands[0] == ".replace") {
                        if (check_selected_pos(player)) {
                            system.run(() => {
                                try {
                                    if (commands[1] == "let" || commands[2] == "let") {
                                        player_setting_data(player);
                                        DA_data[player.id]["let"].type = "replace";
                                        DA_data[player.id]["let"]["RC_pos"] = RC_pos;
                                        if (commands[1] == "let" && commands[2] == "let") {
                                            DA_data[player.id]["let"]["replace_type"] = 3;
                                            DA_data[player.id]["let"]["replace_select_num"] = 0;
                                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => 変換前のブロックを置いた後、変換後のブロックを置いてください。"}]}`)
                                        } else if (commands[1] == "let") {
                                            DA_data[player.id]["let"]["replace_type"] = 1;
                                            DA_data[player.id]["let"]["replace_block"] = commands[2];
                                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => 変換後のブロックを置いてください。"}]}`)
                                        } else if (commands[2] == "let") {
                                            DA_data[player.id]["let"]["replace_type"] = 2;
                                            DA_data[player.id]["let"]["replace_block"] = commands[1];
                                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => 変換したいブロックを置いてください。"}]}`)
                                        }
                                        task_finish_func(this_tickingarea_index);
                                    } else {
                                        let plus_x = null;
                                        let plus_z = null;
                                        let this_undo_index = null;
                                        const e = (min_pos, max_pos, x, y, z, taskQueue) => {
                                            const plus_y = ((max_pos.y - y) < 6) ? max_pos.y - y : 6;
                                            run_command_player(player, `fill ${x} ${y} ${z} ${x + plus_x} ${y + plus_y} ${z + plus_z} ${commands[1]} replace ${commands[2]}`);
                                            check_is_success(player, Math.floor(x + plus_x / 2), Math.floor(y + plus_y / 2), Math.floor(z + plus_z / 2), e, taskQueue);
                                        }
                                        run_select_change(this_task_id, player, RC_pos, () => {
                                            DA_data[player.id]["undo"].push([]);
                                            this_undo_index = DA_data[player.id]["undo"].length - 1;
                                        }, (min_pos, max_pos, x, z, taskQueue) => {
                                            plus_x = ((max_pos.x - x) < (Nob_tp_ao - 1)) ? max_pos.x - x : (Nob_tp_ao - 1);
                                            plus_z = ((max_pos.z - z) < (Nob_tp_ao - 1)) ? max_pos.z - z : (Nob_tp_ao - 1);
                                            run_command_player(player, `tickingarea add ${x} ${min_pos.y} ${z} ${x + plus_x} ${max_pos.y} ${z + plus_z} DA_temp${this_tickingarea_index} true`);
                                            // taskQueue.unshift(`wait for test block:[${Math.floor(x + plus_x / 2)} ${Math.floor((min_pos.y + max_pos.y) / 2)} ${Math.floor(z + plus_z / 2)} ${Math.floor(x + plus_x)} ${Math.floor((min_pos.y))} ${Math.floor(z + plus_z)} ${Math.floor(x)} ${Math.floor(max_pos.y)} ${Math.floor(z)}]`);
                                            taskQueue.unshift(`wait for test block:[${Math.floor(x + plus_x)} ${Math.floor((min_pos.y))} ${Math.floor(z + plus_z)} ${Math.floor(x)} ${Math.floor(max_pos.y)} ${Math.floor(z)}]`);
                                        }, (min_pos, max_pos, x, z, taskQueue) => {
                                            const UUID = Get_UUID();
                                            run_command_player(player, `structure save "DA:${UUID}" ${x} ${min_pos.y} ${z} ${x + plus_x} ${max_pos.y} ${z + plus_z}`)
                                            DA_structures[UUID] = { x: x, y: min_pos.y, z: z, size: plus_x * (max_pos.y - min_pos.y) * plus_z, name: `DA:${UUID}`, player: { id: player.id, name: player.nameTag }, date: Get_now_date() };
                                            DA_data[player.id]["undo"][this_undo_index].unshift({ UUID: UUID, pos: { mx: x, my: min_pos.y, mz: z } })
                                        }, (min_pos, max_pos, x, y, z, taskQueue) => {
                                            e(min_pos, max_pos, x, y, z, taskQueue);
                                        }, (min_pos, max_pos, x, z, taskQueue) => {
                                            run_command_player(player, `tickingarea remove DA_temp${this_tickingarea_index}`);
                                        }, () => { }, () => {
                                            task_finish_func(this_tickingarea_index);
                                        })
                                    }
                                } catch (e) {
                                    run_command_player(player, `tellraw @s { "rawtext": [{ "text": "§cDA => 指定したブロックは無効です！" }] }`)
                                    run_command_player(player, `say => ${e}`);
                                    task_finish_func(this_tickingarea_index);
                                }
                            })
                            ev.cancel = true;
                        } else {
                            system.run(() => {
                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 範囲が選択されていません"}]}`);
                                task_finish_func(this_tickingarea_index);
                            })
                        }
                    } else if (commands[0] == ".rotate") {
                        if (check_selected_pos(player)) {
                            if (commands[1] == "90" || commands[1] == "180" || commands[1] == "270") {

                            } else if (commands[1] == "show" && (commands[2] == "90" || commands[2] == "180" || commands[2] == "270")) {
                                const pos = RC_pos;
                                const min_pos = {
                                    x: Math.min(pos.pos1.x, pos.pos2.x),
                                    y: Math.min(pos.pos1.y, pos.pos2.y),
                                    z: Math.min(pos.pos1.z, pos.pos2.z)
                                };
                                const max_pos = {
                                    x: Math.max(pos.pos1.x, pos.pos2.x),
                                    y: Math.max(pos.pos1.y, pos.pos2.y),
                                    z: Math.max(pos.pos1.z, pos.pos2.z)
                                };
                                const structure_arrays = [];
                                for (let z = max_pos.z; z >= min_pos.z; z--) {
                                    structure_arrays.push([]);
                                    for (let x = max_pos.x; x >= min_pos.x; x--) {
                                        structure_arrays[structure_arrays.length - 1].push(1);
                                    }
                                }
                                const rotated = rotate_array(structure_arrays, commands[2] ?? 90);
                                DA_data[player.id]["prediction"]["pos1"] = { x: min_pos.x, y: min_pos.y, z: min_pos.z };
                                DA_data[player.id]["prediction"]["pos2"] = { x: min_pos.x + (rotated[rotated.length - 1].length - 1), y: max_pos.y, z: min_pos.z + (rotated.length - 1) };
                                task_finish_func(this_tickingarea_index);
                                return;
                            } else {
                                task_finish_func(this_tickingarea_index);
                                return;
                            }
                            ev.cancel = true;
                            if (commands[1] == 180) {
                                DA_command(player, ".flip xz", ev, RES_RC_pos);
                                task_finish_func(this_tickingarea_index);
                                return;
                            }
                            DA_data[player.id]["undo"].push([]);
                            let this_undo_index = DA_data[player.id]["undo"].length - 1;
                            system.run(async () => {
                                const pos = RC_pos;
                                const min_pos = {
                                    x: Math.min(pos.pos1.x, pos.pos2.x),
                                    y: Math.min(pos.pos1.y, pos.pos2.y),
                                    z: Math.min(pos.pos1.z, pos.pos2.z)
                                };
                                const max_pos = {
                                    x: Math.max(pos.pos1.x, pos.pos2.x),
                                    y: Math.max(pos.pos1.y, pos.pos2.y),
                                    z: Math.max(pos.pos1.z, pos.pos2.z)
                                };
                                const taskQueue = [];
                                let tickingarea = { x: Infinity, z: Infinity };
                                const structure_arrays = [];
                                const undo_array = [];
                                const rotated_undo_array = [];
                                const chunk = 32;
                                let gz = max_pos.z;
                                function tick_loop_before() {
                                    return new Promise((resolve) => {
                                        async function one_tick_loop() {
                                            if (gz >= min_pos.z) {
                                                function two_tick_loop() {
                                                    let gx = max_pos.x;
                                                    return new Promise((res2) => {
                                                        function tick_loop() {
                                                            const z_percent = (1 - ((gz - min_pos.z) / (max_pos.z - min_pos.z)));
                                                            run_command_player(player, `title @s actionbar §o§b§l回転前情報取得中:${Math.floor((z_percent + ((1 - ((gx - min_pos.x) / (max_pos.x - min_pos.x))) * (chunk / (max_pos.z - min_pos.z)))) * 10000) / 100}%`);
                                                            if (gx >= min_pos.x) {
                                                                const minus_vec = { x: Math.min(gx - min_pos.x, chunk), z: Math.min(gz - min_pos.z, chunk) }
                                                                for (let z = (gz - minus_vec.z); z <= gz; z++) {
                                                                    if (structure_arrays[max_pos.z - z] == null) {
                                                                        structure_arrays[max_pos.z - z] = [];
                                                                    }
                                                                    for (let x = (gx - minus_vec.x); x <= gx; x++) {
                                                                        let is_undoed = false;
                                                                        for (let i = 0; i < undo_array.length; i++) {
                                                                            if (undo_array[i].x - x <= 63 && (undo_array[i].x >= x) && undo_array[i].z - z <= 63 && (undo_array[i].z >= z)) {
                                                                                is_undoed = true;
                                                                                break;
                                                                            }
                                                                        }
                                                                        if (!is_undoed) {
                                                                            const UUID = Get_UUID();
                                                                            undo_array.push({ x: x, z: z, UUID: UUID });
                                                                            taskQueue.push(() => {
                                                                                const dx = (x - 63 > min_pos.x) ? x - 63 : min_pos.x;
                                                                                const dz = (z - 63 > min_pos.z) ? z - 63 : min_pos.z;
                                                                                run_command_player(player, `structure save "DA:${UUID}" ${x} ${min_pos.y} ${z} ${dx} ${max_pos.y} ${dz}`);
                                                                                DA_structures[UUID] = { x: x, y: min_pos.y, z: z, size: (dx - x) * (max_pos.y - min_pos.y) * (dz - z), name: `DA:${UUID}`, player: { id: player.id, name: player.nameTag }, date: Get_now_date() };
                                                                                DA_data[player.id]["undo"][this_undo_index].push({ UUID: UUID, pos: { mx: Math.min(x, dx), my: min_pos.y, mz: Math.min(z, dz) } })
                                                                            })
                                                                        }
                                                                        const UUID = Get_UUID();
                                                                        structure_arrays[max_pos.z - z][max_pos.x - x] = ({ UUID: UUID, x: x, z: z });
                                                                        if (Math.abs(tickingarea.x - x) > 63 || Math.abs(tickingarea.z - z) > 63) {
                                                                            tickingarea = { x: x, z: z };
                                                                            taskQueue.push("next_stop");
                                                                            taskQueue.push(() => {
                                                                                run_command_player(player, `tickingarea remove DA_temp${this_tickingarea_index}`);
                                                                            })
                                                                            taskQueue.push(() => {
                                                                                run_command_player(player, `tickingarea add ${x - 63} ${min_pos.y} ${z - 63} ${x + 63} ${max_pos.y} ${z + 63} DA_temp${this_tickingarea_index} true`);
                                                                            })
                                                                        }
                                                                        taskQueue.push(() => {
                                                                            run_command_player(player, `structure save "DA:${UUID}" ${x} ${min_pos.y} ${z} ${x} ${max_pos.y} ${z}`);
                                                                            DA_structures[UUID] = { x: x, y: min_pos.y, z: z, size: max_pos.y - min_pos.y, name: `DA:${UUID}`, player: { id: player.id, name: player.nameTag }, date: Get_now_date() };
                                                                            if (commands[2] == "cut") {
                                                                                run_command_player(player, `fill ${x} ${min_pos.y} ${z} ${x} ${max_pos.y} ${z} air`);
                                                                            }
                                                                        })
                                                                    }
                                                                }
                                                                gx -= chunk;
                                                                system.runTimeout(tick_loop, DA_save_on_world[player.id]["Connect_Pass"]);
                                                            } else {
                                                                res2();
                                                            }
                                                        }
                                                        tick_loop();
                                                    })
                                                }
                                                await two_tick_loop();
                                                gz -= chunk;
                                                system.runTimeout(one_tick_loop, DA_save_on_world[player.id]["Connect_Pass"]);
                                            } else {
                                                resolve();
                                            }
                                        }
                                        one_tick_loop();
                                    })
                                }
                                await tick_loop_before();
                                // world.sendMessage(JSON.stringify(structure_arrays));
                                // return;
                                const rotated = rotate_array(structure_arrays, commands[1] ?? 90);
                                tickingarea = { x: Infinity, z: Infinity };
                                let az = 0
                                function tick_loop_after() {
                                    return new Promise((resolve) => {
                                        async function one_tick_loop() {
                                            if (az < rotated.length) {
                                                function two_tick_loop() {
                                                    let gx = 0;
                                                    return new Promise((res2) => {
                                                        function tick_loop() {
                                                            // run_command_player(player, `title @s actionbar §o§6§l回転後情報取得中:${Math.floor((az / rotated.length) * 10000) / 100}%`);
                                                            run_command_player(player, `title @s actionbar §o§6§l回転後情報取得中:${Math.floor((((chunk / rotated.length) * (gx / rotated[az].length)) + (az / rotated.length)) * 10000) / 100}%`);
                                                            if (gx < rotated[az].length) {
                                                                for (let z = az; z < az + chunk; z++) {
                                                                    for (let x = gx; x < gx + chunk; x++) {
                                                                        const jx = min_pos.x + x;
                                                                        const jz = min_pos.z + z;
                                                                        let is_undoed = false;
                                                                        for (let i = 0; i < rotated_undo_array.length; i++) {
                                                                            if (rotated_undo_array[i].x - jx <= 64 && rotated_undo_array[i].z - jz <= 64) {
                                                                                is_undoed = true;
                                                                                break;
                                                                            }
                                                                        }
                                                                        if (!is_undoed) {
                                                                            const UUID = Get_UUID();
                                                                            rotated_undo_array.push({ x: jx, z: jz, UUID: UUID });
                                                                            taskQueue.push(() => {
                                                                                const dx = (jx + 64 < (rotated[z].length - 1) + min_pos.x) ? jx + 64 : (rotated[z].length - 1) + min_pos.x;
                                                                                const dz = (jz + 64 < (rotated.length - 1) + min_pos.z) ? jz + 64 : (rotated.length - 1) + min_pos.z;
                                                                                run_command_player(player, `structure save "DA:${UUID}" ${jx} ${min_pos.y} ${jz} ${dx} ${max_pos.y} ${dz}`);
                                                                                DA_structures[UUID] = { x: jx, y: min_pos.y, z: jz, size: Math.abs(dx - jx) * (max_pos.y - min_pos.y) * Math.abs(dz - jz), name: `DA:${UUID}`, player: { id: player.id, name: player.nameTag }, date: Get_now_date() };
                                                                                DA_data[player.id]["undo"][this_undo_index].push({ UUID: UUID, pos: { mx: Math.min(jx, dx), my: min_pos.y, mz: Math.min(jz, dz) } })
                                                                            })
                                                                        }
                                                                        if (Math.abs(tickingarea.x - (min_pos.x + x)) > 63 || Math.abs(tickingarea.z - (min_pos.z + z)) > 63) {
                                                                            tickingarea = { x: min_pos.x + x, z: min_pos.z + z };
                                                                            taskQueue.push("next_stop");
                                                                            taskQueue.push(() => {
                                                                                run_command_player(player, `tickingarea remove DA_temp${this_tickingarea_index}`);
                                                                            })
                                                                            taskQueue.push(() => {
                                                                                run_command_player(player, `tickingarea add ${(min_pos.x + x) - 63} ${min_pos.y} ${(min_pos.z + z) - 63} ${(min_pos.x + x) + 63} ${max_pos.y} ${(min_pos.z + z) + 63} DA_temp${this_tickingarea_index} true`);
                                                                            })
                                                                        }
                                                                        taskQueue.push(() => {
                                                                            run_command_player(player, `structure load "DA:${rotated[z][x].UUID}" ${min_pos.x + x} ${min_pos.y} ${min_pos.z + z} ${Number(commands[1]) ?? 90}_degrees`);
                                                                            run_command_player(player, `structure delete "DA:${rotated[z][x].UUID}"`);
                                                                            delete DA_structures[rotated[z][x].UUID];
                                                                        })
                                                                    }
                                                                }
                                                                gx += chunk;
                                                                system.runTimeout(tick_loop, 1);
                                                            } else {
                                                                res2();
                                                            }
                                                        }
                                                        tick_loop();
                                                    })
                                                }
                                                await two_tick_loop();
                                                system.runTimeout(one_tick_loop, 1);
                                                az += chunk;
                                            } else {
                                                resolve();
                                            }
                                        }
                                        one_tick_loop();
                                    })
                                }
                                await tick_loop_after();


                                let message_decoration = ["---", "#--", "##-", "###", "-##", "--#", "---"];
                                let next_stop = 0;
                                function processQueue() {
                                    if (taskQueue.length === 0) {
                                        run_command_player(player, `title @s actionbar §o§b§l完了！`);
                                        task_finish_func(this_tickingarea_index);
                                        return;
                                    } else {
                                        for (let i = 0; i < 128; i++) {
                                            if (taskQueue.length > 0) {
                                                if (next_stop > -10) {
                                                    next_stop--;
                                                }
                                                const task = taskQueue.shift();
                                                if (task == "next_stop") {
                                                    next_stop = 2;
                                                } else if (task) {
                                                    task();
                                                    if (next_stop >= 0) {
                                                        i = 1000;
                                                        break;
                                                    }
                                                }
                                            } else {
                                                break;
                                            }
                                        }
                                        const decoration_index = (taskQueue.length % message_decoration.length);
                                        if (DA_now_tasking[this_task_id].situation == "Stopping") {
                                            taskQueue.splice(0, Infinity);
                                            for (let z = 0; z < rotated.length; z++) {
                                                for (let x = 0; x < rotated[z].length; x++) {
                                                    run_command_player(player, `structure delete "DA:${rotated[z][x].UUID}"`);
                                                    delete DA_structures[rotated[z][x].UUID]
                                                }
                                            }
                                        }
                                        run_command_player(player, `title @s actionbar §e${message_decoration[decoration_index]}§o§6残り:${taskQueue.length}個§r§e${message_decoration[decoration_index]}`);
                                        if (Math.floor(taskQueue.length / 100) % 20 == 0 && taskQueue.length > 10) {
                                            run_command_player(player, `title @s actionbar §o§6-=-処理待ち-=-`);
                                            system.runTimeout(processQueue, (DA_save_on_world[player.id]["Connect_Pass"] ?? 1));
                                        } else {
                                            system.runTimeout(processQueue, (DA_save_on_world[player.id]["Connect_Pass"] ?? 1));
                                        }
                                    };
                                }
                                processQueue();
                            });
                        } else {
                            system.run(() => {
                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 範囲が選択されていません"}]}`);
                                task_finish_func(this_tickingarea_index);
                            })
                        }
                    } else if (commands[0] == ".flip") {
                        if (check_selected_pos(player)) {
                            if (commands[1] == "x" || commands[1] == "z" || commands[1] == "xz") {

                            } else if (commands[1] == "show" && (commands[2] == "x" || commands[2] == "z" || commands[2] == "xz")) {
                                const pos = RC_pos;
                                const min_pos = {
                                    x: Math.min(pos.pos1.x, pos.pos2.x),
                                    y: Math.min(pos.pos1.y, pos.pos2.y),
                                    z: Math.min(pos.pos1.z, pos.pos2.z)
                                };
                                const max_pos = {
                                    x: Math.max(pos.pos1.x, pos.pos2.x),
                                    y: Math.max(pos.pos1.y, pos.pos2.y),
                                    z: Math.max(pos.pos1.z, pos.pos2.z)
                                };
                                const structure_arrays = [];
                                for (let z = max_pos.z; z >= min_pos.z; z--) {
                                    structure_arrays.push([]);
                                    for (let x = max_pos.x; x >= min_pos.x; x--) {
                                        structure_arrays[structure_arrays.length - 1].push(1);
                                    }
                                }
                                const fliped = flip(structure_arrays, commands[2] ?? "x");
                                DA_data[player.id]["prediction"]["pos1"] = { x: min_pos.x, y: min_pos.y, z: min_pos.z };
                                DA_data[player.id]["prediction"]["pos2"] = { x: min_pos.x + (fliped[fliped.length - 1].length - 1), y: max_pos.y, z: min_pos.z + (fliped.length - 1) };
                                task_finish_func(this_tickingarea_index);
                                return;
                            } else {
                                task_finish_func(this_tickingarea_index);
                                return;
                            }
                            ev.cancel = true;
                            DA_data[player.id]["undo"].push([]);
                            let this_undo_index = DA_data[player.id]["undo"].length - 1;
                            system.run(async () => {
                                const pos = RC_pos;
                                const min_pos = {
                                    x: Math.min(pos.pos1.x, pos.pos2.x),
                                    y: Math.min(pos.pos1.y, pos.pos2.y),
                                    z: Math.min(pos.pos1.z, pos.pos2.z)
                                };
                                const max_pos = {
                                    x: Math.max(pos.pos1.x, pos.pos2.x),
                                    y: Math.max(pos.pos1.y, pos.pos2.y),
                                    z: Math.max(pos.pos1.z, pos.pos2.z)
                                };
                                const taskQueue = [];
                                let tickingarea = { x: Infinity, z: Infinity };
                                const structure_arrays = [];
                                const undo_array = [];
                                const fliped_undo_array = [];
                                const chunk = 32;
                                function before_one_tick() {
                                    let gz = max_pos.z;
                                    return new Promise((resolve) => {
                                        async function one_tick_loop() {
                                            if (gz >= min_pos.z) {
                                                let gx = max_pos.x;
                                                function await_tick() {
                                                    return new Promise((res2) => {
                                                        function two_tick_loop() {
                                                            const z_percent = (1 - ((gz - min_pos.z) / (max_pos.z - min_pos.z)));
                                                            run_command_player(player, `title @s actionbar §o§b§l対称移動前情報取得中:${Math.floor((z_percent + ((1 - ((gx - min_pos.x) / (max_pos.x - min_pos.x))) * (chunk / (max_pos.z - min_pos.z)))) * 10000) / 100}%`);
                                                            if (gx >= min_pos.x) {
                                                                const minus_vec = { x: Math.min(gx - min_pos.x, chunk), z: Math.min(gz - min_pos.z, chunk) }
                                                                for (let z = (gz - minus_vec.z); z <= gz; z++) {
                                                                    if (structure_arrays[max_pos.z - z] == null) {
                                                                        structure_arrays[max_pos.z - z] = [];
                                                                    }
                                                                    for (let x = (gx - minus_vec.x); x <= gx; x++) {
                                                                        let is_undoed = false;
                                                                        for (let i = 0; i < undo_array.length; i++) {
                                                                            if (undo_array[i].x - x <= 63 && (undo_array[i].x >= x) && undo_array[i].z - z <= 63 && (undo_array[i].z >= z)) {
                                                                                is_undoed = true;
                                                                                break;
                                                                            }
                                                                        }
                                                                        if (!is_undoed) {
                                                                            const UUID = Get_UUID();
                                                                            undo_array.push({ x: x, z: z, UUID: UUID });
                                                                            taskQueue.push(() => {
                                                                                const dx = (x - 63 > min_pos.x) ? x - 63 : min_pos.x;
                                                                                const dz = (z - 63 > min_pos.z) ? z - 63 : min_pos.z;
                                                                                run_command_player(player, `structure save "DA:${UUID}" ${x} ${min_pos.y} ${z} ${dx} ${max_pos.y} ${dz}`);
                                                                                DA_structures[UUID] = { x: x, y: min_pos.y, z: z, size: Math.abs(dx - x) * (max_pos.y - min_pos.y) * Math.abs(dz - z), name: `DA:${UUID}`, player: { id: player.id, name: player.nameTag }, date: Get_now_date() };
                                                                                DA_data[player.id]["undo"][this_undo_index].push({ UUID: UUID, pos: { mx: Math.min(x, dx), my: min_pos.y, mz: Math.min(z, dz) } })
                                                                            })
                                                                        }
                                                                        const UUID = Get_UUID();
                                                                        structure_arrays[max_pos.z - z][max_pos.x - x] = ({ UUID: UUID, x: x, z: z });
                                                                        if (Math.abs(tickingarea.x - x) > 63 || Math.abs(tickingarea.z - z) > 63) {
                                                                            tickingarea = { x: x, z: z };
                                                                            taskQueue.push("next_stop");
                                                                            taskQueue.push(() => {
                                                                                run_command_player(player, `tickingarea remove DA_temp${this_tickingarea_index}`);
                                                                            })
                                                                            taskQueue.push(() => {
                                                                                run_command_player(player, `tickingarea add ${x - 63} ${min_pos.y} ${z - 63} ${x + 63} ${max_pos.y} ${z + 63} DA_temp${this_tickingarea_index} true`);
                                                                            })
                                                                            taskQueue.push(`wait for test block:${x} ${min_pos.y} ${z}`);
                                                                        }
                                                                        taskQueue.push(() => {
                                                                            run_command_player(player, `structure save "DA:${UUID}" ${x} ${min_pos.y} ${z} ${x} ${max_pos.y} ${z}`);
                                                                            DA_structures[UUID] = { x: x, y: min_pos.y, z: z, size: max_pos.y - min_pos.y, name: `DA:${UUID}`, player: { id: player.id, name: player.nameTag }, date: Get_now_date() };
                                                                            if (commands[2] == "cut") {
                                                                                run_command_player(player, `fill ${x} ${min_pos.y} ${z} ${x} ${max_pos.y} ${z} air`);
                                                                            }
                                                                        })
                                                                    }
                                                                }
                                                                gx -= chunk;
                                                                system.runTimeout(two_tick_loop, DA_save_on_world[player.id]["Connect_Pass"]);
                                                            } else {
                                                                res2();
                                                            }
                                                        }
                                                        two_tick_loop();
                                                    })
                                                }
                                                await await_tick();
                                                system.runTimeout(one_tick_loop, DA_save_on_world[player.id]["Connect_Pass"]);
                                                gz -= chunk;
                                            } else {
                                                resolve();
                                            }
                                        }
                                        one_tick_loop();
                                    })
                                }
                                await before_one_tick();
                                let fliped = flip(structure_arrays, commands[1] ?? "x");
                                if (commands[1] == "xz") {
                                    fliped = flip(flip(fliped, "x"), "z");
                                }
                                tickingarea = { x: Infinity, z: Infinity };
                                function after_one_tick() {
                                    let az = 0;
                                    return new Promise((resolve) => {
                                        async function one_tick_loop() {
                                            if (az < fliped.length) {
                                                let ax = 0;
                                                function await_tick() {
                                                    return new Promise((res2) => {
                                                        function two_tick_loop() {
                                                            run_command_player(player, `title @s actionbar §o§6§l対称移動後情報取得中:${Math.floor((((chunk / fliped.length) * (ax / fliped[az].length)) + (az / fliped.length)) * 10000) / 100}%`);
                                                            if (ax < fliped[az].length) {
                                                                for (let z = az; z < Math.min(fliped.length, az + chunk); z++) {
                                                                    for (let x = ax; x < Math.min(fliped[z].length, ax + chunk); x++) {
                                                                        const jx = min_pos.x + x;
                                                                        const jz = min_pos.z + z;
                                                                        let is_undoed = false;
                                                                        for (let i = 0; i < fliped_undo_array.length; i++) {
                                                                            if (fliped_undo_array[i].x - jx <= 64 && fliped_undo_array[i].z - jz <= 64) {
                                                                                is_undoed = true;
                                                                                break;
                                                                            }
                                                                        }
                                                                        if (!is_undoed) {
                                                                            const UUID = Get_UUID();
                                                                            fliped_undo_array.push({ x: jx, z: jz, UUID: UUID });
                                                                            taskQueue.push(() => {
                                                                                const dx = (jx + 64 < (fliped[z].length - 1) + min_pos.x) ? jx + 64 : (fliped[z].length - 1) + min_pos.x;
                                                                                const dz = (jz + 64 < (fliped.length - 1) + min_pos.z) ? jz + 64 : (fliped.length - 1) + min_pos.z;
                                                                                run_command_player(player, `structure save "DA:${UUID}" ${jx} ${min_pos.y} ${jz} ${dx} ${max_pos.y} ${dz}`);
                                                                                DA_structures[UUID] = { x: jx, y: min_pos.y, z: jz, size: Math.abs(dx - jx) * (max_pos.y - min_pos.y) * Math.abs(dz - jz), name: `DA:${UUID}`, player: { id: player.id, name: player.nameTag }, date: Get_now_date() };
                                                                                DA_data[player.id]["undo"][this_undo_index].push({ UUID: UUID, pos: { mx: Math.min(jx, dx), my: min_pos.y, mz: Math.min(jz, dz) } })
                                                                            })
                                                                        }
                                                                        if (Math.abs(tickingarea.x - (min_pos.x + x)) > 63 || Math.abs(tickingarea.z - (min_pos.z + z)) > 63) {
                                                                            tickingarea = { x: min_pos.x + x, z: min_pos.z + z };
                                                                            taskQueue.push("next_stop");
                                                                            taskQueue.push(() => {
                                                                                run_command_player(player, `tickingarea remove DA_temp${this_tickingarea_index}`);
                                                                            })
                                                                            taskQueue.push(() => {
                                                                                run_command_player(player, `tickingarea add ${(min_pos.x + x) - 63} ${min_pos.y} ${(min_pos.z + z) - 63} ${(min_pos.x + x) + 63} ${max_pos.y} ${(min_pos.z + z) + 63} DA_temp${this_tickingarea_index} true`);
                                                                            })
                                                                            taskQueue.push(`wait for test block:${min_pos.x + x} ${min_pos.y} ${min_pos.z + z}`);
                                                                        }
                                                                        taskQueue.push(() => {
                                                                            run_command_player(player, `structure load "DA:${fliped[z][x].UUID}" ${min_pos.x + x} ${min_pos.y} ${min_pos.z + z} 0_degrees ${commands[1] ?? "x"}`);
                                                                            run_command_player(player, `structure delete "DA:${fliped[z][x].UUID}"`);
                                                                            delete DA_structures[fliped[z][x].UUID]
                                                                        })
                                                                    }
                                                                }
                                                                ax += chunk;
                                                                system.runTimeout(two_tick_loop, 1);
                                                            } else {
                                                                res2();
                                                            }
                                                        }
                                                        two_tick_loop();
                                                    })
                                                }
                                                await await_tick();
                                                system.runTimeout(one_tick_loop, 1);
                                                az += chunk;
                                            } else {
                                                resolve();
                                            }
                                        }
                                        one_tick_loop();
                                    })
                                }
                                await after_one_tick();
                                let message_decoration = ["---", "#--", "##-", "###", "-##", "--#", "---"];
                                let next_stop = 0;
                                function processQueue() {
                                    if (taskQueue.length === 0) {
                                        run_command_player(player, `title @s actionbar §o§b§l完了！`);
                                        task_finish_func(this_tickingarea_index);
                                        return;
                                    } else {
                                        for (let i = 0; i < 128; i++) {
                                            if (taskQueue.length > 0) {
                                                if (typeof taskQueue[0] == "string") {
                                                    if (String(taskQueue[0]).indexOf("wait for test block:") != -1) {
                                                        const [x, y, z] = String(taskQueue[0]).split("wait for test block:")[1].split(" ");
                                                        let block = false;
                                                        try {
                                                            block = (player.dimension).getBlock({ x: Math.floor(Number(x)), y: Math.floor(Number(y)), z: Math.floor(Number(z)) });
                                                        } catch (e) {
                                                            task_finish_func(this_tickingarea_index);
                                                            run_command_player(player, `say §cDA-Error(Please reload) => ${e}`);
                                                        }
                                                        if (block != undefined) {
                                                            taskQueue.shift();
                                                        }
                                                        break;
                                                    }
                                                }
                                                if (next_stop > -10) {
                                                    next_stop--;
                                                }
                                                const task = taskQueue.shift();
                                                if (task == "next_stop") {
                                                    next_stop = 2;
                                                } else if (task) {
                                                    task();
                                                    if (next_stop >= 0) {
                                                        i = 1000;
                                                        break;
                                                    }
                                                }
                                            } else {
                                                break;
                                            }
                                        }
                                        const decoration_index = (taskQueue.length % message_decoration.length);
                                        if (DA_now_tasking[this_task_id].situation == "Stopping") {
                                            for (let z = 0; z < fliped.length; z++) {
                                                for (let x = 0; x < fliped[z].length; x++) {
                                                    run_command_player(player, `structure delete "DA:${fliped[z][x].UUID}"`);
                                                    delete DA_structures[fliped[z][x].UUID]
                                                }
                                            }
                                            taskQueue.splice(0, Infinity);
                                        }
                                        run_command_player(player, `title @s actionbar §e${message_decoration[decoration_index]}§o§6残り:${taskQueue.length}個§r§e${message_decoration[decoration_index]}`);
                                        if (Math.floor(taskQueue.length / 100) % 20 == 0 && taskQueue.length > 10) {
                                            run_command_player(player, `title @s actionbar §o§6-=-処理待ち-=-`);
                                            system.runTimeout(processQueue, (DA_save_on_world[player.id]["Connect_Pass"] ?? 1));
                                        } else {
                                            system.runTimeout(processQueue, (DA_save_on_world[player.id]["Connect_Pass"] ?? 1));
                                        }
                                    };
                                }
                                processQueue();
                            });
                        } else {
                            system.run(() => {
                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 範囲が選択されていません"}]}`);
                                task_finish_func(this_tickingarea_index);
                            })
                        }
                    } else if (commands[0] == ".flip2") {
                        if (check_selected_pos(player)) {
                            if (commands[1] == "x" || commands[1] == "z" || commands[1] == "xz") {

                            } else if (commands[1] == "show" && (commands[2] == "x" || commands[2] == "z" || commands[2] == "xz")) {
                                const pos = RC_pos;
                                const min_pos = {
                                    x: Math.min(pos.pos1.x, pos.pos2.x),
                                    y: Math.min(pos.pos1.y, pos.pos2.y),
                                    z: Math.min(pos.pos1.z, pos.pos2.z)
                                };
                                const max_pos = {
                                    x: Math.max(pos.pos1.x, pos.pos2.x),
                                    y: Math.max(pos.pos1.y, pos.pos2.y),
                                    z: Math.max(pos.pos1.z, pos.pos2.z)
                                };
                                const structure_arrays = [];
                                for (let z = max_pos.z; z >= min_pos.z; z--) {
                                    structure_arrays.push([]);
                                    for (let x = max_pos.x; x >= min_pos.x; x--) {
                                        structure_arrays[structure_arrays.length - 1].push(1);
                                    }
                                }
                                const fliped = flip(structure_arrays, commands[2] ?? "x");
                                DA_data[player.id]["prediction"]["pos1"] = { x: min_pos.x, y: min_pos.y, z: min_pos.z };
                                DA_data[player.id]["prediction"]["pos2"] = { x: min_pos.x + (fliped[fliped.length - 1].length - 1), y: max_pos.y, z: min_pos.z + (fliped.length - 1) };
                                task_finish_func(this_tickingarea_index);
                                return;
                            } else {
                                task_finish_func(this_tickingarea_index);
                                return;
                            }
                            ev.cancel = true;
                            DA_data[player.id]["undo"].push([]);
                            let this_undo_index = DA_data[player.id]["undo"].length - 1;
                            system.run(async () => {
                                const pos = RC_pos;
                                const min_pos = {
                                    x: Math.min(pos.pos1.x, pos.pos2.x),
                                    y: Math.min(pos.pos1.y, pos.pos2.y),
                                    z: Math.min(pos.pos1.z, pos.pos2.z)
                                };
                                const max_pos = {
                                    x: Math.max(pos.pos1.x, pos.pos2.x),
                                    y: Math.max(pos.pos1.y, pos.pos2.y),
                                    z: Math.max(pos.pos1.z, pos.pos2.z)
                                };
                                const taskQueue = [];
                                let tickingarea = { x: Infinity, z: Infinity };
                                const undo_array = [];
                                const fliped_undo_array = [];
                                const chunk = 64;
                                const structure_arrays = [];
                                let WI = 0;
                                const zChunks = Array.from(
                                    { length: Math.ceil((max_pos.z - min_pos.z + 1) / chunk) },
                                    (_, i) => max_pos.z - i * chunk
                                );
                                const xChunks = Array.from(
                                    { length: Math.ceil((max_pos.x - min_pos.x + 1) / chunk) },
                                    (_, i) => max_pos.x - i * chunk
                                );
                                let chunks_index = { x: 0, z: 0 };
                                zChunks.map(gz => {
                                    xChunks.map(gx => {
                                        const minus_vec = {
                                            x: Math.min(gx - min_pos.x, chunk),
                                            z: Math.min(gz - min_pos.z, chunk)
                                        };
                                        const zRange = Array.from(
                                            { length: minus_vec.z + 1 },
                                            (_, i) => (gz - minus_vec.z) + i
                                        );
                                        const xRange = Array.from(
                                            { length: minus_vec.x + 1 },
                                            (_, i) => (gx - minus_vec.x) + i
                                        );
                                        zRange.map(z => {
                                            const idxZ = max_pos.z - z;
                                            structure_arrays[idxZ] = structure_arrays[idxZ] || [];
                                            xRange.map(x => {
                                                structure_arrays[idxZ][max_pos.x - x] = { index: WI, x: max_pos.x - x, z: idxZ, cx: chunks_index.x, cz: chunks_index.z };
                                            });
                                        });
                                        WI++;
                                        chunks_index.x++;
                                    });
                                    chunks_index.x = 0;
                                    chunks_index.z++;
                                });
                                let fliped = flip(structure_arrays, commands[1] ?? "x");
                                const visited_chunks = [];
                                const UUIDS = [];
                                let message_decoration = ["---", "#--", "##-", "###", "-##", "--#", "---"];
                                function flip_tick_loop() {
                                    return new Promise((resolve) => {
                                        let z = 0;
                                        async function z_loop() {
                                            if (z < structure_arrays.length) {
                                                for (let x = 0; x < structure_arrays[z].length; x += chunk) {
                                                    const this_x = Number(String(x));
                                                    const this_z = Number(String(z));
                                                    if (visited_chunks.indexOf(`${structure_arrays[z][x].index} => ${fliped[z][x].index}`) === -1) {
                                                        run_command_player(player, `title @s actionbar §r§e${message_decoration[z % (message_decoration.length)]}§6移動前情報取得 : §l${Math.min(Math.floor((((z / structure_arrays.length) * 2 + (x / structure_arrays[z].length * (chunk / structure_arrays.length)))) * 10000) / 100, 100)}%§r§e${message_decoration[z % (message_decoration.length)]}`)
                                                        visited_chunks.push(`${structure_arrays[z][x].index} => ${fliped[z][x].index}`);
                                                        visited_chunks.push(`${fliped[z][x].index} => ${structure_arrays[z][x].index}`);
                                                        const lip = {
                                                            x: ((chunk - (fliped[0].length % chunk)) % chunk),
                                                            z: ((chunk - (fliped.length % chunk)) % chunk)
                                                        };
                                                        const ref_pos = {
                                                            x2: min_pos.x + (fliped[z][x].cx * chunk),
                                                            z2: min_pos.z + (fliped[z][x].cz * chunk),
                                                        };
                                                        const UUID_1 = Get_UUID();
                                                        const UUID_2 = Get_UUID();
                                                        const xz_Change = {
                                                            x1: ((min_pos.x + this_x + (chunk - 1) > max_pos.x) || commands[1] === "x"),
                                                            z1: ((min_pos.z + this_z + (chunk - 1) > max_pos.z) || commands[1] === "z"),
                                                            x2: ((ref_pos.x2 + (chunk - 1) > max_pos.x) || commands[1] === "x"),
                                                            z2: ((ref_pos.z2 + (chunk - 1) > max_pos.z) || commands[1] === "z"),
                                                        };
                                                        const str_pos = {
                                                            s: [`${min_pos.x + this_x} ${min_pos.y} ${min_pos.z + this_z} `, `${Math.min(min_pos.x + this_x + (chunk - 1), max_pos.x)} ${max_pos.y} ${Math.min(min_pos.z + this_z + (chunk - 1), max_pos.z)}`],
                                                            f: [`${ref_pos.x2} ${min_pos.y} ${ref_pos.z2}`, `${Math.min(ref_pos.x2 + (chunk - 1), max_pos.x)} ${max_pos.y} ${Math.min(ref_pos.z2 + (chunk - 1), max_pos.z)}`]
                                                        }
                                                        const s_uuid_json_pos_0 = pos_string_to_json(str_pos.s[0]);
                                                        const s_uuid_json_pos_1 = pos_string_to_json(str_pos.s[1]);
                                                        const f_uuid_json_pos_0 = pos_string_to_json(str_pos.f[0]);
                                                        const f_uuid_json_pos_1 = pos_string_to_json(str_pos.f[1]);
                                                        const undo_pos = {
                                                            s_min: { mx: Math.min(s_uuid_json_pos_0.x, s_uuid_json_pos_1.x), my: Math.min(s_uuid_json_pos_0.y, s_uuid_json_pos_1.y), mz: Math.min(s_uuid_json_pos_0.z, s_uuid_json_pos_1.z) },
                                                            f_min: { mx: Math.min(f_uuid_json_pos_0.x, f_uuid_json_pos_1.x), my: Math.min(f_uuid_json_pos_0.y, f_uuid_json_pos_1.y), mz: Math.min(f_uuid_json_pos_0.z, f_uuid_json_pos_1.z) }
                                                        }
                                                        run_command_player(player, `tickingarea remove DA_temp${this_tickingarea_index}`);
                                                        await await_one_tick();
                                                        run_command_player(player, `tickingarea add ${str_pos.s[0]} ${str_pos.s[1]} DA_temp${this_tickingarea_index}`);
                                                        await wait_for_load(player, pos_string_to_json(str_pos.s[0]), pos_string_to_json(str_pos.s[1]));
                                                        run_command_player(player, `structure save "DA:${UUID_1}" ${str_pos.s[0]} ${str_pos.s[1]}`);
                                                        DA_data[player.id]["undo"][this_undo_index].push({ UUID: UUID_1, pos: undo_pos.s_min })
                                                        await await_one_tick();
                                                        run_command_player(player, `tickingarea remove DA_temp${this_tickingarea_index}`);
                                                        await await_one_tick();
                                                        run_command_player(player, `tickingarea add ${str_pos.f[0]} ${str_pos.f[1]} DA_temp${this_tickingarea_index}`);
                                                        await wait_for_load(player, pos_string_to_json(str_pos.f[0]), pos_string_to_json(str_pos.f[1]));
                                                        run_command_player(player, `structure save "DA:${UUID_2}" ${str_pos.f[0]} ${str_pos.f[1]}`);
                                                        DA_data[player.id]["undo"][this_undo_index].push({ UUID: UUID_2, pos: undo_pos.f_min })
                                                        await await_one_tick();
                                                        UUIDS.push(JSON.parse(JSON.stringify([
                                                            { UUID: UUID_1, x: ref_pos.x2 - ((xz_Change.x1) ? 0 : lip.x), y: min_pos.y, z: ref_pos.z2 - ((xz_Change.z1) ? 0 : lip.z) },
                                                            { UUID: UUID_2, x: min_pos.x - ((xz_Change.x2) ? 0 : lip.x) + this_x, y: min_pos.y, z: min_pos.z - ((xz_Change.z2) ? 0 : lip.z) + this_z }
                                                        ])));
                                                    }
                                                }
                                                z += chunk;
                                                system.runTimeout(z_loop, 1);
                                            } else {
                                                resolve();
                                            }
                                        }
                                        z_loop();
                                    });
                                }
                                await flip_tick_loop();
                                const psi = Number(String(UUIDS.length));
                                function load_uuids() {
                                    return new Promise((resolve) => {
                                        async function tick_UUID() {
                                            run_command_player(player, `title @s actionbar §6§l出力中 : ${Math.floor((1 - (UUIDS.length / psi)) * 10000) / 100}%`)
                                            if (UUIDS.length > 0) {
                                                const this_UUID = UUIDS.shift();
                                                const TU = [
                                                    `${this_UUID[0].x} ${this_UUID[0].y} ${this_UUID[0].z}`,
                                                    `${this_UUID[0].x + chunk} ${max_pos.y} ${this_UUID[0].z + chunk}`,
                                                    `${this_UUID[1].x} ${this_UUID[1].y} ${this_UUID[1].z}`,
                                                    `${this_UUID[1].x + chunk} ${max_pos.y} ${this_UUID[1].z + chunk}`
                                                ]
                                                run_command_player(player, `tickingarea remove DA_temp${this_tickingarea_index}`);
                                                await await_one_tick();
                                                run_command_player(player, `tickingarea add ${TU[0]} ${TU[1]} DA_temp${this_tickingarea_index}`);
                                                await wait_for_load(player, pos_string_to_json(`${TU[0]}`), pos_string_to_json(`${TU[1]}`));
                                                run_command_player(player, `structure load "DA:${this_UUID[0].UUID}" ${TU[0]} 0_degrees ${commands[1] ?? "x"}`);
                                                await await_one_tick();
                                                // run_command_player(player, `structure delete "DA:${this_UUID[0].UUID}"`);
                                                run_command_player(player, `tickingarea remove DA_temp${this_tickingarea_index}`);
                                                await await_one_tick();
                                                run_command_player(player, `tickingarea add ${TU[2]} ${TU[3]} DA_temp${this_tickingarea_index}`);
                                                await wait_for_load(player, pos_string_to_json(`${TU[2]}`), pos_string_to_json(`${TU[3]}`));
                                                run_command_player(player, `structure load "DA:${this_UUID[1].UUID}" ${TU[2]} 0_degrees ${commands[1] ?? "x"}`);
                                                await await_one_tick();
                                                // run_command_player(player, `structure delete "DA:${this_UUID[1].UUID}"`);
                                                system.runTimeout(tick_UUID, 1);
                                            } else {
                                                resolve();
                                            }
                                        }
                                        tick_UUID();
                                    })
                                }
                                await load_uuids();
                                task_finish_func(this_tickingarea_index);
                            })
                        } else {
                            system.run(() => {
                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 範囲が選択されていません"}]}`);
                                task_finish_func(this_tickingarea_index);
                            })
                        }
                    } else if (commands[0] == ".ball") {
                        if (check_selected_pos(player)) {
                            if (Number(commands[1]) > 0 || commands[1] == "auto") {

                            } else if (commands[1] == "show" && (Number(commands[2]) > 0 || commands[2] == "auto")) {
                                const pos = RC_pos;
                                const radius = (commands[2] == "auto") ? Math.round(Math.min(Math.min(Math.abs(pos.pos2.x - pos.pos1.x), Math.abs(pos.pos2.z - pos.pos1.z)), Math.abs(pos.pos2.y - pos.pos1.y)) / 2) : commands[2];
                                const center_pos = {
                                    x: Math.floor((pos.pos1.x + pos.pos2.x) / 2),
                                    y: Math.floor((pos.pos1.y + pos.pos2.y) / 2),
                                    z: Math.floor((pos.pos1.z + pos.pos2.z) / 2),
                                }
                                DA_data[player.id]["prediction"]["type"] = "ball";
                                DA_data[player.id]["prediction"]["pos"] = ((commands[2] == "auto") ? center_pos : pos.pos1);
                                DA_data[player.id]["prediction"]["r"] = Number(radius);
                                task_finish_func(this_tickingarea_index);
                                return;
                            } else {
                                system.run(() => {
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 無効な構文です"}]}`);
                                })
                                task_finish_func(this_tickingarea_index);
                                return;
                            }
                            const type = commands[3] ?? "fill";
                            ev.cancel = true;
                            if (commands[2] == "let") {
                                DA_data[player.id]["let"]["type"] = "ball";
                                DA_data[player.id]["let"]["RC_pos"] = RC_pos;
                                DA_data[player.id]["let"]["parameter"] = ` ${type}`;
                                DA_data[player.id]["let"]["radius"] = commands[1];
                                system.run(() => {
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => 球を作りたいブロックを置いてください。"}]}`)
                                })
                                task_finish_func(this_tickingarea_index);
                                return;
                            }
                            const pos = RC_pos;
                            const radius = (commands[1] == "auto") ? Math.round(Math.min(Math.min(Math.abs(pos.pos2.x - pos.pos1.x), Math.abs(pos.pos2.z - pos.pos1.z)), Math.abs(pos.pos2.y - pos.pos1.y)) / 2) : commands[1];
                            const center_pos = {
                                x: Math.floor((pos.pos1.x + pos.pos2.x) / 2),
                                y: Math.floor((pos.pos1.y + pos.pos2.y) / 2),
                                z: Math.floor((pos.pos1.z + pos.pos2.z) / 2),
                            }
                            DA_data[player.id]["undo"].push([]);
                            let this_undo_index = DA_data[player.id]["undo"].length - 1;
                            system.run(async () => {
                                let message_decoration = ["---", "#--", "##-", "###", "-##", "--#", "---"];
                                let next_stop = 0;
                                const min_pos = {
                                    x: (((commands[1] == "auto") ? center_pos.x : pos.pos1.x) - Number(radius)),
                                    y: (((commands[1] == "auto") ? center_pos.y : pos.pos1.y) - Number(radius)),
                                    z: (((commands[1] == "auto") ? center_pos.z : pos.pos1.z) - Number(radius))
                                };
                                const max_pos = {
                                    x: ((commands[1] == "auto") ? center_pos.x : pos.pos1.x) + Number(radius),
                                    y: ((commands[1] == "auto") ? center_pos.y : pos.pos1.y) + Number(radius),
                                    z: ((commands[1] == "auto") ? center_pos.z : pos.pos1.z) + Number(radius)
                                };
                                const taskQueue = [];
                                let tickingarea = { x: Infinity, z: Infinity };
                                const undo_array = [];
                                let rest_z = max_pos.z;
                                function processQueue() {
                                    return new Promise((resolve) => {
                                        function processQueue_child() {
                                            if (taskQueue.length === 0) {
                                                resolve();
                                                return;
                                            } else {
                                                for (let i = 0; i < 128; i++) {
                                                    if (taskQueue.length > 0) {
                                                        if (typeof taskQueue[0] == "string") {
                                                            if (String(taskQueue[0]).indexOf("wait for test block:") != -1) {
                                                                const [x, y, z] = String(taskQueue[0]).split("wait for test block:")[1].split(" ");
                                                                let block = false;
                                                                try {
                                                                    block = (player.dimension).getBlock({ x: Math.floor(Number(x)), y: Math.floor(Number(y)), z: Math.floor(Number(z)) });
                                                                } catch (e) {
                                                                    task_finish_func(this_tickingarea_index);
                                                                    run_command_player(player, `say §cDA-Error(Please reload) => ${e}`);
                                                                }
                                                                if (block != undefined) {
                                                                    taskQueue.shift();
                                                                }
                                                                break;
                                                            }
                                                        }
                                                        if (next_stop > -10) {
                                                            next_stop--;
                                                        }
                                                        const task = taskQueue.shift();
                                                        if (task == "next_stop") {
                                                            next_stop = 2;
                                                        } else if (task) {
                                                            task();
                                                            if (next_stop >= 0) {
                                                                i = 1000;
                                                                break;
                                                            }
                                                        }
                                                    } else {
                                                        break;
                                                    }
                                                }
                                                const decoration_index = (taskQueue.length % message_decoration.length);
                                                if (DA_now_tasking[this_task_id].situation == "Stopping") {
                                                    taskQueue.splice(0, Infinity);
                                                }
                                                run_command_player(player, `title @s actionbar §e${message_decoration[decoration_index]}§o§6残り:${taskQueue.length}個§r§e${message_decoration[decoration_index]}\n.　　　　§b${max_pos.z - min_pos.z - rest_z}/${max_pos.z - min_pos.z} (${Math.floor((max_pos.z - min_pos.z - rest_z) / (max_pos.z - min_pos.z) * 100)}%)　　　　.`);
                                                if (Math.floor(taskQueue.length / 100) % 20 == 0 && taskQueue.length > 10) {
                                                    run_command_player(player, `title @s actionbar §o§6-=-処理待ち-=-`);
                                                    system.runTimeout(processQueue_child, 1);
                                                } else {
                                                    system.runTimeout(processQueue_child, 1);
                                                }
                                            };
                                        }
                                        processQueue_child();
                                    })
                                }
                                async function in_other(z) {
                                    for (let x = max_pos.x; x >= min_pos.x; x--) {
                                        let is_undoed = false;
                                        for (let i = 0; i < undo_array.length; i++) {
                                            if (undo_array[i].x - x <= 63 && (undo_array[i].x >= x) && undo_array[i].z - z <= 63 && (undo_array[i].z >= z)) {
                                                is_undoed = true;
                                                break;
                                            }
                                        }
                                        if (!is_undoed) {
                                            const UUID = Get_UUID();
                                            undo_array.push({ x: x, z: z, UUID: UUID });
                                            taskQueue.push(() => {
                                                const dx = (x - 63 > min_pos.x) ? x - 63 : min_pos.x;
                                                const dz = (z - 63 > min_pos.z) ? z - 63 : min_pos.z;
                                                run_command_player(player, `structure save "DA:${UUID}" ${x} ${min_pos.y} ${z} ${dx} ${max_pos.y} ${dz}`);
                                                DA_structures[UUID] = { x: x, y: min_pos.y, z: z, size: Math.abs(dx - x) * (max_pos.y - min_pos.y) * Math.abs(dz - z), name: `DA:${UUID}`, player: { id: player.id, name: player.nameTag }, date: Get_now_date() };
                                                DA_data[player.id]["undo"][this_undo_index].push({ UUID: UUID, pos: { mx: Math.min(x, dx), my: min_pos.y, mz: Math.min(z, dz) } })
                                            })
                                        }
                                        if (Math.abs(tickingarea.x - x) > 63 || Math.abs(tickingarea.z - z) > 63) {
                                            tickingarea = { x: x, z: z };
                                            taskQueue.push("next_stop");
                                            taskQueue.push(() => {
                                                run_command_player(player, `tickingarea remove DA_temp${this_tickingarea_index}`);
                                            })
                                            taskQueue.push(() => {
                                                run_command_player(player, `tickingarea add ${x - 63} ${min_pos.y} ${z - 63} ${x + 63} ${max_pos.y} ${z + 63} DA_temp${this_tickingarea_index} true`);
                                            })
                                            taskQueue.push(`wait for test block:${x} ${min_pos.y} ${z}`);
                                        }
                                        for (let y = min_pos.y; y < max_pos.y; y++) {
                                            const dx = x - ((commands[1] == "auto") ? center_pos.x : pos.pos1.x);
                                            const dy = y - ((commands[1] == "auto") ? center_pos.y : pos.pos1.y);
                                            const dz = z - ((commands[1] == "auto") ? center_pos.z : pos.pos1.z);
                                            if (type == "fill") {
                                                if (dx * dx + dy * dy + dz * dz < (Number(radius) * Number(radius))) {
                                                    const e = () => {
                                                        rest_z = z - min_pos.z;
                                                        run_command_player(player, `setblock ${x} ${y} ${z} ${commands[2]}`);
                                                        check_is_success(player, x, y, z, e, taskQueue);
                                                    }
                                                    taskQueue.push(e);
                                                }
                                            } else if (type == "outline") {
                                                if (Math.floor(dx * dx + dy * dy + dz * dz) >= (Number(radius - 1) * Number(radius - 1)) && Math.floor(dx * dx + dy * dy + dz * dz) < (Number(radius) * Number(radius))) {
                                                    const e = () => {
                                                        rest_z = z - min_pos.z;
                                                        run_command_player(player, `setblock ${x} ${y} ${z} ${commands[2]}`);
                                                        check_is_success(player, x, y, z, e, taskQueue);
                                                    }
                                                    taskQueue.push(e);
                                                }
                                            }
                                        }
                                        if (taskQueue.length > Math.pow(2, 14) && radius > 32) {
                                            await processQueue();
                                        }
                                    }
                                }
                                if (radius > 32) {
                                    let z = max_pos.z;
                                    const PR_function = () => {
                                        return new Promise((resolve) => {
                                            async function one_tick_loop() {
                                                if (z >= min_pos.z) {
                                                    await in_other(z);
                                                    system.runTimeout(one_tick_loop, 1);
                                                } else {
                                                    resolve();
                                                    return;
                                                }
                                                z--;
                                            }
                                            one_tick_loop();
                                        })
                                    }
                                    await PR_function();
                                    await processQueue();
                                    run_command_player(player, `title @s actionbar §l§b完了！`);
                                    task_finish_func(this_tickingarea_index);
                                } else {
                                    for (let z = max_pos.z; z >= min_pos.z; z--) {
                                        await in_other(z);
                                    }
                                    await processQueue();
                                    task_finish_func(this_tickingarea_index);
                                }
                            });
                        } else {
                            system.run(() => {
                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 範囲が選択されていません"}]}`);
                                task_finish_func(this_tickingarea_index);
                            })
                        }
                    } else if (commands[0] == ".circle") {
                        if (check_selected_pos(player)) {
                            if (Number(commands[1]) > 0 || commands[1] == "auto") {

                            } else if (commands[1] == "show" && (Number(commands[2]) > 0 || commands[2] == "auto")) {
                                const pos = RC_pos;
                                const radius = (commands[2] == "auto") ? Math.round(Math.min(Math.abs(pos.pos2.x - pos.pos1.x), Math.abs(pos.pos2.z - pos.pos1.z)) / 2) : commands[2];
                                const center_pos = {
                                    x: Math.floor((pos.pos1.x + pos.pos2.x) / 2),
                                    y: Math.floor((pos.pos1.y + pos.pos2.y) / 2),
                                    z: Math.floor((pos.pos1.z + pos.pos2.z) / 2),
                                }
                                const min_pos = {
                                    x: ((commands[2] == "auto") ? center_pos.x : pos.pos1.x),
                                    y: Math.min(pos.pos1.y, pos.pos2.y),
                                    z: ((commands[2] == "auto") ? center_pos.z : pos.pos1.z)
                                };
                                const max_pos = {
                                    x: ((commands[2] == "auto") ? center_pos.x : pos.pos1.x),
                                    y: Math.max(pos.pos2.y, pos.pos1.y),
                                    z: ((commands[2] == "auto") ? center_pos.z : pos.pos1.z)
                                };
                                DA_data[player.id]["prediction"]["type"] = "circle";
                                DA_data[player.id]["prediction"]["min_pos"] = min_pos;
                                DA_data[player.id]["prediction"]["max_pos"] = max_pos;
                                DA_data[player.id]["prediction"]["r"] = Number(radius);
                                task_finish_func(this_tickingarea_index);
                                return;
                            } else {
                                system.run(() => {
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 無効な構文です"}]}`);
                                })
                                task_finish_func(this_tickingarea_index);
                                return;
                            }
                            const type = (commands[3] == null || commands[3] == "" || commands[3] == undefined) ? "fill" : commands[3];
                            const pos = RC_pos;
                            const radius = (commands[1] == "auto") ? Math.round(Math.min(Math.abs(pos.pos2.x - pos.pos1.x), Math.abs(pos.pos2.z - pos.pos1.z)) / 2) : commands[1];
                            const center_pos = {
                                x: Math.floor((pos.pos1.x + pos.pos2.x) / 2),
                                y: Math.floor((pos.pos1.y + pos.pos2.y) / 2),
                                z: Math.floor((pos.pos1.z + pos.pos2.z) / 2),
                            }
                            ev.cancel = true;
                            let bold = 0;
                            if (typeof Number(commands[4]) == "number" && commands[4] != null) {
                                if (commands[4] != null && Number(commands[4]) != NaN && commands[4] != "" && commands[4] != 0) {
                                    bold = Math.floor(Number(commands[4] - 1));
                                    if (bold > Number(radius) || bold <= 1) {
                                        system.run(() => {
                                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 外周は2ブロック以上・円の半径以下の太さのみ対応しています。"}]}`)
                                        })
                                        task_finish_func(this_tickingarea_index);
                                        return;
                                    }
                                }
                            }
                            if (commands[2] == "let") {
                                DA_data[player.id]["let"]["type"] = "circle";
                                DA_data[player.id]["let"]["RC_pos"] = RC_pos;
                                DA_data[player.id]["let"]["parameter"] = `${type}`;
                                DA_data[player.id]["let"]["radius"] = commands[1];
                                DA_data[player.id]["let"]["bold"] = (bold == 0 ? bold : bold + 1);
                                system.run(() => {
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => 円を作りたいブロックを置いてください。"}]}`)
                                })
                                task_finish_func(this_tickingarea_index);
                                return;
                            }
                            DA_data[player.id]["undo"].push([]);
                            let this_undo_index = DA_data[player.id]["undo"].length - 1;
                            system.run(async () => {
                                run_command_player(player, `title @s actionbar §l§6計算中・・・`);
                                let message_decoration = ["---", "#--", "##-", "###", "-##", "--#", "---"];
                                let next_stop = 0;
                                const min_pos = {
                                    x: ((commands[1] == "auto") ? center_pos.x : pos.pos1.x) - Number(radius),
                                    y: Math.min(pos.pos1.y, pos.pos2.y),
                                    z: ((commands[1] == "auto") ? center_pos.z : pos.pos1.z) - Number(radius)
                                };
                                const max_pos = {
                                    x: ((commands[1] == "auto") ? center_pos.x : pos.pos1.x) + Number(radius),
                                    y: Math.max(pos.pos2.y, pos.pos1.y),
                                    z: ((commands[1] == "auto") ? center_pos.z : pos.pos1.z) + Number(radius)
                                };
                                const taskQueue = [];
                                let tickingarea = { x: Infinity, z: Infinity };
                                const undo_array = [];
                                let rest_z = max_pos.z;
                                function processQueue() {
                                    return new Promise((resolve) => {
                                        function processQueue_child() {
                                            if (taskQueue.length === 0) {
                                                resolve();
                                                return;
                                            } else {
                                                for (let i = 0; i < 128; i++) {
                                                    if (taskQueue.length > 0) {
                                                        if (typeof taskQueue[0] == "string") {
                                                            if (String(taskQueue[0]).indexOf("wait for test block:") != -1) {
                                                                const [x, y, z] = String(taskQueue[0]).split("wait for test block:")[1].split(" ");
                                                                let block = false;
                                                                try {
                                                                    block = (player.dimension).getBlock({ x: Math.floor(Number(x)), y: Math.floor(Number(y)), z: Math.floor(Number(z)) });
                                                                } catch (e) {
                                                                    task_finish_func(this_tickingarea_index);
                                                                    run_command_player(player, `say §cDA-Error(Please reload) => ${e}`);
                                                                }
                                                                if (block != undefined) {
                                                                    taskQueue.shift();
                                                                }
                                                                break;
                                                            }
                                                        }
                                                        if (next_stop > -10) {
                                                            next_stop--;
                                                        }
                                                        const task = taskQueue.shift();
                                                        if (task == "next_stop") {
                                                            next_stop = 2;
                                                        } else if (task) {
                                                            task();
                                                            if (next_stop >= 0) {
                                                                i = 1000;
                                                                break;
                                                            }
                                                        }
                                                    } else {
                                                        break;
                                                    }
                                                }
                                                const decoration_index = (taskQueue.length % message_decoration.length);
                                                if (DA_now_tasking[this_task_id].situation == "Stopping") {
                                                    taskQueue.splice(0, Infinity);
                                                }
                                                run_command_player(player, `title @s actionbar §e${message_decoration[decoration_index]}§o§6残り:${taskQueue.length}個§r§e${message_decoration[decoration_index]}\n.　　　　§b${max_pos.z - min_pos.z - rest_z}/${max_pos.z - min_pos.z} (${Math.floor((max_pos.z - min_pos.z - rest_z) / (max_pos.z - min_pos.z) * 100)}%)　　　　.`);
                                                if (Math.floor(taskQueue.length / 100) % 20 == 0 && taskQueue.length > 10) {
                                                    run_command_player(player, `title @s actionbar §o§6-=-処理待ち-=-`);
                                                    system.runTimeout(processQueue_child, 1);
                                                } else {
                                                    system.runTimeout(processQueue_child, 1);
                                                }
                                            };
                                        }
                                        processQueue_child();
                                    })
                                }
                                async function in_other(z) {
                                    for (let x = max_pos.x; x >= min_pos.x; x--) {
                                        let is_undoed = false;
                                        for (let i = 0; i < undo_array.length; i++) {
                                            if (undo_array[i].x - x <= 63 && (undo_array[i].x >= x) && undo_array[i].z - z <= 63 && (undo_array[i].z >= z)) {
                                                is_undoed = true;
                                                break;
                                            }
                                        }
                                        const tr = () => {
                                            run_command_player(player, `tickingarea remove DA_temp${this_tickingarea_index}`);
                                        };
                                        const ta = () => {
                                            run_command_player(player, `tickingarea add ${x - 63} ${min_pos.y} ${z - 63} ${x + 63} ${max_pos.y} ${z + 63} DA_temp${this_tickingarea_index} true`);
                                        };
                                        if (!(tickingarea.x - 63 < x && tickingarea.x + 63 > x) || !(tickingarea.z - 63 < z && tickingarea.z + 63 > z)) {
                                            tickingarea = { x: x, z: z };
                                            taskQueue.push("next_stop");
                                            taskQueue.push(tr)
                                            taskQueue.push(ta)
                                            taskQueue.push(`wait for test block:${x} ${min_pos.y} ${z}`);
                                        }
                                        if (!is_undoed) {
                                            const UUID = Get_UUID();
                                            undo_array.push({ x: x, z: z, UUID: UUID });
                                            taskQueue.push(() => {
                                                const dx = (x - 63 > min_pos.x) ? x - 63 : min_pos.x;
                                                const dz = (z - 63 > min_pos.z) ? z - 63 : min_pos.z;
                                                run_command_player(player, `structure save "DA:${UUID}" ${x} ${min_pos.y} ${z} ${dx} ${max_pos.y} ${dz}`);
                                                DA_structures[UUID] = { x: x, y: min_pos.y, z: z, size: Math.abs(dx - x) * (max_pos.y - min_pos.y) * Math.abs(dz - z), name: `DA:${UUID}`, player: { id: player.id, name: player.nameTag }, date: Get_now_date() };
                                                DA_data[player.id]["undo"][this_undo_index].push({ UUID: UUID, pos: { mx: Math.min(x, dx), my: min_pos.y, mz: Math.min(z, dz) } })
                                            })
                                        }
                                        const dx = x - ((commands[1] == "auto") ? center_pos.x : pos.pos1.x);
                                        const dz = z - ((commands[1] == "auto") ? center_pos.z : pos.pos1.z);
                                        if (type == "fill") {
                                            if (dx * dx + dz * dz < (Number(radius) * Number(radius))) {
                                                const e = () => {
                                                    rest_z = z - min_pos.z;
                                                    run_command_player(player, `fill ${x} ${min_pos.y} ${z} ${x} ${max_pos.y} ${z} ${commands[2]}`);
                                                    check_is_success(player, x, min_pos.y, z, e, taskQueue);
                                                };
                                                taskQueue.push(e)
                                            }
                                        } else if (type == "outline") {
                                            if (Math.floor(dx * dx + dz * dz) >= (Number(radius - (1 + bold)) * Number(radius - (1 + bold))) && Math.floor(dx * dx + dz * dz) < (Number(radius) * Number(radius))) {
                                                const e = () => {
                                                    rest_z = z - min_pos.z;
                                                    run_command_player(player, `fill ${x} ${min_pos.y} ${z} ${x} ${max_pos.y} ${z} ${commands[2]}`);
                                                    check_is_success(player, x, min_pos.y, z, e, taskQueue);
                                                }
                                                taskQueue.push(e);
                                            }
                                        }
                                        if (taskQueue.length > Math.pow(2, 14) && radius > 32) {
                                            await processQueue();
                                        }
                                    }
                                }
                                if (radius > 32) {
                                    let z = max_pos.z;
                                    const PR_function = () => {
                                        return new Promise((resolve) => {
                                            async function one_tick_loop() {
                                                if (z >= min_pos.z) {
                                                    await in_other(z);
                                                    system.runTimeout(one_tick_loop, 1);
                                                } else {
                                                    resolve();
                                                    return;
                                                }
                                                z--;
                                            }
                                            one_tick_loop();
                                        })
                                    }
                                    await PR_function();
                                    await processQueue();
                                    run_command_player(player, `title @s actionbar §l§b完了！`);
                                    task_finish_func(this_tickingarea_index);
                                } else {
                                    for (let z = max_pos.z; z >= min_pos.z; z--) {
                                        await in_other(z);
                                    }
                                    await processQueue();
                                    task_finish_func(this_tickingarea_index);
                                }
                            });
                        } else {
                            system.run(() => {
                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 範囲が選択されていません"}]}`);
                                task_finish_func(this_tickingarea_index);
                            })
                        }
                    } else if (commands[0] == ".line") {
                        if (check_selected_pos(player)) {
                            const taskQueue = [];
                            const tickingarea = { x: Infinity, y: Infinity, z: Infinity };
                            const undo_array = [];
                            const pos = RC_pos;
                            const min_pos = {
                                x: Math.min(pos.pos1.x, pos.pos2.x),
                                y: Math.min(pos.pos1.y, pos.pos2.y),
                                z: Math.min(pos.pos1.z, pos.pos2.z)
                            };
                            const max_pos = {
                                x: Math.max(pos.pos1.x, pos.pos2.x),
                                y: Math.max(pos.pos1.y, pos.pos2.y),
                                z: Math.max(pos.pos1.z, pos.pos2.z)
                            };
                            const thickness = commands[1] ? Number(commands[1]) : 1;
                            DA_data[player.id]["undo"].push([]);
                            let this_undo_index = DA_data[player.id]["undo"].length - 1;
                            ev.cancel = true;
                            if (Number(commands[1]) > 0 && commands[2] != null) {
                                if (commands[2] == "let") {
                                    DA_data[player.id]["let"]["type"] = "line";
                                    DA_data[player.id]["let"]["RC_pos"] = RC_pos;
                                    DA_data[player.id]["let"]["tick"] = Number(commands[1]);
                                    DA_data[player.id]["let"]["parameter"] = commands[3];
                                    system.run(() => {
                                        run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => 線を作りたいブロックを置いてください。"}]}`)
                                    })
                                    task_finish_func(this_tickingarea_index);
                                    return;
                                }
                                system.run(() => {
                                    const dx = pos.pos2.x - pos.pos1.x, dy = pos.pos2.y - pos.pos1.y, dz = pos.pos2.z - pos.pos1.z;
                                    const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
                                    if (dist === 0) return;
                                    const steps = Math.ceil(dist);
                                    const offset = Math.floor(thickness / 2);

                                    for (let i = 0; i <= steps; i++) {
                                        const t = i / steps;
                                        const res_pos = {
                                            x: Math.round((pos.pos1.x + dx * t) - offset),
                                            y: Math.round((pos.pos1.y + dy * t) - offset),
                                            z: Math.round((pos.pos1.z + dz * t) - offset),
                                            dx: Math.round((pos.pos1.x + dx * t) + offset),
                                            dy: Math.round((pos.pos1.y + dy * t) + offset),
                                            dz: Math.round((pos.pos1.z + dz * t) + offset),
                                        }
                                        if (commands[3] == "hor") {
                                            res_pos.y = (pos.pos1.y + dy * t);
                                        } else if (commands[3] == "vec") {
                                            res_pos.y = Math.round(Math.min(pos.pos1.y, pos.pos2.y));
                                            res_pos.dy = Math.round(Math.max(pos.pos1.y, pos.pos2.y));
                                        }
                                        res_pos.x = Math.max(Math.min(res_pos.x, max_pos.x), min_pos.x);
                                        res_pos.y = Math.max(Math.min(res_pos.y, max_pos.y), min_pos.y);
                                        res_pos.z = Math.max(Math.min(res_pos.z, max_pos.z), min_pos.z);
                                        res_pos.dx = Math.max(Math.min(res_pos.dx, max_pos.x), min_pos.x);
                                        res_pos.dy = Math.max(Math.min(res_pos.dy, max_pos.y), min_pos.y);
                                        res_pos.dz = Math.max(Math.min(res_pos.dz, max_pos.z), min_pos.z);
                                        for (let x = res_pos.x; x <= res_pos.dx; x++) {
                                            for (let z = res_pos.z; z <= res_pos.dz; z++) {
                                                if ((tickingarea.x - 63) > x || (tickingarea.x + 63) < x || (tickingarea.z - 63) > z || (tickingarea.z + 63) < z) {
                                                    tickingarea.x = x; tickingarea.z = z;
                                                    taskQueue.push("next_stop");
                                                    taskQueue.push(() => {
                                                        run_command_player(player, `tickingarea remove DA_temp${this_tickingarea_index}`);
                                                    })
                                                    taskQueue.push(() => {
                                                        run_command_player(player, `tickingarea add ${x - 63} ${res_pos.y} ${z - 63} ${x + 63} ${res_pos.dy} ${z + 63} DA_temp${this_tickingarea_index} true`);
                                                    })
                                                    taskQueue.push(`wait for test block:${x} ${min_pos.y} ${z}`);
                                                }
                                                let is_in_undo = false;
                                                for (let i = 0; i < undo_array.length; i++) {
                                                    if (undo_array[i].x - 31 <= x && undo_array[i].x + 31 >= x && undo_array[i].z - 31 <= z && undo_array[i].z + 31 >= z) {
                                                        is_in_undo = true;
                                                        break;
                                                    }
                                                }
                                                if (!is_in_undo) {
                                                    const UUID = Get_UUID();
                                                    const px = (x - 31 >= min_pos.x) ? x - 31 : min_pos.x;
                                                    const pz = (z - 31 >= min_pos.z) ? z - 31 : min_pos.z;
                                                    const gx = ((x + 31) <= max_pos.x) ? (x + 31) : max_pos.x;
                                                    const gz = ((z + 31) <= max_pos.z) ? (z + 31) : max_pos.z;
                                                    undo_array.push({ x: x, z: z, UUID: UUID });
                                                    taskQueue.push(() => {
                                                        run_command_player(player, `structure save "DA:${UUID}" ${px} ${min_pos.y} ${pz} ${gx} ${max_pos.y} ${gz}`);
                                                        DA_structures[UUID] = { x: px, y: min_pos.y, z: pz, size: Math.abs(gx - px) * (max_pos.y - min_pos.y) * Math.abs(gz - pz), name: `DA:${UUID}`, player: { id: player.id, name: player.nameTag }, date: Get_now_date() };
                                                        DA_data[player.id]["undo"][this_undo_index].unshift({ UUID: UUID, pos: { mx: Math.min(px, gx), my: min_pos.y, mz: Math.min(pz, gz) } })
                                                    })
                                                }
                                                taskQueue.push(() => {
                                                    run_command_player(player, `fill ${x} ${res_pos.y} ${z} ${x} ${res_pos.dy} ${z} ${commands[2]}`)
                                                })
                                            }
                                        }
                                    }
                                    let message_decoration = ["---", "#--", "##-", "###", "-##", "--#", "---"];
                                    let next_stop = 0;
                                    function processQueue() {
                                        if (taskQueue.length === 0) {
                                            run_command_player(player, `title @s actionbar §o§b§l完了！`);
                                            task_finish_func(this_tickingarea_index);
                                            return;
                                        } else {
                                            for (let i = 0; i < 128; i++) {
                                                if (taskQueue.length > 0) {
                                                    if (typeof taskQueue[0] == "string") {
                                                        if (String(taskQueue[0]).indexOf("wait for test block:") != -1) {
                                                            const [x, y, z] = String(taskQueue[0]).split("wait for test block:")[1].split(" ");
                                                            let block = false;
                                                            try {
                                                                block = (player.dimension).getBlock({ x: Math.floor(Number(x)), y: Math.floor(Number(y)), z: Math.floor(Number(z)) });
                                                            } catch (e) {
                                                                task_finish_func(this_tickingarea_index);
                                                                run_command_player(player, `say §cDA-Error(Please reload) => ${e}`);
                                                            }
                                                            if (block != undefined) {
                                                                taskQueue.shift();
                                                            }
                                                            break;
                                                        }
                                                    }
                                                    if (next_stop > -10) {
                                                        next_stop--;
                                                    }
                                                    const task = taskQueue.shift();
                                                    if (task == "next_stop") {
                                                        next_stop = 2;
                                                    } else if (task) {
                                                        task();
                                                        if (next_stop >= 0) {
                                                            i = 1000;
                                                            break;
                                                        }
                                                    }
                                                } else {
                                                    break;
                                                }
                                            }
                                            const decoration_index = (taskQueue.length % message_decoration.length);
                                            if (DA_now_tasking[this_task_id].situation == "Stopping") {
                                                taskQueue.splice(0, Infinity);
                                            }
                                            run_command_player(player, `title @s actionbar §e${message_decoration[decoration_index]}§o§6残り:${taskQueue.length}個§r§e${message_decoration[decoration_index]}`);
                                            if (Math.floor(taskQueue.length / 100) % 20 == 0 && taskQueue.length > 10) {
                                                run_command_player(player, `title @s actionbar §o§6-=-処理待ち-=-`);
                                                system.runTimeout(processQueue, (DA_save_on_world[player.id]["Connect_Pass"] ?? 1));
                                            } else {
                                                system.runTimeout(processQueue, (DA_save_on_world[player.id]["Connect_Pass"] ?? 1));
                                            }
                                        };
                                    }
                                    processQueue();
                                })
                            } else {
                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 構文が違います。"}]}`);
                                task_finish_func(this_tickingarea_index);
                            }
                        } else {
                            system.run(() => {
                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 範囲が選択されていません"}]}`);
                                task_finish_func(this_tickingarea_index);
                            })
                        }
                    } else if (commands[0] == ".BezierCurves") {
                        if (check_selected_pos(player)) {
                            if (commands[1] == "start") {
                                DA_data[player.id]["is_BC_mode"] = true;
                                DA_data[player.id]["BC_pos"] = [RC_pos.pos1, RC_pos.pos2];
                                DA_data[player.id]["BC_sample_num"] = commands[2] ?? 100;
                                task_finish_func(this_tickingarea_index);
                                system.run(() => {
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => 開発補助ブラシでブロックを壊してパスを追加、\n右クリックしてパスを削除してください。\nその後、「決定する」を押してください。"}]}`);
                                })
                            } else if (commands[1] == "enter") {
                                if (commands[2] == "let") {
                                    DA_data[player.id]["let"]["type"] = "BezierCurves";
                                    DA_data[player.id]["let"]["RC_pos"] = RC_pos;
                                    DA_data[player.id]["let"]["Fill_line"] = `${commands[3] ?? 0} ${commands[4] ?? 0} ${commands[5] ?? 0} ${commands[6] ?? 0} ${commands[7] ?? 0} ${commands[8] ?? 0}`;
                                    system.run(() => {
                                        run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => ベジェ曲線を作りたいブロックを置いてください。"}]}`)
                                    })
                                    task_finish_func(this_tickingarea_index);
                                    return;
                                }
                                system.run(() => {
                                    player_setting_data(player);
                                    const poss = GetBezierCurve(DA_data[player.id]["BC_pos"], DA_data[player.id]["BC_sample_num"]);

                                    const taskQueue = [];
                                    const tickingarea = { x: Infinity, y: Infinity, z: Infinity };
                                    const undo_array = [];
                                    const pos = RC_pos;
                                    let min_pos = {
                                        x: Math.min(pos.pos1.x, pos.pos2.x),
                                        y: Math.min(pos.pos1.y, pos.pos2.y),
                                        z: Math.min(pos.pos1.z, pos.pos2.z)
                                    };
                                    let max_pos = {
                                        x: Math.max(pos.pos1.x, pos.pos2.x),
                                        y: Math.max(pos.pos1.y, pos.pos2.y),
                                        z: Math.max(pos.pos1.z, pos.pos2.z)
                                    };
                                    for (let i = 0; i < poss.length; i++) {
                                        min_pos.x = Math.min(min_pos.x, poss[i].x);
                                        min_pos.y = Math.min(min_pos.y, poss[i].y);
                                        min_pos.z = Math.min(min_pos.z, poss[i].z);
                                        max_pos.x = Math.max(max_pos.x, poss[i].x);
                                        max_pos.y = Math.max(max_pos.y, poss[i].y);
                                        max_pos.z = Math.max(max_pos.z, poss[i].z);
                                    }
                                    let T_min_pos = {
                                        x: min_pos.x + Math.min(commands[3] ?? 0, commands[6] ?? 0),
                                        y: min_pos.y + Math.min(commands[4] ?? 0, commands[7] ?? 0),
                                        z: min_pos.z + Math.min(commands[5] ?? 0, commands[8] ?? 0)
                                    };
                                    let T_max_pos = {
                                        x: max_pos.x + Math.max(commands[3] ?? 0, commands[6] ?? 0),
                                        y: max_pos.y + Math.max(commands[4] ?? 0, commands[7] ?? 0),
                                        z: max_pos.z + Math.max(commands[5] ?? 0, commands[8] ?? 0)
                                    };
                                    DA_data[player.id]["undo"].push([]);
                                    let this_undo_index = DA_data[player.id]["undo"].length - 1;
                                    ev.cancel = true;

                                    for (let i = 0; i < poss.length; i++) {
                                        const mip = {
                                            x: poss[i].x + Math.min(commands[3] ?? 0, commands[6] ?? 0),
                                            y: poss[i].y + Math.min(commands[4] ?? 0, commands[7] ?? 0),
                                            z: poss[i].z + Math.min(commands[5] ?? 0, commands[8] ?? 0),
                                        }
                                        const map = {
                                            x: poss[i].x + Math.max(commands[3] ?? 0, commands[6] ?? 0),
                                            y: poss[i].y + Math.max(commands[4] ?? 0, commands[7] ?? 0),
                                            z: poss[i].z + Math.max(commands[5] ?? 0, commands[8] ?? 0),
                                        }
                                        const x = poss[i].x;
                                        const y = poss[i].y;
                                        const z = poss[i].z;
                                        if ((tickingarea.x - 63) > mip.x || (tickingarea.x + 63) < map.x || (tickingarea.z - 63) > mip.z || (tickingarea.z + 63) < map.z) {
                                            tickingarea.x = x; tickingarea.z = z;
                                            taskQueue.push("next_stop");
                                            taskQueue.push(() => {
                                                run_command_player(player, `tickingarea remove DA_temp${this_tickingarea_index}`);
                                            })
                                            taskQueue.push(() => {
                                                run_command_player(player, `tickingarea add ${x - 63} ${min_pos.y} ${z - 63} ${x + 63} ${max_pos.y} ${z + 63} DA_temp${this_tickingarea_index} true`);
                                            })
                                            taskQueue.push(`wait for test block:[${mip.x} ${mip.y} ${mip.z} ${map.x} ${map.y} ${map.z}]`);
                                        }
                                        let is_in_undo = false;
                                        for (let i = 0; i < undo_array.length; i++) {
                                            if (undo_array[i].x - 31 <= x && undo_array[i].x + 31 >= x && undo_array[i].z - 31 <= z && undo_array[i].z + 31 >= z) {
                                                is_in_undo = true;
                                                break;
                                            }
                                        }
                                        if (!is_in_undo) {
                                            const UUID = Get_UUID();
                                            const px = (x - 31 >= T_min_pos.x) ? x - 31 : T_min_pos.x;
                                            const pz = (z - 31 >= T_min_pos.z) ? z - 31 : T_min_pos.z;
                                            const gx = ((x + 31) <= T_max_pos.x) ? (x + 31) : T_max_pos.x;
                                            const gz = ((z + 31) <= T_max_pos.z) ? (z + 31) : T_max_pos.z;
                                            undo_array.push({ x: x, z: z, UUID: UUID });
                                            taskQueue.push(() => {
                                                run_command_player(player, `structure save "DA:${UUID}" ${px} ${T_min_pos.y} ${pz} ${gx} ${T_max_pos.y} ${gz}`);
                                                DA_structures[UUID] = { x: px, y: T_min_pos.y, z: pz, size: Math.abs(gx - px) * (T_max_pos.y - T_min_pos.y) * Math.abs(gz - pz), name: `DA:${UUID}`, player: { id: player.id, name: player.nameTag }, date: Get_now_date() };
                                                DA_data[player.id]["undo"][this_undo_index].unshift({ UUID: UUID, pos: { mx: Math.min(px, gx), my: T_min_pos.y, mz: Math.min(pz, gz) } })
                                            })
                                        }
                                        taskQueue.push(() => {
                                            run_command_player(player, `fill ${mip.x} ${mip.y} ${mip.z} ${map.x} ${map.y} ${map.z} ${commands[2]}`)
                                        })
                                    }

                                    let message_decoration = ["---", "#--", "##-", "###", "-##", "--#", "---"];
                                    let next_stop = 0;
                                    function processQueue() {
                                        if (taskQueue.length === 0) {
                                            run_command_player(player, `title @s actionbar §o§b§l完了！`);
                                            task_finish_func(this_tickingarea_index);
                                            return;
                                        } else {
                                            for (let i = 0; i < 128; i++) {
                                                if (taskQueue.length > 0) {
                                                    if (typeof taskQueue[0] == "string") {
                                                        if (taskQueue[0].indexOf("wait for test block") != -1) {
                                                            let poss = [];
                                                            if (String(taskQueue[0]).indexOf("wait for test block:[") != -1) {
                                                                const input_pos = JSON.parse(String(taskQueue[0]).split("wait for test block:")[1].replaceAll(" ", ","));
                                                                const basic_pos = [{ x: input_pos[0], y: input_pos[1], z: input_pos[2] }, { x: input_pos[3], y: input_pos[4], z: input_pos[5] }];
                                                                const min_pos = {
                                                                    x: Math.min(basic_pos[0].x, basic_pos[1].x),
                                                                    y: Math.min(basic_pos[0].y, basic_pos[1].y),
                                                                    z: Math.min(basic_pos[0].z, basic_pos[1].z)
                                                                }
                                                                const max_pos = {
                                                                    x: Math.max(basic_pos[0].x, basic_pos[1].x),
                                                                    y: Math.max(basic_pos[0].y, basic_pos[1].y),
                                                                    z: Math.max(basic_pos[0].z, basic_pos[1].z)
                                                                }
                                                                for (let x = min_pos.x; x <= max_pos.x; x += (32 - ((DA_save_on_world[player.id]["Connect_Pass"] ?? 0) * 3))) {
                                                                    for (let z = min_pos.z; z <= max_pos.z; z += (32 - ((DA_save_on_world[player.id]["Connect_Pass"] ?? 0) * 3))) {
                                                                        poss.push(x, (Math.floor(Math.random() * 2) == 0) ? min_pos.y : max_pos.y, z);
                                                                    }
                                                                }
                                                                const square = [[0, 0, 0], [1, 0, 0], [0, 0, 1], [1, 0, 1], [0, 1, 0], [1, 1, 0], [0, 1, 1], [1, 1, 1]];
                                                                for (let g = 0; g < square.length; g++) {
                                                                    poss.push(basic_pos[square[g][0]].x, basic_pos[square[g][1]].y, basic_pos[square[g][2]].z);
                                                                }
                                                            } else {
                                                                const input_pos = String(taskQueue[0]).split("wait for test block:")[1].split(" ");
                                                                poss = input_pos;
                                                            }
                                                            let block = [];
                                                            try {
                                                                for (let i = 0; (i + 2) < poss.length; i += 3) {
                                                                    block.push((player.dimension).getBlock({ x: Math.floor(Number(poss[i])), y: Math.floor(Number(poss[i + 1])), z: Math.floor(Number(poss[i + 2])) }));
                                                                }
                                                            } catch (e) {
                                                                run_command_player(player, `say §cDA-Error(Please reload) => ${e}`);
                                                            }
                                                            if (block.indexOf(undefined) == -1 && block.indexOf(null) == -1) {
                                                                taskQueue.shift();
                                                            }
                                                        }
                                                    }
                                                    if (next_stop > -10) {
                                                        next_stop--;
                                                    }
                                                    const task = taskQueue.shift();
                                                    if (DA_now_tasking[this_task_id].situation == "Stopping") {
                                                        taskQueue.splice(0, Infinity);
                                                    }
                                                    if (task == "next_stop") {
                                                        next_stop = 2;
                                                    } else if (task) {
                                                        task();
                                                        if (next_stop >= 0) {
                                                            i = 1000;
                                                            break;
                                                        }
                                                    }
                                                } else {
                                                    break;
                                                }
                                            }
                                            const decoration_index = (taskQueue.length % message_decoration.length);
                                            if (DA_now_tasking[this_task_id].situation == "Stopping") {
                                                taskQueue.splice(0, Infinity);
                                            }
                                            run_command_player(player, `title @s actionbar §e${message_decoration[decoration_index]}§o§6残り:${taskQueue.length}個§r§e${message_decoration[decoration_index]}`);
                                            if (Math.floor(taskQueue.length / 100) % 20 == 0 && taskQueue.length > 10) {
                                                run_command_player(player, `title @s actionbar §o§6-=-処理待ち-=-`);
                                                system.runTimeout(processQueue, (DA_save_on_world[player.id]["Connect_Pass"] ?? 1));
                                            } else {
                                                system.runTimeout(processQueue, (DA_save_on_world[player.id]["Connect_Pass"] ?? 1));
                                            }
                                        };
                                    }
                                    processQueue();

                                    DA_data[player.id]["is_BC_mode"] = false;
                                    DA_data[player.id]["BC_pos"] = [];
                                    DA_data[player.id]["BC_sample_num"] = 100;
                                })
                            }
                            ev.cancel = true;
                        } else {
                            system.run(() => {
                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 範囲が選択されていません"}]}`);
                                task_finish_func(this_tickingarea_index);
                            })
                        }
                    } else if (commands[0] == ".ts") {
                        if (check_selected_pos(player)) {
                            DA_data[player.id]["is_TS_mode"] = true;
                            DA_data[player.id]["terrain_CP"] = [];
                            task_finish_func(this_tickingarea_index);
                            system.run(() => {
                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => 開発補助ブラシでブロックを壊してパスを追加、\n右クリックしてパスを削除してください。\nその後、「地形を生成する」を押してください。"}]}`);
                            })
                            ev.cancel = true;
                        } else {
                            system.run(() => {
                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 先に範囲を選択してください。"}]}`);
                                task_finish_func(this_tickingarea_index);
                            })
                        }
                    } else if (commands[0] == ".terrain") {
                        if (check_selected_pos(player)) {
                            if (Number(commands[1]) > 0 && Number(commands[1]) < 1 && Number(commands[2]) >= -32768 && Number(commands[2]) <= 32768) {
                                system.run(async () => {
                                    player_setting_data(player);
                                    if (commands[3] == "let") {
                                        DA_data[player.id]["let"]["type"] = "terrain";
                                        DA_data[player.id]["let"]["RC_pos"] = RC_pos;
                                        DA_data[player.id]["let"]["Undulations"] = Number(commands[1]);
                                        DA_data[player.id]["let"]["Ter_Seed"] = Number(commands[2]);
                                        DA_data[player.id]["let"]["Hold_pass"] = (commands[4] ?? false);
                                        DA_data[player.id]["let"]["CTRL_type"] = Number(commands[5] ?? 0);
                                        DA_data[player.id]["let"]["CTRL_weight"] = Number(commands[6] ?? 4);
                                        system.run(() => {
                                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => 地形を作りたいブロックを置いてください。"}]}`)
                                        })
                                        task_finish_func(this_tickingarea_index);
                                        return;
                                    }
                                    const taskQueue = [];
                                    const tickingarea = { x: Infinity, y: Infinity, z: Infinity };
                                    const undo_array = [];
                                    const terrain = [];
                                    const pos = RC_pos;
                                    DA_data[player.id]["undo"].push([]);
                                    let this_undo_index = DA_data[player.id]["undo"].length - 1;
                                    ev.cancel = true;
                                    let min_pos = {
                                        x: Math.min(pos.pos1.x, pos.pos2.x),
                                        y: Math.min(pos.pos1.y, pos.pos2.y),
                                        z: Math.min(pos.pos1.z, pos.pos2.z)
                                    };
                                    let max_pos = {
                                        x: Math.max(pos.pos1.x, pos.pos2.x),
                                        y: Math.max(pos.pos1.y, pos.pos2.y),
                                        z: Math.max(pos.pos1.z, pos.pos2.z)
                                    };

                                    async function run_temp() {
                                        return new Promise((resolve) => {
                                            for (let i = 0; i < terrain.length; i++) {
                                                min_pos.x = Math.min(min_pos.x, terrain[i].x);
                                                min_pos.y = Math.min(min_pos.y, terrain[i].y);
                                                min_pos.z = Math.min(min_pos.z, terrain[i].z);
                                                max_pos.x = Math.max(max_pos.x, terrain[i].x);
                                                max_pos.y = Math.max(max_pos.y, terrain[i].y);
                                                max_pos.z = Math.max(max_pos.z, terrain[i].z);
                                            }

                                            for (let i = 0; i < terrain.length; i++) {
                                                const x = terrain[i].x;
                                                const y = terrain[i].y;
                                                const z = terrain[i].z;
                                                if ((tickingarea.x - 60) > x || (tickingarea.x + 60) < x || (tickingarea.z - 60) > z || (tickingarea.z + 60) < z) {
                                                    tickingarea.x = x; tickingarea.z = z;
                                                    taskQueue.push("next_stop");
                                                    taskQueue.push(() => {
                                                        run_command_player(player, `tickingarea remove DA_temp${this_tickingarea_index}`);
                                                    })
                                                    taskQueue.push(() => {
                                                        run_command_player(player, `tickingarea add ${x - 63} ${min_pos.y} ${z - 63} ${x + 63} ${max_pos.y} ${z + 63} DA_temp${this_tickingarea_index} true`);
                                                    })
                                                    taskQueue.push(`wait for test block:${x} ${min_pos.y} ${z}`);
                                                    taskQueue.push(`wait for test block:${x + 60} ${min_pos.y} ${z + 60}`);
                                                    taskQueue.push(`wait for test block:${x - 60} ${max_pos.y} ${z - 60}`);
                                                }
                                                let is_in_undo = false;
                                                for (let i = 0; i < undo_array.length; i++) {
                                                    if (undo_array[i].x - 31 <= x && undo_array[i].x + 31 >= x && undo_array[i].z - 31 <= z && undo_array[i].z + 31 >= z) {
                                                        is_in_undo = true;
                                                        break;
                                                    }
                                                }
                                                if (!is_in_undo) {
                                                    const UUID = Get_UUID();
                                                    const px = (x - 31 >= min_pos.x) ? x - 31 : min_pos.x;
                                                    const pz = (z - 31 >= min_pos.z) ? z - 31 : min_pos.z;
                                                    const gx = ((x + 31) <= max_pos.x) ? (x + 31) : max_pos.x;
                                                    const gz = ((z + 31) <= max_pos.z) ? (z + 31) : max_pos.z;
                                                    undo_array.push({ x: x, z: z, UUID: UUID });
                                                    taskQueue.push(() => {
                                                        run_command_player(player, `structure save "DA:${UUID}" ${px} ${min_pos.y} ${pz} ${gx} ${max_pos.y} ${gz}`);
                                                        DA_structures[UUID] = { x: px, y: min_pos.y, z: pz, size: Math.abs(gx - px) * (max_pos.y - min_pos.y) * Math.abs(gz - pz), name: `DA:${UUID}`, player: { id: player.id, name: player.nameTag }, date: Get_now_date() };
                                                        DA_data[player.id]["undo"][this_undo_index].unshift({ UUID: UUID, pos: { mx: Math.min(px, gx), my: min_pos.y, mz: Math.min(pz, gz) } })
                                                    })
                                                }
                                                taskQueue.push(() => {
                                                    run_command_player(player, `fill ${x} ${min_pos.y} ${z} ${x} ${max_pos.y} ${z} air`)
                                                    run_command_player(player, `fill ${x} ${min_pos.y} ${z} ${x} ${y} ${z} ${commands[3]}`)
                                                })
                                            }

                                            let message_decoration = ["---", "#--", "##-", "###", "-##", "--#", "---"];
                                            let next_stop = 0;
                                            function processQueue() {
                                                if (taskQueue.length === 0) {
                                                    run_command_player(player, `title @s actionbar §o§b§l完了！`);
                                                    resolve()
                                                    return;
                                                } else {
                                                    for (let i = 0; i < 128; i++) {
                                                        if (taskQueue.length > 0) {
                                                            if (typeof taskQueue[0] == "string") {
                                                                if (String(taskQueue[0]).indexOf("wait for test block:") != -1) {
                                                                    const [x, y, z] = String(taskQueue[0]).split("wait for test block:")[1].split(" ");
                                                                    let block = false;
                                                                    try {
                                                                        block = (player.dimension).getBlock({ x: Math.floor(Number(x)), y: Math.floor(Number(y)), z: Math.floor(Number(z)) });
                                                                    } catch (e) {
                                                                        resolve();
                                                                        run_command_player(player, `say §cDA-Error(Please reload) => ${e}`);
                                                                    }
                                                                    if (block != undefined) {
                                                                        taskQueue.shift();
                                                                    }
                                                                    break;
                                                                }
                                                            }
                                                            if (next_stop > -10) {
                                                                next_stop--;
                                                            }
                                                            const task = taskQueue.shift();
                                                            if (DA_now_tasking[this_task_id].situation == "Stopping") {
                                                                taskQueue.splice(0, Infinity);
                                                            }
                                                            if (task == "next_stop") {
                                                                next_stop = 2;
                                                            } else if (task) {
                                                                task();
                                                                if (next_stop >= 0) {
                                                                    i = 1000;
                                                                    break;
                                                                }
                                                            }
                                                        } else {
                                                            break;
                                                        }
                                                    }
                                                    const decoration_index = (taskQueue.length % message_decoration.length);
                                                    if (DA_now_tasking[this_task_id].situation == "Stopping") {
                                                        taskQueue.splice(0, Infinity);
                                                    }
                                                    run_command_player(player, `title @s actionbar §e${message_decoration[decoration_index]}§o§6残り:${taskQueue.length}個§r§e${message_decoration[decoration_index]}`);
                                                    if (Math.floor(taskQueue.length / 100) % 20 == 0 && taskQueue.length > 10) {
                                                        run_command_player(player, `title @s actionbar §o§6-=-処理待ち-=-`);
                                                        system.runTimeout(processQueue, (DA_save_on_world[player.id]["Connect_Pass"] ?? 1));
                                                    } else {
                                                        system.runTimeout(processQueue, (DA_save_on_world[player.id]["Connect_Pass"] ?? 1));
                                                    }
                                                };
                                            }
                                            processQueue();
                                        })
                                    }

                                    async function GetPerlinNoiseTerrain(minX, minZ, maxX, maxZ, baseY, amplitude, scale = 0.1, seed = 0, controlPoints = []) {
                                        let x = minX;
                                        const PR_function = () => {
                                            return new Promise((resolve) => {
                                                const chunkSize = 48;
                                                let currentChunkX = minX;
                                                let currentChunkZ = minZ;
                                                async function one_tick_loop() {
                                                    run_command_player(player, `title @s actionbar §e地形生成中・・・チャンクX:${currentChunkX} Z:${currentChunkZ}`);
                                                    if (currentChunkX <= maxX && DA_now_tasking[this_task_id].situation !== "Stopping") {
                                                        function generate_chunk() {
                                                            return new Promise((resolve) => {
                                                                let x = currentChunkX;
                                                                function GC_loop() {
                                                                    if (x <= Math.min(currentChunkX + chunkSize - 1, maxX)) {
                                                                        for (let z = currentChunkZ; z <= Math.min(currentChunkZ + chunkSize - 1, maxZ); z++) {
                                                                            let weightSum = 0, weightedY = 0, epsilon = 1;
                                                                            let max_weight = -Infinity;
                                                                            const noise = perlinNoise(((x + seed) * scale) % 131072, ((z + seed) * scale) % 131072);
                                                                            if (controlPoints.length > 0) {
                                                                                for (const cp of controlPoints) {
                                                                                    let d = 0;
                                                                                    if (cp.is_line && (cp["dx"] != null && cp["dy"] != null && cp["dz"] != null)) {
                                                                                        const np = getNearestPoint({ x: x, y: Infinity, z: z }, { x: cp.x, y: cp.y, z: cp.z }, { x: cp.dx, y: cp.dy, z: cp.dz });
                                                                                        d = Math.sqrt((x - np.x) ** 2 + (z - np.z) ** 2);
                                                                                    } else {
                                                                                        d = Math.sqrt((x - cp.x) ** 2 + (z - cp.z) ** 2);
                                                                                    }
                                                                                    const weight = 1 / ((d / cp.weight) + epsilon);
                                                                                    weightedY += cp.y * weight;
                                                                                    weightSum += weight;
                                                                                    max_weight = Math.max(max_weight, weight);
                                                                                }
                                                                                const controlHeight = weightedY / weightSum;
                                                                                const controlWeight = (1 - Math.pow(1 - max_weight, Number(commands[6] ?? 4)));
                                                                                let finalHeight = 0;
                                                                                if ((commands[5] ?? 0) == 0) {
                                                                                    finalHeight = Math.floor(controlHeight + noise * amplitude); //type1
                                                                                } else if (commands[5] == 1) {
                                                                                    finalHeight = Math.floor(((controlHeight + baseY) + (noise * amplitude)) / 2); //type2
                                                                                } else if (commands[5] == 2) {
                                                                                    finalHeight = Math.round((((controlHeight - baseY) * controlWeight) + ((noise * amplitude) * (1 - controlWeight))) + baseY);
                                                                                }
                                                                                terrain.push({ x: x, y: finalHeight, z: z });
                                                                            } else {
                                                                                const height = Math.floor(baseY + noise * amplitude);
                                                                                terrain.push({ x: x, y: height, z: z });
                                                                            }
                                                                        }
                                                                        system.runTimeout(GC_loop, 1);
                                                                    } else {
                                                                        resolve();
                                                                    }
                                                                    x++;
                                                                }
                                                                GC_loop();
                                                            })
                                                        }
                                                        await generate_chunk();
                                                        await run_temp();
                                                        terrain.splice(0, Infinity);
                                                        if (currentChunkZ + chunkSize <= maxZ) {
                                                            currentChunkZ += chunkSize;
                                                        } else {
                                                            currentChunkZ = minZ;
                                                            currentChunkX += chunkSize;
                                                        }

                                                        system.runTimeout(one_tick_loop, 1);
                                                    } else {
                                                        resolve();
                                                        return;
                                                    }
                                                }
                                                one_tick_loop();
                                            });
                                        }
                                        await PR_function();
                                        return terrain;
                                    }
                                    await GetPerlinNoiseTerrain(min_pos.x, min_pos.z, max_pos.x, max_pos.z, min_pos.y, (max_pos.y - min_pos.y), Number(commands[1]), Number(commands[2] ?? 0), DA_data[player.id]["terrain_CP"] ?? []);
                                    await run_temp();
                                    task_finish_func(this_tickingarea_index);
                                    run_command_player(player, `title @s actionbar §b完了！`);
                                    if (commands[4] == false) {
                                        DA_data[player.id]["is_TS_mode"] = false;
                                        DA_data[player.id]["terrain_CP"] = [];
                                    }
                                    return;
                                })
                            } else {
                                system.run(() => {
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 無効な構文です"}]}`);
                                })
                                task_finish_func(this_tickingarea_index);
                                return;
                            }
                        } else {
                            system.run(() => {
                                run_command_player(player, `tellraw @s { "rawtext": [{ "text": "§cDA => 範囲を選択してください" }] }`);
                            })
                            task_finish_func(this_tickingarea_index);
                        }
                        ev.cancel = true;
                    } else if (commands[0] == ".frame") {
                        if (check_selected_pos(player)) {
                            if (commands[4] == "let") {
                                DA_data[player.id]["let"]["type"] = "frame";
                                DA_data[player.id]["let"]["frame_data"] = msg;
                                system.run(() => {
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => Frameしたいブロックを置いてください。"}]}`)
                                })
                                task_finish_func(this_tickingarea_index);
                                return;
                            }
                            system.run(async () => {
                                const taskQueue = [];
                                DA_data[player.id]["undo"].push([]);
                                let this_undo_index = DA_data[player.id]["undo"].length - 1;
                                const tickingarea = { x: Infinity, y: Infinity, z: Infinity };
                                const undo_array = [];
                                const pos = RC_pos;
                                const min_pos = {
                                    x: Math.min(pos.pos1.x, pos.pos2.x),
                                    y: Math.min(pos.pos1.y, pos.pos2.y),
                                    z: Math.min(pos.pos1.z, pos.pos2.z)
                                };
                                const max_pos = {
                                    x: Math.max(pos.pos1.x, pos.pos2.x),
                                    y: Math.max(pos.pos1.y, pos.pos2.y),
                                    z: Math.max(pos.pos1.z, pos.pos2.z)
                                };
                                const start_pos = {
                                    x: Number(commands[1]),
                                    y: Number(commands[2]),
                                    z: Number(commands[3])
                                };
                                const hit = player.dimension.getBlock(start_pos);
                                let globalVisited = new Set();
                                let Dont_search = new Set();
                                function posToString(pos) {
                                    return `${pos.x},${pos.y},${pos.z}`;
                                }
                                function getNeighbors(pos) {
                                    return [
                                        { x: pos.x + 1, y: pos.y, z: pos.z },
                                        { x: pos.x, y: pos.y + 1, z: pos.z },
                                        { x: pos.x, y: pos.y - 1, z: pos.z },
                                        { x: pos.x, y: pos.y, z: pos.z + 1 },
                                        { x: pos.x, y: pos.y, z: pos.z - 1 },
                                        { x: pos.x - 1, y: pos.y, z: pos.z },

                                        { x: pos.x + 1, y: pos.y, z: pos.z + 1 },
                                        { x: pos.x + 1, y: pos.y, z: pos.z - 1 },
                                        { x: pos.x - 1, y: pos.y, z: pos.z + 1 },
                                        { x: pos.x - 1, y: pos.y, z: pos.z - 1 },
                                        { x: pos.x, y: pos.y + 1, z: pos.z + 1 },
                                        { x: pos.x + 1, y: pos.y + 1, z: pos.z },
                                        { x: pos.x, y: pos.y + 1, z: pos.z - 1 },
                                        { x: pos.x + 1, y: pos.y - 1, z: pos.z },
                                        { x: pos.x, y: pos.y - 1, z: pos.z + 1 },
                                        { x: pos.x - 1, y: pos.y + 1, z: pos.z },
                                        { x: pos.x, y: pos.y - 1, z: pos.z - 1 },
                                        { x: pos.x - 1, y: pos.y - 1, z: pos.z },

                                        { x: pos.x + 1, y: pos.y + 1, z: pos.z + 1 },
                                        { x: pos.x + 1, y: pos.y + 1, z: pos.z - 1 },
                                        { x: pos.x + 1, y: pos.y - 1, z: pos.z + 1 },
                                        { x: pos.x + 1, y: pos.y - 1, z: pos.z - 1 },
                                        { x: pos.x - 1, y: pos.y + 1, z: pos.z - 1 },
                                        { x: pos.x - 1, y: pos.y + 1, z: pos.z + 1 },
                                        { x: pos.x - 1, y: pos.y - 1, z: pos.z + 1 },
                                        { x: pos.x - 1, y: pos.y - 1, z: pos.z - 1 },
                                    ];
                                }
                                let state = {};
                                async function dijkstraSearch(dimension, targetType, startPos) {
                                    globalVisited = new Set();
                                    globalVisited.add(posToString(startPos));
                                    state = {
                                        dimension: dimension,
                                        targetType: targetType,
                                        queue: [{ pos: startPos, dist: 0, path: [startPos] }]
                                    };
                                    await dijkstraStep();
                                }
                                async function dijkstraStep() {
                                    if (DA_now_tasking[this_task_id].situation == "Stopping") {
                                        run_command_player(player, `title @s actionbar §o§b§l完了！`);
                                        task_finish_func(this_tickingarea_index);
                                        return;
                                    } else {
                                        let loop_num = 0;
                                        for (let i = 0; i < Math.min(state.queue.length, 24); i++) {
                                            if (state.queue.length === 0) {
                                                world.sendMessage("探索中止: 指定ブロックが見つかりませんでした。");
                                                task_finish_func(this_tickingarea_index);
                                                return;
                                            }
                                            const current = state.queue.shift();
                                            if (current.dist > commands[5]) {
                                                run_command_player(player, `title @s actionbar §o§b§l完了！`);
                                                task_finish_func(this_tickingarea_index);
                                                return;
                                            }
                                            if (current.pos.y < -64 || current.pos.y > 320 || min_pos.x > current.pos.x || max_pos.x < current.pos.x || min_pos.y > current.pos.y || max_pos.y < current.pos.y || min_pos.z > current.pos.z || max_pos.z < current.pos.z) continue;
                                            if (tickingarea.x - 30 > current.pos.x || tickingarea.x + 30 < current.pos.x || tickingarea.z - 30 > current.pos.z || tickingarea.z + 30 < current.pos.z) {
                                                tickingarea.x = current.pos.x; tickingarea.y = current.pos.y; tickingarea.z = current.pos.z;
                                                run_command_player(player, `tickingarea remove DA_temp${this_tickingarea_index}`);
                                                await await_one_tick();
                                                run_command_player(player, `tickingarea add ${tickingarea.x - 31} ${min_pos.y} ${tickingarea.z - 31} ${tickingarea.x + 31} ${max_pos.y} ${tickingarea.z + 31} DA_temp${this_tickingarea_index} true`);
                                                await wait_for_load(player, { x: current.pos.x - 30, y: current.pos.y, z: current.pos.z - 30 }, { x: current.pos.x + 30, y: current.pos.y, z: current.pos.z + 30 });
                                                const x = current.pos.x;
                                                const z = current.pos.z;
                                                const T_min_pos = {
                                                    x: Math.min(pos.pos1.x, pos.pos2.x) + Math.min(commands[6] ?? 0, commands[9] ?? 0),
                                                    y: Math.min(pos.pos1.y, pos.pos2.y) + Math.min(commands[7] ?? 0, commands[10] ?? 0),
                                                    z: Math.min(pos.pos1.z, pos.pos2.z) + Math.min(commands[8] ?? 0, commands[11] ?? 0)
                                                };
                                                const T_max_pos = {
                                                    x: Math.max(pos.pos1.x, pos.pos2.x) + Math.max(commands[6] ?? 0, commands[9] ?? 0),
                                                    y: Math.max(pos.pos1.y, pos.pos2.y) + Math.max(commands[7] ?? 0, commands[10] ?? 0),
                                                    z: Math.max(pos.pos1.z, pos.pos2.z) + Math.max(commands[8] ?? 0, commands[11] ?? 0)
                                                };
                                                const UUID = Get_UUID();
                                                const px = (x - 31 >= T_min_pos.x) ? x - 31 : T_min_pos.x;
                                                const pz = (z - 31 >= T_min_pos.z) ? z - 31 : T_min_pos.z;
                                                const gx = ((x + 31) <= T_max_pos.x) ? (x + 31) : T_max_pos.x;
                                                const gz = ((z + 31) <= T_max_pos.z) ? (z + 31) : T_max_pos.z;
                                                undo_array.push({ x: x, z: z, UUID: UUID });
                                                run_command_player(player, `structure save "DA:${UUID}" ${px} ${T_min_pos.y} ${pz} ${gx} ${T_max_pos.y} ${gz}`);
                                                DA_structures[UUID] = { x: px, y: T_min_pos.y, z: pz, size: Math.abs(gx - px) * (T_max_pos.y - T_min_pos.y) * Math.abs(gz - pz), name: `DA:${UUID}`, player: { id: player.id, name: player.nameTag }, date: Get_now_date() };
                                                DA_data[player.id]["undo"][this_undo_index].unshift({ UUID: UUID, pos: { mx: Math.min(px, gx), my: T_min_pos.y, mz: Math.min(pz, gz) } })
                                            }
                                            const block = state.dimension.getBlock(current.pos);
                                            if (block && block.typeId === state.targetType && !Dont_search.has(posToString(current.pos))) {
                                                globalVisited.add(posToString(current.pos));
                                                await finishSearch(current);
                                                Dont_search.add(posToString(current.pos));
                                                return;
                                            }
                                            for (const nb of getNeighbors(current.pos)) {
                                                if (nb.y < -64 || nb.y > 340) continue;
                                                const key = posToString(nb);
                                                if (!globalVisited.has(key)) {
                                                    globalVisited.add(key);
                                                    run_command_player(player, `particle minecraft:basic_crit_particle ${nb.x} ${nb.y} ${nb.z}`);
                                                    state.queue.push({
                                                        pos: nb,
                                                        dist: current.dist + 1,
                                                        path: current.path.concat([nb])
                                                    });
                                                }
                                                loop_num++;
                                            }
                                            if (loop_num > 512) {
                                                break;
                                            }
                                        }
                                        system.runTimeout(() => {
                                            dijkstraStep();
                                        }, 1);
                                    }
                                }
                                async function finishSearch(foundNode) {
                                    for (const pos of foundNode.path) {
                                        const mip = {
                                            x: pos.x + Math.min(commands[6] ?? 0, commands[9] ?? 0),
                                            y: pos.y + Math.min(commands[7] ?? 0, commands[10] ?? 0),
                                            z: pos.z + Math.min(commands[8] ?? 0, commands[11] ?? 0),
                                        }
                                        const map = {
                                            x: pos.x + Math.max(commands[6] ?? 0, commands[9] ?? 0),
                                            y: pos.y + Math.max(commands[7] ?? 0, commands[10] ?? 0),
                                            z: pos.z + Math.max(commands[8] ?? 0, commands[11] ?? 0),
                                        }
                                        if (tickingarea.x - 30 > mip.x || tickingarea.x + 30 < map.x || tickingarea.z - 30 > mip.z || tickingarea.z + 30 < map.z) {
                                            tickingarea.x = pos.x; tickingarea.y = pos.y; tickingarea.z = pos.z;
                                            run_command_player(player, `tickingarea remove DA_temp${this_tickingarea_index}`);
                                            await await_one_tick();
                                            run_command_player(player, `tickingarea add ${tickingarea.x - 31} ${min_pos.y} ${tickingarea.z - 31} ${tickingarea.x + 31} ${max_pos.y} ${tickingarea.z + 31} DA_temp${this_tickingarea_index} true`);
                                            await wait_for_load(player, { x: pos.x - 30, y: pos.y, z: pos.z - 30 }, { x: pos.x + 30, y: pos.y, z: pos.z + 30 });
                                        }
                                        run_command(`fill ${mip.x} ${mip.y} ${mip.z} ${map.x} ${map.y} ${map.z} ${commands[4]}`);
                                    }
                                    system.runTimeout(() => {
                                        dijkstraSearch(state.dimension, state.targetType, foundNode.pos);
                                    }, 1);
                                }
                                dijkstraSearch(player.dimension, hit.type.id, start_pos);
                            })
                        } else {
                            system.run(() => {
                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 範囲が選択されていません"}]}`);
                                task_finish_func(this_tickingarea_index);
                            })
                        }
                        ev.cancel = true;
                    } else if (commands[0] == ".symmetric") {
                        if (check_selected_pos(player)) {
                            system.run(() => {
                                player_setting_data(player);
                                let type = "LRFB";
                                if (commands[1] == "LR") {
                                    type = "LR";
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§a始点を中心とします。左右対称です。"}]}`);
                                } else if (commands[1] == "LRFB") {
                                    type = "LRFB";
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§a始点を中心とします。前後左右対称です。"}]}`);
                                } else if (commands[1] == "rotate") {
                                    type = "rotate";
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§a始点を中心とします。前後左右点対称です。"}]}`);
                                }
                                const pos = get_selected_pos(player).pos1;
                                DA_data[player.id]["symmetric"] = {
                                    center: pos,
                                    type: type
                                }
                            })
                            ev.cancel = true;
                        }
                    } else if (commands[0] == ".undo") {
                        player_setting_data(player);
                        ev.cancel = true;
                        if (DA_data[player.id]["undo"].length > 0) {
                            system.run(() => {
                                const temp = DA_data[player.id]["undo"].pop();
                                const taskQueue = [];
                                for (let i = 0; i < temp.length; i++) {
                                    taskQueue.push(() => {
                                        run_command_player(player, `tickingarea add ${temp[i].pos.mx} ${temp[i].pos.my} ${temp[i].pos.mz} ${temp[i].pos.mx + 64} 320 ${temp[i].pos.mz + 64} DA_temp${this_tickingarea_index} true`);
                                    })
                                    taskQueue.push(`wait for test block:${temp[i].pos.mx} ${temp[i].pos.my} ${temp[i].pos.mz}`)
                                    taskQueue.push(`wait for test block:${temp[i].pos.mx + 64} ${temp[i].pos.my} ${temp[i].pos.mz + 64}`)
                                    taskQueue.push(() => {
                                        run_command_player(player, `structure load "DA:${temp[i].UUID}" ${temp[i].pos.mx} ${temp[i].pos.my} ${temp[i].pos.mz}`);
                                    })
                                    taskQueue.push(() => {
                                        run_command_player(player, `structure delete "DA:${temp[i].UUID}"`);
                                        delete DA_structures[temp[i].UUID];
                                        run_command_player(player, `tickingarea remove DA_temp${this_tickingarea_index}`);
                                    })
                                }
                                let message_decoration = ["---", "#--", "##-", "###", "-##", "--#", "---"];
                                function processQueue() {
                                    if (taskQueue.length === 0) {
                                        run_command_player(player, `title @s actionbar §o§b§l完了！`);
                                        task_finish_func(this_tickingarea_index);
                                        return;
                                    } else {
                                        if (String(taskQueue[0]).indexOf("wait for test block:") != -1) {
                                            const [x, y, z] = String(taskQueue[0]).split("wait for test block:")[1].split(" ");
                                            let block = false;
                                            try {
                                                block = (player.dimension).getBlock({ x: Math.floor(Number(x)), y: Math.floor(Number(y)), z: Math.floor(Number(z)) });
                                            } catch (e) {
                                                task_finish_func(this_tickingarea_index);
                                                run_command_player(player, `say §cDA-Error(Please reload) => ${e}`);
                                            }
                                            if (block != undefined) {
                                                taskQueue.shift();
                                            }
                                        } else {
                                            const task = taskQueue.shift();
                                            task();
                                        }
                                        const decoration_index = (taskQueue.length % message_decoration.length);
                                        if (DA_now_tasking[this_task_id].situation == "Stopping") {
                                            taskQueue.splice(0, Infinity);
                                        }
                                        run_command_player(player, `title @s actionbar §e${message_decoration[decoration_index]}§o§6残り:${taskQueue.length}個§r§e${message_decoration[decoration_index]}`);
                                        if (taskQueue.length % 100 == 0 && taskQueue.length > 10) {
                                            run_command_player(player, `title @s actionbar §o§6-=-処理待ち-=-`);
                                            system.runTimeout(processQueue, (DA_save_on_world[player.id]["Waiting_drawing"] ?? 60));
                                        } else {
                                            system.runTimeout(processQueue, (DA_save_on_world[player.id]["Connect_Pass"] ?? 1));
                                        }
                                    };
                                }
                                processQueue();
                            })
                        } else {
                            system.run(() => {
                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§c§lこれ以上戻せません！"}]}`);
                                task_finish_func(this_tickingarea_index);
                            })
                        }
                    } else if (commands[0] == ".automatic_undo") {
                        player_setting_data(player);
                        ev.cancel = true;
                        if (DA_ABU[player.id]["Automatic_block_undo"].length > 0) {
                            system.run(() => {
                                const temp = DA_ABU[player.id]["Automatic_block_undo"].pop();
                                const taskQueue = [];
                                const rast_tickingarea = { x: Infinity, z: Infinity };
                                for (let i = 0; i < temp.length; i++) {
                                    if (Math.abs(rast_tickingarea.x - temp[i].x) > 31 || Math.abs(rast_tickingarea.z - temp[i].z) > 31) {
                                        rast_tickingarea.x = temp[i].x;
                                        rast_tickingarea.z = temp[i].z;
                                        taskQueue.push(() => {
                                            run_command_player(player, `tickingarea remove DA_temp${this_tickingarea_index}`);
                                        })
                                        taskQueue.push(() => {
                                            run_command_player(player, `tickingarea add ${temp[i].x - 31} ${temp[i].y} ${temp[i].z - 31} ${temp[i].x + 31} 320 ${temp[i].z + 31} DA_temp${this_tickingarea_index} true`);
                                        })
                                        taskQueue.push(`wait for test block:${temp[i].x} ${temp[i].y} ${temp[i].z}`)
                                    }
                                    taskQueue.push(() => {
                                        run_command_player(player, `fill ${temp[i].x} ${temp[i].y} ${temp[i].z} ${temp[i].x} ${temp[i].y} ${temp[i].z} air replace ${temp[i].block}`);
                                    })
                                }
                                let message_decoration = ["---", "#--", "##-", "###", "-##", "--#", "---"];
                                function processQueue() {
                                    if (taskQueue.length === 0) {
                                        run_command_player(player, `title @s actionbar §o§b§l完了！`);
                                        task_finish_func(this_tickingarea_index);
                                        return;
                                    } else {
                                        for (let i = 0; i < 64; i++) {
                                            if (taskQueue.length === 0) {
                                                break;
                                            } else if (String(taskQueue[0]).indexOf("wait for test block:") != -1) {
                                                const [x, y, z] = String(taskQueue[0]).split("wait for test block:")[1].split(" ");
                                                let block = false;
                                                try {
                                                    block = (player.dimension).getBlock({ x: Math.floor(Number(x)), y: Math.floor(Number(y)), z: Math.floor(Number(z)) });
                                                } catch (e) {
                                                    task_finish_func(this_tickingarea_index);
                                                    run_command_player(player, `say §cDA-Error(Please reload) => ${e}`);
                                                }
                                                if (block != undefined) {
                                                    taskQueue.shift();
                                                }
                                                break;
                                            } else {
                                                const task = taskQueue.shift();
                                                task();
                                            }
                                        }
                                        const decoration_index = (taskQueue.length % message_decoration.length);
                                        if (DA_now_tasking[this_task_id].situation == "Stopping") {
                                            taskQueue.splice(0, Infinity);
                                        }
                                        run_command_player(player, `title @s actionbar §e${message_decoration[decoration_index]}§o§6残り:${taskQueue.length}個§r§e${message_decoration[decoration_index]}`);
                                        if (taskQueue.length % 100 == 0 && taskQueue.length > 10) {
                                            run_command_player(player, `title @s actionbar §o§6-=-処理待ち-=-`);
                                            system.runTimeout(processQueue, (DA_save_on_world[player.id]["Waiting_drawing"] ?? 60));
                                        } else {
                                            system.runTimeout(processQueue, (DA_save_on_world[player.id]["Connect_Pass"] ?? 1));
                                        }
                                    };
                                }
                                processQueue();
                            })
                        } else {
                            system.run(() => {
                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§c§lこれ以上戻せません！"}]}`);
                                task_finish_func(this_tickingarea_index);
                            })
                        }
                    } else if (commands[0] == ".clear") {
                        if (commands[1] == "show") {
                            DA_data[player.id]["prediction"] = null;
                        } else {
                            DA_data[player.id]["prediction"] = null;
                            DA_data[player.id]["select"] = null;
                        }
                        DA_data[player.id]["is_TS_mode"] = false;
                        DA_data[player.id]["terrain_CP"] = [];
                        DA_data[player.id]["is_BC_mode"] = false;
                        DA_data[player.id]["BC_pos"] = [];
                        DA_data[player.id]["BC_sample_num"] = 100;
                        delete DA_data[player.id]["symmetric"];
                        ev.cancel = true;
                        task_finish_func(this_tickingarea_index);
                    } else if (commands[0] == ".kit") {
                        if (commands[1] == "all" || commands[1] == "All") {
                            system.run(() => {
                                run_command_player(player, `clear @s da:da_brush`);
                                run_command_player(player, `clear @s da:da_art`);
                                run_command_player(player, `clear @s da:da_other`);
                                run_command_player(player, `clear @s da:da_taskmanager`);
                                run_command_player(player, `clear @s da:da_automatic`);
                                run_command_player(player, `clear @s da:da_chat`);
                                run_command_player(player, `clear @s da:da_about_me`);
                                run_command_player(player, `give @s da:da_brush`);
                                run_command_player(player, `give @s da:da_art`);
                                run_command_player(player, `give @s da:da_other`);
                                run_command_player(player, `give @s da:da_taskmanager`);
                                run_command_player(player, `give @s da:da_automatic`);
                                run_command_player(player, `give @s da:da_about_me`);
                                run_command_player(player, `give @s da:da_chat`);
                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => Success"}]}`);
                            })
                        } else if (commands[1] == "arc" || commands[1] == "Arc") {
                            system.run(() => {
                                run_command_player(player, `clear @s da:da_brush`);
                                run_command_player(player, `clear @s da:da_art`);
                                run_command_player(player, `clear @s da:da_other`);
                                run_command_player(player, `clear @s da:da_taskmanager`);
                                run_command_player(player, `clear @s da:da_automatic`);
                                run_command_player(player, `give @s da:da_brush`);
                                run_command_player(player, `give @s da:da_art`);
                                run_command_player(player, `give @s da:da_other`);
                                run_command_player(player, `give @s da:da_taskmanager`);
                                run_command_player(player, `give @s da:da_automatic`);
                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => Success"}]}`);
                            })
                        } else {
                            system.run(() => {
                                run_command_player(player, `clear @s da:da_brush`);
                                run_command_player(player, `clear @s da:da_art`);
                                run_command_player(player, `clear @s da:da_other`);
                                run_command_player(player, `give @s da:da_brush`);
                                run_command_player(player, `give @s da:da_art`);
                                run_command_player(player, `give @s da:da_other`);
                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => Success\n§b.kit arc で全ての建築用kitを取得できます。\n.kit allでDAの全てのアイテムを取得できます。"}]}`);
                            })
                        }
                        ev.cancel = true;
                        task_finish_func(this_tickingarea_index);
                    } else if (commands[0] == ".bindCheck" || commands[0] == ".bindcheck") {
                        system.run(() => {
                            if (DA_save_on_world[player.id]["bind"] == null) {
                                DA_save_on_world[player.id]["bind"] = [];
                            }
                            let text_f = "";
                            const bind = DA_save_on_world[player.id]["bind"];
                            for (let i = 0; i < bind.length; i++) {
                                if (bind[i].type == "Chat") {
                                    text_f += `\n§e§l${i} §r§e番目:「${bind[i].value}」とチャットをしたとき ${bind[i].commands} を実行。`;
                                } else {
                                    text_f += `\n§e§l${i} §r§e番目:「${bind[i].value}」を右クリックしたとき ${bind[i].commands} を実行。`;
                                }
                            }
                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA  => ${text_f}"}]}`);
                            task_finish_func(this_tickingarea_index);
                        })
                        ev.cancel = true;
                    } else if (commands[0] == ".bind") {
                        system.run(() => {
                            if (DA_save_on_world[player.id]["bind"] == null) {
                                DA_save_on_world[player.id]["bind"] = [];
                            }
                            if (String(commands[2]) == "Chat" || String(commands[2]) == "RightClick") {
                                let command_text = "";
                                for (let i = 3; i < commands.length; i++) {
                                    if (i == 3) {
                                        command_text += `${commands[i]}`;
                                    } else {
                                        command_text += ` ${commands[i]}`;
                                    }
                                }
                                DA_save_on_world[player.id]["bind"].push({ type: String(commands[2]), commands: String(command_text), value: String(commands[1]) });
                                save_DASOW_on_world();
                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA  => bindしました(現在のbind数:${DA_save_on_world[player.id]["bind"].length})"}]}`);
                            } else {
                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA  => 構文が正しくありません"}]}`);
                            }
                            task_finish_func(this_tickingarea_index);
                        })
                        ev.cancel = true;
                    } else if (commands[0] == ".unbind") {
                        system.run(() => {
                            if (DA_save_on_world[player.id]["bind"] == null) {
                                DA_save_on_world[player.id]["bind"] = [];
                            }
                            if (String(commands[2]) == "Chat" || String(commands[2]) == "RightClick") {
                                let is_deleted = false;
                                for (let i = 0; i < DA_save_on_world[player.id]["bind"].length; i++) {
                                    if (DA_save_on_world[player.id]["bind"][i].type == String(commands[2]) && DA_save_on_world[player.id]["bind"][i].value == String(commands[1])) {
                                        DA_save_on_world[player.id]["bind"].splice(i, 1);
                                        i--;
                                        run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA  => bindを解除しました(現在のbind数:${DA_save_on_world[player.id]["bind"].length})"}]}`);
                                        is_deleted = true;
                                    }
                                }
                                if (!is_deleted) {
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§eDA  => 解除先のbindは見つかりませんでした(現在のbind数:${DA_save_on_world[player.id]["bind"].length})"}]}`);
                                }
                                save_DASOW_on_world();
                            } else {
                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA  => 構文が正しくありません"}]}`);
                            }
                            task_finish_func(this_tickingarea_index);
                        })
                        ev.cancel = true;
                    } else {
                        if (now_task_num[this_tickingarea_index] != null) {
                            task_finish_func(this_tickingarea_index);
                        }
                    }
                }
            }
        }
    } catch (e) {
        run_command_player(S_player, `say DA ERROR => ${e}`);
    }
}

system.runInterval(() => {
    const players = world.getPlayers();
    if (players.length < 1) {
        return;
    }
    if (basic_player == null) {
        basic_player = players[0];
    }
    if (!loaded) {
        loaded = true;
        run_command(`tellraw @a {"rawtext":[{"text":"§b§oDevelopment Assistance 2.0.3 Inugitune"}]}`);
        if (DA_save_on_world["world_data"] == null) {
            DA_save_on_world["world_data"] = {
                LUNATIC: [],
                EXTRA: [],
                BASIC: []
            };
        }
        let is_LUNATIC = false;
        for (let i = 0; i < players.length; i++) {
            if (DA_save_on_world["world_data"]["LUNATIC"].indexOf(players[i].id) != -1) {
                is_LUNATIC = true;
                break;
            }
        }
        if (!is_LUNATIC) {
            DA_save_on_world["world_data"]["LUNATIC"].push(players[0].id);
            run_command_player(players[0], `tellraw @s {"rawtext":[{"text":"§b§lDA => オーナーが見つからなかったため、貴方を§eオーナー(LUNATIC)§bにしました。"}]}`);
        }
        for (let i = 0; i < players.length; i++) {
            player_setting_data(players[i]);
        }
        save_DASOW_on_world();
    }
    for (const key in players) {
        if (Object.prototype.hasOwnProperty.call(players, key)) {
            const player = players[key];
            if (DA_data[player.id] != null) {
                let Range_particle = "minecraft:obsidian_glow_dust_particle";
                let Prediction_Range_particle = "minecraft:villager_happy";
                let show_other = false;
                if (DA_save_on_world[player.id] == null) {
                    Range_particle = "minecraft:obsidian_glow_dust_particle";
                    Prediction_Range_particle = "minecraft:villager_happy";
                } else if (DA_save_on_world[player.id]["Range"] == null || DA_save_on_world[player.id]["Prediction_Range"] == null) {
                    Range_particle = "minecraft:obsidian_glow_dust_particle";
                    Prediction_Range_particle = "minecraft:villager_happy";
                } else if (DA_save_on_world[player.id]["Range"]["particle"] != null && DA_save_on_world[player.id]["Prediction_Range"]["particle"] != null) {
                    const DWRP = DA_save_on_world[player.id]["Range"]["particle"];
                    const DWPRP = DA_save_on_world[player.id]["Prediction_Range"]["particle"];
                    Range_particle = (DWRP != "" && DWRP.indexOf(":") != -1 && String(DWRP).length > 2) ? DWRP : "minecraft:obsidian_glow_dust_particle";
                    Prediction_Range_particle = (DWPRP != "" && DWPRP.indexOf(":") != -1 && String(DWPRP).length > 2) ? DWPRP : "minecraft:villager_happy";
                }
                if (DA_save_on_world[player.id] != null) {
                    if (DA_save_on_world[player.id]["is_show_other"] != null) {
                        show_other = DA_save_on_world[player.id].is_show_other;
                    }
                }
                if (DA_data[player.id]["BC_pos"] != null) {
                    if (DA_data[player.id]["BC_pos"].length > 0) {
                        const BC_pos = DA_data[player.id]["BC_pos"];
                        if (tick % 40 == 0) {
                            for (let g = 0; g < BC_pos.length; g++) {
                                show_particle(player, `particle DA:purple_x ${BC_pos[g].x}.0 ${BC_pos[g].y}.0 ${BC_pos[g].z}.0`, show_other)
                                show_particle(player, `particle DA:purple_y ${BC_pos[g].x}.0 ${BC_pos[g].y}.0 ${BC_pos[g].z}.0`, show_other)
                                show_particle(player, `particle DA:purple_z ${BC_pos[g].x}.0 ${BC_pos[g].y}.0 ${BC_pos[g].z}.0`, show_other)
                                show_particle(player, `particle DA:purple_x ${BC_pos[g].x + 1}.0 ${BC_pos[g].y}.0 ${BC_pos[g].z}.0`, show_other)
                                show_particle(player, `particle DA:purple_y ${BC_pos[g].x}.0 ${BC_pos[g].y + 1}.0 ${BC_pos[g].z}.0`, show_other)
                                show_particle(player, `particle DA:purple_z ${BC_pos[g].x}.0 ${BC_pos[g].y}.0 ${BC_pos[g].z + 1}.0`, show_other)
                            }
                        }
                        const sample_num = DA_data[player.id]["BC_sample_num"];
                        const step = Math.floor(sample_num / 10);
                        for (let g = 0; g < 10; g++) {
                            const rp = GetBezierCurve(BC_pos, sample_num, ((tick % step * 10) + g));
                            show_particle(player, `particle DA:purple_pointer_hor ${Math.floor(rp.x)} ${Math.floor(rp.y + 1)}.5 ${Math.floor(rp.z)}`, show_other);
                            show_particle(player, `particle DA:purple_pointer_vec ${Math.floor(rp.x)} ${Math.floor(rp.y + 1)}.5 ${Math.floor(rp.z)}`, show_other);
                        }
                        if (DA_data[player.id]["now_BC_index"] == null) { DA_data[player.id]["now_BC_index"] = 0 };
                        if (DA_data[player.id]["now_BC_index"] + 1 >= BC_pos.length) {
                            DA_data[player.id]["now_BC_index"] = 0;
                        }
                        const index = DA_data[player.id]["now_BC_index"];
                        let edge_pos = getEdgePosition(BC_pos[index + 1], BC_pos[index], (tick % 20) * 5);
                        show_particle(player, `particle DA:yellow_orb ${edge_pos.x} ${edge_pos.y} ${edge_pos.z}`, show_other);
                        if (tick % 20 == 0) {
                            DA_data[player.id]["now_BC_index"]++;
                        }
                    }
                }
                if (DA_data[player.id]["terrain_CP"] != null) {
                    if (DA_data[player.id]["terrain_CP"].length > 0) {
                        const terrain_CP = DA_data[player.id]["terrain_CP"];
                        for (let g = 0; g < terrain_CP.length; g++) {
                            if (tick % 40 == 0) {
                                show_particle(player, `particle DA:purple_x ${terrain_CP[g].x}.0 ${terrain_CP[g].y}.0 ${terrain_CP[g].z}.0`, show_other)
                                show_particle(player, `particle DA:purple_y ${terrain_CP[g].x}.0 ${terrain_CP[g].y}.0 ${terrain_CP[g].z}.0`, show_other)
                                show_particle(player, `particle DA:purple_z ${terrain_CP[g].x}.0 ${terrain_CP[g].y}.0 ${terrain_CP[g].z}.0`, show_other)
                                show_particle(player, `particle DA:purple_x ${terrain_CP[g].x + 1}.0 ${terrain_CP[g].y}.0 ${terrain_CP[g].z}.0`, show_other)
                                show_particle(player, `particle DA:purple_y ${terrain_CP[g].x}.0 ${terrain_CP[g].y + 1}.0 ${terrain_CP[g].z}.0`, show_other)
                                show_particle(player, `particle DA:purple_z ${terrain_CP[g].x}.0 ${terrain_CP[g].y}.0 ${terrain_CP[g].z + 1}.0`, show_other)
                            }
                            if (terrain_CP[g]["is_line"] == true && terrain_CP[g]["dx"] != null && terrain_CP[g]["dy"] != null && terrain_CP[g]["dz"] != null) {
                                const pos = [
                                    { x: terrain_CP[g].x, y: terrain_CP[g].y, z: terrain_CP[g].z },
                                    { x: terrain_CP[g].dx, y: terrain_CP[g].dy, z: terrain_CP[g].dz },
                                ]
                                const pattern = [[0, 0], [1, 0], [0, 1], [1, 1]];
                                let speed = Math.floor(Math.min(Math.max(Math.sqrt(32768 / ((Math.abs(pos[0].x - pos[1].x) + 1) * (Math.abs(pos[0].y - pos[1].y) + 1) * (Math.abs(pos[0].z - pos[1].z) + 1))), 1), 100));
                                let loop_num = 1;
                                let edge_pos = getEdgePosition(pos[0], pos[1], ((tick + Math.floor((100 / speed / loop_num) * g)) % (100 / speed)) * speed);
                                for (let i = 0; i < pattern.length; i++) {
                                    let Adjustment_X = (pos[pattern[i][0]].x < pos[(pattern[i][0] == 0) ? 1 : 0].x) ? 0 : 1;
                                    let Adjustment_Y_0 = (pos[pattern[i][0]].y < pos[(pattern[i][0] == 0) ? 1 : 0].y) ? 0 : 1;
                                    let Adjustment_Y_1 = (pos[pattern[i][1]].y < pos[(pattern[i][1] == 0) ? 1 : 0].y) ? 0 : 1;
                                    let Adjustment_Z = (pos[pattern[i][1]].z < pos[(pattern[i][1] == 0) ? 1 : 0].z) ? 0 : 1;
                                    Adjustment_X = (pos[0].x == pos[1].x) ? (pattern[i][0]) : Adjustment_X;
                                    Adjustment_Y_0 = (pos[0].y == pos[1].y) ? (pattern[i][0]) : Adjustment_Y_0;
                                    Adjustment_Y_1 = (pos[0].y == pos[1].y) ? (pattern[i][1]) : Adjustment_Y_1;
                                    Adjustment_Z = (pos[0].z == pos[1].z) ? (pattern[i][1]) : Adjustment_Z;
                                    show_particle(player, `particle ${Range_particle} ${Math.floor(pos[pattern[i][0]].x + Adjustment_X)}.0 ${Math.floor((pos[pattern[i][1]].y + Adjustment_Y_1) * 100) / 100} ${Math.floor(edge_pos.z * 100) / 100}`, show_other)
                                    show_particle(player, `particle ${Range_particle} ${Math.floor(pos[pattern[i][0]].x + Adjustment_X)}.0 ${Math.floor(edge_pos.y * 100) / 100} ${Math.floor(pos[pattern[i][1]].z + Adjustment_Z)}.0`, show_other)
                                    show_particle(player, `particle ${Range_particle} ${Math.floor(edge_pos.x * 100) / 100} ${Math.floor((pos[pattern[i][0]].y + Adjustment_Y_0) * 100) / 100} ${Math.floor(pos[pattern[i][1]].z + Adjustment_Z)}.0`, show_other)
                                }
                            }
                        }
                    }
                }
                if (DA_data[player.id]["select"] != null) {
                    if (DA_data[player.id]["select"]["pos1"].length != 0 && DA_data[player.id]["select"]["pos2"].length != 0) {
                        const pos = [
                            DA_data[player.id]["select"]["pos1"],
                            DA_data[player.id]["select"]["pos2"]
                        ];
                        const pattern = [[0, 0], [1, 0], [0, 1], [1, 1]];
                        let speed = Math.floor(Math.min(Math.max(Math.sqrt(32768 / ((Math.abs(pos[0].x - pos[1].x) + 1) * (Math.abs(pos[0].y - pos[1].y) + 1) * (Math.abs(pos[0].z - pos[1].z) + 1))), 1), 100));
                        let loop_num = 1;
                        if (speed < 5) {
                            loop_num = (7 - speed);
                        }
                        for (let g = 0; g < loop_num; g++) {
                            let edge_pos = getEdgePosition(pos[0], pos[1], ((tick + Math.floor((100 / speed / loop_num) * g)) % (100 / speed)) * speed);
                            if (tick % 20 == 0) {
                                const S_T = ["start", "stop"];
                                if (DA_save_on_world[player.id].is_show_SF) {
                                    for (let i = 0; i < 2; i++) {
                                        const MF_x = Math.floor(pos[i].x);
                                        const MF_y = Math.floor(pos[i].y);
                                        const MF_z = Math.floor(pos[i].z);
                                        show_particle(player, `particle DA:${S_T[i]}_x ${MF_x}.0 ${MF_y}.0 ${MF_z}.0`, show_other)
                                        show_particle(player, `particle DA:${S_T[i]}_y ${MF_x}.0 ${MF_y}.0 ${MF_z}.0`, show_other)
                                        show_particle(player, `particle DA:${S_T[i]}_z ${MF_x}.0 ${MF_y}.0 ${MF_z}.0`, show_other)
                                        show_particle(player, `particle DA:${S_T[i]}_x ${MF_x + 1}.0 ${MF_y}.0 ${MF_z}.0`, show_other)
                                        show_particle(player, `particle DA:${S_T[i]}_y ${MF_x}.0 ${MF_y + 1}.0 ${MF_z}.0`, show_other)
                                        show_particle(player, `particle DA:${S_T[i]}_z ${MF_x}.0 ${MF_y}.0 ${MF_z + 1}.0`, show_other)
                                    }
                                }
                                if (DA_save_on_world[player.id].is_show_center) {
                                    if (tick % 40 == 0) {
                                        const center_x = Math.floor((pos[0].x + pos[1].x) / 2 * 10) / 10;
                                        const center_y = Math.floor((pos[0].y + pos[1].y) / 2 * 10) / 10;
                                        const center_z = Math.floor((pos[0].z + pos[1].z) / 2 * 10) / 10;
                                        show_particle(player, `particle DA:center_x ${center_x + 0.01} ${center_y + 0.01} ${center_z + 0.01}`, show_other)
                                        show_particle(player, `particle DA:center_y ${center_x + 0.01} ${center_y + 0.01} ${center_z + 0.01}`, show_other)
                                        show_particle(player, `particle DA:center_z ${center_x + 0.01} ${center_y + 0.01} ${center_z + 0.01}`, show_other)
                                        show_particle(player, `particle DA:center_x ${center_x + 1 + 0.01} ${center_y + 0.01} ${center_z + 0.01}`, show_other)
                                        show_particle(player, `particle DA:center_y ${center_x + 0.01} ${center_y + 1 + 0.01} ${center_z + 0.01}`, show_other)
                                        show_particle(player, `particle DA:center_z ${center_x + 0.01} ${center_y + 0.01} ${center_z + 1 + 0.01}`, show_other)
                                    }
                                }
                            }
                            for (let i = 0; i < pattern.length; i++) {
                                let Adjustment_X = (pos[pattern[i][0]].x < pos[(pattern[i][0] == 0) ? 1 : 0].x) ? 0 : 1;
                                let Adjustment_Y_0 = (pos[pattern[i][0]].y < pos[(pattern[i][0] == 0) ? 1 : 0].y) ? 0 : 1;
                                let Adjustment_Y_1 = (pos[pattern[i][1]].y < pos[(pattern[i][1] == 0) ? 1 : 0].y) ? 0 : 1;
                                let Adjustment_Z = (pos[pattern[i][1]].z < pos[(pattern[i][1] == 0) ? 1 : 0].z) ? 0 : 1;
                                Adjustment_X = (pos[0].x == pos[1].x) ? (pattern[i][0]) : Adjustment_X;
                                Adjustment_Y_0 = (pos[0].y == pos[1].y) ? (pattern[i][0]) : Adjustment_Y_0;
                                Adjustment_Y_1 = (pos[0].y == pos[1].y) ? (pattern[i][1]) : Adjustment_Y_1;
                                Adjustment_Z = (pos[0].z == pos[1].z) ? (pattern[i][1]) : Adjustment_Z;
                                show_particle(player, `particle ${Range_particle} ${Math.floor(pos[pattern[i][0]].x + Adjustment_X)}.0 ${Math.floor((pos[pattern[i][1]].y + Adjustment_Y_1) * 100) / 100} ${Math.floor(edge_pos.z * 100) / 100}`, show_other)
                                show_particle(player, `particle ${Range_particle} ${Math.floor(pos[pattern[i][0]].x + Adjustment_X)}.0 ${Math.floor(edge_pos.y * 100) / 100} ${Math.floor(pos[pattern[i][1]].z + Adjustment_Z)}.0`, show_other)
                                show_particle(player, `particle ${Range_particle} ${Math.floor(edge_pos.x * 100) / 100} ${Math.floor((pos[pattern[i][0]].y + Adjustment_Y_0) * 100) / 100} ${Math.floor(pos[pattern[i][1]].z + Adjustment_Z)}.0`, show_other)
                            }
                        }
                    }
                }
                if (DA_data[player.id]["prediction"] != null) {
                    if (DA_data[player.id]["prediction"]["type"] == "ball") {
                        if (DA_data[player.id]["prediction"]["temp"] == null) {
                            DA_data[player.id]["prediction"]["temp"] = {
                                sita: 0,
                                phi: 0,
                            }
                        }
                        let prediction = DA_data[player.id]["prediction"];
                        let temp = DA_data[player.id]["prediction"]["temp"];
                        let temp_r = DA_data[player.id]["prediction"]["r"];
                        let speed = Math.floor(Math.min(Math.max(Math.sqrt(32768 / ((Math.abs(temp_r) + 1) * (Math.abs(temp_r) + 1) * (Math.abs(temp_r) + 1))), 1), 10));
                        let loop_num = 1;
                        if (speed < 5) {
                            loop_num = Math.min(Math.max(Math.floor(((7 - speed))) * 2, 1), 16);
                        }
                        for (let i = 0; i < loop_num; i++) {
                            temp.phi += (Math.PI / 18 * speed);
                            if (temp.phi > Math.PI * 2) {
                                temp.sita += (Math.PI / 18 * speed);
                                temp.phi = 0;
                            }
                            if (temp.sita > Math.PI * 2) {
                                temp.sita = 0;
                            }

                            let x = Math.floor(temp_r * Math.cos(temp.sita) * Math.sin(temp.phi) * 100) / 100;
                            let y = Math.floor(temp_r * Math.sin(temp.sita) * Math.sin(temp.phi) * 100) / 100;
                            let z = Math.floor(temp_r * Math.cos(temp.phi) * 100) / 100;
                            show_particle(player, `particle ${Prediction_Range_particle}  ${prediction.pos.x + x + 0.5} ${prediction.pos.y + y + 0.5} ${prediction.pos.z + z + 0.5}`, show_other)
                            show_particle(player, `particle ${Prediction_Range_particle}  ${prediction.pos.x - x + 0.5} ${prediction.pos.y - y + 0.5} ${prediction.pos.z - z + 0.5}`, show_other)
                        }
                    } else if (DA_data[player.id]["prediction"]["type"] == "circle") {
                        let prediction = DA_data[player.id]["prediction"];
                        if (DA_data[player.id]["prediction"]["temp2"] == null) {
                            DA_data[player.id]["prediction"]["temp2"] = {
                                sita: 0,
                                y: prediction.min_pos.y,
                            }
                        }
                        let temp = DA_data[player.id]["prediction"]["temp2"];
                        let temp_r = DA_data[player.id]["prediction"]["r"];
                        let speed = Math.floor(Math.min(Math.max(Math.sqrt(32768 / ((Math.abs(temp_r) + 1) * (Math.abs(prediction.max_pos.y - prediction.min_pos.y) + 1) * (Math.abs(temp_r) + 1))), 1), 10));
                        let loop_num = 1;
                        if (speed < 5) {
                            loop_num = Math.min(Math.max(Math.floor(((7 - speed))) * 2, 1), 16);
                        }
                        for (let i = 0; i < loop_num; i++) {
                            temp.sita += (Math.PI / 36 * speed);
                            if (temp.sita > Math.PI * 2) {
                                temp.y++;
                                temp.sita = 0;
                            }
                            if (temp.y > prediction.max_pos.y) {
                                temp.y = prediction.min_pos.y;
                            }

                            let x = Math.floor(temp_r * Math.cos(temp.sita) * 100) / 100;
                            let z = Math.floor(temp_r * Math.sin(temp.sita) * 100) / 100;
                            show_particle(player, `particle ${Prediction_Range_particle}  ${prediction.min_pos.x + x + 0.5} ${temp.y + 0.5} ${prediction.min_pos.z + z + 0.5}`, show_other)
                            show_particle(player, `particle ${Prediction_Range_particle}  ${prediction.min_pos.x - x + 0.5} ${temp.y + 0.5} ${prediction.min_pos.z - z + 0.5}`, show_other)
                        }
                    } else if (DA_data[player.id]["prediction"]["pos1"].length != 0 && DA_data[player.id]["prediction"]["pos2"].length != 0) {
                        const pos = [
                            DA_data[player.id]["prediction"]["pos1"],
                            DA_data[player.id]["prediction"]["pos2"]
                        ];
                        const pattern = [[0, 0], [1, 0], [0, 1], [1, 1]];
                        let speed = Math.floor(Math.min(Math.max(Math.sqrt(32768 / ((Math.abs(pos[0].x - pos[1].x) + 1) * (Math.abs(pos[0].y - pos[1].y) + 1) * (Math.abs(pos[0].z - pos[1].z) + 1))), 1), 100));
                        let loop_num = 1;
                        if (speed < 5) {
                            loop_num = Math.min(Math.floor(((7 - speed) / 2)), 1);
                        }
                        for (let g = 0; g < loop_num; g++) {
                            let edge_pos = getEdgePosition(pos[0], pos[1], ((tick + Math.floor((100 / speed / loop_num) * g)) % (100 / speed)) * speed);
                            for (let i = 0; i < pattern.length; i++) {
                                let Adjustment_X = (pos[pattern[i][0]].x < pos[(pattern[i][0] == 0) ? 1 : 0].x) ? 0 : 1;
                                let Adjustment_Y_0 = (pos[pattern[i][0]].y < pos[(pattern[i][0] == 0) ? 1 : 0].y) ? 0 : 1;
                                let Adjustment_Y_1 = (pos[pattern[i][1]].y < pos[(pattern[i][1] == 0) ? 1 : 0].y) ? 0 : 1;
                                let Adjustment_Z = (pos[pattern[i][1]].z < pos[(pattern[i][1] == 0) ? 1 : 0].z) ? 0 : 1;
                                Adjustment_X = (pos[0].x == pos[1].x) ? (pattern[i][0]) : Adjustment_X;
                                Adjustment_Y_0 = (pos[0].y == pos[1].y) ? (pattern[i][0]) : Adjustment_Y_0;
                                Adjustment_Y_1 = (pos[0].y == pos[1].y) ? (pattern[i][1]) : Adjustment_Y_1;
                                Adjustment_Z = (pos[0].z == pos[1].z) ? (pattern[i][1]) : Adjustment_Z;
                                show_particle(player, `particle ${Prediction_Range_particle} ${Math.floor(pos[pattern[i][0]].x + Adjustment_X)}.0 ${Math.floor((pos[pattern[i][1]].y + Adjustment_Y_1) * 100) / 100} ${Math.floor(edge_pos.z * 100) / 100}`, show_other)
                                show_particle(player, `particle ${Prediction_Range_particle} ${Math.floor(pos[pattern[i][0]].x + Adjustment_X)}.0 ${Math.floor(edge_pos.y * 100) / 100} ${Math.floor(pos[pattern[i][1]].z + Adjustment_Z)}.0`, show_other)
                                show_particle(player, `particle ${Prediction_Range_particle} ${Math.floor(edge_pos.x * 100) / 100} ${Math.floor((pos[pattern[i][0]].y + Adjustment_Y_0) * 100) / 100} ${Math.floor(pos[pattern[i][1]].z + Adjustment_Z)}.0`, show_other)
                            }
                        }
                    }
                }
                if (DA_data[player.id]["Iconnect"] != null) {
                    if (DA_data[player.id]["Iconnect"]["flag"]) {
                        if (DA_data[player.id]["Iconnect"]["inventory"] == null) {
                            DA_data[player.id]["Iconnect"]["inventory"] = {
                                main: [],
                                offhand: null,
                                Equipment: {},
                            }
                        }
                        const target = DA_data[player.id]["Iconnect"].target;
                        try {
                            const is_first = DA_data[player.id]["Iconnect"]["is_first"] ?? true;
                            //自分から
                            const my_inventory = player.getComponent("minecraft:inventory").container;
                            const my_Offhand = player.getComponent("minecraft:equippable").getEquipment("Offhand");
                            const my_Head = player.getComponent("minecraft:equippable").getEquipment("Head");
                            const my_Chest = player.getComponent("minecraft:equippable").getEquipment("Chest");
                            const my_Feet = player.getComponent("minecraft:equippable").getEquipment("Feet");
                            const my_Legs = player.getComponent("minecraft:equippable").getEquipment("Legs");
                            const my_item_arr = [];
                            for (let i = 0; i < my_inventory.size; i++) {
                                const my_inventory_item = my_inventory.getItem(i);
                                if (my_inventory_item != undefined) {
                                    my_item_arr.push({ id: my_inventory_item.type.id, num: my_inventory_item.amount })
                                }
                            }
                            if (JSON.stringify(DA_data[player.id]["Iconnect"]["inventory"]["main"]) != JSON.stringify(my_item_arr) && !is_first) {
                                for (let i = 0; i < my_inventory.size; i++) {
                                    const my_inventory_item = my_inventory.getItem(i);
                                    target.getComponent("minecraft:inventory").container.setItem(i, my_inventory_item);
                                }
                            }
                            let JD_my_Offhand = (my_Offhand != undefined) ? { id: my_Offhand.type.id, num: my_Offhand.amount } : {};
                            let JD_my_Head = (my_Head != undefined) ? { id: my_Head.type.id, num: my_Head.amount } : {};
                            let JD_my_Chest = (my_Chest != undefined) ? { id: my_Chest.type.id, num: my_Chest.amount } : {};
                            let JD_my_Legs = (my_Legs != undefined) ? { id: my_Legs.type.id, num: my_Legs.amount } : {};
                            let JD_my_Feet = (my_Feet != undefined) ? { id: my_Feet.type.id, num: my_Feet.amount } : {};
                            if (JSON.stringify(DA_data[player.id]["Iconnect"]["inventory"]["offhand"]) != JSON.stringify(JD_my_Offhand) && !is_first) {
                                target.getComponent("minecraft:equippable").setEquipment("Offhand", my_Offhand);
                            }
                            if (JSON.stringify(DA_data[player.id]["Iconnect"]["inventory"]["Equipment"]["head"]) != JSON.stringify(JD_my_Head) && !is_first) {
                                target.getComponent("minecraft:equippable").setEquipment("Head", my_Head);
                            }
                            if (JSON.stringify(DA_data[player.id]["Iconnect"]["inventory"]["Equipment"]["chest"]) != JSON.stringify(JD_my_Chest) && !is_first) {
                                target.getComponent("minecraft:equippable").setEquipment("Chest", my_Chest);
                            }
                            if (JSON.stringify(DA_data[player.id]["Iconnect"]["inventory"]["Equipment"]["legs"]) != JSON.stringify(JD_my_Legs) && !is_first) {
                                target.getComponent("minecraft:equippable").setEquipment("Legs", my_Legs);
                            }
                            if (JSON.stringify(DA_data[player.id]["Iconnect"]["inventory"]["Equipment"]["feet"]) != JSON.stringify(JD_my_Feet) && !is_first) {
                                target.getComponent("minecraft:equippable").setEquipment("Feet", my_Feet);
                            }
                            //相手から
                            const target_inventory = target.getComponent("minecraft:inventory").container;
                            const Offhand = target.getComponent("minecraft:equippable").getEquipment("Offhand");
                            const Head = target.getComponent("minecraft:equippable").getEquipment("Head");
                            const Chest = target.getComponent("minecraft:equippable").getEquipment("Chest");
                            const Feet = target.getComponent("minecraft:equippable").getEquipment("Feet");
                            const Legs = target.getComponent("minecraft:equippable").getEquipment("Legs");
                            const item_arr = [];
                            for (let i = 0; i < target_inventory.size; i++) {
                                const target_inventory_item = target_inventory.getItem(i);
                                if (target_inventory_item != undefined) {
                                    item_arr.push({ id: target_inventory_item.type.id, num: target_inventory_item.amount })
                                }
                                player.getComponent("minecraft:inventory").container.setItem(i, target_inventory_item)
                            }
                            player.getComponent("minecraft:equippable").setEquipment("Offhand", Offhand);
                            player.getComponent("minecraft:equippable").setEquipment("Head", Head);
                            player.getComponent("minecraft:equippable").setEquipment("Chest", Chest);
                            player.getComponent("minecraft:equippable").setEquipment("Feet", Feet);
                            player.getComponent("minecraft:equippable").setEquipment("Legs", Legs);
                            DA_data[player.id]["Iconnect"]["inventory"]["main"] = item_arr;
                            DA_data[player.id]["Iconnect"]["inventory"]["offhand"] = (Offhand != undefined) ? { id: Offhand.type.id, num: Offhand.amount } : {};
                            DA_data[player.id]["Iconnect"]["inventory"]["Equipment"]["head"] = (Head != undefined) ? { id: Head.type.id, num: Head.amount } : {};
                            DA_data[player.id]["Iconnect"]["inventory"]["Equipment"]["chest"] = (Chest != undefined) ? { id: Chest.type.id, num: Chest.amount } : {};
                            DA_data[player.id]["Iconnect"]["inventory"]["Equipment"]["legs"] = (Legs != undefined) ? { id: Legs.type.id, num: Legs.amount } : {};
                            DA_data[player.id]["Iconnect"]["inventory"]["Equipment"]["feet"] = (Feet != undefined) ? { id: Feet.type.id, num: Feet.amount } : {};
                            DA_data[player.id]["Iconnect"]["is_first"] = false;
                            run_command_player(player, `title @s actionbar ${target.nameTag} §r§eのインベントリを共有中`);
                            run_command_player(target, `title @s actionbar ${player.nameTag} §r§eがインベントリを共有中`);
                        } catch (e) {
                            DA_data[player.id]["Iconnect"]["flag"] = false;
                            run_command_player(player, `tellraw @s{"rawtext":[{"text":"§cDA => インベントリ共有を強制終了しました。"}]}`)
                            run_command(`say => ${e.stack} ${e}`)
                        }
                    }
                }
            }
        }
    }
    if (players[0] == null) {
        return;
    }
    run_command(`tag @a remove IG_has_offhand_DA_AM`);
    run_command(`tag @a[hasitem={item=da:da_automatic,location=slot.weapon.offhand}] add IG_has_offhand_DA_AM`);
    for (let i = 0; i < players.length; i++) {
        if (Math.floor(players[i].getVelocity().x * 100) != 0 || Math.floor(players[i].getVelocity().y * 100) != 0 || Math.floor(players[i].getVelocity().z * 100) != 0) {
            DA_is_Leave[players[i].id] = (new Date).getTime();
        }
        if (players[i].isSneaking) {
            if (Run_function_at_shift[players[i].id] != null) {
                Run_function_at_shift[players[i].id]();
                delete Run_function_at_shift[players[i].id];
            }
            if (DA_save_on_world[players[i].id] != null) {
                if (DA_save_on_world[players[i].id]["elytra_boost"] == true && players[i].isGliding) {
                    let rotate = (players[i].getRotation().y) % 360;
                    let angle = (players[i].getRotation().x) % 360;
                    let vec = {
                        x: Math.sin((rotate + 180) * (Math.PI / 180)),
                        z: Math.cos(rotate * (Math.PI / 180))
                    }
                    const strength = Number(DA_save_on_world[players[i].id]["elytra_boost_strength"] ?? 1);
                    players[i].applyKnockback(vec.x, vec.z, Number(strength) * (1 - Math.abs(-angle / 90)), Number(strength) * (-angle / 90));
                }
            }
        }
        if (DA_save_on_world[players[i].id] != null) {
            if (DA_data[players[i].id] != null) {
                if (DA_save_on_world[players[i].id]["inventory_silder"] == 1 || (DA_save_on_world[players[i].id]["inventory_silder"] == 2 && players[i].isSneaking)) {
                    let is_ISSI_chenged = false;
                    let sob = 0;
                    if (DA_data[players[i].id]["before_ISSI"] != null) {
                        if (DA_data[players[i].id]["before_ISSI"]["index"] != players[i].selectedSlotIndex) {
                            is_ISSI_chenged = true;
                            if ((new Date).getTime() - DA_data[players[i].id]["before_ISSI"]["time"] < 600 && !((DA_data[players[i].id]["before_ISSI"]["mixim_num"] - Math.abs(DA_data[players[i].id]["before_ISSI"]["score"])) > 3)) {
                                if (DA_data[players[i].id]["before_ISSI"]["index"] < players[i].selectedSlotIndex) {
                                    DA_data[players[i].id]["before_ISSI"]["score"]++;
                                    sob = 1;
                                } else {
                                    DA_data[players[i].id]["before_ISSI"]["score"]--;
                                    sob = -1;
                                }
                            } else {
                                DA_data[players[i].id]["before_ISSI"]["score"] = 0;
                                DA_data[players[i].id]["before_ISSI"]["mixim_num"] = 0;
                            }
                            DA_data[players[i].id]["before_ISSI"]["mixim_num"] = Math.max(Math.abs(DA_data[players[i].id]["before_ISSI"]["score"]), DA_data[players[i].id]["before_ISSI"]["mixim_num"]);
                        };
                    }
                    if (DA_data[players[i].id]["before_ISSI"] == null || is_ISSI_chenged) {
                        if (DA_data[players[i].id]["before_ISSI"] == null) {
                            DA_data[players[i].id]["before_ISSI"] = { index: players[i].selectedSlotIndex, time: (new Date).getTime(), score: 0, mixim_num: 0 };
                        }
                        DA_data[players[i].id]["before_ISSI"].index = players[i].selectedSlotIndex;
                        DA_data[players[i].id]["before_ISSI"].time = (new Date).getTime();
                    }
                    const JN = (DA_save_on_world[players[i].id]["inventory_silder"] == 2) ? 2 : 6;
                    if (players[i].selectedSlotIndex == 8 || (DA_data[players[i].id]["before_ISSI"]["score"] < -JN && sob == 1)) {
                        if (DA_data[players[i].id]["IS_next"] == -1 || (DA_data[players[i].id]["before_ISSI"]["score"] < -JN && sob == 1)) {
                            const pc = players[i].getComponent("minecraft:inventory").container;
                            for (let g = 0; g < pc.size - 9; g++) {
                                pc.swapItems(g, (g + 9) % (pc.size), pc);
                            }
                        }
                        if (DA_data[players[i].id]["IS_next"] != 1 && (DA_save_on_world[players[i].id]["inventory_silder_alert"] ?? false)) {
                            run_command_player(players[i], `playsound random.stone_click @s ~~1.5~ 100 1`);
                        }
                        DA_data[players[i].id]["IS_next"] = 1;
                    } else if (players[i].selectedSlotIndex == 0 || (DA_data[players[i].id]["before_ISSI"]["score"] > JN && sob == -1)) {
                        if (DA_data[players[i].id]["IS_next"] == 1 || (DA_data[players[i].id]["before_ISSI"]["score"] > JN && sob == -1)) {
                            const pc = players[i].getComponent("minecraft:inventory").container;
                            for (let g = pc.size - 1; g >= 9; g--) {
                                pc.swapItems(g, (g + 9) % (pc.size), pc);
                            }
                        }
                        if (DA_data[players[i].id]["IS_next"] != -1 && (DA_save_on_world[players[i].id]["inventory_silder_alert"] ?? false)) {
                            run_command_player(players[i], `playsound random.stone_click @s ~~1.5~ 100 1`);
                        }
                        DA_data[players[i].id]["IS_next"] = -1;
                    } else {
                        DA_data[players[i].id]["IS_next"] = 0;
                    }
                } else if (DA_save_on_world[players[i].id]["inventory_silder"] == 2 && !players[i].isSneaking) {
                    if (DA_data[players[i].id]["before_ISSI"] != null) {
                        DA_data[players[i].id]["before_ISSI"]["score"] = 0;
                        DA_data[players[i].id]["before_ISSI"]["mixim_num"] = 0;
                    }
                    DA_data[players[i].id]["IS_next"] = 0;
                }
                if (DA_data[players[i].id]["inventory"] != null && (DA_save_on_world[players[i].id]["inventory_cleaner"] ?? false)) {
                    DA_data[players[i].id]["inventory"][players[i].selectedSlotIndex]["score"] = 0;
                    DA_data[players[i].id]["inventory"][players[i].selectedSlotIndex]["time"] = (new Date).getTime();
                }
            }
            if (DA_save_on_world[players[i].id]["fly_speed"] != null && DA_save_on_world[players[i].id]["custom_speed"] != null) {
                if (DA_save_on_world[players[i].id]["custom_speed"] == true && players[i].isFlying && DA_save_on_world[players[i].id]["fly_speed"] > 1) {
                    const move_input = players[i].inputInfo.getMovementVector();
                    const move_input_true = (move_input.x != 0 || move_input.y != 0);
                    // 注意！https://learn.microsoft.com/ja-jp/minecraft/creator/scriptapi/minecraft/server/inputinfo?view=minecraft-bedrock-experimental
                    // 実験的機能。
                    //players[i].inputInfo.getButtonState("Jump")
                    //players[i].inputInfo.getButtonState("Sneak")
                    //players[i].inputInfo.getMovementVector();
                    const player_info = players[i].inputInfo;
                    if (move_input_true) {
                        const velocity = players[i].getVelocity();
                        let rotate = (players[i].getRotation().y) % 360;
                        let angle = (players[i].getRotation().x) % 360;
                        let vec = {
                            x: Math.sin(((rotate) + 180) * (Math.PI / 180)),
                            z: Math.cos((rotate) * (Math.PI / 180))
                        }
                        const speed = Math.sqrt(Math.pow(Math.floor(velocity.x * 100), 2) + Math.pow(Math.floor(velocity.y * 100), 2) + Math.pow(Math.floor(velocity.z * 100), 2));
                        if (speed > 100) {
                            if (DA_data[players[i].id] == null) {
                                player_setting_data(players[i]);
                            }
                            const strength = Math.min(((speed) / 66), DA_save_on_world[players[i].id]["fly_speed"]);
                            const is_press_y = (player_info.getButtonState("Sneak") == "Pressed" || player_info.getButtonState("Jump") == "Pressed") ? 2 : 0;
                            players[i].applyKnockback(vec.x, vec.z, Number(strength * move_input.y) * (1 - Math.abs(1 / 90)), Math.max(Math.min(Math.floor(Number(strength * (velocity.y * is_press_y))), DA_save_on_world[players[i].id]["fly_speed"]), -DA_save_on_world[players[i].id]["fly_speed"]));
                        }
                    }
                }
            }
        }
    }
    if (DA_save_on_world["MOMIJI"] != null) {
        const JP_now = Get_now_date();
        if (DA_save_on_world["MOMIJI"]["stopwatch"] != null) {
            const stopwatch = DA_save_on_world["MOMIJI"]["stopwatch"];
            for (let i = 0; i < stopwatch.length; i++) {
                try {
                    if (JP_now.getTime() - stopwatch[i].time > 1000 * 60 * 60 * 24 * 3) {
                        throw new Error("stop");
                    }
                    run_command_player(stopwatch[i].player, `title @s actionbar ${format_milisec_to_str(JP_now.getTime() - stopwatch[i].time, true)}`)
                } catch (e) {
                    stopwatch.splice(i, 1);
                    i--;
                }
            }
        }
    }

    tick++;
    if (tick > 1000) {
        tick = 0;
    }
})

function player_setting_data(player) {
    if (DA_data[player.id] == null) {
        DA_data[player.id] = {};
    }
    if (DA_data[player.id]["select"] == null) {
        DA_data[player.id]["select"] = {
            pos1: [],
            pos2: []
        }
    }
    if (DA_data[player.id]["prediction"] == null) {
        DA_data[player.id]["prediction"] = {
            pos1: [],
            pos2: []
        }
    }
    if (DA_data[player.id]["let"] == null) {
        DA_data[player.id]["let"] = {
            type: null,
        };
    }
    if (DA_data[player.id]["undo"] == null) {
        DA_data[player.id]["undo"] = [];
    }
    if (DA_data[player.id]["Automatic_block_undo"] == null) {
        DA_data[player.id]["Automatic_block_undo"] = [];
    }
    if (DA_data[player.id]["copy"] == null) {
        DA_data[player.id]["copy"] = [];
    }
    if (DA_data[player.id]["copy_data"] == null) {
        DA_data[player.id]["copy_data"] = {};
    }
    if (DA_save_on_world[player.id] == null) {
        DA_save_on_world[player.id] = {
            show_type: "ボタン",
            Range: {
                particle: "minecraft:obsidian_glow_dust_particle",
            },
            Prediction_Range: {
                particle: "minecraft:villager_happy",
            },
        };
    }
    if (DA_save_on_world[player.id]["is_show_SF"] == null || DA_save_on_world[player.id]["is_show_center"] == null) {
        DA_save_on_world[player.id]["is_show_SF"] = false;
        DA_save_on_world[player.id]["is_show_center"] = true;
    }
    if (DA_save_on_world[player.id]["Connect_Pass"] == null) {
        DA_save_on_world[player.id]["Connect_Pass"] = 1;
    }
    if (DA_save_on_world[player.id]["LUNATIC_setting"] == null) {
        DA_save_on_world[player.id]["LUNATIC_setting"] = {
            can_change_setting: true,
            can_player_tp: false,
            can_camera: false,
            can_bind: false,
            can_change_num: 1024,
            can_fill: true,
            can_replace: true,
            can_cut: true,
            can_rotate: true,
            can_flip: true,
            can_copy: true,
            can_paste: true,
            can_circle: true,
            can_ball: true,
            can_line: true,
            can_BezierCurves: true,
            can_terrain: false,
            can_frame: false,
            can_undo: true,
            can_select_num: 1024,
            can_tp_select: true,
            can_use_automatic: false,
            can_use_taskmanager: false,
        };
    } else if (DA_save_on_world[player.id]["LUNATIC_setting"]["can_use_taskmanager"] == null) {
        DA_save_on_world[player.id]["LUNATIC_setting"] = null;
        player_setting_data(player);
    }
    if (DA_save_on_world["group_chat"] == null) {
        DA_save_on_world["group_chat"] = {

        }
    }
    if (DA_save_on_world["list_chat"] == null) {
        DA_save_on_world["list_chat"] = {

        };
    }
    if (DA_data[player.id]["Next_Registration_Commands"] == null) {
        DA_data[player.id]["Next_Registration_Commands"] = false;
    }
    if (DA_ABU[player.id] == null) {
        DA_ABU[player.id] = {};
    }
    if (DA_ABU[player.id]["Automatic_block_undo"] == null) {
        DA_ABU[player.id]["Automatic_block_undo"] = [];
    }
}

function check_selected_pos(player) {
    if (DA_data[player.id] != null) {
        if (DA_data[player.id]["select"] != null) {
            if (DA_data[player.id]["select"]["pos1"].length != 0 && DA_data[player.id]["select"]["pos2"].length != 0)
                return true;
        } else {
            return false;
        }
    } else {
        return false;
    }
}

function get_selected_pos(player) {
    if (DA_data[player.id] == null) {
        return null;
    } else {
        return { pos1: DA_data[player.id]["select"]["pos1"], pos2: DA_data[player.id]["select"]["pos2"] };
    }
}

let last_DA_brush_use = 0;

world.beforeEvents.itemUseOn.subscribe(ev => {
    const block = ev.block;
    const block_pos = block.location;
    const player = ev.source;
    const item = ev.itemStack.typeId;
    if (get_authority_num(player) < 3 && item == "da:da_brush") {
        use_on_block = (new Date).getTime();
    }
    if (DA_data[player.id] != null) {
        if (DA_save_on_world[player.id] != null) {
            if ((DA_save_on_world[player.id]["inventory_cleaner"] ?? false) && (DA_data[player.id]["inventory"] != null)) {
                DA_data[player.id]["inventory"][player.selectedSlotIndex]["score"] = 0;
                DA_data[player.id]["inventory"][player.selectedSlotIndex]["time"] = (new Date).getTime();
                DA_data[player.id]["inventory"][player.selectedSlotIndex]["id"] = item;
            }
        }
    }
    if (get_authority_num(player) < 3 && item == "da:da_brush" && (new Date).getTime() - last_DA_brush_use > 250) {
        last_DA_brush_use = (new Date).getTime();
        player_setting_data(player);
        if ((DA_data[player.id]["is_BC_mode"] ?? false) == true) {
            system.run(() => {
                const BC_pos = DA_data[player.id]["BC_pos"];
                let is_deleted = false;
                for (let i = 1; i < BC_pos.length - 1; i++) {
                    if (BC_pos[i].x == block_pos.x && BC_pos[i].y == block_pos.y && BC_pos[i].z == block_pos.z) {
                        DA_data[player.id]["BC_pos"].splice(i, 1);
                        i--;
                        is_deleted = true;
                        run_command_player(player, `title @s actionbar §b${block_pos.x} ${block_pos.y} ${block_pos.z}のパスポイントを削除しました。`);
                    }
                }
                if (!is_deleted) {
                    run_command_player(player, `title @s actionbar §6指定した場所にパスポイントはありません。`);
                }
            })
        } else if ((DA_data[player.id]["is_TS_mode"] ?? false) == true) {
            system.run(() => {
                const terrain_CP = DA_data[player.id]["terrain_CP"];
                let is_deleted = false;
                for (let i = 0; i < terrain_CP.length; i++) {
                    if (terrain_CP[i].x == block_pos.x && terrain_CP[i].y == block_pos.y && terrain_CP[i].z == block_pos.z) {
                        DA_data[player.id]["terrain_CP"].splice(i, 1);
                        i--;
                        is_deleted = true;
                        run_command_player(player, `title @s actionbar §b${block_pos.x} ${block_pos.y} ${block_pos.z}のパスポイントを削除しました。`);
                    }
                }
                if (!is_deleted) {
                    run_command_player(player, `title @s actionbar §6指定した場所にパスポイントはありません。`);
                }
            })
        } else {
            system.run(() => {
                DA_data[player.id].select.pos2 = block_pos;
                run_command_player(player, `title @s actionbar §b${block_pos.x} ${block_pos.y} ${block_pos.z}に終点をセットしました。`);
            })
        }
    }
    if (get_authority_num(player) < 3 && item == "da:da_brush") {
        ev.cancel = true;
    }
})

function run_select_change(this_task_id, player, position = null, before = (min_pos, max_pos, taskQueue) => { }, before_xz = (min_pos, max_pos, x, z, taskQueue) => { }, xz = (min_pos, max_pos, x, z, taskQueue) => { }, xzy = (min_pos, max_pos, x, y, z, taskQueue) => { }, after_xz = (min_pos, max_pos, x, z, taskQueue) => { }, b_then = (min_pos, max_pos, taskQueue) => { }, after = () => { }) {
    const pos = position ?? get_selected_pos(player);
    const min_pos = { x: Math.min(pos.pos1.x, pos.pos2.x), y: Math.min(pos.pos1.y, pos.pos2.y), z: Math.min(pos.pos1.z, pos.pos2.z) }
    const max_pos = { x: Math.max(pos.pos1.x, pos.pos2.x), y: Math.max(pos.pos1.y, pos.pos2.y), z: Math.max(pos.pos1.z, pos.pos2.z) }
    const taskQueue = [];
    before(min_pos, max_pos, taskQueue);
    const ConPas = DA_save_on_world[player.id]["Connect_Pass"];
    for (let x = min_pos.x; x <= max_pos.x; x += Nob_tp_ao - ((ConPas < 1) ? 0 : ConPas - 1)) {
        for (let z = min_pos.z; z <= max_pos.z; z += Nob_tp_ao - ((ConPas < 1) ? 0 : ConPas - 1)) {
            taskQueue.push(() => { before_xz(min_pos, max_pos, x, z, taskQueue) });
            taskQueue.push(() => { xz(min_pos, max_pos, x, z, taskQueue) });
            for (let y = min_pos.y; y <= max_pos.y; y += 6) {
                taskQueue.push(() => { xzy(min_pos, max_pos, x, y, z, taskQueue) });
            }
            taskQueue.push(() => { after_xz(min_pos, max_pos, x, z, taskQueue) });
        }
    }
    taskQueue.push(() => { b_then(min_pos, max_pos, taskQueue) });
    let message_decoration = ["---", "#--", "##-", "###", "-##", "--#", "---"];
    function processQueue() {
        if (taskQueue.length === 0) {
            run_command_player(player, `title @s actionbar §o§b§l完了！`);
            after();
            return;
        } else {
            let is_string = false;
            if (typeof taskQueue[0] == "string") {
                if (String(taskQueue[0]).indexOf("wait for test block:") != -1) {
                    is_string = true;
                    let poss = [];
                    if (String(taskQueue[0]).indexOf("wait for test block:[") != -1) {
                        const input_pos = JSON.parse(String(taskQueue[0]).split("wait for test block:")[1].replaceAll(" ", ","));
                        const basic_pos = [{ x: input_pos[0], y: input_pos[1], z: input_pos[2] }, { x: input_pos[3], y: input_pos[4], z: input_pos[5] }];
                        const min_pos = {
                            x: Math.min(basic_pos[0].x, basic_pos[1].x),
                            y: Math.min(basic_pos[0].y, basic_pos[1].y),
                            z: Math.min(basic_pos[0].z, basic_pos[1].z)
                        }
                        const max_pos = {
                            x: Math.max(basic_pos[0].x, basic_pos[1].x),
                            y: Math.max(basic_pos[0].y, basic_pos[1].y),
                            z: Math.max(basic_pos[0].z, basic_pos[1].z)
                        }
                        for (let x = min_pos.x; x <= max_pos.x; x += (32 - ((DA_save_on_world[player.id]["Connect_Pass"] ?? 0) * 3))) {
                            for (let z = min_pos.z; z <= max_pos.z; z += (32 - ((DA_save_on_world[player.id]["Connect_Pass"] ?? 0) * 3))) {
                                poss.push(x, (Math.floor(Math.random() * 2) == 0) ? min_pos.y : max_pos.y, z);
                            }
                        }
                        const square = [[0, 0, 0], [1, 0, 0], [0, 0, 1], [1, 0, 1], [0, 1, 0], [1, 1, 0], [0, 1, 1], [1, 1, 1]];
                        for (let g = 0; g < square.length; g++) {
                            poss.push(basic_pos[square[g][0]].x, basic_pos[square[g][1]].y, basic_pos[square[g][2]].z);
                        }
                    } else {
                        const input_pos = String(taskQueue[0]).split("wait for test block:")[1].split(" ");
                        poss = input_pos;
                    }
                    let block = [];
                    try {
                        for (let i = 0; (i + 2) < poss.length; i += 3) {
                            block.push((player.dimension).getBlock({ x: Math.floor(Number(poss[i])), y: Math.floor(Number(poss[i + 1])), z: Math.floor(Number(poss[i + 2])) }));
                        }
                    } catch (e) {
                        run_command_player(player, `say §cDA-Error(Please reload) => ${e}`);
                    }
                    if (block.indexOf(undefined) == -1 && block.indexOf(null) == -1) {
                        taskQueue.shift();
                    }
                }
            }
            if (!is_string) {
                const task = taskQueue.shift();
                if (task)
                    task();
            }
            const decoration_index = (taskQueue.length % message_decoration.length);
            run_command_player(player, `title @s actionbar §e${message_decoration[decoration_index]}§o§6残り:${taskQueue.length}個§r§e${message_decoration[decoration_index]}`);
            if (DA_now_tasking[this_task_id].situation == "Stopping") {
                taskQueue.splice(0, Infinity);
            }
            if (taskQueue.length % 100 == 0 && taskQueue.length > 10) {
                run_command_player(player, `title @s actionbar §o§6-=-処理待ち-=-`);
                system.runTimeout(processQueue, (DA_save_on_world[player.id]["Waiting_drawing"] ?? 60));
            } else {
                system.runTimeout(processQueue, (DA_save_on_world[player.id]["Connect_Pass"] ?? 1));
            }
        };
    }
    processQueue();
}

world.beforeEvents.chatSend.subscribe(ev => {
    const msg = String(ev.message).replaceAll("\"", "").replaceAll("\'", "").replaceAll("\`", "").replaceAll("\\", "");
    const player = ev.sender;
    let is_binded = false;
    DA_is_Leave[player.id] = (new Date).getTime();
    if (DA_save_on_world[player.id] != null) {
        if (DA_save_on_world[player.id]["bind"] != null) {
            const bind = DA_save_on_world[player.id]["bind"];
            for (let i = 0; i < bind.length; i++) {
                if (bind[i].type == "Chat" && bind[i].value == msg) {
                    system.run(() => {
                        run_command_player(player, `tellraw @s {"rawtext":[{"text":"§b§oDA => 実行: ${bind[i].commands}"}]}`)
                    })
                    DA_command(player, bind[i].commands, ev);
                    ev.cancel = true;
                    is_binded = true;
                }
            }
        }
    }
    if (!is_binded) {
        DA_command(player, msg, ev);
    }
    if (!ev.cancel) {
        MOMIJI(player, msg);
        if (!ev.cancel) {
            const All_players = world.getAllPlayers();
            if (DA_save_on_world["list_chat"] != null) {
                for (let i = 0; i < All_players.length; i++) {
                    if (DA_save_on_world["list_chat"][All_players[i].id] != null) {
                        DA_save_on_world["list_chat"][All_players[i].id]["skip_lcs"] = false;
                    }
                }
            }
            for (const key in DA_save_on_world["group_chat"]) {
                if (Object.prototype.hasOwnProperty.call(DA_save_on_world["group_chat"], key)) {
                    DA_save_on_world["group_chat"][key]["skip_gcs"] = false;
                }
            }
        }
        This_chat_ID++;
        if (This_chat_ID > 9999) {
            This_chat_ID = 1;
        }
        const TCID = Number(String(This_chat_ID));
        if (msg.indexOf("https://") != -1 || msg.indexOf("http://") != -1) {
            system.run(() => {
                run_command_player(player, `tellraw @a {"rawtext":[{"text":"§eDA Copy Link=>§b .cl ${TCID}"}]}`);
            })
            DA_copy_chats.unshift({ ID: TCID, type: "url", value: `${msg}`, time: Get_now_date() });
        } else if (msg.indexOf("cp[") != -1 && msg.split("]").length > 1) {
            system.run(() => {
                run_command_player(player, `tellraw @a {"rawtext":[{"text":"§eDA Copy Text=>§b .cl ${TCID}"}]}`);
            })
            DA_copy_chats.unshift({ ID: TCID, type: "cp", value: `${extractCp(msg)}`, time: Get_now_date() });
        } else {
            DA_copy_chats.unshift({ ID: TCID, type: "text", value: `${msg}`, time: Get_now_date() });
        }
        DA_copy_chats.splice(30);
    }
})

const extractCp = s => { let b = s.indexOf('.cp['); if (b < 0) return null; b = s.indexOf('[', b); if (b < 0) return null; for (let d = 0, j = b; j < s.length; j++) { d += s[j] == '[' ? 1 : s[j] == ']' ? -1 : 0; if (d === 0) return s.slice(b + 1, j); } return null; };


let now_TOB_player = null;
const TOB = [];
const TOB_tickingarea = { x: Infinity, y: Infinity, z: Infinity };

// タスクを距離順にソートする関数
function sort_TOB_by_distance() {
    if (now_TOB_player && TOB.length > 30) {
        const playerPos = now_TOB_player.location;
        TOB.sort((a, b) => {
            if (typeof a !== "function" || typeof b !== "function") return 0;
            const posA = a.pos;
            const posB = b.pos;
            if (!posA || !posB) return 0;

            const distA = Math.hypot(posA.x - playerPos.x, posA.y - playerPos.y, posA.z - playerPos.z);
            const distB = Math.hypot(posB.x - playerPos.x, posB.y - playerPos.y, posB.z - playerPos.z);
            return distA - distB;
        });
    }
}

function Task_of_Blocks(player, pos, block) {
    now_TOB_player = player;

    if (TOB_tickingarea.x - 63 > pos.x || TOB_tickingarea.x + 63 < pos.x || TOB_tickingarea.z - 63 > pos.z || TOB_tickingarea.z + 63 < pos.z) {
        TOB.push(() => {
            run_command_player(player, `tickingarea remove DA_temp`);
        });

        TOB_tickingarea.x = pos.x;
        TOB_tickingarea.z = pos.z;

        TOB.push(() => {
            run_command_player(player, `tickingarea add ${pos.x - 63} ${pos.y - 63} ${pos.z - 63} ${pos.x + 63} 320 ${pos.z + 63} DA_temp true`);
        });

        TOB.push(`wait for test block:${pos.x} ${pos.y} ${pos.z}`);
    }

    TOB.push(Object.assign(() => {
        run_command_player(player, `setblock ${pos.x} ${pos.y} ${pos.z} ${block}`);
    }, { pos }));

    sort_TOB_by_distance();
}

function TOB_loop() {
    if (TOB.length === 0) {
        system.runTimeout(TOB_loop, 5);
        return;
    } else {
        let is_string = false;
        if (typeof TOB[0] == "string") {
            if (String(TOB[0]).indexOf("wait for test block:") !== -1) {
                is_string = true;
                const [x, y, z] = String(TOB[0]).split("wait for test block:")[1].split(" ");
                let block = false;
                try {
                    const player = now_TOB_player;
                    if (player != null) {
                        block = (player.dimension).getBlock({ x: Math.floor(Number(x)), y: Math.floor(Number(y)), z: Math.floor(Number(z)) });
                    } else {
                        run_command(`say §cDA-Error(TOB_loop) => Player Not found`);
                        return;
                    }
                } catch (e) {
                    task_finish_func(this_tickingarea_index);
                    run_command(`say §cDA-Error(TOB_loop) => ${e}`);
                }
                if (block !== undefined) {
                    TOB.shift();
                }
            }
        }
        if (!is_string) {
            const task = TOB.shift();
            if (task) task();
        }

        let message_decoration = ["---", "#--", "##-", "###", "-##", "--#", "---"];
        const decoration_index = (TOB.length % message_decoration.length);
        if (now_TOB_player != null) {
            const player = now_TOB_player;
            run_command_player(player, `title @s actionbar §e${message_decoration[decoration_index]}§o§6残り:${TOB.length}個§r§e${message_decoration[decoration_index]}`);
            if (TOB.length > 30) {
                run_command_player(player, `title @s actionbar §o§6-=-タスク渋滞中:${TOB.length}-=-`);
            }
        }
        if (TOB.length === 0) {
            const player = now_TOB_player;
            if (player != null) { run_command_player(player, `tickingarea remove DA_temp`); }
        }
        system.runTimeout(TOB_loop, 1);
    }
}
TOB_loop();



world.beforeEvents.playerBreakBlock.subscribe(ev => {
    const block = ev.block;
    const block_pos = block.location;
    const player = ev.player;
    let item = ev.itemStack;
    if (ev.itemStack != null) {
        item = item.typeId;
        if (DA_data[player.id] != null) {
            if (DA_save_on_world[player.id] != null) {
                if ((DA_save_on_world[player.id]["inventory_cleaner"] ?? false) && (DA_data[player.id]["inventory"] != null)) {
                    DA_data[player.id]["inventory"][player.selectedSlotIndex]["score"] = 0;
                    DA_data[player.id]["inventory"][player.selectedSlotIndex]["time"] = (new Date).getTime();
                    DA_data[player.id]["inventory"][player.selectedSlotIndex]["id"] = item;
                }
            }
        }
    }
    system.run(() => {
        if (DA_data[player.id] != null) {
            if (DA_data[player.id]["frame"] != null) {
                const frame_value = DA_data[player.id]["frame"];
                system.runTimeout(() => {
                    DA_command(player, `.frame ${block_pos.x} ${block_pos.y} ${block_pos.z} ${frame_value["block"]} ${frame_value["searches_num"]} ${frame_value["fill_line"]}`)
                })
                delete DA_data[player.id]["frame"];
                return;
            }
        }
        if (get_authority_num(player) < 3 && item == "da:da_brush") {
            player_setting_data(player);
            if ((DA_data[player.id]["is_BC_mode"] ?? false) == true) {
                const bc = DA_data[player.id]["BC_pos"];
                let this_bc_index = null;
                let is_setting = false;
                for (let i = 0; i < bc.length; i++) {
                    if (bc[i].x == block_pos.x && bc[i].y == block_pos.y && bc[i].z == block_pos.z) {
                        is_setting = true;
                        this_bc_index = i;
                        break;
                    }
                }
                if (!is_setting) {
                    const before_arr = JSON.parse(JSON.stringify(DA_data[player.id]["BC_pos"]));
                    DA_data[player.id]["BC_pos"].splice(before_arr.length - 1, 0, { x: block_pos.x, y: block_pos.y, z: block_pos.z, weight: 1 });
                    run_command_player(player, `title @s actionbar §a${block_pos.x} ${block_pos.y} ${block_pos.z}をパスポイントに追加しました。`)
                } else {
                    Show_Form("modal", player, {
                        title: (`パスポイント設定`),
                        content: [
                            { type: "text", text: "重みを設定", value: "数値を入力(0.1~100)", default: `${bc[this_bc_index]["weight"]}` },
                        ]
                    }, (value) => {
                        if (Number(value[0]) >= 0.1 && Number(value[0]) <= 100) {
                            for (let i = 0; i < bc.length; i++) {
                                if (bc[i].x == block_pos.x && bc[i].y == block_pos.y && bc[i].z == block_pos.z) {
                                    DA_data[player.id]["BC_pos"][i]["weight"] = Number(value[0]);
                                    break;
                                }
                            }
                        } else {
                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 範囲外です。"}]}`)
                        }
                    })
                }
            } else if ((DA_data[player.id]["is_TS_mode"] ?? false) == true) {
                const ps = DA_data[player.id]["terrain_CP"];
                let this_ps_index = null;
                let is_setting = false;
                for (let i = 0; i < ps.length; i++) {
                    if (ps[i].x == block_pos.x && ps[i].y == block_pos.y && ps[i].z == block_pos.z) {
                        is_setting = true;
                        this_ps_index = i;
                        break;
                    }
                }
                if (!is_setting) {
                    if (DA_data[player.id]["is_TS_Line"] != null) {
                        const ts_pos = DA_data[player.id]["is_TS_Line"];
                        for (let i = 0; i < ps.length; i++) {
                            if (ps[i].x == ts_pos.x && ps[i].y == ts_pos.y && ps[i].z == ts_pos.z) {
                                DA_data[player.id]["terrain_CP"][i].dx = block_pos.x;
                                DA_data[player.id]["terrain_CP"][i].dy = block_pos.y;
                                DA_data[player.id]["terrain_CP"][i].dz = block_pos.z;
                                run_command_player(player, `title @s actionbar §a${block_pos.x} ${block_pos.y} ${block_pos.z}に線を繋げました。`);
                                break;
                            }
                        }
                        DA_data[player.id]["is_TS_Line"] = null;
                    } else {
                        DA_data[player.id]["terrain_CP"].push({ x: block_pos.x, y: block_pos.y, z: block_pos.z, weight: 1, is_line: false });
                        run_command_player(player, `title @s actionbar §a${block_pos.x} ${block_pos.y} ${block_pos.z}をパスポイントに追加しました。`);
                    }
                } else {
                    Show_Form("modal", player, {
                        title: (`パスポイント設定`),
                        content: [
                            { type: "text", text: "重みを設定", value: "数値を入力(0.1~100)", default: `${ps[this_ps_index]["weight"]}` },
                            { type: "toggle", text: "線にする", default: ps[this_ps_index]["is_line"] },
                        ]
                    }, (value) => {
                        if (Number(value[0]) >= 0.1 && Number(value[0]) <= 100) {
                            for (let i = 0; i < ps.length; i++) {
                                if (ps[i].x == block_pos.x && ps[i].y == block_pos.y && ps[i].z == block_pos.z) {
                                    if (value[1] != ps[i]["is_line"]) {
                                        DA_data[player.id]["terrain_CP"][i]["is_line"] = value[1];
                                        DA_data[player.id]["is_TS_Line"] = block_pos;
                                        if (value[1] == true) {
                                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => 線の終点を開発補助ブラシでブロックを壊して、\n指定してください。"}]}`)
                                        }
                                    }
                                    DA_data[player.id]["terrain_CP"][i]["weight"] = Number(value[0]);
                                    break;
                                }
                            }
                        } else {
                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 範囲外です。"}]}`)
                        }
                    })
                }
            } else {
                DA_data[player.id].select.pos1 = block_pos;
                run_command_player(player, `title @s actionbar §a${block_pos.x} ${block_pos.y} ${block_pos.z}に始点をセットしました。`)
            }
        }
    })
    if (get_authority_num(player) < 3 && item == "da:da_brush") {
        ev.cancel = true;
    }
    if (DA_data[player.id] != null) {
        if (DA_data[player.id]["frame"] != null) {
            ev.cancel = true;
        }
        if (DA_data[player.id]["symmetric"] != null) {
            system.run(() => {
                const center = DA_data[player.id]["symmetric"].center;
                if (DA_data[player.id]["symmetric"].type == "LR") {
                    Task_of_Blocks(player, { x: center.x - (block_pos.x - center.x), y: block_pos.y, z: center.z - (block_pos.z - center.z) }, "air");
                } else if (DA_data[player.id]["symmetric"].type == "LRFB") {
                    Task_of_Blocks(player, { x: center.x - (block_pos.x - center.x), y: block_pos.y, z: center.z - (block_pos.z - center.z) }, "air");
                    Task_of_Blocks(player, { x: center.x + (block_pos.x - center.x), y: block_pos.y, z: center.z - (block_pos.z - center.z) }, "air");
                    Task_of_Blocks(player, { x: center.x - (block_pos.x - center.x), y: block_pos.y, z: center.z + (block_pos.z - center.z) }, "air");
                } else if (DA_data[player.id]["symmetric"].type == "rotate") {
                    Task_of_Blocks(player, { x: center.x - (block_pos.x - center.x), y: block_pos.y, z: center.z - (block_pos.z - center.z) }, "air");
                    Task_of_Blocks(player, { x: center.x + (block_pos.z - center.z), y: block_pos.y, z: center.z - (block_pos.x - center.x) }, "air");
                    Task_of_Blocks(player, { x: center.x - (block_pos.z - center.z), y: block_pos.y, z: center.z + (block_pos.x - center.x) }, "air");
                }
            })
        }
    }
})

world.beforeEvents.playerPlaceBlock.subscribe(ev => {
    const block = ev.block;
    const block_pos = block.location;
    const player = ev.player;
    if (DA_data[player.id] != null) {
        if (DA_data[player.id]["let"].type == "fill") {
            system.run(() => {
                const block = ev.block;
                const block_parameter = block.permutation.getAllStates();
                const string_parameter = String(JSON.stringify(Object.fromEntries(Object.entries(block_parameter).map(([k, v]) => [k.replaceAll(":", "&b2^94"), typeof v === "string" ? v.replaceAll(":", "&b2^94") : v])))).replaceAll("{", "[").replaceAll("}", "]").replaceAll(":", "=").replaceAll("&b2^94", ":");
                DA_command(player, `.fill ${block.type.id}${string_parameter}`, { cancel: false }, DA_data[player.id]["let"]["RC_pos"] ?? null)
            })
            DA_data[player.id]["let"].type = null;
        } else if (DA_data[player.id]["let"].type == "replace") {
            if (DA_data[player.id]["let"]["replace_type"] == 3 && DA_data[player.id]["let"]["replace_select_num"] == 0) {
                system.run(() => {
                    const block = ev.block;
                    const block_parameter = block.permutation.getAllStates();
                    const string_parameter = String(JSON.stringify(Object.fromEntries(Object.entries(block_parameter).map(([k, v]) => [k.replaceAll(":", "&b2^94"), typeof v === "string" ? v.replaceAll(":", "&b2^94") : v])))).replaceAll("{", "[").replaceAll("}", "]").replaceAll(":", "=").replaceAll("&b2^94", ":");
                    DA_data[player.id]["let"]["replace_select_num"]++;
                    DA_data[player.id]["let"]["replace_block"] = `${block.type.id}${string_parameter}`;
                    run_command_player(player, `title @s actionbar §b§l変換したいブロックを設定しました。`)
                })
            } else {
                system.run(() => {
                    const block = ev.block;
                    const block_parameter = block.permutation.getAllStates();
                    const string_parameter = String(JSON.stringify(Object.fromEntries(Object.entries(block_parameter).map(([k, v]) => [k.replaceAll(":", "&b2^94"), typeof v === "string" ? v.replaceAll(":", "&b2^94") : v])))).replaceAll("{", "[").replaceAll("}", "]").replaceAll(":", "=").replaceAll("&b2^94", ":");

                    if (DA_data[player.id]["let"]["replace_type"] == 1 || DA_data[player.id]["let"]["replace_type"] == 3) {
                        DA_command(player, `.replace ${block.type.id}${string_parameter} ${DA_data[player.id]["let"]["replace_block"]}`, { cancel: false }, DA_data[player.id]["let"]["RC_pos"] ?? null);
                    } else if (DA_data[player.id]["let"]["replace_type"] == 2) {
                        DA_command(player, `.replace ${DA_data[player.id]["let"]["replace_block"]} ${block.type.id}${string_parameter}`, { cancel: false }, DA_data[player.id]["let"]["RC_pos"] ?? null);
                    }
                })
                DA_data[player.id]["let"].type = null;
            }

        } else if (DA_data[player.id]["let"].type == "ball") {
            if (check_selected_pos(player)) {
                system.run(() => {
                    const block = ev.block;
                    const block_parameter = block.permutation.getAllStates();
                    const string_parameter = String(JSON.stringify(Object.fromEntries(Object.entries(block_parameter).map(([k, v]) => [k.replaceAll(":", "&b2^94"), typeof v === "string" ? v.replaceAll(":", "&b2^94") : v])))).replaceAll("{", "[").replaceAll("}", "]").replaceAll(":", "=").replaceAll("&b2^94", ":");
                    DA_command(player, `.ball ${DA_data[player.id]["let"]["radius"]} ${block.type.id}${string_parameter}${DA_data[player.id]["let"]["parameter"]}`, { cancel: false }, DA_data[player.id]["let"]["RC_pos"] ?? null)
                })
                DA_data[player.id]["let"].type = null;
            } else {
                system.run(() => {
                    run_command_player(player, `tellraw @s { "rawtext": [{ "text": "§cDA => 範囲が選択されていません。(ball)" }] }`)
                })
            }
        } else if (DA_data[player.id]["let"].type == "circle") {
            if (check_selected_pos(player)) {
                system.run(() => {
                    const block = ev.block;
                    const block_parameter = block.permutation.getAllStates();
                    const string_parameter = String(JSON.stringify(Object.fromEntries(Object.entries(block_parameter).map(([k, v]) => [k.replaceAll(":", "&b2^94"), typeof v === "string" ? v.replaceAll(":", "&b2^94") : v])))).replaceAll("{", "[").replaceAll("}", "]").replaceAll(":", "=").replaceAll("&b2^94", ":");
                    DA_command(player, `.circle ${DA_data[player.id]["let"]["radius"]} ${block.type.id}${string_parameter} ${DA_data[player.id]["let"]["parameter"]} ${DA_data[player.id]["let"]["bold"]}`, { cancel: false }, DA_data[player.id]["let"]["RC_pos"] ?? null)
                })
                DA_data[player.id]["let"].type = null;
            } else {
                system.run(() => {
                    run_command_player(player, `tellraw @s { "rawtext": [{ "text": "§cDA => 範囲が選択されていません。(circle)" }] }`)
                })
            }
        } else if (DA_data[player.id]["let"].type == "line") {
            if (check_selected_pos(player)) {
                system.run(() => {
                    const block = ev.block;
                    const block_parameter = block.permutation.getAllStates();
                    const string_parameter = String(JSON.stringify(Object.fromEntries(Object.entries(block_parameter).map(([k, v]) => [k.replaceAll(":", "&b2^94"), typeof v === "string" ? v.replaceAll(":", "&b2^94") : v])))).replaceAll("{", "[").replaceAll("}", "]").replaceAll(":", "=").replaceAll("&b2^94", ":");
                    DA_command(player, `.line ${DA_data[player.id]["let"]["tick"]} ${block.type.id}${string_parameter} ${DA_data[player.id]["let"]["parameter"]}`, { cancel: false }, DA_data[player.id]["let"]["RC_pos"] ?? null)
                })
                DA_data[player.id]["let"].type = null;
            } else {
                system.run(() => {
                    run_command_player(player, `tellraw @s { "rawtext": [{ "text": "§cDA => 範囲が選択されていません。(line)" }] }`)
                })
            }
        } else if (DA_data[player.id]["let"].type == "BezierCurves") {
            if (check_selected_pos(player)) {
                system.run(() => {
                    const block = ev.block;
                    const block_parameter = block.permutation.getAllStates();
                    const string_parameter = String(JSON.stringify(Object.fromEntries(Object.entries(block_parameter).map(([k, v]) => [k.replaceAll(":", "&b2^94"), typeof v === "string" ? v.replaceAll(":", "&b2^94") : v])))).replaceAll("{", "[").replaceAll("}", "]").replaceAll(":", "=").replaceAll("&b2^94", ":");
                    DA_command(player, `.BezierCurves enter ${block.type.id}${string_parameter} ${DA_data[player.id]["let"]["Fill_line"]}`, { cancel: false }, DA_data[player.id]["let"]["RC_pos"] ?? null)
                })
                DA_data[player.id]["let"].type = null;
            } else {
                system.run(() => {
                    run_command_player(player, `tellraw @s { "rawtext": [{ "text": "§cDA => 範囲が選択されていません。(BezierCurves)" }] }`)
                })
            }
        } else if (DA_data[player.id]["let"].type == "terrain") {
            if (check_selected_pos(player)) {
                system.run(() => {
                    const block = ev.block;
                    const block_parameter = block.permutation.getAllStates();
                    const string_parameter = String(JSON.stringify(Object.fromEntries(Object.entries(block_parameter).map(([k, v]) => [k.replaceAll(":", "&b2^94"), typeof v === "string" ? v.replaceAll(":", "&b2^94") : v])))).replaceAll("{", "[").replaceAll("}", "]").replaceAll(":", "=").replaceAll("&b2^94", ":");
                    DA_command(player, `.terrain ${DA_data[player.id]["let"]["Undulations"]} ${DA_data[player.id]["let"]["Ter_Seed"]} ${block.type.id}${string_parameter} ${DA_data[player.id]["let"]["Hold_pass"]} ${DA_data[player.id]["let"]["CTRL_type"]} ${DA_data[player.id]["let"]["CTRL_weight"]}`, { cancel: false }, DA_data[player.id]["let"]["RC_pos"] ?? null)
                })
                DA_data[player.id]["let"].type = null;
            } else {
                system.run(() => {
                    run_command_player(player, `tellraw @s { "rawtext": [{ "text": "§cDA => 範囲が選択されていません。(terrain)" }] }`)
                })
            }
        } else if (DA_data[player.id]["let"].type == "frame") {
            if (check_selected_pos(player) && DA_data[player.id]["let"]["frame_data"] != null) {
                system.run(() => {
                    const block = ev.block;
                    const block_parameter = block.permutation.getAllStates();
                    const string_parameter = String(JSON.stringify(Object.fromEntries(Object.entries(block_parameter).map(([k, v]) => [k.replaceAll(":", "&b2^94"), typeof v === "string" ? v.replaceAll(":", "&b2^94") : v])))).replaceAll("{", "[").replaceAll("}", "]").replaceAll(":", "=").replaceAll("&b2^94", ":");
                    DA_command(player, `${DA_data[player.id]["let"]["frame_data"].replaceAll(`let`, `${block.type.id}${string_parameter}`)}`, { cancel: false }, DA_data[player.id]["let"]["RC_pos"] ?? null)
                })
                DA_data[player.id]["let"].type = null;
            } else {
                system.run(() => {
                    run_command_player(player, `tellraw @s { "rawtext": [{ "text": "§cDA => 範囲が選択されていません。(terrain)" }] }`)
                })
            }
        } else if (DA_data[player.id]["symmetric"] != null) {
            system.run(() => {
                const block = ev.block;
                const block_pos = block.location;
                const block_parameter = block.permutation.getAllStates();
                const string_parameter = String(JSON.stringify(Object.fromEntries(Object.entries(block_parameter).map(([k, v]) => [k.replaceAll(":", "&b2^94"), typeof v === "string" ? v.replaceAll(":", "&b2^94") : v])))).replaceAll("{", "[").replaceAll("}", "]").replaceAll(":", "=").replaceAll("&b2^94", ":");
                const center = DA_data[player.id]["symmetric"].center;
                if (DA_data[player.id]["symmetric"].type == "LR") {
                    Task_of_Blocks(player, { x: center.x - (block_pos.x - center.x), y: block_pos.y, z: center.z - (block_pos.z - center.z) }, `${block.type.id}${string_parameter}`);
                } else if (DA_data[player.id]["symmetric"].type == "LRFB") {
                    Task_of_Blocks(player, { x: center.x - (block_pos.x - center.x), y: block_pos.y, z: center.z - (block_pos.z - center.z) }, `${block.type.id}${string_parameter}`);
                    Task_of_Blocks(player, { x: center.x + (block_pos.x - center.x), y: block_pos.y, z: center.z - (block_pos.z - center.z) }, `${block.type.id}${string_parameter}`);
                    Task_of_Blocks(player, { x: center.x - (block_pos.x - center.x), y: block_pos.y, z: center.z + (block_pos.z - center.z) }, `${block.type.id}${string_parameter}`);
                } else if (DA_data[player.id]["symmetric"].type == "rotate") {
                    Task_of_Blocks(player, { x: center.x - (block_pos.x - center.x), y: block_pos.y, z: center.z - (block_pos.z - center.z) }, `${block.type.id}${string_parameter}`);
                    Task_of_Blocks(player, { x: center.x + (block_pos.z - center.z), y: block_pos.y, z: center.z - (block_pos.x - center.x) }, `${block.type.id}${string_parameter}`);
                    Task_of_Blocks(player, { x: center.x - (block_pos.z - center.z), y: block_pos.y, z: center.z + (block_pos.x - center.x) }, `${block.type.id}${string_parameter}`);
                }
            })
        }
    }
    if (get_authority_num(player) < 3 && player.hasTag("IG_has_offhand_DA_AM")) {
        const LUN_setting = DA_save_on_world[player.id]["LUNATIC_setting"];
        if (LUN_setting["can_use_automatic"] != null && get_authority_num(player) >= 2) {
            if (LUN_setting["can_use_automatic"] == false) {
                system.run(() => {
                    run_command_player(player, `titleraw @s actionbar {"rawtext":[{"text":"§cDA => 許可されていない機能です。"}]}`);
                })
                return;
            }
        }
        const AW = !(DA_save_on_world[player.id]["Automatic_water"] ?? true);
        system.run(() => {
            const type = DA_save_on_world[player.id]["Automatic_type"];
            const mode = { "normal": "§aノーマルモード", "no_judge": "§eブロック無判別", "edge": "§b端判定モード" };
            run_command_player(player, `title @s actionbar ${mode[type] ?? "モードを選択してください。"}`);
        })
        function getTargetBlock(player, maxDistance = 10) {
            const dim = player.dimension;
            const origin = player.getHeadLocation();
            const direction = player.getViewDirection();
            const result = dim.getBlockFromRay(origin, direction, { includePassableBlocks: true, maxDistance: maxDistance, includeLiquidBlocks: !AW });
            if (result != undefined) {
                return result;
            }
            return null;
        }

        function getPlacementPosition(hitResult) {
            const face = hitResult.faceLocation;
            return {
                x: Math.floor(hitResult.block.x + face.x),
                y: Math.floor(hitResult.block.y + face.y),
                z: Math.floor(hitResult.block.z + face.z)
            };
        }
        const hit = getTargetBlock(player, 10);

        if (hit) {
            const placePos = getPlacementPosition(hit);
            system.run(() => {
                const block = ev.block;
                const block_parameter = block.permutation.getAllStates();
                const string_parameter = String(JSON.stringify(Object.fromEntries(Object.entries(block_parameter).map(([k, v]) => [k.replaceAll(":", "&b2^94"), typeof v === "string" ? v.replaceAll(":", "&b2^94") : v])))).replaceAll("{", "[").replaceAll("}", "]").replaceAll(":", "=").replaceAll("&b2^94", ":");
                let bg_search_arr = [[1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1]];
                let setblock_pre = [0, 0, 0];
                if (hit.face == "Up") {
                    bg_search_arr = [[1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1], [1, 0, 1], [-1, 0, -1], [1, 0, -1], [-1, 0, 1]];
                    setblock_pre = [0, 1, 0];
                } else if (hit.face == "Down") {
                    bg_search_arr = [[1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1], [1, 0, 1], [-1, 0, -1], [1, 0, -1], [-1, 0, 1]];
                    setblock_pre = [0, -1, 0];
                } else if (hit.face == "West") {
                    bg_search_arr = [[0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1], [0, 1, 1], [0, -1, -1], [0, -1, 1], [0, 1, -1]];
                    setblock_pre = [-1, 0, 0];
                } else if (hit.face == "North") {
                    bg_search_arr = [[0, 1, 0], [0, -1, 0], [1, 0, 0], [-1, 0, 0], [1, 1, 0], [-1, -1, 0], [1, -1, 0], [-1, 1, 0]];
                    setblock_pre = [0, 0, -1];
                } else if (hit.face == "East") {
                    bg_search_arr = [[0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1], [0, 1, 1], [0, -1, -1], [0, -1, 1], [0, 1, -1]];
                    setblock_pre = [1, 0, 0];
                } else if (hit.face == "South") {
                    bg_search_arr = [[0, 1, 0], [0, -1, 0], [1, 0, 0], [-1, 0, 0]];
                    setblock_pre = [0, 0, 1];
                }
                if ((DA_save_on_world[player.id]["Automatic_in_diagonal"] ?? false) == false) {
                    bg_search_arr.splice(4, Infinity);
                }
                let searched = [{ pos: hit.block, search: bg_search_arr }];
                let visited = {};
                visited[`${hit.block.x},${hit.block.y},${hit.block.z}`] = true;
                let ai = 0;
                let before_SL = 0;
                function AIS() {
                    if (ai < 1) {
                        // const limits_type = { normal: 8, no_judge: 12, edge: 32 };
                        const limits_type = { normal: 32, no_judge: 32, edge: 32 };
                        const limits = limits_type[DA_save_on_world[player.id]["Automatic_type"]];
                        let sertched_num = 0;
                        for (let l = 0; l < limits; l++) {
                            const currentLength = searched.length;
                            for (let i = before_SL; i < currentLength; i++) {
                                const node = searched[i];
                                for (let g = 0; g < node.search.length; g++) {
                                    const sss = node.search[g];
                                    const dx = node.pos.x + sss[0];
                                    const dy = node.pos.y + sss[1];
                                    const dz = node.pos.z + sss[2];
                                    const Automatic_type = DA_save_on_world[player.id]["Automatic_type"];
                                    let is_clear_judges = false;
                                    if (Automatic_type == "normal") {
                                        is_clear_judges = (player.dimension.getBlock({ x: dx, y: dy, z: dz }).type.id == hit.block.type.id);
                                    } else if (Automatic_type == "edge") {
                                        const search_block = (x = 0, y = 0, z = 0) => { return player.dimension.getBlock({ x: dx + x, y: dy + y, z: dz + z }).type.id };
                                        const raw_block = hit.block.type.id;
                                        let is_edge = false;
                                        for (let x = -1; x <= 1; x++) {
                                            for (let z = -1; z <= 1; z++) {
                                                if (!(x == 0 && z == 0)) {
                                                    if (hit.face == "Up" || hit.face == "Down") {
                                                        if (search_block(x, 0, z) != raw_block) {
                                                            is_edge = true;
                                                            break;
                                                        }
                                                    } else if (hit.face == "West" || hit.face == "East") {
                                                        if (search_block(0, x, z) != raw_block) {
                                                            is_edge = true;
                                                            break;
                                                        }
                                                    } else if (hit.face == "North" || hit.face == "South") {
                                                        if (search_block(x, z, 0) != raw_block) {
                                                            is_edge = true;
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        is_clear_judges = (search_block() == raw_block && (is_edge));
                                    } else if (Automatic_type == "no_judge") {
                                        is_clear_judges = true;
                                    }
                                    if (is_clear_judges) {
                                        if (!is_airs(player, dx, dy, dz) && is_airs(player, dx + setblock_pre[0], dy + setblock_pre[1], dz + setblock_pre[2], AW)) {
                                            const key = `${dx},${dy},${dz}`;
                                            if (!visited[key]) {
                                                visited[key] = true;
                                                let search_arr = JSON.parse(JSON.stringify(bg_search_arr));
                                                for (let j = 0; j < search_arr.length; j++) {
                                                    if (search_arr[j][0] === -sss[0] && search_arr[j][1] === -sss[1] && search_arr[j][2] === -sss[2]) {
                                                        search_arr.splice(j, 1);
                                                        break;
                                                    }
                                                }
                                                searched.push({ pos: { x: dx, y: dy, z: dz }, search: search_arr });
                                                sertched_num++;
                                                if (sertched_num > (DA_save_on_world[player.id]["Automatic_max"] ?? 64)) {
                                                    l = Infinity;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            before_SL = currentLength;
                        }
                        system.runTimeout(AIS, 1);
                    } else {
                        if (DA_ABU[player.id] == null) {
                            player_setting_data(player);
                        }
                        DA_ABU[player.id][`Automatic_block_undo`].push([]);
                        const ABU_index = (DA_ABU[player.id][`Automatic_block_undo`].length - 1);
                        for (let n = 0; n < searched.length; n++) {
                            let pos_aj = { "Up": [0, 1, 0], "Down": [0, -1, 0], "West": [-1, 0, 0], "East": [1, 0, 0], "North": [0, 0, -1], "South": [0, 0, 1] };
                            let rasted = { x: searched[n].pos.x + pos_aj[hit.face][0], y: searched[n].pos.y + pos_aj[hit.face][1], z: searched[n].pos.z + pos_aj[hit.face][2], block: `${block.type.id}${string_parameter}` };
                            run_command_player(player, `setblock ${rasted.x} ${rasted.y} ${rasted.z} ${rasted.block}`)
                            DA_ABU[player.id][`Automatic_block_undo`][ABU_index].push(JSON.parse(JSON.stringify(rasted)));
                        }
                        if (DA_ABU[player.id][`Automatic_block_undo`].length > 32) {
                            DA_ABU[player.id][`Automatic_block_undo`].splice(0, DA_ABU[player.id][`Automatic_block_undo`].length - 32);
                        }
                    }
                    ai++;
                }
                AIS();
                // }
            })
        }
    }
})

function Show_Form(type = "action", player, data, function_name) {
    if (type == "action") {
        const form = new ActionFormData().title(`${data.title}`);
        for (let i = 0; i < data.content.length; i++) {
            if (data.content[i].type == "button") {
                if (data.content[i].icon != null) {
                    form.button(`${data.content[i].value}`, `${data.content[i].icon}`);
                } else {
                    form.button(`${data.content[i].value}`);
                }
            } else if (data.content[i].type == "body") {
                form.body(`${data.content[i].value}`);
            }
        }

        form.show(player).then((result) => {
            function_name(result);
        })
    } else if (type == "modal") {
        const modalForm = new ModalFormData().title(`${data.title}`);
        for (let i = 0; i < data.content.length; i++) {
            if (data.content[i].type == "toggle") {
                modalForm.toggle(data.content[i].text, data.content[i]["default"] ?? false);
            } else if (data.content[i].type == "slider") {
                modalForm.slider(data.content[i].text, data.content[i]["min"], data.content[i]["max"], data.content[i]["step"], data.content[i]["default"]);
            } else if (data.content[i].type == "select") {
                modalForm.dropdown(data.content[i].text, data.content[i]["value"], data.content[i]["default"]);
            } else if (data.content[i].type == "text") {
                modalForm.textField(data.content[i].text, data.content[i]["value"], data.content[i]["default"] ?? null);
            };
        }
        modalForm
            .show(player)
            .then((formData) => {
                if (!formData.canceled) {
                    // const data = JSON.parse(JSON.parse(formData.formValues));
                    function_name(formData.formValues);
                }
            })
            .catch((error) => {
                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => フォームの表示に失敗しました:${error}"}]}`)
                return -1;
            });
    } else if (type == "message") {
        const messageForm = new MessageFormData().title(`${data.title}`);
        messageForm.body(`${data.body}`);
        messageForm.button1(`${data.confirm}`);
        messageForm.button2(`${data.cancel}`);
        messageForm
            .show(player)
            .then((formData) => {
                if (formData.canceled || formData.selection === undefined) {
                    return;
                }
                function_name(formData);
            })
            .catch((error) => {
                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => フォームの表示に失敗しました:${error}"}]}`)
                return -1;
            });
    }
}

function isBlockTypeExists(blockId) {
    try {
        return (BlockTypes.get(blockId) !== undefined);
    } catch (e) {
        return false;
    }
}

function isValidItem(itemId) {
    try {
        return ItemTypes.get(itemId) !== undefined;
    } catch (e) {
        return false;
    }
}

const menu_message = ["本日のメニューは？", "本日はいかがなさいますか？", "何にしようかな～", "TIP:狼も歩けば棒に当たる", "ご注文お決まりましたらボタンからお知らせください。", "ご注文は狼ですか？"];

world.beforeEvents.itemUse.subscribe(ev => {
    const player = ev.source;
    const item = ev.itemStack.typeId;
    const int_player_pos = { x: Math.floor(player.location.x), y: Math.floor(player.location.y), z: Math.floor(player.location.z) };
    const player_name = String(player.nameTag).replaceAll("\"", "").replaceAll("\'", "").replaceAll("\`", "").replaceAll("\\", "");
    system.run(() => {
        if (DA_data[player.id] != null) {
            if (DA_save_on_world[player.id] != null) {
                if ((DA_save_on_world[player.id]["inventory_cleaner"] ?? false) && (DA_data[player.id]["inventory"] != null)) {
                    DA_data[player.id]["inventory"][player.selectedSlotIndex]["score"] = 0;
                    DA_data[player.id]["inventory"][player.selectedSlotIndex]["time"] = (new Date).getTime();
                    DA_data[player.id]["inventory"][player.selectedSlotIndex]["id"] = item;
                }
            }
        }
        if (get_authority_num(player) < 3 && DA_save_on_world[player.id] != null) {
            if (DA_save_on_world[player.id]["bind"] != null) {
                const bind = DA_save_on_world[player.id]["bind"];
                for (let i = 0; i < bind.length; i++) {
                    if (bind[i].type == "RightClick" && (bind[i].value == item || bind[i].value == item.replace("minecraft:", ""))) {
                        run_command_player(player, `tellraw @s {"rawtext":[{"text":"§b§oDA => 実行: ${bind[i].commands}"}]}`)
                        DA_command(player, bind[i].commands);
                    }
                }
            }
        }
        if (get_authority_num(player) < 3 && item == "da:da_brush") {
            if (!player.isSneaking && ((new Date).getTime() - use_on_block) > 100) {
                Show_Form("action", player, {
                    title: (`範囲のオプション`), content: [
                        { type: "button", value: "範囲指定" },
                        { type: "button", value: "§4選択範囲/予想範囲の表示解除" },
                        { type: "button", value: "§a予想範囲の表示解除" },
                        { type: "button", value: "選択先にテレポート" },
                        { type: "button", value: "§b詳細取得" },
                    ]
                }, (result) => {
                    if (result.canceled) {
                        return -1;
                    } else {
                        if (result.selection == 0) {
                            Show_Form("modal", player, {
                                title: (`テレポート先　オプション`),
                                content: [
                                    { type: "select", text: "範囲の指定先", value: ["始点", "終点", "両方"], default: 0 },
                                    { type: "toggle", text: "自分位置を座標の中心とする", default: true },
                                    { type: "text", text: "", value: "X軸" },
                                    { type: "text", text: "", value: "Y軸" },
                                    { type: "text", text: "", value: "Z軸" },

                                ]
                            }, (value) => {
                                const select_pos = { x: Number(value[2] ?? 0), y: Number(value[3] ?? 0), z: Number(value[4] ?? 0) };
                                if (value[1]) {
                                    select_pos.x += Math.floor(player.location.x);
                                    select_pos.y += Math.floor(player.location.y);
                                    select_pos.z += Math.floor(player.location.z);
                                }
                                player_setting_data(player);
                                if (value[0] == 0) {
                                    DA_data[player.id].select.pos1 = select_pos;
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§a${select_pos.x} ${select_pos.y} ${select_pos.z}に始点をセットしました。"}]}`);
                                } else if (value[0] == 1) {
                                    DA_data[player.id].select.pos2 = select_pos;
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§b${select_pos.x} ${select_pos.y} ${select_pos.z}に終点をセットしました。"}]}`);
                                } else if (value[0] == 2) {
                                    DA_data[player.id].select.pos1 = select_pos;
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§a${select_pos.x} ${select_pos.y} ${select_pos.z}に始点をセットしました。"}]}`);
                                    DA_data[player.id].select.pos2 = select_pos;
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§b${select_pos.x} ${select_pos.y} ${select_pos.z}に終点をセットしました。"}]}`);
                                }
                            })
                        } else if (result.selection == 1) {
                            DA_command(player, `.clear`);
                        } else if (result.selection == 2) {
                            DA_command(player, `.clear show`);
                        } else if (result.selection == 3) {
                            const LUN_setting = DA_save_on_world[player.id]["LUNATIC_setting"];
                            if (LUN_setting[`can_tp_select`] == false && get_authority_num(player) >= 2) {
                                system.run(() => {
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 許可されていない機能です。"}]}`)
                                })
                                return;
                            }
                            if (check_selected_pos(player)) {
                                Show_Form("modal", player, {
                                    title: (`テレポート先　オプション`),
                                    content: [
                                        { type: "select", text: "どこへテレポートしたいですか？", value: ["始点", "終点", "中央"], default: 0 }
                                    ]
                                }, (value) => {
                                    const pos = get_selected_pos(player);
                                    if (value[0] == 0) {
                                        run_command_player(player, `tp @s ${pos.pos1.x} ${pos.pos1.y} ${pos.pos1.z}`);
                                    } else if (value[0] == 1) {
                                        run_command_player(player, `tp @s ${pos.pos2.x} ${pos.pos2.y} ${pos.pos2.z}`);
                                    } else if (value[0] == 2) {
                                        const dx = Math.floor((pos.pos1.x + pos.pos2.x) / 2 * 10) / 10;
                                        const dy = Math.floor((pos.pos1.y + pos.pos2.y) / 2 * 10) / 10;
                                        const dz = Math.floor((pos.pos1.z + pos.pos2.z) / 2 * 10) / 10;
                                        run_command_player(player, `tp @s ${dx} ${dy} ${dz}`);
                                    }
                                })
                            } else {
                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => まだ範囲が選択されていません。"}]}`);
                            }
                        } else if (result.selection == 4) {
                            if (check_selected_pos(player)) {
                                const pos = get_selected_pos(player);
                                const text = `僕の香りと君の香りを混ぜあってみたい`;
                                // https://youtu.be/XuVCgVWI7_k?list=RDXuVCgVWI7_k
                                Show_Form("action", player, {
                                    title: (`範囲のオプション`), content: [
                                        {
                                            type: "body", value: `
§a§l始点:${pos.pos1.x} ${pos.pos1.y} ${pos.pos1.z}
§4§l終点:${pos.pos2.x} ${pos.pos2.y} ${pos.pos2.z}
§b§l距離:${pos.pos2.x - pos.pos1.x} ${pos.pos2.y - pos.pos1.y} ${pos.pos2.z - pos.pos1.z}
§b§l直線距離:${Math.floor(Math.sqrt(Math.pow(pos.pos2.x - pos.pos1.x, 2) + Math.pow(pos.pos2.y - pos.pos1.y, 2) + Math.pow(pos.pos2.z - pos.pos1.z, 2)) * 100) / 100}
                                    ` },
                                        { type: "button", value: text[Math.floor(Math.random() * text.length)] },
                                    ]
                                }, (result) => {
                                    if (result.canceled) {
                                        return -1;
                                    } else {

                                    }
                                })
                            } else {
                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 範囲が選択されていません。"}]}`)
                            }
                        }
                    }
                })
            } else if (((new Date).getTime() - use_on_block) > 100) {
                player_setting_data(player);
                if (DA_data[player.id].select.pos1.length == 0) {
                    DA_data[player.id].select.pos1 = int_player_pos;
                    run_command_player(player, `title @s actionbar §a${int_player_pos.x} ${int_player_pos.y} ${int_player_pos.z}に始点をセットしました。`)
                } else {
                    DA_data[player.id].select.pos2 = int_player_pos;
                    run_command_player(player, `title @s actionbar §b${int_player_pos.x} ${int_player_pos.y} ${int_player_pos.z}に終点をセットしました。`)
                }
            }
        } else if (get_authority_num(player) < 3 && item == "da:da_other") {
            const DO_arr = [
                { type: "button", value: "プレイヤーにテレポート" },
                { type: "button", value: "その他機能" },
                { type: "button", value: "設定" },
                { type: "button", value: "バインド(登録)" },
            ]
            if (DA_save_on_world["world_data"]["LUNATIC"].indexOf(player.id) != -1) {
                DO_arr.push({ type: "button", value: "プレイヤー権限", icon: "textures/ui/FriendsIcon" });
            }
            Show_Form("action", player, {
                title: (`${menu_message[Math.floor(Math.random() * menu_message.length)]}`), content: DO_arr
            }, (result) => {
                if (result.canceled) {
                    return -1;
                } else {
                    if (result.selection == 0) {
                        const LUN_setting = DA_save_on_world[player.id]["LUNATIC_setting"];
                        if (LUN_setting["can_player_tp"] == false && get_authority_num(player) >= 2) {
                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 許可されていない機能です。"}]}`);
                            return;
                        }
                        const All_players = world.getPlayers();
                        const players_info = [];
                        for (let i = 0; i < All_players.length; i++) {
                            players_info.push(String(All_players[i].nameTag).replaceAll("\"", "").replaceAll("\'", "").replaceAll("\`", "").replaceAll("\\", ""));
                        }
                        Show_Form("modal", player, {
                            title: "だれにTPしますか？",
                            content: [
                                { type: "select", text: "だれにTPしますか？", value: players_info, default: 0 }
                            ]
                        }, (value) => {
                            run_command_player(player, `tp @s "${All_players[value[0]].nameTag}"`)
                        })
                    } else if (result.selection == 1) {
                        Show_Form("action", player, {
                            title: "Select",
                            content: [
                                { type: "button", value: "カメラ機能" },
                                { type: "button", value: "インベントリ共有機能" },
                                { type: "button", value: "インベントリクリーナ" },
                                { type: "button", value: "インベントリスライダー" }
                            ]
                        }, (result) => {
                            if (result.canceled) {
                                return -1;
                            } else if (result.selection == 0) {
                                const LUN_setting = DA_save_on_world[player.id]["LUNATIC_setting"];
                                if (LUN_setting["can_camera"] == false && get_authority_num(player) >= 2) {
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 許可されていない機能です。"}]}`);
                                    return;
                                }
                                Show_Form("action", player, {
                                    title: "Select",
                                    content: [
                                        { type: "button", value: "§a設定した位置に切り替える" },
                                        { type: "button", value: "§b元の位置に戻す" },
                                        { type: "button", value: "§4カメラ位置をここに設定する。" }
                                    ]
                                }, (result) => {
                                    if (result.canceled) {
                                        return -1;
                                    } else {
                                        player_setting_data(player);
                                        if (result.selection == 0) {
                                            if (DA_data[player.id]["camera_pos"] != null) {
                                                const pos = DA_data[player.id]["camera_pos"];
                                                run_command_player(player, `camera @s set minecraft:free ease 2 in_out_expo pos ${pos.x} ${pos.y} ${pos.z} rot ${pos.vec} ${pos.hor}`);
                                            } else {
                                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 位置が設定されていません。"}]}`)
                                            }
                                        } else if (result.selection == 1) {
                                            run_command_player(player, `camera @s clear`)
                                        } else if (result.selection == 2) {
                                            const pos = player.location;
                                            DA_data[player.id]["camera_pos"] = { x: Math.floor(pos.x * 10) / 10, y: Math.floor((pos.y + 1.75) * 10) / 10, z: Math.floor(pos.z * 10) / 10, hor: Math.floor(player.getRotation().y), vec: Math.floor(player.getRotation().x) };
                                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => カメラ位置をセットしました。"}]}`)
                                        }
                                    }
                                })
                            } else if (result.selection == 1) {
                                if (get_authority_num(player) != 0) {
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 許可されていない機能です。"}]}`);
                                    return;
                                }
                                Show_Form("action", player, {
                                    title: "Select",
                                    content: [
                                        { type: "button", value: "§e他人のインベントリを編集し始める" },
                                        { type: "button", value: "§4インベントリの編集を停止する。" }
                                    ]
                                }, (result) => {
                                    if (result.canceled) {
                                        return -1;
                                    } else {
                                        const show_content = [];
                                        const all_PD = [];
                                        const All_players = world.getAllPlayers();
                                        for (let i = 0; i < All_players.length; i++) {
                                            all_PD.push({ name: String(All_players[i].nameTag), player: All_players[i] })
                                            show_content.push(
                                                { type: "button", value: String(All_players[i].nameTag) }
                                            )
                                        }
                                        player_setting_data(player);
                                        if (result.selection == 0) {
                                            Show_Form("action", player, {
                                                title: "Select",
                                                content: show_content
                                            }, (result) => {
                                                if (result.canceled) {

                                                } else {
                                                    DA_command(player, `.Iconnect ${String(all_PD[result.selection].name).replaceAll(" ", "&5a1%")}`);
                                                }
                                            })
                                        } else if (result.selection == 1) {
                                            DA_command(player, `.IDisconnect`)
                                        }
                                    }
                                })
                            } else if (result.selection == 2) {
                                Show_Form("modal", player, {
                                    title: "インベントリクリーナ",
                                    content: [
                                        { type: "toggle", text: "§l§6オン/オフ", default: DA_save_on_world[player.id]["inventory_cleaner"] ?? false },
                                        { type: "toggle", text: "ホットバーを含める", default: DA_save_on_world[player.id]["inventory_include_hotbar"] ?? false },
                                        { type: "slider", text: "§l§6非使用削除時間(分)§r\n現在の値", min: 1, max: 10, step: 1, default: DA_save_on_world[player.id]["ICR_time"] ?? 5 },
                                        { type: "text", text: "アイテムを指定した時間使って居なかったり\nメインハンドに持って居ないと削除されます\n", value: "入力不要" },
                                    ]
                                }, (value) => {
                                    DA_save_on_world[player.id]["inventory_cleaner"] = value[0];
                                    DA_save_on_world[player.id]["ICR_time"] = Number(value[2]);
                                    DA_save_on_world[player.id]["inventory_include_hotbar"] = value[1];
                                    save_DASOW_on_world();
                                })
                            } else if (result.selection == 3) {
                                Show_Form("modal", player, {
                                    title: "インベントリスライダー",
                                    content: [
                                        { type: "select", text: "§6タイプ", value: ["オフ", "常に", "スニーク時のみ"], default: (DA_save_on_world[player.id]["inventory_silder"] ?? 0) },
                                        { type: "toggle", text: "効果音で準備が整ったことを通知する", default: (DA_save_on_world[player.id]["inventory_silder_alert"] ?? false) },
                                    ]
                                }, (value) => {
                                    DA_save_on_world[player.id]["inventory_silder"] = value[0];
                                    DA_save_on_world[player.id]["inventory_silder_alert"] = value[1];
                                    save_DASOW_on_world();
                                })
                            }
                        })
                    } else if (result.selection == 2) {
                        player_setting_data(player);
                        const LUN_setting = DA_save_on_world[player.id]["LUNATIC_setting"];
                        if (LUN_setting["can_change_setting"] == false && get_authority_num(player) >= 2) {
                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 許可されていない機能です。"}]}`);
                            return;
                        }
                        Show_Form("action", player, {
                            title: "設定",
                            content: [
                                { type: "button", value: "開発補助ブラシの設定", icon: "textures/items/da_brush" },
                                { type: "button", value: "建築選択コンパスの設定", icon: "textures/items/da_ArtSelector" },
                                { type: "button", value: "チャットの設定", icon: "textures/ui/chat_send" },
                                { type: "button", value: "タスク/メモリの設定", icon: "textures/items/da_taskmanager" },
                                { type: "button", value: "その他の設定" },
                            ]
                        }, (result) => {
                            if (result.selection == 0) {
                                let select_types = ["ボタン", "セレクター", "区切り"];
                                Show_Form("modal", player, {
                                    title: "設定",
                                    content: [
                                        { type: "text", text: "選択範囲のパーティクル", value: "§l§bパーティクルIDを入力", default: `${DA_save_on_world[player.id].Range.particle}` },
                                        { type: "text", text: "予想範囲のパーティクル", value: "§l§bパーティクルIDを入力", default: `${DA_save_on_world[player.id].Prediction_Range.particle}` },
                                        { type: "toggle", text: "始点/終点の表示", default: DA_save_on_world[player.id].is_show_SF ?? false },
                                        { type: "toggle", text: "中央の表示", default: DA_save_on_world[player.id].is_show_center ?? false },
                                        { type: "toggle", text: "自分のみに表示", default: DA_save_on_world[player.id].is_show_other ?? false },
                                    ]
                                }, (result) => {
                                    let is_true_particle = false;
                                    try {
                                        run_command_player(player, `particle ${result[0]} ~~~`);
                                        run_command_player(player, `particle ${result[1]} ~~~`);
                                        is_true_particle = true;
                                    } catch {
                                        is_true_particle = false;
                                    }
                                    if (is_true_particle) {
                                        DA_save_on_world[player.id].Range.particle = result[0];
                                        DA_save_on_world[player.id].Prediction_Range.particle = result[1];
                                        DA_save_on_world[player.id].is_show_SF = result[2];
                                        DA_save_on_world[player.id].is_show_center = result[3];
                                        DA_save_on_world[player.id].is_show_other = result[4];
                                        save_DASOW_on_world();
                                    } else {
                                        run_command_player(player, `tellraw @s {"rawtext":[{"text":"§c§lDA => 変更は拒否されました(パーティクルIDが不適切です)"}]}`);
                                    }
                                })
                            } else if (result.selection == 1) {
                                let select_types = ["ボタン", "セレクター", "区切り"];
                                Show_Form("modal", player, {
                                    title: "設定",
                                    content: [
                                        { type: "select", text: "§6選択範囲編集画面の表示形式", value: ["ボタン", "セレクター", "区切り"], default: select_types.indexOf(DA_save_on_world[player.id].show_type) },
                                        { type: "slider", text: "§l§6生成速度:§r\n数値が小さいほど、生成速度は早くなりますが、生成ミスが増えます。\n数値が大きいほど、生成速度は遅くなりますが、生成ミスが減ります。\n現在の値", min: 1, max: 10, step: 1, default: DA_save_on_world[player.id]["Connect_Pass"] ?? 1 },
                                        { type: "slider", text: "§l§6描画待機時間:§r\n数値が小さいほど、描画待機の時間が縮みます。\n現在の値", min: 1, max: 60, step: 5, default: DA_save_on_world[player.id]["Waiting_drawing"] ?? 60 }
                                    ]
                                }, (result) => {
                                    DA_save_on_world[player.id].show_type = select_types[result[0]];
                                    DA_save_on_world[player.id]["Connect_Pass"] = Number(result[1]);
                                    DA_save_on_world[player.id]["Waiting_drawing"] = Number(result[2]);
                                    save_DASOW_on_world();
                                })
                            } else if (result.selection == 2) {
                                Show_Form("modal", player, {
                                    title: "設定",
                                    content: [
                                        { type: "toggle", text: "椛", default: DA_save_on_world[player.id]["Chat_support"] ?? false },
                                    ]
                                }, (result) => {
                                    DA_save_on_world[player.id]["Chat_support"] = result[0];
                                    save_DASOW_on_world();
                                })
                            } else if (result.selection == 3) {
                                const now_setting = DA_save_on_world["memory"] ?? {};
                                Show_Form("modal", player, {
                                    title: "設定",
                                    content: [
                                        { type: "slider", text: "§l§6最大メモリ使用量", min: 256, max: 4096, step: 256, default: now_setting["max"] ?? 1024 },
                                        { type: "select", text: "§l§e100%の時", value: ["§l何もしない", "§1§lメモリ開放【弱】", "§a§lメモリ開放【標準】", "§e§lメモリ開放【強】", "§c§lメモリ開放【全て】"], default: (now_setting["on_100"] ?? (0 - 1)) + 1 },
                                        { type: "select", text: "§l§e200%の時", value: ["§l何もしない", "§1§lメモリ開放【弱】", "§a§lメモリ開放【標準】", "§e§lメモリ開放【強】", "§c§lメモリ開放【全て】"], default: (now_setting["on_200"] ?? (0 - 1)) + 1 },
                                        { type: "select", text: "§l§e300%の時", value: ["§l何もしない", "§1§lメモリ開放【弱】", "§a§lメモリ開放【標準】", "§e§lメモリ開放【強】", "§c§lメモリ開放【全て】"], default: (now_setting["on_300"] ?? (1 - 1)) + 1 },
                                        { type: "select", text: "§l§e400%の時", value: ["§l何もしない", "§1§lメモリ開放【弱】", "§a§lメモリ開放【標準】", "§e§lメモリ開放【強】", "§c§lメモリ開放【全て】"], default: (now_setting["on_400"] ?? (2 - 1)) + 1 },
                                        { type: "select", text: "§l§e500%の時", value: ["§l何もしない", "§1§lメモリ開放【弱】", "§a§lメモリ開放【標準】", "§e§lメモリ開放【強】", "§c§lメモリ開放【全て】"], default: (now_setting["on_500"] ?? (3 - 1)) + 1 },
                                    ]
                                }, (result) => {
                                    DA_save_on_world["memory"] = {
                                        max: result[0],
                                        on_100: result[1] - 1,
                                        on_200: result[2] - 1,
                                        on_300: result[3] - 1,
                                        on_400: result[4] - 1,
                                        on_500: result[5] - 1
                                    };
                                    save_DASOW_on_world();
                                })
                            } else if (result.selection == 4) {
                                let movement_speed = player.getComponent("minecraft:movement");
                                let under_water = player.getComponent("minecraft:underwater_movement");
                                let lava_speed = player.getComponent("minecraft:lava_movement");
                                Show_Form("modal", player, {
                                    title: "設定",
                                    content: [
                                        { type: "toggle", text: "スニークでエリトラブースト", default: DA_save_on_world[player.id]["elytra_boost"] ?? false },
                                        { type: "slider", text: "エリトラブーストの強さ", min: 1, max: 10, step: 1, default: DA_save_on_world[player.id]["elytra_boost_strength"] ?? 1 },
                                        { type: "toggle", text: "カスタムスピード(KS)", default: DA_save_on_world[player.id]["custom_speed"] ?? false },
                                        { type: "slider", text: "KS:クリエ/スペク飛行の速さ", min: 1, max: 30, step: 1, default: DA_save_on_world[player.id]["fly_speed"] ?? 1 },
                                        { type: "slider", text: "KS:水中の速さ", min: Math.floor(under_water.effectiveMin * 100), max: Math.floor(Math.min(under_water.effectiveMax, 2) * 100), step: 1, default: Math.round(under_water.currentValue * 100) },
                                        { type: "slider", text: "KS:熔岩の中の速さ", min: Math.floor(lava_speed.effectiveMin * 100), max: Math.floor(Math.min(lava_speed.effectiveMax, 2) * 100), step: 1, default: Math.round(lava_speed.currentValue * 100) },
                                    ]
                                }, (result) => {
                                    DA_save_on_world[player.id]["elytra_boost"] = result[0];
                                    DA_save_on_world[player.id]["elytra_boost_strength"] = result[1];
                                    DA_save_on_world[player.id]["custom_speed"] = result[2];
                                    DA_save_on_world[player.id]["fly_speed"] = result[3];
                                    save_DASOW_on_world();
                                    if (result[2]) {
                                        under_water.setCurrentValue(result[4] / 100);
                                        lava_speed.setCurrentValue(result[5] / 100);
                                    } else {
                                        under_water.resetToDefaultValue();
                                        lava_speed.resetToDefaultValue();
                                    }
                                })
                            }
                        })
                    } else if (result.selection == 3) {
                        player_setting_data(player);
                        const LUN_setting = DA_save_on_world[player.id]["LUNATIC_setting"];
                        if (LUN_setting["can_bind"] == false && get_authority_num(player) >= 2) {
                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 許可されていない機能です。"}]}`);
                            return;
                        }
                        Show_Form("action", player, {
                            title: "設定",
                            content: [
                                { type: "button", value: "Chat (チャット)" },
                                { type: "button", value: "RightClick (右クリックをしたとき)" },
                                { type: "button", value: "確認" },
                                { type: "button", value: "削除" },
                                { type: "button", value: "§4全て削除" },
                            ]
                        }, (result) => {
                            if (result.selection == 0) {
                                Show_Form("modal", player, {
                                    title: "設定",
                                    content: [
                                        { type: "text", text: "どのチャットを撃った時に発動させますか？", value: "§bテキストを入力" },
                                    ]
                                }, (value) => {
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => 発動させたい機能を、§l§bいつものように選んで、§r§a設定してください。\n§e注意:一部機能はバインドできません"}]}`);
                                    DA_data[player.id]["Next_Registration_Commands"] = true;
                                    DA_data[player.id]["type"] = "Chat";
                                    DA_data[player.id]["value"] = value[0];
                                })
                            } else if (result.selection == 1) {
                                Show_Form("modal", player, {
                                    title: "設定",
                                    content: [
                                        { type: "text", text: "どのアイテムを右クリックした時に発動させますか？", value: "§bアイテムIDを入力" },
                                    ]
                                }, (value) => {
                                    let item_name = (value[0].indexOf(":") == -1) ? value[0] : `minecraft:${value[0]}`;
                                    if (isValidItem(item_name)) {
                                        DA_data[player.id]["Next_Registration_Commands"] = true;
                                        DA_data[player.id]["type"] = "RightClick";
                                        DA_data[player.id]["value"] = value[0];
                                        run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => 発動させたい機能を、§l§bいつものように選んで、§r§a設定してください。\n§e注意:一部機能はバインドできません"}]}`);
                                    } else {
                                        run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 指定されたIDのアイテムは存在しません。"}]}`);
                                    }
                                })
                            } else if (result.selection == 2) {
                                DA_command(player, ".bindCheck");
                            } else if (result.selection == 3) {
                                Show_Form("modal", player, {
                                    title: "何番目を削除しますか？",
                                    content: [
                                        { type: "text", text: "何番目を削除しますか？", value: "数値を入力" },
                                    ]
                                }, (value) => {
                                    if (DA_save_on_world[player.id]["bind"][value[0]] == null) {
                                        run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => その番号のバインドはありません。"}]}`)
                                    } else {
                                        run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => 正常にアンバインドされました。"}]}`)
                                        DA_save_on_world[player.id]["bind"].splice(value[0], 1);
                                        save_DASOW_on_world();
                                    }
                                })
                            } else if (result.selection == 4) {
                                Show_Form("modal", player, {
                                    title: "§4§l本当に全て削除しますか？",
                                    content: [
                                        { type: "toggle", text: "§4§l本当に全て削除しますか？" },
                                    ]
                                }, (value) => {
                                    if (value[0]) {
                                        run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => 正常にアンバインドされました。"}]}`)
                                        DA_save_on_world[player.id]["bind"] = [];
                                        save_DASOW_on_world();
                                    }
                                })
                            }
                        })
                    } else if (result.selection == (DO_arr.length - 1)) {
                        const players = world.getAllPlayers();
                        const members_arr = [];
                        const world_data = DA_save_on_world["world_data"];
                        for (let i = 0; i < players.length; i++) {
                            const player_name = String(players[i].nameTag).replaceAll("\"", "").replaceAll("\'", "").replaceAll("\`", "").replaceAll("\\", "");
                            if (world_data["LUNATIC"].indexOf(players[i].id) != -1) {
                                members_arr.push({ type: "button", value: `${player_name}§r (§5§lLUNATIC§r)`, icon: "textures/ui/op", Class_index: 0, Class: "LUNATIC", player: players[i] })
                            } else if (world_data["EXTRA"].indexOf(players[i].id) != -1) {
                                members_arr.push({ type: "button", value: `${player_name}§r (§4§lEXTRA§r)`, icon: "textures/ui/permissions_member_star", Class_index: 1, Class: "EXTRA", player: players[i] })
                            } else if (world_data["BASIC"].indexOf(players[i].id) != -1) {
                                members_arr.push({ type: "button", value: `${player_name}§r (§e§lBASIC§r)`, icon: "textures/ui/permissions_visitor_hand", Class_index: 2, Class: "BASIC", player: players[i] })
                            } else {
                                members_arr.push({ type: "button", value: `${player_name}§r (§lNeutralized§r)`, icon: "textures/blocks/barrier", Class_index: 3, Class: "Neutralized", player: players[i] })
                            }
                        }
                        Show_Form("action", player, {
                            title: "権限一覧",
                            content: members_arr
                        }, (value) => {
                            const data = members_arr[value.selection];
                            const classes = ["LUNATIC", "EXTRA", "BASIC", "Neutralized"];
                            const classes_dec = ["§5§lLUNATIC", "§4§lEXTRA", "§e§lBASIC", "§lNeutralized"];
                            player_setting_data(data.player);
                            let setting_of_player = [
                                { type: "button", value: "§l§e権限を変更する" },
                            ]
                            if (data.Class_index == 2) {
                                setting_of_player.push({ type: "button", value: `制約-開補設定アイ`, icon: "textures/items/da_OtherSelector" })
                                setting_of_player.push({ type: "button", value: `制約-建築補助コンパス`, icon: "textures/items/da_ArtSelector" })
                                setting_of_player.push({ type: "button", value: `制約-開発補助ブラシ`, icon: "textures/items/da_brush" })
                                setting_of_player.push({ type: "button", value: `制約-自動ブロック設置`, icon: "textures/items/da_automatic" })
                                setting_of_player.push({ type: "button", value: `制約-タスクマネージャー`, icon: "textures/items/da_taskmanager" })
                            }
                            Show_Form("action", player, {
                                title: `${data.player.nameTag}§r§bの設定`,
                                content: setting_of_player
                            }, (value) => {
                                if (value.canceled) {
                                    return -1;
                                } else if (value.selection == 0) {
                                    const classes_info = [
                                        "LUNATICは最上級の権限を持ち、全ての設定ができます。",
                                        "EXTRAは2番目に権限を持ち、大まかな設定ができますが、権限の変更のみできません。",
                                        "BASICは3番目の権限で、LUNATICの人から制約された機能および範囲でしかアドオンを使えません。",
                                        "Neutralizedはデフォルトの権限です。このアドオンの使用ができません。"
                                    ];
                                    Show_Form("modal", player, {
                                        title: `${data.player.nameTag}§r§bの設定`,
                                        content: [
                                            { type: "select", text: `現在の権限\n説明(${classes_dec[data.Class_index]}§r):${classes_info[data.Class_index]}`, value: classes_dec, default: data.Class_index }
                                        ]
                                    }, (value) => {
                                        const Dci = world_data[classes[data.Class_index]];
                                        for (let i = 0; i < classes.length; i++) {
                                            if (world_data[classes[i]] != null) {
                                                for (let g = 0; g < world_data[classes[i]].length; g++) {
                                                    if (world_data[classes[i]][g] == data.player.id) {
                                                        world_data[classes[i]].splice(g, 1);
                                                        g--;
                                                    }
                                                }
                                            }
                                        }
                                        if (value[0] != 3) {
                                            world_data[classes[value[0]]].push(data.player.id);
                                        }
                                        system.run(() => {
                                            run_command_player(player, `tellraw @a {"rawtext":[{"text":"§e§lDA Change Log : \n§r${player_name}§r §b§l=>§r ${String(data.player.nameTag).replaceAll("\"", "").replaceAll("\'", "").replaceAll("\`", "").replaceAll("\\", "")}§r\n${classes_dec[data.Class_index]}§r §b§l>>> §r${classes_dec[value[0]]}"}]}`)
                                        })
                                        save_DASOW_on_world();
                                    })
                                } else if (value.selection == 1) {
                                    const LUN_setting = DA_save_on_world[data.player.id]["LUNATIC_setting"];
                                    let show_content = [];
                                    show_content.push({ type: "toggle", text: `設定変更`, default: LUN_setting["can_change_setting"] })
                                    show_content.push({ type: "toggle", text: `プレイヤーにテレポート`, default: LUN_setting["can_player_tp"] })
                                    show_content.push({ type: "toggle", text: `カメラ`, default: LUN_setting["can_camera"] })
                                    show_content.push({ type: "toggle", text: `バインド(登録)`, default: LUN_setting["can_bind"] })
                                    Show_Form("modal", player, {
                                        title: `制限設定`,
                                        content: show_content
                                    }, (value) => {
                                        LUN_setting["can_change_setting"] = value[0];
                                        LUN_setting["can_player_tp"] = value[1];
                                        LUN_setting["can_camera"] = value[2];
                                        LUN_setting["can_bind"] = value[3];
                                        save_DASOW_on_world();
                                    })
                                } else if (value.selection == 2) {
                                    const LUN_setting = DA_save_on_world[data.player.id]["LUNATIC_setting"];
                                    let show_content = [];
                                    const CCN_arr = ["64", "128", "256", "512", "1024", "2048", "無制限"];
                                    const CCN_num = [64, 128, 256, 512, 1024, 2048, Infinity];
                                    show_content.push({ type: "select", text: `一度に編集できるブロック数`, value: CCN_arr, default: CCN_num.indexOf(LUN_setting["can_change_num"]) ?? 0 })
                                    show_content.push({ type: "toggle", text: `Fill (塗りつぶし)`, default: LUN_setting["can_fill"] })
                                    show_content.push({ type: "toggle", text: `Replace (置き換え)`, default: LUN_setting["can_replace"] })
                                    show_content.push({ type: "toggle", text: `Delete (削除)`, default: LUN_setting["can_cut"] })
                                    show_content.push({ type: "toggle", text: `Rotate (回転する)`, default: LUN_setting["can_rotate"] })
                                    show_content.push({ type: "toggle", text: `Flip (対称移動する)`, default: LUN_setting["can_flip"] })
                                    show_content.push({ type: "toggle", text: `Copy (コピー)`, default: LUN_setting["can_copy"] })
                                    show_content.push({ type: "toggle", text: `Paste (ペースト)`, default: LUN_setting["can_paste"] })
                                    show_content.push({ type: "toggle", text: `Circle (円を作る)`, default: LUN_setting["can_circle"] })
                                    show_content.push({ type: "toggle", text: `Ball (球を作る)`, default: LUN_setting["can_ball"] })
                                    show_content.push({ type: "toggle", text: `Line (線を引く)`, default: LUN_setting["can_line"] })
                                    show_content.push({ type: "toggle", text: `BezierCurves (ベジェ曲線)`, default: LUN_setting["can_BezierCurves"] })
                                    show_content.push({ type: "toggle", text: `terrain (地形生成)`, default: LUN_setting["can_terrain"] })
                                    show_content.push({ type: "toggle", text: `Frame (ブロックを繋ぐ)`, default: LUN_setting["can_frame"] ?? false })
                                    show_content.push({ type: "toggle", text: `Undo (1個戻す)`, default: LUN_setting["can_undo"] })
                                    Show_Form("modal", player, {
                                        title: `使用できる機能設定変更`,
                                        content: show_content
                                    }, (value) => {
                                        LUN_setting["can_change_num"] = CCN_num[value[0]];
                                        LUN_setting["can_fill"] = value[1];
                                        LUN_setting["can_replace"] = value[2];
                                        LUN_setting["can_cut"] = value[3];
                                        LUN_setting["can_rotate"] = value[4];
                                        LUN_setting["can_flip"] = value[5];
                                        LUN_setting["can_copy"] = value[6];
                                        LUN_setting["can_paste"] = value[7];
                                        LUN_setting["can_circle"] = value[8];
                                        LUN_setting["can_ball"] = value[9];
                                        LUN_setting["can_line"] = value[10];
                                        LUN_setting["can_BezierCurves"] = value[11];
                                        LUN_setting["can_terrain"] = value[12];
                                        LUN_setting["can_frame"] = value[13];
                                        LUN_setting["can_undo"] = value[14];
                                        save_DASOW_on_world();
                                    })
                                } else if (value.selection == 3) {
                                    const LUN_setting = DA_save_on_world[data.player.id]["LUNATIC_setting"];
                                    let show_content = [];
                                    const CCN_arr = ["64", "128", "256", "512", "1024", "2048", "無制限"];
                                    const CCN_num = [64, 128, 256, 512, 1024, 2048, Infinity];
                                    // show_content.push({ type: "select", text: `一度に選択できるブロック数`, value: CCN_arr, default: CCN_num.indexOf(LUN_setting["can_select_num"]) ?? 0 })
                                    show_content.push({ type: "toggle", text: `選択先にテレポート`, default: LUN_setting["can_tp_select"] })
                                    Show_Form("modal", player, {
                                        title: `使用できる機能設定変更`,
                                        content: show_content
                                    }, (value) => {
                                        // LUN_setting["can_select_num"] = CCN_num[value[0]];
                                        LUN_setting["can_tp_select"] = value[0];
                                        save_DASOW_on_world();
                                    })
                                } else if (value.selection == 4) {
                                    const LUN_setting = DA_save_on_world[data.player.id]["LUNATIC_setting"];
                                    let show_content = [];
                                    show_content.push({ type: "toggle", text: `使用`, default: LUN_setting["can_use_automatic"] })
                                    Show_Form("modal", player, {
                                        title: `使用できる機能設定変更`,
                                        content: show_content
                                    }, (value) => {
                                        LUN_setting["can_use_automatic"] = value[0];
                                        save_DASOW_on_world();
                                    })
                                } else if (value.selection == 5) {
                                    const LUN_setting = DA_save_on_world[data.player.id]["LUNATIC_setting"];
                                    let show_content = [];
                                    show_content.push({ type: "toggle", text: `使用`, default: LUN_setting["can_use_taskmanager"] })
                                    Show_Form("modal", player, {
                                        title: `使用できる機能設定変更`,
                                        content: show_content
                                    }, (value) => {
                                        LUN_setting["can_use_taskmanager"] = value[0];
                                        save_DASOW_on_world();
                                    })
                                }
                            })
                        })
                    }
                }
            })
        } else if (get_authority_num(player) < 3 && item == "da:da_art") {
            let now_page = 0;
            let NMI = "action";
            let fin_sec = 4;
            let options = {}
            const template = {
                title: (`${menu_message[Math.floor(Math.random() * menu_message.length)]}`), content: [
                    { type: "button", value: "Fill (塗りつぶし)", class: "fill" },
                    { type: "button", value: "Replace (置き換え)", class: "replace" },
                    { type: "button", value: "Delete (削除)", class: "cut" },
                    { type: "button", value: "Rotate (回転する)", class: "rotate" },
                    { type: "button", value: "Flip (対称移動する)", class: "flip" },
                    { type: "button", value: "Copy (コピー)", class: "copy" },
                    { type: "button", value: "Paste (ペースト)", class: "paste" },
                    { type: "button", value: "Circle (円を作る)", class: "circle" },
                    { type: "button", value: "Ball (球を作る)", class: "ball" },
                    { type: "button", value: "Line (線を引く)", class: "line" },
                    { type: "button", value: "BezierCurves (ベジェ曲線)", class: "BezierCurves" },
                    { type: "button", value: "terrain (地形生成)", class: "terrain" },
                    { type: "button", value: "Frame (ブロックを繋ぐ)", class: "frame" },
                    { type: "button", value: "Undo (1個戻す)", class: "undo" },
                ]
            }
            player_setting_data(player);
            if (get_authority_num(player) >= 2) {
                for (let i = 0; i < template.content.length; i++) {
                    const LUN_setting = DA_save_on_world[player.id]["LUNATIC_setting"];
                    const LUN_arr = template.content[i].class;
                    if (LUN_setting[`can_${String(LUN_arr)}`] != null) {
                        if (LUN_setting[`can_${String(LUN_arr)}`] == false) {
                            template.content[i].value = `§4${template.content[i].value}`;
                        }
                    } else {
                        template.content[i].value = `§4${template.content[i].value}`;
                    }
                }
            }
            const SF_func = () => {
                if (DA_save_on_world[player.id].show_type == "ボタン") {
                    options = template;
                } else if (DA_save_on_world[player.id].show_type == "セレクター") {
                    NMI = "modal";
                    const opt_trans = [];
                    for (let i = 0; i < template.content.length; i++) {
                        opt_trans.push(template.content[i].value);
                    }
                    options = {
                        title: (`範囲のオプション`), content: [
                            { type: "select", text: "", value: opt_trans, default: 0 },
                        ]
                    }
                } else if (DA_save_on_world[player.id].show_type == "区切り") {
                    const content = [{ type: "button", value: "§2§l前へ" }];
                    fin_sec = 4;
                    if (now_page == 0) {
                        fin_sec = 3;
                        content.shift();
                    }
                    for (let i = 0; i < 3; i++) {
                        if (template.content[(now_page * 3) + i] != null) {
                            content.push({ type: "button", value: template.content[(now_page * 3) + i].value });
                        } else {
                            fin_sec = i + 1;
                            break;
                        }
                    }
                    if ((now_page + 1) * 3 < template.content.length) {
                        content.push({ type: "button", value: "§9§l次へ" });
                    }
                    options = {
                        title: (`${menu_message[Math.floor(Math.random() * menu_message.length)]}`), content: content
                    }
                }
                Show_Form(NMI, player, options, (TR) => {
                    if (TR.canceled) {
                        return -1;
                    } else {
                        let result = {};
                        if (DA_save_on_world[player.id].show_type == "ボタン") {
                            result = TR;
                        } else if (DA_save_on_world[player.id].show_type == "セレクター") {
                            result["selection"] = TR[0];
                        } else if (DA_save_on_world[player.id].show_type == "区切り") {
                            result["selection"] = Number(String(TR.selection));
                            if (result.selection == 0 && now_page > 0) {
                                now_page--;
                                system.runTimeout(SF_func, 1);
                                return;
                            }
                            if (result.selection == fin_sec && (now_page + 1) * 3 < template.content.length) {
                                now_page++;
                                system.runTimeout(SF_func, 1);
                                return;
                            }
                            if (now_page > 0) {
                                result.selection -= 1;
                            }
                            result.selection += (now_page * 3);
                        }
                        const LUN_setting = DA_save_on_world[player.id]["LUNATIC_setting"];
                        const LUN_arr = template.content[result.selection].class;
                        if (LUN_setting[`can_${String(LUN_arr)}`] != null && get_authority_num(player) >= 2) {
                            if (LUN_setting[`can_${String(LUN_arr)}`] == false) {
                                system.run(() => {
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 許可されていない機能です。"}]}`)
                                })
                                ev.cancel = true;
                                return;
                            }
                        } else if (get_authority_num(player) >= 2) {
                            system.run(() => {
                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 許可されていない機能です。"}]}`)
                            })
                            ev.cancel = true;
                            return;
                        }
                        if (result.selection == 0) {
                            Show_Form("modal", player, {
                                title: "オプションをお選びください。",
                                content: [
                                    { type: "toggle", text: "§l§b置いたもので塗りつぶす。" },
                                    { type: "text", text: "(上のボタンをONにした場合、以下の入力は不要です。)\n§l§bブロックのIDを入力", value: "§l§bブロックのIDを入力" }
                                ]
                            }, (value) => {
                                if (value[0]) {
                                    DA_command(player, `.fill let`);
                                } else {
                                    if (value[1] != null) {
                                        if (isBlockTypeExists(value[1])) {
                                            DA_command(player, `.fill ${value[1]}`);
                                        } else {
                                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 指定したIDのブロックは存在しません。"}]}`);
                                        }
                                    }
                                }
                            })
                        } else if (result.selection == 1) {
                            Show_Form("modal", player, {
                                title: "オプションをお選びください。",
                                content: [
                                    { type: "toggle", text: "§l§b置いたものを置き換える" },
                                    { type: "text", text: "または", value: "§l§b置き換えるブロックのIDを入力" },
                                    { type: "toggle", text: "§l§b置いたもので置き換える" },
                                    { type: "text", text: "または", value: "§l§b置き換え先のブロックのIDを入力" },
                                ]
                            }, (value) => {
                                if (value[0] && value[2]) {
                                    DA_command(player, `.replace let let`);
                                } else if (value[0]) {
                                    DA_command(player, `.replace ${value[3]} let`);
                                } else if (value[2]) {
                                    DA_command(player, `.replace let ${value[1]}`);
                                } else {
                                    if (value[1] != null) {
                                        if (isBlockTypeExists(value[1]) && isBlockTypeExists(value[3])) {
                                            DA_command(player, `.replace ${value[3]} ${value[1]}`);
                                        } else {
                                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 指定したIDのブロックは存在しません。"}]}`);
                                        }
                                    }
                                }
                            })
                        } else if (result.selection == 2) {
                            DA_command(player, `.cut`);
                        } else if (result.selection == 3) {
                            Show_Form("modal", player, {
                                title: "オプションをお選びください。",
                                content: [
                                    { type: "toggle", text: "回転後の範囲を表示(回転はしません)" },
                                    { type: "toggle", text: "回転前のブロックを削除" },
                                    { type: "select", text: "何度回転させたいですか?", value: ["0", "90", "180", "270"], default: 0 }
                                ]
                            }, (value) => {
                                let values_type = [0, 90, 180, 270];
                                if (value[0]) {
                                    if (values_type[value[2]] != 0) {
                                        DA_command(player, `.rotate show ${Number(values_type[value[2]])}`);
                                    }
                                } else {
                                    if (values_type[value[2]] != 0) {
                                        DA_command(player, `.rotate ${Number(values_type[value[2]])} ${value[1] ? "cut" : ""}`);
                                    } else {
                                        run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => ＊どういうわけか、もうその形になっている"}]}`);
                                    }
                                }
                            })
                        } else if (result.selection == 4) {
                            Show_Form("modal", player, {
                                title: "オプションをお選びください。",
                                content: [
                                    { type: "toggle", text: "対称移動後の範囲表示(対称移動はしません)" },
                                    { type: "toggle", text: "x軸" },
                                    { type: "toggle", text: "z軸" },
                                ]
                            }, (value) => {
                                if (!value[1] && !value[2]) {
                                    return;
                                }
                                if (value[0]) {
                                    DA_command(player, `.flip show ${value[1] ? "x" : ""}${value[2] ? "z" : ""}`);
                                } else {
                                    DA_command(player, `.flip ${value[1] ? "x" : ""}${value[2] ? "z" : ""}`);
                                }
                            })
                        } else if (result.selection == 5) {
                            DA_command(player, `.copy`);
                        } else if (result.selection == 6) {
                            Show_Form("modal", player, {
                                title: "オプションをお選びください。",
                                content: [
                                    { type: "toggle", text: "ペーストの範囲表示(ペーストはしません)" },
                                    { type: "select", text: "ペースト先は？", value: ["選択の始点", "自分の場所"], default: 0 },
                                ]
                            }, (value) => {
                                if (value[0]) {
                                    DA_command(player, `.paste show${value[1] == 0 ? " select" : ""}`);
                                } else {
                                    DA_command(player, `.paste${value[1] == 0 ? " select" : ""}`);
                                }
                            })
                        } else if (result.selection == 7) {
                            Show_Form("modal", player, {
                                title: "オプションをお選びください。",
                                content: [
                                    { type: "toggle", text: "範囲表示(円の作成はしません)" },
                                    { type: "select", text: "生成範囲", value: ["フィル", "外周のみ", "輪/太さ指定"], default: 0 },
                                    { type: "toggle", text: "置いた物で生成する" },
                                    { type: "text", text: "または", value: "§l§bブロックのIDを入力" },
                                    { type: "toggle", text: "選択範囲内に生成する" },
                                    { type: "text", text: "または 円の半径を決めてください", value: "円の半径を入力(半角数字)" }
                                ]
                            }, (value) => {
                                if ((Number(value[5]) > 0 && Number(value[5]) < 8192) || value[4]) {
                                    if (value[0]) {
                                        DA_command(player, `.circle show ${value[4] ? "auto" : Number(value[5])}`);
                                    } else {
                                        function Love_Fireworks(bold) {
                                            if (value[2]) {
                                                DA_command(player, `.circle ${value[4] ? "auto" : Number(value[5])} let ${(value[1] != 0) ? "outline" : "fill"} ${bold}`);
                                            } else {
                                                if (isBlockTypeExists(value[3])) {
                                                    DA_command(player, `.circle ${value[4] ? "auto" : Number(value[5])} ${value[3]} ${(value[1] != 0) ? "outline" : "fill"} ${bold}`);
                                                } else {
                                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 指定したIDのブロックは存在しません。"}]}`);
                                                }
                                            }
                                        }
                                        if (value[1] == 2) {
                                            Show_Form("modal", player, {
                                                title: "オプションをお選びください。",
                                                content: [
                                                    { type: "text", text: "輪の太さを決めてください。", value: "輪の太さを入力(半角数字)" }
                                                ]
                                            }, (value_s) => {
                                                if (Number(value_s[0]) > 1) {
                                                    Love_Fireworks(`${Number(value_s[0])}`);
                                                } else {
                                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"$cDA => 無効な太さです。"}]}`);
                                                }
                                            })
                                        } else {
                                            Love_Fireworks("");
                                        }
                                    }
                                } else {
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 範囲外です。"}]}`)
                                }
                            })
                        } else if (result.selection == 8) {
                            Show_Form("modal", player, {
                                title: "オプションをお選びください。",
                                content: [
                                    { type: "toggle", text: "範囲表示(球の作成はしません)" },
                                    { type: "toggle", text: "外周のみ" },
                                    { type: "toggle", text: "置いた物で生成する" },
                                    { type: "text", text: "または", value: "§l§bブロックのIDを入力" },
                                    { type: "toggle", text: "選択範囲内に生成する" },
                                    { type: "text", text: "または 球の半径を決めてください", value: "球の半径を入力(半角数字)" }
                                ]
                            }, (value) => {
                                if ((Number(value[5]) > 0 && Number(value[5]) < 257) || value[4]) {
                                    if (value[0]) {
                                        DA_command(player, `.ball show ${(value[4]) ? "auto" : Number(value[5])}`);
                                    } else {
                                        if (value[2]) {
                                            DA_command(player, `.ball ${(value[4]) ? "auto" : Number(value[5])} let ${value[1] ? "outline" : "fill"}`);
                                        } else {
                                            if (isBlockTypeExists(value[3])) {
                                                DA_command(player, `.ball ${(value[4]) ? "auto" : Number(value[5])} ${value[3]} ${value[1] ? "outline" : "fill"}`);
                                            } else {
                                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 指定したIDのブロックは存在しません。"}]}`);
                                            }
                                        }
                                    }
                                } else {
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 範囲外です。"}]}`)
                                }
                            })
                        } else if (result.selection == 9) {
                            const select_types = ["normal", "hor", "vec"];
                            Show_Form("modal", player, {
                                title: "オプションをお選びください。",
                                content: [
                                    { type: "select", text: "線の種類", value: ["ノーマル", "平坦", "壁"], default: 0 },
                                    { type: "toggle", text: "置いた物で生成する" },
                                    { type: "text", text: "または", value: "§l§bブロックのIDを入力" },
                                    { type: "text", text: "線の太さを決めてください", value: "線の太さを入力(半角数字)" }
                                ]
                            }, (value) => {
                                if (Number(value[3]) > 0 && Number(value[3]) < 257) {
                                    if (value[1]) {
                                        DA_command(player, `.line ${value[3]} let ${select_types[value[0]]}`);
                                    } else {
                                        if (isBlockTypeExists(value[2])) {
                                            DA_command(player, `.line ${value[3]} ${value[2]} ${select_types[value[0]]}`);
                                        } else {
                                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 指定したIDのブロックは存在しません。"}]}`);
                                        }
                                    }
                                } else {
                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 範囲外です。"}]}`)
                                }
                            })
                        } else if (result.selection == 10) {
                            Show_Form("action", player, {
                                title: "オプションをお選びください。",
                                content: [
                                    { type: "button", value: "ベジェ曲線を書き始める" },
                                    { type: "button", value: "決定する" },
                                    { type: "button", value: "参照数の変更" }
                                ]
                            }, (result) => {
                                if (result.selection == 0) {
                                    Show_Form("modal", player, {
                                        title: "オプションをお選びください。",
                                        content: [
                                            { type: "slider", text: "§l§6参照数\n§rデフォルトは100です。数値が大きいほどブロック設置の感覚が狭くなります。", min: 10, max: 1000, step: 10, default: 100 },
                                        ]
                                    }, (value) => {
                                        DA_command(player, `.BezierCurves start ${value[0]}`);
                                    })
                                } else if (result.selection == 1) {
                                    Show_Form("modal", player, {
                                        title: "オプションをお選びください。",
                                        content: [
                                            { type: "toggle", text: "置いた物で生成する" },
                                            { type: "text", text: "または", value: "§l§bブロックのIDを入力" },
                                            { type: "text", text: "§6§lFill line(不必須)§r\nfillコマンドで~を使った時のように、範囲を決めれます。\n例:-1 0 3 1 -3 0 \n(ベジェ曲線からxを-1～1、yを0～-3、zを3～0に掛けてブロックを設置する)", value: "スペースで区切ってください" },
                                        ]
                                    }, (value) => {
                                        let is_not_regular = false;
                                        if (value[2] != "") {
                                            const vs = value[2].split(" ");
                                            for (let i = 0; i < vs.length; i++) {
                                                if (Number(vs[i]) > -Infinity) {

                                                } else {
                                                    is_not_regular = true;
                                                    break;
                                                }
                                            }
                                        }
                                        if (!is_not_regular) {
                                            if (value[0]) {
                                                DA_command(player, `.BezierCurves enter let ${value[2]}`);
                                            } else {
                                                if (isBlockTypeExists(value[1])) {
                                                    DA_command(player, `.BezierCurves enter ${value[1]} ${value[2]}`);
                                                } else {
                                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 指定したIDのブロックは存在しません。"}]}`);
                                                }
                                            }
                                        } else {
                                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 無効な構文です。"}]}`);
                                        }
                                    })
                                } else if (result.selection == 2) {
                                    Show_Form("modal", player, {
                                        title: "オプションをお選びください。",
                                        content: [
                                            { type: "slider", text: "§l§6参照数\n§rデフォルトは100です。数値が大きいほどブロック設置の間隔が狭くなります。", min: 10, max: 1000, step: 10, default: Number(DA_data[player.id]["BC_sample_num"] ?? 100) },
                                        ]
                                    }, (value) => {
                                        if (Number(value[0]) > 0) {
                                            DA_data[player.id]["BC_sample_num"] = Number(value[0]);
                                        } else {
                                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 範囲外です。"}]}`);
                                        }
                                    })
                                }
                            })
                        } else if (result.selection == 11) {
                            Show_Form("action", player, {
                                title: "オプションをお選びください。",
                                content: [
                                    { type: "button", value: "パスを指定する" },
                                    { type: "button", value: "§l§6地形を生成する" }
                                ]
                            }, (result) => {
                                if (result.selection == 0) {
                                    DA_command(player, `.ts`);
                                } else if (result.selection == 1) {
                                    const content = [
                                        { type: "slider", text: "起伏の調整", min: 1, max: 100, step: 1, default: 10 },
                                        { type: "text", text: "シード値(-32768 ~ 32768)", value: "(-32768 ~ 32768)" },
                                        { type: "toggle", text: "置いた物で生成する" },
                                        { type: "text", text: "または", value: "§l§bブロックのIDを入力" },
                                        { type: "toggle", text: "パスを保持する" },
                                    ];
                                    const Correction_pattern = ["加法", "平均", "比率"];
                                    if (DA_data[player.id]["terrain_CP"] != null) {
                                        if (DA_data[player.id]["terrain_CP"].length > 0) {
                                            content.push({ type: "select", text: "補正パターン", value: Correction_pattern, default: 0 })
                                        }
                                    }
                                    Show_Form("modal", player, {
                                        title: "オプションをお選びください。",
                                        content: content
                                    }, (value) => {
                                        function ru_tr(value) {
                                            if (Number(value[1] ?? 0) >= -32768 && Number(value[1] ?? 0) <= 32768 && Number(value[0]) > 0) {
                                                if (value[2]) {
                                                    DA_command(player, `.terrain ${Number(value[0]) / 100} ${value[1] ?? 0} let ${value[4]} ${value[5] ?? null} ${value[6] ?? null}`);
                                                } else {
                                                    if (isBlockTypeExists(value[3])) {
                                                        DA_command(player, `.terrain ${Number(value[0]) / 100} ${value[1] ?? 0} ${value[3]} ${value[4]} ${value[5] ?? null} ${value[6] ?? null}`);
                                                    } else {
                                                        run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 指定したIDのブロックは存在しません。"}]}`);
                                                    }
                                                }
                                            } else {
                                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 範囲外です。"}]}`)
                                            }
                                        }
                                        if ((value[5] ?? null) == 2) {
                                            Show_Form("modal", player, {
                                                title: "比率の倍率",
                                                content: [{ type: "slider", text: "比率の倍率", min: 2, max: 40, step: 2, default: 4 }]
                                            }, (res) => {
                                                const send_arr = JSON.parse(JSON.stringify(value));
                                                send_arr.push(res[0]);
                                                ru_tr(send_arr);
                                            })
                                        } else {
                                            ru_tr(value);
                                        }
                                    })
                                }
                            })
                        } else if (result.selection == 12) {
                            function RS12() {
                                Show_Form("action", player, {
                                    title: "どちらにしますか？",
                                    content: [
                                        { type: "button", value: "§6§l使う" },
                                        { type: "button", value: "説明を見る" }
                                    ]
                                }, (result) => {
                                    if (result.selection == 0) {
                                        Show_Form("modal", player, {
                                            title: "オプション",
                                            content: [
                                                { type: "slider", text: "最大探索範囲", min: 4, max: 16, step: 1, default: 6 },
                                                { type: "toggle", text: "置いた物で生成する" },
                                                { type: "text", text: "または", value: "§l§bブロックのIDを入力" },
                                                { type: "text", text: "§6§lFill line(不必須)§r\nfillコマンドで~を使った時のように、範囲を決めれます。\n例:-1 0 3 1 -3 0 \n(ベジェ曲線からxを-1～1、yを0～-3、zを3～0に掛けてブロックを設置する)", value: "スペースで区切ってください" },
                                            ]
                                        }, (value) => {
                                            let is_not_regular = false;
                                            if (value[3] != "") {
                                                const vs = value[3].split(" ");
                                                for (let i = 0; i < vs.length; i++) {
                                                    if (Number(vs[i]) > -Infinity) {

                                                    } else {
                                                        is_not_regular = true;
                                                        break;
                                                    }
                                                }
                                            }
                                            if (!is_not_regular) {
                                                if (isBlockTypeExists(value[2]) || value[1]) {
                                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => スタート地点のブロックを壊してください。"}]}`);
                                                    DA_data[player.id]["frame"] = {
                                                        searches_num: value[0],
                                                        block: (value[1]) ? "let" : value[2],
                                                        fill_line: value[3],
                                                    }
                                                } else {
                                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 指定したIDのブロックは存在しません。"}]}`);
                                                }
                                            } else {
                                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 無効な構文です。"}]}`);
                                            }
                                        })
                                    } else if (result.selection == 1) {
                                        Show_Form("action", player, {
                                            title: "どちらにしますか？",
                                            content: [
                                                { type: "body", value: `ブロックとブロックを指定したブロックで繋げてくれます。\n1.範囲を指定します。\n2.範囲内にガイドのようにブロックをまばらでいいので置きます。\n3.Frame機能を使ってガイドのブロック、繋げたいブロックを指定します。\n4.ガイドに沿って指定したブロックが敷かれます。` },
                                                { type: "button", value: "戻る" }
                                            ]
                                        }, (result) => {
                                            system.runTimeout(RS12, 1)
                                        })
                                    }
                                })
                            }
                            RS12();
                        } else if (result.selection == 13) {
                            DA_command(player, `.undo`);
                        }
                    }
                })
            }
            SF_func();
        } else if (get_authority_num(player) < 3 && item == "da:da_automatic") {
            const LUN_setting = DA_save_on_world[player.id]["LUNATIC_setting"];
            if (LUN_setting["can_use_automatic"] != null && get_authority_num(player) >= 2) {
                if (LUN_setting["can_use_automatic"] == false) {
                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 許可されていない機能です。"}]}`);
                    return;
                }
            }
            function re_form() {
                const AW = DA_save_on_world[player.id]["Automatic_water"];
                const AID = DA_save_on_world[player.id]["Automatic_in_diagonal"];
                Show_Form("action", player, {
                    title: "オプションをお選びください。",
                    content: [
                        { type: "body", value: "§lアイテムをオフハンド(左)\nに持って使用します\n§r" },
                        { type: "button", value: "ノーマルモード" },
                        { type: "button", value: "ブロック無判別モード" },
                        { type: "button", value: "端判定モード" },
                        // { type: "button", value: `${(AW == null) ? "§b" : ((AW) ? "§b" : "§4")}§l液体を判定:${(AW == null) ? "ON" : ((AW) ? "ON" : "OFF")}` },
                        { type: "button", value: `${(AID == null) ? "§4" : ((AID) ? "§b" : "§4")}§l斜めを許可:${(AID == null) ? "OFF" : ((AID) ? "ON" : "OFF")}` },
                        { type: "button", value: "最終行動を戻す" },
                        { type: "button", value: "上限を設定" },
                    ]
                }, (result) => {
                    if (result.canceled) {
                        return -1;
                    } else {
                        if (result.selection == 0) {
                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => ノーマルモードです。\n設置先のブロックを判別して、\n同じブロックに接している所のみ\nブロックを設置します。"}]}`)
                            DA_save_on_world[player.id]["Automatic_type"] = "normal";
                        } else if (result.selection == 1) {
                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => ブロック無判別モードです。\n設置先のブロックを判別せす、\nブロックを設置します。"}]}`)
                            DA_save_on_world[player.id]["Automatic_type"] = "no_judge";
                        } else if (result.selection == 2) {
                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§aDA => 端判定モードです。\n端を自動判定し、その面だけ\nブロックを設置します。"}]}`)
                            DA_save_on_world[player.id]["Automatic_type"] = "edge";
                        } else if (result.selection == 3) {
                            if (DA_save_on_world[player.id]["Automatic_in_diagonal"] == false) {
                                DA_save_on_world[player.id]["Automatic_in_diagonal"] = true;
                            } else {
                                DA_save_on_world[player.id]["Automatic_in_diagonal"] = false;
                            }
                            system.runTimeout(re_form, 1);
                        } else if (result.selection == 5) {
                            Show_Form("modal", player, {
                                title: "上限を設定してください。",
                                content: [
                                    { type: "slider", text: "自動ブロック設置上限", min: 4, max: 96, step: 4, default: (DA_save_on_world[player.id]["Automatic_max"] ?? 64) },
                                ]
                            }, (value) => {
                                if (Number(value[0]) > 0 && Number(value[0]) < 100) {
                                    DA_save_on_world[player.id]["Automatic_max"] = Number(value[0]);
                                    save_DASOW_on_world();
                                }
                            })
                        }
                        if (result.selection == 4) {
                            DA_command(player, ".automatic_undo");
                        } else {
                            save_DASOW_on_world();
                        }
                    }
                })
            }
            re_form();
        } else if (get_authority_num(player) < 3 && item == "da:da_taskmanager") {
            function SF_DT() {

                const content_arr = [
                    { type: "body", value: `§l§b現在のタスク合計:${Object.keys(DA_now_tasking).length}` },
                    { type: "button", value: `§1§lメモリーへ行く` },
                    { type: "button", value: `§c§l全て中止する` },
                ];
                const key_on_index = [];
                for (const key in DA_now_tasking) {
                    if (Object.prototype.hasOwnProperty.call(DA_now_tasking, key)) {
                        const situation = DA_now_tasking[key].situation;
                        let color = "§4";
                        if (situation == "Pending") {
                            color = "§e";
                        } else if (situation == "Running") {
                            color = "§a§l";
                        } else if (situation == "Stopping") {
                            color = "§7";
                        }
                        key_on_index.push(key);
                        content_arr.push({ type: "button", value: `${color}ID:${key} ${situation} ${DA_now_tasking[key].command.slice(0, 16)}${String(DA_now_tasking.command).length > 16 ? "..." : ""}` },);
                    }
                }
                Show_Form("action", player, {
                    title: "現在のタスク",
                    content: content_arr
                }, (result) => {
                    if (result.selection == 0) {
                        let memory_num = ((DA_save_on_world["memory"] ?? {})["max"]) ?? 1024;
                        let all_size = 0;
                        const data = {
                            title: `メモリー`,
                            content: [
                                { type: "button", value: `§6§lタスクマネージャーへ行く` },
                                { type: "button", value: `§1§l解放する` },
                            ]
                        }
                        for (const key in DA_structures) {
                            if (Object.prototype.hasOwnProperty.call(DA_structures, key)) {
                                const date = new Date(DA_structures[key].date);
                                all_size += DA_structures[key].size;
                                if (data.content.length < 16) {
                                    data.content.push({ type: "button", value: `${date.getMonth() + 1}/${date.getDate()} ${date.getHours()}:${date.getMinutes()} ${DA_structures[key].player.name}` });
                                }
                            }
                        }
                        const KD = ((all_size / 32) + (JSON.stringify(DA_data).length * 32) + (JSON.stringify(DA_ABU).length / 16)) / 1024;
                        const percent = Math.floor(KD / (memory_num) * 10000) / 100;
                        let percent_color = "§1";
                        if (percent > 90) { percent_color = "§4" } else if (percent > 70) { percent_color = "§6" } else if (percent > 50) { percent_color = "§e" } else if (percent > 25) { percent_color = "§a" };
                        data.content.unshift({ type: "body", value: `§l§b現在のメモリ使用量:\n${percent_color}${Math.floor(KD * 100) / 100}/${memory_num} KD\n${percent}％\n` });
                        Show_Form("action", player, data, (value) => {
                            if (value.selection == 0) {
                                system.runTimeout(SF_DT, 1);
                            } else if (value.selection == 1) {
                                Show_Form("action", player, {
                                    title: "解放度合い",
                                    content: [
                                        { type: "body", value: "メモリの解放度合いを選んでください。" },
                                        { type: "button", value: "§1弱" },
                                        { type: "button", value: "§a標準" },
                                        { type: "button", value: "§e強" },
                                        { type: "button", value: "§c全て" },
                                    ]
                                }, (res) => {
                                    if (res.canceled) {

                                    } else {
                                        memory_delete(res.selection);
                                    }
                                })
                            }
                        })
                    } else if (result.selection == 1) {
                        for (let i = 0; i < key_on_index.length; i++) {
                            DA_command(player, `.stop ${key_on_index[i]}`);
                        }
                    } else if (result.selection > 0) {
                        const this_index = result.selection - 2;
                        const this_task = DA_now_tasking[key_on_index[this_index]];
                        const situation = this_task.situation;
                        let color = "§4";
                        if (situation == "Pending") {
                            color = "§e";
                        } else if (situation == "Running") {
                            color = "§b§l";
                        } else if (situation == "Stopping") {
                            color = "§7";
                        }
                        let text = "";
                        text += `ID: ${key_on_index[this_index]}`;
                        text += `\n状態: ${color}${situation}`;
                        text += `\n§r実行者: ${this_task.player_name}§r`;
                        text += `\n実行: ${this_task.command}§r`;
                        Show_Form("message", player, {
                            title: `タスクの詳細`,
                            body: text,
                            confirm: "§l戻る",
                            cancel: "§4§l中断する",
                        }, (result) => {
                            if (result != undefined) {
                                if (result.selection == 1) {
                                    DA_command(player, `.stop ${key_on_index[this_index]}`);
                                } else {
                                    system.runTimeout(SF_DT, 1);
                                }
                            }
                        })
                    }
                })
            }
            SF_DT();
        } else if (item == "da:da_about_me") {
            function show_about() {
                if (DA_save_on_world["About"] == null) {
                    DA_save_on_world["About"] = {

                    }
                    save_DASOW_on_world();
                } else {
                    if (Object.keys(DA_save_on_world["About"]) > 32) {
                        const object = DA_save_on_world["About"];
                        const sortedKeys = Object.keys(object["Last_login"]).sort((a, b) => object["Last_login"][a] - object["Last_login"][b]);
                        for (let i = 0; i < Math.min(3, sortedKeys.length); i++) {
                            delete DA_save_on_world["About"][sortedKeys[i]];
                        }
                    }
                    if (DA_save_on_world["About"] != null) {
                        const one_txt = `only[プレイヤー名] と書いた行は、\nそのプレイヤーのみに表示されます。\n1つ 1行です。`;
                        const content = [
                            { type: "button", value: "自分の自己紹介を書く/編集する" }
                        ];
                        const about = DA_save_on_world["About"];
                        const All_players = world.getAllPlayers();
                        const All_players_id = [];
                        for (let i = 0; i < All_players.length; i++) {
                            All_players_id.push(All_players[i].id);
                        }
                        for (const key in about) {
                            if (Object.prototype.hasOwnProperty.call(about, key)) {
                                content.push({ type: "button", value: `${about[key].name}`, icon: `${about[key].icon ?? ((All_players_id.indexOf(key) != -1) ? "textures/items/DA_online" : "textures/items/DA_offline")}`, id: key });
                            }
                        }
                        Show_Form("action", player, {
                            title: (`自己紹介ノート`), content: content
                        }, (result) => {
                            if (result.canceled) {
                                return -1;
                            } else {
                                if (result.selection == 0) {
                                    let about_me = "";
                                    const AM_content = [];
                                    if (about[player.id] != null) {
                                        about_me = about[player.id].text;
                                        let looped_num = 0;
                                        const ats = about[player.id].text.split("\n");
                                        for (let i = 0; i < ats.length; i++) {
                                            if (ats[i] != "") {
                                                AM_content.push({ type: "text", text: `${(i == 0) ? `${one_txt}` : ""}`, value: ``, default: `${ats[i]}` })
                                                looped_num++;
                                            }
                                        }
                                        if (looped_num == 0) {
                                            AM_content.push({ type: "text", text: `${one_txt}`, value: "", default: `` });
                                        }
                                    } else {
                                        AM_content.push({ type: "text", text: `${one_txt}`, value: "", default: `` });
                                    }
                                    AM_content.push({ type: "toggle", text: "決定する\n(オフの場合は一行追加されます)" });
                                    AM_content.push({ type: "text", text: "アイコン設定\n", value: "textures/ のフォルダにあるものです。", default: (about[player.id] != null) ? (about[player.id].icon ?? "") : "" });
                                    function show_edit_about_me() {
                                        const amt = about_me.split("\n");
                                        for (let i = 0; i < amt.length; i++) {
                                            if (AM_content[i] != null) {
                                                if (AM_content[i].type == "text") {
                                                    AM_content[i].default = amt[i];
                                                    if (i != 0 && i != amt.length - 1) {
                                                        AM_content[i].text = "";
                                                    }
                                                }
                                            }
                                        }
                                        Show_Form("modal", player, {
                                            title: (`Create The 自己紹介`),
                                            content: AM_content
                                        }, (value) => {
                                            if (!value[value.length - 2]) {
                                                about_me = "";
                                                let cuted = false;
                                                let finally_index = 0;
                                                for (let i = 0; i < value.length - 2; i++) {
                                                    about_me += (`${(i == 0) ? "" : "\n"}${value[i].replaceAll("\n", "")}`);
                                                    finally_index = i;
                                                    if (String(about_me).length > 512) {
                                                        cuted = true;
                                                        about_me = String(about_me).slice(0, 512);
                                                        break;
                                                    }
                                                }
                                                if (value[value.length - 3] != "" && (finally_index == value.length - 3)) {
                                                    if (AM_content.length < 11) {
                                                        AM_content.splice(AM_content.length - 2, 0, { type: "text", text: `${(AM_content.length == 10) ? "最大行数は10行です" : ""}${(cuted ? "最大文字数は512文字です" : "")}`, value: "", default: `` });
                                                    }
                                                } else {
                                                    if (AM_content[AM_content.length - 3] != null) {
                                                        if (AM_content[AM_content.length - 3].type == "text") {
                                                            AM_content[AM_content.length - 3].text = `${(AM_content.length == 10) ? "最大行数は10行です" : ""}${(cuted ? "最大文字数は512文字です" : "")}`;
                                                        }
                                                    }
                                                }
                                                AM_content[AM_content.length - 1].default = value[value.length - 1];
                                                system.runTimeout(show_edit_about_me, 1);
                                            } else {
                                                about_me = "";
                                                for (let i = 0; i < value.length - 2; i++) {
                                                    about_me += (`${(i == 0) ? "" : "\n"}${value[i].replaceAll("\n", "")}`);
                                                }
                                                DA_save_on_world["About"][player.id] = {
                                                    text: about_me,
                                                    name: player.nameTag,
                                                    icon: (value[value.length - 1] == "") ? null : `textures/${value[value.length - 1].replace("textures/", "")}`,
                                                    Last_login: (new Date).getTime()
                                                }
                                                save_DASOW_on_world();
                                            }
                                        })
                                    }
                                    show_edit_about_me();
                                } else if (about[content[result.selection].id] != null) {
                                    let atxt = ``;
                                    let before_only = false;
                                    const acid = String(about[content[result.selection].id].text).split("\n");
                                    for (let i = 0; i < acid.length; i++) {
                                        if (acid[i].indexOf("only[") != -1 && acid[i].indexOf("]") != -1) {
                                            const asp = String(acid[i]).match(/only\[(.*?)\]/)[1].split(",");
                                            for (let g = 0; g < asp.length; g++) {
                                                if (similarityPercentage(asp[g], player.nameTag) > 90) {
                                                    atxt += `§b------あなただけに表示------§r\n`;
                                                    atxt += acid[i].replaceAll(`${asp}`, "").replace("only[]", "");
                                                    before_only = true;
                                                }
                                            }
                                        } else {
                                            if (before_only) {
                                                before_only = false;
                                                atxt += `\n§b-------------------------------------------§r`;
                                            }
                                            atxt += `${(i == 0) ? "" : "\n"}${acid[i]}`;
                                        }
                                    }
                                    Show_Form("message", player, {
                                        title: `${about[content[result.selection].id].name}§rの自己紹介`,
                                        body: `${atxt}`,
                                        confirm: `他の人の自己紹介も観る`,
                                        cancel: `閲覧を止める`,
                                    }, (result) => {
                                        if (result != undefined) {
                                            if (result.selection == 1) {
                                            } else {
                                                system.runTimeout(show_about, 1);
                                            }
                                        }
                                    })
                                }
                            }
                        })
                    }
                }
            }
            show_about();
        } else if (item == "da:da_chat") {
            Show_Form("action", player, {
                title: "チャット設定",
                content: [
                    { type: "button", value: `グループチャット`, icon: "textures/gui/controls/waterdescend_pressed" },
                    { type: "button", value: `リストチャット`, icon: "textures/gui/controls/flyingdescend_pressed" },
                    { type: "button", value: `範囲チャット`, icon: "textures/gui/controls/down_pressed" },
                    // { type: "button", value: `` },
                ]
            }, (result) => {
                if (result.canceled) {

                } else {
                    if (result.selection == 0) {
                        const content = [
                            { type: "button", value: "チャットのデフォルトを\nグループチャットにする", icon: "textures/gui/newgui/Language16" },
                            { type: "button", value: "作成", icon: "textures/gui/controls/waterdescend_pressed" },
                            { type: "button", value: "削除", icon: "textures/blocks/barrier" },
                            { type: "button", value: "プレイヤー追加", icon: "textures/gui/controls/down_pressed" },
                            { type: "button", value: "プレイヤー削除", icon: "textures/blocks/barrier" },
                            { type: "button", value: "チェック", icon: "textures/items/spyglass" },
                            { type: "button", value: "全てのグループ", icon: "textures/blocks/glass" },
                        ]
                        if (DA_data[player.id]["GCF"] != null) {
                            content[0] = { type: "button", value: "§6チャットのデフォルトを解除する", icon: "textures/gui/newgui/Language16" };
                        }
                        Show_Form("action", player, {
                            title: "チャット設定",
                            content: content
                        }, (result) => {
                            if (result.canceled) {

                            } else {
                                if (result.selection == 0) {
                                    if (DA_data[player.id]["GCF"] == null) {
                                        const group_in_me = [];
                                        const group_in_data = [];
                                        for (const key in DA_save_on_world["group_chat"]) {
                                            if (Object.prototype.hasOwnProperty.call(DA_save_on_world["group_chat"], key)) {
                                                if (DA_save_on_world["group_chat"][key].players.some(item => item.id === player.id)) {
                                                    group_in_me.push(`ID:${key} NAME:${DA_save_on_world["group_chat"][key].name}`);
                                                    group_in_data.push(key);
                                                }
                                            }
                                        }
                                        if (group_in_me.length > 0) {
                                            Show_Form("modal", player, {
                                                title: "デフォルト設定",
                                                content: [
                                                    { type: "select", text: "どのグループチャットをチャットのデフォルトにしたいですか？", value: group_in_me }
                                                ]
                                            }, (value) => {
                                                DA_command(player, `.group forced ${group_in_data[value[0]]} ${player.nameTag}`)
                                            })
                                        } else {
                                            if (value[0]) {
                                                system.run(() => {
                                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => まだどのグループにも所属していません。"}]}`)
                                                })
                                            }
                                        }
                                    } else {
                                        DA_command(player, `.group release`);
                                    }
                                } else if (result.selection == 1) {
                                    Show_Form("modal", player, {
                                        title: "チャット設定",
                                        content: [
                                            { type: "text", text: "グループIDを決めてください。§c(必須/スペース不可)", value: "" },
                                            { type: "text", text: "グループ名を決めてください。(不必須)", value: "" }
                                        ]
                                    }, (value) => {
                                        if ((value[0].replaceAll(" ", "").replaceAll("　", "").replaceAll("§", "").replaceAll("\\", "")).length < 2 || value[0].length > 10) {
                                            system.run(() => {
                                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => グループIDは2文字以上 10文字以下である必要があります。"}]}`)
                                            })
                                        } else {
                                            if (value[0].indexOf(" ") == -1) {
                                                DA_command(player, `.group create ${value[0].replaceAll(" ", "").replaceAll("　", "").replaceAll("§", "").replaceAll("\\", "")} ${value[1]}`);
                                            } else {
                                                system.run(() => {
                                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => グループIDにスペースは入力できません。"}]}`)
                                                })
                                            }
                                        }
                                    })
                                } else if (result.selection == 2) {
                                    if (DA_save_on_world["group_chat"] != null) {
                                        const group_in_me = [];
                                        const group_in_data = [];
                                        for (const key in DA_save_on_world["group_chat"]) {
                                            if (Object.prototype.hasOwnProperty.call(DA_save_on_world["group_chat"], key)) {
                                                if (DA_save_on_world["group_chat"][key].players.some(item => item.id === player.id)) {
                                                    group_in_me.push(`ID:${key} NAME:${DA_save_on_world["group_chat"][key].name}`);
                                                    group_in_data.push(key);
                                                }
                                            }
                                        }
                                        if (group_in_data.length > 0) {
                                            Show_Form("modal", player, {
                                                title: "チャット設定",
                                                content: [
                                                    { type: "select", text: "削除したいグループを選択", value: group_in_me, default: 0 },
                                                    { type: "text", text: "または削除したいグループIDを入力", value: "" }
                                                ]
                                            }, (value) => {
                                                DA_command(player, `.group delete ${(value[1] != "") ? value[1] : group_in_data[value[0]]}`);
                                            })
                                        } else {
                                            system.run(() => {
                                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => まだどのグループにも所属していません。"}]}`)
                                            })
                                        }
                                    } else {
                                        system.run(() => {
                                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => まだこのワールドにはグループが存在しません。"}]}`)
                                        })
                                    }
                                } else if (result.selection == 3) {
                                    if (DA_save_on_world["group_chat"] != null) {
                                        const group_in_me = [];
                                        const group_in_data = [];
                                        const can_add_players = [];
                                        const All_players = world.getAllPlayers();
                                        for (const key in DA_save_on_world["group_chat"]) {
                                            if (Object.prototype.hasOwnProperty.call(DA_save_on_world["group_chat"], key)) {
                                                if (DA_save_on_world["group_chat"][key].players.some(item => item.id === player.id)) {
                                                    group_in_me.push(`ID:${key} NAME:${DA_save_on_world["group_chat"][key].name}`);
                                                    group_in_data.push(key);
                                                }
                                            }
                                        }
                                        for (let i = 0; i < All_players.length; i++) {
                                            can_add_players.push(`${All_players[i].nameTag}`);
                                        }
                                        if (group_in_me.length == 0) {
                                            system.run(() => {
                                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => まだどこのグループにも所属していません"}]}`)
                                            })
                                        } else {
                                            Show_Form("modal", player, {
                                                title: "チャット設定",
                                                content: [
                                                    { type: "select", text: "グループを選択", value: group_in_me, default: 0 },
                                                    { type: "select", text: "追加したいプレイヤーを選択", value: can_add_players, default: 0 },
                                                ]
                                            }, (value) => {
                                                DA_command(player, `.group add ${group_in_data[value[0]]} ${can_add_players[value[1]]}`);
                                            })
                                        }
                                    } else {
                                        system.run(() => {
                                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => まだこのワールドにはグループが存在しません。"}]}`)
                                        })
                                    }
                                } else if (result.selection == 4) {
                                    if (DA_save_on_world["group_chat"] != null) {
                                        const group_in_me = [];
                                        const group_in_data = [];
                                        const can_add_players = [];
                                        const All_players = world.getAllPlayers();
                                        for (const key in DA_save_on_world["group_chat"]) {
                                            if (Object.prototype.hasOwnProperty.call(DA_save_on_world["group_chat"], key)) {
                                                if (DA_save_on_world["group_chat"][key].players.some(item => item.id === player.id)) {
                                                    group_in_me.push(`ID:${key} NAME:${DA_save_on_world["group_chat"][key].name}`);
                                                    group_in_data.push(key);
                                                }
                                            }
                                        }
                                        for (let i = 0; i < All_players.length; i++) {
                                            can_add_players.push(`${All_players[i].nameTag}`);
                                        }
                                        if (group_in_me.length == 0) {
                                            system.run(() => {
                                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => まだどこのグループにも所属していません"}]}`)
                                            })
                                        } else {
                                            Show_Form("modal", player, {
                                                title: "チャット設定",
                                                content: [
                                                    { type: "select", text: "グループを選択", value: group_in_me, default: 0 },
                                                    { type: "select", text: "削除したいプレイヤーを選択", value: can_add_players, default: 0 },
                                                ]
                                            }, (value) => {
                                                DA_command(player, `.group remove ${group_in_data[value[0]]} ${can_add_players[value[1]]}`);
                                            })
                                        }
                                    } else {
                                        system.run(() => {
                                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => まだこのワールドにはグループが存在しません。"}]}`)
                                        })
                                    }
                                } else if (result.selection == 5) {
                                    if (DA_save_on_world["group_chat"] != null) {
                                        const group_in_me = [];
                                        const group_in_data = [];
                                        const can_add_players = [];
                                        for (const key in DA_save_on_world["group_chat"]) {
                                            if (Object.prototype.hasOwnProperty.call(DA_save_on_world["group_chat"], key)) {
                                                if (DA_save_on_world["group_chat"][key].players.some(item => item.id === player.id)) {
                                                    group_in_me.push(`ID:${key} NAME:${DA_save_on_world["group_chat"][key].name}`);
                                                    group_in_data.push(key);
                                                }
                                            }
                                        }
                                        if (group_in_me.length == 0) {
                                            system.run(() => {
                                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => まだどこのグループにも所属していません"}]}`)
                                            })
                                        } else {
                                            Show_Form("modal", player, {
                                                title: "チャット設定",
                                                content: [
                                                    { type: "select", text: "グループを選択", value: group_in_me, default: 0 },
                                                ]
                                            }, (value) => {
                                                DA_command(player, `.group check ${group_in_data[value[0]]}`);
                                            })
                                        }
                                    } else {
                                        system.run(() => {
                                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => まだこのワールドにはグループが存在しません。"}]}`)
                                        })
                                    }
                                } else if (result.selection == 6) {
                                    if (DA_save_on_world["group_chat"] != null) {
                                        DA_command(player, `.group all`);
                                    } else {
                                        system.run(() => {
                                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => まだこのワールドにはグループが存在しません。"}]}`)
                                        })
                                    }
                                }
                            }
                        })
                    } else if (result.selection == 1) {
                        Show_Form("action", player, {
                            title: "チャット設定",
                            content: [
                                { type: "button", value: "プレイヤー追加", icon: "textures/gui/controls/down_pressed" },
                                { type: "button", value: "プレイヤー削除", icon: "textures/blocks/barrier" },
                                { type: "button", value: "リセット", icon: "textures/blocks/sculk_shrieker_top" },
                                { type: "button", value: "チェック", icon: "textures/items/spyglass" },
                            ]
                        }, (result) => {
                            if (result.canceled) {

                            } else {
                                if (result.selection == 0) {
                                    player_setting_data(player);
                                    if (DA_save_on_world["list_chat"] != null) {
                                        const All_players = world.getAllPlayers();
                                        const content = [];
                                        for (let i = 0; i < All_players.length; i++) {
                                            if (DA_save_on_world["list_chat"][player.id] != null) {
                                                if (DA_save_on_world["list_chat"][player.id].players.some(item => item.id === All_players[i].id)) {
                                                    continue;
                                                }
                                            }
                                            content.push({ type: "button", value: `${All_players[i].nameTag}`, name: All_players[i].nameTag })
                                        }
                                        if (content.length == 0) {
                                            system.run(() => {
                                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => これ以上登録できません！"}]}`)
                                            })
                                        } else {
                                            Show_Form("action", player, {
                                                title: "チャット設定",
                                                content: content,
                                            }, (value) => {
                                                if (value.canceled) {

                                                } else {
                                                    DA_command(player, `.list add ${content[value.selection].name}`);
                                                }
                                            })
                                        }
                                    } else {
                                        system.run(() => {
                                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 別の機能を使って初期化してください。"}]}`)
                                        })
                                    }
                                } else if (result.selection == 1) {
                                    player_setting_data(player);
                                    if (DA_save_on_world["list_chat"] != null) {
                                        if (DA_save_on_world["list_chat"][player.id] != null) {
                                            const All_players = world.getAllPlayers();
                                            const content = [];
                                            for (let i = 0; i < All_players.length; i++) {
                                                if (DA_save_on_world["list_chat"][player.id] != null) {
                                                    if (DA_save_on_world["list_chat"][player.id].players.some(item => item.id === All_players[i].id)) {
                                                        content.push({ type: "button", value: `${All_players[i].nameTag}`, name: All_players[i].nameTag })
                                                    }
                                                }
                                            }
                                            if (content.length == 0) {
                                                system.run(() => {
                                                    run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => もうリストにはだれも居ません。"}]}`)
                                                })
                                            } else {
                                                Show_Form("action", player, {
                                                    title: "チャット設定",
                                                    content: content,
                                                }, (value) => {
                                                    if (value.canceled) {

                                                    } else {
                                                        DA_command(player, `.list remove ${content[value.selection].name}`);
                                                    }
                                                })
                                            }
                                        } else {
                                            system.run(() => {
                                                run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => まだリストを作っていません。"}]}`)
                                            })
                                        }
                                    } else {
                                        system.run(() => {
                                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => まだリストを作っていません。"}]}`)
                                        })
                                    }
                                } else if (result.selection == 2) {
                                    player_setting_data(player);
                                    if (DA_save_on_world["list_chat"] != null) {
                                        DA_save_on_world["list_chat"][player.id] = {
                                            players: [{ id: player.id, name: player.nameTag }],
                                        }
                                    } else {
                                        system.run(() => {
                                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 別の機能を使って初期化してください。"}]}`)
                                        })
                                    }
                                } else if (result.selection == 3) {
                                    player_setting_data(player);
                                    if (DA_save_on_world["list_chat"] != null) {
                                        DA_command(player, `.list check`)
                                    } else {
                                        system.run(() => {
                                            run_command_player(player, `tellraw @s {"rawtext":[{"text":"§cDA => 別の機能を使って初期化してください。"}]}`)
                                        })
                                    }
                                }
                            }
                        })
                    } else if (result.selection == 2) {
                        Show_Form("action", player, {
                            title: "半径チャットの使い方",
                            content: [
                                { type: "body", value: `指定した範囲内のプレイヤーにのみ\nメッセージを送れます。\n\n構文:r.範囲(半径) メッセージ\n\n例:\nr.12 こんにちは\n(半径12以内の人に「こんにちは」を送る)\nr.8 やっほ～\n(半径8以内の人に「やっほ～」を送る)\n§e注意: r.範囲 と　メッセージ　の間にスペース(半角)を入れることを忘れないでください。` },
                                { type: "button", value: `了解！` },
                            ]
                        }, () => {

                        })
                    }
                }
            })
        }
    })
    if (get_authority_num(player) < 3 && (item == "da:da_brush" || item == "da:da_art")) {
        ev.cancel = true;
    }
})

function format_milisec_to_str(mili, is_stopwatch = false) {
    const sec = Math.floor(mili / 1000);
    let return_text = "";
    if (sec / 3600 >= 1) {
        return_text += `${Math.floor(sec / 3600)}${is_stopwatch ? ":" : "時間"}`;
    }
    if (sec / 60 >= 1) {
        return_text += `${String(Math.floor(sec / 60)).padStart((sec / 3600 >= 1) ? 2 : 1, "0")}${is_stopwatch ? ":" : "分"}`;
    }
    return_text += `${String(sec % 60).padStart((sec / 60 >= 1) ? 2 : 1, "0")}${is_stopwatch ? "" : "秒"}`;
    if (is_stopwatch) {
        return_text += `.${mili - (sec * 1000)}`;
    }
    return return_text;
}
system.runInterval(() => {
    if (DA_save_on_world["MOMIJI"] != null) {
        const JP_now = Get_now_date();
        if (DA_save_on_world["MOMIJI"]["alarm"] != null) {
            const alarm = DA_save_on_world["MOMIJI"]["alarm"];
            for (let i = 0; i < alarm.length; i++) {
                const AT = (new Date(alarm[i].time))
                if (AT.getTime() < JP_now.getTime()) {
                    run_command(`tellraw @a {"rawtext":[{"text":"§6<§f椛§6>§r ${AT.getHours()}時${AT.getMinutes()}分${random_from_array(["になったよ～！", "。約束どうり、お知らせするよ♪", "だね。教えにきたよ♪", "だっ！さっき声かけてねって言った時間だよ♪"])}"}]}`)
                    const All_players = world.getAllPlayers();
                    for (let g = 0; g < All_players.length; g++) {
                        if (All_players[g].id == alarm[i].id) {
                            run_command_player(All_players[g], `playsound DA.alarm @a ~~~ 10 1`);
                        }
                    }
                    alarm.splice(i, 1);
                    save_DASOW_on_world();
                    i--;
                }
            }
        }
        if (DA_save_on_world["MOMIJI"]["timer"] != null) {
            const timer = DA_save_on_world["MOMIJI"]["timer"];
            for (let i = 0; i < timer.length; i++) {
                if ((new Date(timer[i].time)).getTime() < JP_now.getTime()) {
                    run_command(`tellraw @a {"rawtext":[{"text":"§6<§f椛§6>§r ${timer[i].timer_string}${random_from_array(["だよ～！♪", "だね。約束どうり、お知らせするよ♪", "だね。教えにきたよ♪", "だっ！さっき声かけてねって言った時間だよ♪"])}"}]}`)
                    const All_players = world.getAllPlayers();
                    for (let g = 0; g < All_players.length; g++) {
                        if (All_players[g].id == timer[i].id) {
                            run_command_player(All_players[g], `playsound DA.alarm @a ~~~ 10 1`);
                        }
                    }
                    timer.splice(i, 1);
                    save_DASOW_on_world();
                    i--;
                } else {
                    try {
                        if (timer[i].player.isValid()) {
                            run_command_player(timer[i].player, `title @s actionbar 残り ${format_milisec_to_str(timer[i].time.getTime() - JP_now.getTime())}`);
                        }
                    } catch (e) {

                    }
                }
            }
        }
    }
    if (Object.keys(DA_structures).length != DA_structures_num) {
        DA_structures_num = Object.keys(DA_structures).length;
        const str = JSON.stringify(DA_structures);
        let ln = 0;
        for (let i = 0; i < str.length; i += 8192) {
            world.setDynamicProperty(`DA_structures_${ln}`, str.slice(i, i + 8192));
            ln++;
        }
    }
}, 20)

system.runInterval(() => {
    const players = world.getAllPlayers();
    for (let i = 0; i < players.length; i++) {
        player_setting_data(players[i]);
        if (DA_save_on_world[players[i].id] != null && DA_data[players[i].id] != null) {
            if (get_authority_num(players[i]) < 3 && DA_save_on_world[players[i].id]["inventory_cleaner"] && DA_data[players[i].id]["inventory"] == null) {
                const inventory = players[i].getComponent("minecraft:inventory").container;
                DA_data[players[i].id]["inventory"] = [];
                for (let g = 0; g < inventory.size; g++) {
                    if (inventory.getItem(g) != null) {
                        DA_data[players[i].id]["inventory"].push({ index: g, id: inventory.getItem(g).type.id, time: (new Date).getTime(), score: 0 });
                    } else {
                        DA_data[players[i].id]["inventory"].push({ index: g, id: undefined, time: (new Date).getTime(), score: 0 });
                    }
                }
            } else if (get_authority_num(players[i]) < 3 && DA_save_on_world[players[i].id]["inventory_cleaner"] && DA_data[players[i].id]["inventory"] != null) {
                const inventory = players[i].getComponent("minecraft:inventory").container;
                const ivd = DA_data[players[i].id]["inventory"];
                const NDG = (new Date).getTime()
                for (let g = 0; g < ivd.length; g++) {
                    const now_item_id = ((inventory.getItem(ivd[g].index) != null) ? inventory.getItem(ivd[g].index).type.id : undefined);
                    if ((ivd[g].id !== now_item_id) || ((DA_is_Leave[players[i].id] != null) ? ((new Date).getTime() - DA_is_Leave[players[i].id] > (Math.min((DA_save_on_world[players[i].id]["ICR_time"] ?? 5), 3) * 1000 * 60)) : false)) {
                        ivd[g]["id"] = String((inventory.getItem(ivd[g].index) != null) ? inventory.getItem(ivd[g].index).type.id : undefined);
                        ivd[g]["score"] = 0;
                        ivd[g]["time"] = (new Date).getTime();
                    }
                    let cant_delete = false;
                    if (DA_data[players[i].id]["Iconnect"] != null) {
                        if (DA_data[players[i].id]["Iconnect"]["flag"] != null) {
                            cant_delete = DA_data[players[i].id]["Iconnect"]["flag"];
                        }
                    }
                    if (NDG - ivd[g].time > ((DA_save_on_world[players[i].id]["ICR_time"] ?? 5) * 60 * 1000) && !cant_delete) {
                        const inventory = players[i].getComponent("minecraft:inventory").container;
                        if (!(!DA_save_on_world[players[i].id]["inventory_include_hotbar"] && ivd[g].index < 9)) {
                            inventory.setItem(ivd[g].index, undefined);
                            ivd[g]["id"] = String((inventory.getItem(ivd[g].index) != null) ? inventory.getItem(ivd[g].index).type.id : null);
                            ivd[g]["score"] = 0;
                            ivd[g]["time"] = (new Date).getTime();
                        }
                    } else if (cant_delete) {
                        ivd[g]["id"] = String((inventory.getItem(ivd[g].index) != null) ? inventory.getItem(ivd[g].index).type.id : null);
                        ivd[g]["score"] = 0;
                        ivd[g]["time"] = (new Date).getTime();
                    }
                }
            }
        }
    }
    let all_size = 0;
    for (const key in DA_structures) {
        if (Object.prototype.hasOwnProperty.call(DA_structures, key)) {
            all_size += DA_structures[key].size;
        }
    }
    let memory_num = ((DA_save_on_world["memory"] ?? {})["max"]) ?? 1024;
    const KD = ((all_size / 32) + (JSON.stringify(DA_data).length * 32) + (JSON.stringify(DA_ABU).length / 16)) / 1024;
    const percent = Math.floor(KD / (memory_num) * 10000) / 100;
    if (DA_data["memory_stage"] == null) {
        DA_data["memory_stage"] = {
            on_100: false,
            on_200: false,
            on_300: false,
            on_400: false,
            on_500: false,
        }
    }
    if (percent < 100) { DA_data["memory_stage"].on_100 = false; DA_data["memory_stage"].on_200 = false; DA_data["memory_stage"].on_300 = false; DA_data["memory_stage"].on_400 = false; DA_data["memory_stage"].on_500 = false; }
    else if (percent < 200) { DA_data["memory_stage"].on_200 = false; DA_data["memory_stage"].on_300 = false; DA_data["memory_stage"].on_400 = false; DA_data["memory_stage"].on_500 = false; }
    else if (percent < 300) { DA_data["memory_stage"].on_300 = false; DA_data["memory_stage"].on_400 = false; DA_data["memory_stage"].on_500 = false; }
    else if (percent < 400) { DA_data["memory_stage"].on_400 = false; DA_data["memory_stage"].on_500 = false; }
    else if (percent < 500) { DA_data["memory_stage"].on_500 = false; }
    const SM = (DA_save_on_world["memory"] ?? {});
    if (percent > 100 && !DA_data["memory_stage"].on_100) {
        DA_data["memory_stage"].on_100 = true;
        world.sendMessage(`§8メモリ解放活動 開始(100%)`);
        memory_delete((((SM)["on_100"]) ?? 0));
    }
    if (percent > 200 && !DA_data["memory_stage"].on_200) {
        DA_data["memory_stage"].on_200 = true;
        world.sendMessage(`§8メモリ解放活動 開始(200%)`);
        memory_delete((((SM)["on_200"]) ?? 0));
    }
    if (percent > 300 && !DA_data["memory_stage"].on_300) {
        DA_data["memory_stage"].on_300 = true;
        world.sendMessage(`§8メモリ解放活動 開始(300%)`);
        memory_delete((((SM)["on_300"]) ?? 1));
    }
    if (percent > 400 && !DA_data["memory_stage"].on_400) {
        DA_data["memory_stage"].on_400 = true;
        world.sendMessage(`§8メモリ解放活動 開始(400%)`);
        memory_delete((((SM)["on_400"]) ?? 2));
    }
    if (percent > 500 && !DA_data["memory_stage"].on_500) {
        DA_data["memory_stage"].on_500 = true;
        world.sendMessage(`§8メモリ解放活動 開始(500%)`);
        memory_delete((((SM)["on_500"]) ?? 3));
    }
}, 200)

const effects_types = {
    wither: ["衰弱", "ウェザー", "wither"],
    speed: ["スピード", "移動速度上昇", "足を早", "足を速"],
    slowness: ["鈍足", "スピード低下", "移動速度低下", "移動速度降下", "足を遅"],
    haste: ["採掘速度上", "採掘早", "採掘速く", "ブロック壊すの速", "採掘スピード速"],
    mining_fatigue: ["採掘速度下", "採掘遅", "採掘速度低下", "ブロック壊すの遅", "採掘スピード遅"],
    strength: ["力強", "力を強", "strength"],
    instant_health: ["即時回復"],
    instant_damage: ["HP減", "hp減", "ダメージ"],
    jump_boost: ["脚力を上", "脚力上", "ジャンプ"],
    nausea: ["酔"],
    regeneration: ["再生", "回復"],
    resistance: ["耐性"],
    fire_resistance: ["火炎体制", "火炎耐性", "炎"],
    water_breathing: ["水中呼吸", "呼吸", "水中"],
    invisibility: ["透明", "見えなく"],
    blindness: ["盲目", "見えなく"],
    night_vision: ["暗視", "明"],
    hunger: ["空腹", "腹をすか"],
    weakness: ["弱体化", "弱らせ"],
    fatal_poison: ["死の毒"],
    poison: ["毒"],
    health_boost: ["HP増", "hp増", "HPを増", "hpを増", "ハート増", "ハートを増"],
    absorption: ["衝撃吸収", "黄色のハート", "黄"],
    saturation: ["満腹度回復", "腹いっぱい", "満腹"],
    levitation: ["浮遊", "浮か"],
    conduit_power: ["海の幸", "コンジットパワー"],
    slow_falling: ["落下速度低下", "落下"],
    bad_omen: ["不吉な"],
    village_hero: ["村の", "英雄"],
    darkness: ["ダークネス", "darkness", "暗く"],
    trial_omen: ["チャレンジ", "凶", "凶兆"],
    wind_charged: ["畜風", "ウィンドチャージ", "風"],
    weaving: ["巣", "蜘蛛", "張り"],
    oozing: ["スライム", "出"],
    infested: ["虫食", "シルバーフィッシュ"],
    raid_omen: ["強襲", "予感", "襲撃"],
}

function extractStrength(text) {
    let regex = /(\d+)\s*の\s*強さ/;
    let match = text.match(regex);
    if (match && match[1]) {
        return Number(match[1]);
    }
    regex = /(?:強さ|強度|強弱)(?:を)?\s*(\d+)/;
    match = text.match(regex);
    if (match && match[1]) {
        return Number(match[1]);
    }
    regex = /^(\d+)(?=\s*(?:で|、))/;
    match = text.match(regex);
    if (match && match[1]) {
        return Number(match[1]);
    }
    return null;
}


function setting_my_data(player) {
    if (DA_save_on_world["MOMIJI"]["First_Person"][player.id] == null) {
        DA_save_on_world["MOMIJI"]["First_Person"][player.id] = {};
    }
    if (DA_save_on_world["MOMIJI"]["Nickname"][player.id] == null) {
        DA_save_on_world["MOMIJI"]["Nickname"][player.id] = {};
    }
}
let letter_then = "";
function random_from_array(arr, contenu_then = false) {
    if (contenu_then) {
        return arr[letter_then];
    } else {
        letter_then = Math.floor(Math.random() * arr.length);
        return arr[letter_then];
    }
}
let cool_down_MOMIJI = 0;
function MOMIJI(player, msg) {
    if (DA_save_on_world["MOMIJI"] == null) {
        DA_save_on_world["MOMIJI"] = {
            First_Person: {},
            Nickname: {},
            LastUpdated: {}
        }
    } else if (Object.keys(DA_save_on_world["MOMIJI"]["LastUpdated"]).length > 50) {
        const object = DA_save_on_world["MOMIJI"]["LastUpdated"];
        const sortedKeys = Object.keys(object).sort((a, b) => object[a] - object[b]);
        for (let i = 0; i < Math.min(10, sortedKeys.length); i++) {
            delete DA_save_on_world["MOMIJI"]["First_Person"][sortedKeys[i]];
            delete DA_save_on_world["MOMIJI"]["Nickname"][sortedKeys[i]];
            delete DA_save_on_world["MOMIJI"]["LastUpdated"][sortedKeys[i]];
        }

    }
    let FP = DA_save_on_world["MOMIJI"]["First_Person"][player.id];
    let NN = DA_save_on_world["MOMIJI"]["Nickname"][player.id];
    let LU = DA_save_on_world["MOMIJI"]["LastUpdated"][player.id];
    if (FP == null || NN == null || LU == null) {
        DA_save_on_world["MOMIJI"]["First_Person"][player.id] = {};
        DA_save_on_world["MOMIJI"]["Nickname"][player.id] = {};
        DA_save_on_world["MOMIJI"]["LastUpdated"][player.id] = {};
        FP = DA_save_on_world["MOMIJI"]["First_Person"][player.id];
        NN = DA_save_on_world["MOMIJI"]["Nickname"][player.id];
        LU = DA_save_on_world["MOMIJI"]["LastUpdated"][player.id];
    }
    let inedex_FP = ["僕", "私", "自分", "俺", "ぼく", "おれ", "あたくし", "あたし", "あたい", "わい", "おいら"];
    let Male = ["僕", "俺", "ぼく", "おれ", "おいら", "わい"];
    let neutral = ["自分"];
    if (inedex_FP.some(word => msg.includes(word))) {
        setting_my_data(player);
        for (let i = 0; i < inedex_FP.length; i++) {
            if (msg.indexOf(`${inedex_FP[i]}`) != -1) {
                FP[inedex_FP[i]] = (FP[inedex_FP[i]] ?? 0) + 1;
                LU[inedex_FP[i]] = (new Date).getTime();
                if (Male.some(word => msg.includes(word))) {
                    FP["M"] = (FP["M"] ?? 0) + 1;
                } else if (neutral.some(word => msg.includes(word))) {
                    FP["W"] = (FP["W"] ?? 0) + 1;
                } else {
                    FP["N"] = (FP["N"] ?? 0) + 1;
                }
            }
            break;
        }
    }
    if (DA_save_on_world[player.id] != null) {
        if (DA_save_on_world[player.id]["Chat_support"] ?? false) {
            const All_players = world.getAllPlayers();
            let message = "";
            let flag = {
                is_math_que: false
            }
            if (msg.indexOf("=") != -1) {
                try {
                    function tokenize(expr) {
                        let tokens = [];
                        let numberBuffer = "";
                        const flushNumberBuffer = () => {
                            if (numberBuffer !== "") {
                                tokens.push(parseFloat(numberBuffer));
                                numberBuffer = "";
                            }
                        };

                        for (let i = 0; i < expr.length; i++) {
                            let char = expr[i];
                            if (char === " ") {
                                continue;
                            }
                            if (/\d|\./.test(char)) {
                                numberBuffer += char;
                            } else {
                                if (char === '-' && (i === 0 || /[\+\-\*\/\^\%\(\)]/.test(expr[i - 1]))) {
                                    numberBuffer += char;
                                } else {
                                    flushNumberBuffer();
                                    tokens.push(char);
                                }
                            }
                        }
                        flushNumberBuffer();
                        return tokens;
                    }
                    function toRPN(tokens) {
                        const precedence = {
                            "^": 4,
                            "*": 3,
                            "/": 3,
                            "%": 3,
                            "+": 2,
                            "-": 2
                        };
                        const rightAssociative = { "^": true };
                        let outputQueue = [];
                        let operatorStack = [];

                        tokens.forEach(token => {
                            if (typeof token === "number") {
                                outputQueue.push(token);
                            } else if ("^*/%+-".includes(token)) {
                                while (operatorStack.length > 0) {
                                    let top = operatorStack[operatorStack.length - 1];
                                    if ("^*/%+-".includes(top)) {
                                        if (
                                            (rightAssociative[token] && precedence[token] < precedence[top]) ||
                                            (!rightAssociative[token] && precedence[token] <= precedence[top])
                                        ) {
                                            outputQueue.push(operatorStack.pop());
                                            continue;
                                        }
                                    }
                                    break;
                                }
                                operatorStack.push(token);
                            } else if (token === "(") {
                                operatorStack.push(token);
                            } else if (token === ")") {
                                while (operatorStack.length > 0 && operatorStack[operatorStack.length - 1] !== "(") {
                                    outputQueue.push(operatorStack.pop());
                                }
                                if (operatorStack.length === 0) {
                                    throw new Error("括弧の不一致");
                                }
                                operatorStack.pop();
                            }
                        });

                        while (operatorStack.length > 0) {
                            let op = operatorStack.pop();
                            if (op === "(" || op === ")") {
                                throw new Error("括弧の不一致");
                            }
                            outputQueue.push(op);
                        }
                        return outputQueue;
                    }
                    function evaluateRPN(rpnQueue) {
                        let stack = [];
                        rpnQueue.forEach(token => {
                            if (typeof token === "number") {
                                stack.push(token);
                            } else {
                                let b = stack.pop();
                                let a = stack.pop();
                                let result;
                                switch (token) {
                                    case "+":
                                        result = a + b;
                                        break;
                                    case "-":
                                        result = a - b;
                                        break;
                                    case "*":
                                        result = a * b;
                                        break;
                                    case "/":
                                        result = a / b;
                                        break;
                                    case "^":
                                        result = Math.pow(a, b);
                                        break;
                                    case "%":
                                        result = a % b;
                                        break;
                                    default:
                                        throw new Error("未知の演算子: " + token);
                                }
                                stack.push(result);
                            }
                        });
                        if (stack.length !== 1) {
                            throw new Error("計算エラー");
                        }
                        return stack[0];
                    }

                    try {
                        const tokens = tokenize(msg);
                        const rpnQueue = toRPN(tokens);
                        const fa = evaluateRPN(rpnQueue);
                        if (fa == NaN) {
                            throw new Error("NaN")
                        }
                        message = `${random_from_array(["う～ん、多分答えは", "", "多分", "えっと、"])} ${fa} ${random_from_array(["じゃないかな？", "！", "じゃないかなっ...？", "だと思う！", "だね！", "かな～"])}`;
                        flag.is_math_que = true;
                    } catch (e) {
                    }
                } catch (e) {

                }
            }
            function formatDateDiff(target, now = new Date()) {
                const diffMs = target.getTime() - now.getTime();
                const direction = diffMs >= 0 ? "後" : "前";
                const absDiff = Math.abs(diffMs);
                if (
                    target.getFullYear() === now.getFullYear() &&
                    target.getMonth() === now.getMonth() &&
                    target.getDate() === now.getDate() &&
                    absDiff < 24 * 3600000
                ) {
                    const hours = Math.floor(absDiff / 3600000);
                    const minutes = Math.floor((absDiff % 3600000) / 60000);
                    const seconds = Math.floor((absDiff % 60000) / 1000);
                    let parts = [];
                    if (hours > 0) parts.push(hours + "時間");
                    if (minutes > 0) parts.push(minutes + "分");
                    if (hours === 0 && minutes === 0 && seconds > 0) {
                        parts.push(seconds + "秒");
                    }
                    if (parts.length === 0) return "今";
                    return parts.join("") + direction;
                } else {
                    let parts = [];
                    if (target.getFullYear() !== now.getFullYear()) {
                        parts.push(target.getFullYear() + "年");
                    }
                    parts.push((target.getMonth() + 1) + "月");
                    parts.push(target.getDate() + "日");
                    if (target.getHours() !== 0 || target.getMinutes() !== 0 || target.getSeconds() !== 0) {
                        parts.push(target.getHours() + "時");
                        if (target.getMinutes() > 0) {
                            parts.push(target.getMinutes() + "分");
                        }
                        if (target.getSeconds() > 0) {
                            parts.push(target.getSeconds() + "秒");
                        }
                    }
                    return parts.join("");
                }
            }
            function parseTime(str) {
                const now = new Date();
                let totalOffset = 0;
                const relativeRegex = /(\d+)\s*(時間|分|秒|tick|ティック)(?:\s*([^\d\s]{1,5}))?/g;
                let match;
                while ((match = relativeRegex.exec(str)) !== null) {
                    const value = parseInt(match[1], 10);
                    const unit = match[2];
                    const extra = match[3] || "";
                    let offset = 0;
                    if (unit === "時間") {
                        offset = value * 3600000;
                    } else if (unit === "分") {
                        offset = value * 60000;
                    } else if (unit === "秒") {
                        offset = value * 1000;
                    } else if (unit === "tick" || unit === "ティック") {
                        offset = value * 50;
                    }
                    if (extra.indexOf("前") !== -1) {
                        offset = -offset;
                    }
                    totalOffset += offset;
                }
                if (totalOffset !== 0) {
                    return new Date(now.getTime() + totalOffset);
                }
                const absRegex1 = /(\d{1,2})\s*時\s*(\d{1,2})\s*分(?:\s*(\d{1,2})\s*秒)?/;
                const absMatch1 = str.match(absRegex1);
                if (absMatch1) {
                    const hours = parseInt(absMatch1[1], 10);
                    const minutes = parseInt(absMatch1[2], 10);
                    const seconds = absMatch1[3] ? parseInt(absMatch1[3], 10) : 0;
                    const dateRegex = /(\d{1,2})\s*月\s*(\d{1,2})\s*日/;
                    const dateMatch = str.match(dateRegex);
                    let date = new Date(now);
                    if (dateMatch) {
                        const month = parseInt(dateMatch[1], 10) - 1;
                        const day = parseInt(dateMatch[2], 10);
                        date.setMonth(month, day);
                    }
                    date.setHours(hours, minutes, seconds, 0);
                    return date;
                }
                const absRegex2 = /(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?/;
                const absMatch2 = str.match(absRegex2);
                if (absMatch2) {
                    const hours = parseInt(absMatch2[1], 10);
                    const minutes = parseInt(absMatch2[2], 10);
                    const seconds = absMatch2[3] ? parseInt(absMatch2[3], 10) : 0;
                    let date = new Date(now);
                    date.setHours(hours, minutes, seconds, 0);
                    return date;
                }
                return null;
            }
            let keywords = ["カウント", "ストップウォッチ", "測る", "計測"];
            if (Object.values(flag).indexOf(true) == -1 && keywords.some(word => msg.includes(word)) && DA_save_on_world["MOMIJI"] != null) {
                keywords = ["やめて", "停止", "止めて", "ストップ", "stop", "破棄"];
                if (keywords.some(word => msg.includes(word)) && DA_save_on_world["MOMIJI"]["stopwatch"] != null) {
                    const stopwatch = DA_save_on_world["MOMIJI"]["stopwatch"];
                    let show_msg = false;
                    let result_of_time = ``;
                    let is_first = true;
                    let now_fact_num = 0;
                    let stop_watch_length = Number(String(stopwatch.length));
                    for (let i = 0; i < stopwatch.length; i++) {
                        if (stopwatch[i].id == player.id) {
                            now_fact_num++;
                            result_of_time += `${(is_first) ? "" : "\n"}${(stop_watch_length > 1) ? `${now_fact_num}個目 ` : ""}${format_milisec_to_str(Get_now_date().getTime() - stopwatch[i].time.getTime(), true)}`;
                            is_first = false;
                            stopwatch.splice(i, 1);
                            i--;
                            show_msg = true;
                        }
                    };
                    if (show_msg) {
                        message = random_from_array(["了解！ストップウォッチ停止っと、", "おｋ～、時間測るのやめるね♪", "ほいっ、測定やめたよ～"]);
                        message += `\n結果はこんな感じ♪ ${result_of_time}`;
                        flag["stop_watch"] = true;
                    }
                };
            };
            keywords = ["タイマー", "数えて", "かぞえて", "カウント", "測って", "経った", "起こして", "知らせて", "アラーム", "になったら声を", "目覚まし", "ストップウォッチ", "カウントアップ", "教えて"];
            if (Object.values(flag).indexOf(true) == -1 && keywords.some(word => msg.includes(word))) {
                if (DA_save_on_world["MOMIJI"]["alarm"] == null || DA_save_on_world["MOMIJI"]["timer"] == null || DA_save_on_world["MOMIJI"]["stopwatch"] == null) {
                    DA_save_on_world["MOMIJI"]["alarm"] = [];
                    DA_save_on_world["MOMIJI"]["timer"] = [];
                    DA_save_on_world["MOMIJI"]["stopwatch"] = [];
                }
                keywords = [["分", "秒", "時間", "tick", "時", ":"], ["時間", "タイム", "タイマ", "ストップウォッチ", "開始", "始め"]];
                const time = parseTime(msg);
                if (keywords[0].some(word => msg.includes(word)) && time != null) {
                    const JP_time = JP_date(time);
                    keywords = [["起", "教え", "知ら", "アラーム", "になったら声を", "目覚まし"], ["後", "ご", "間", "経った", "たった", "カウント", "タイマー", "数", "測", "数えて"]];
                    if (keywords[0].some(word => msg.includes(word))) {
                        message = `${random_from_array(["わかった！", "了解！", "ok~", "えっと、", "それじゃあ、"])}${JP_time.getHours()}${random_from_array(["時", ":"])}${String(JP_time.getMinutes()).padStart(2, "0")}${random_from_array(["分", ""], true)}${random_from_array(["に呼びかけるね！", "になったら教えるね！", "で呼びかけに来るね～", "だね、その時に知らせるよ！", "にアラームをセット、、っと。"])}`;
                        flag["alarm"] = true;
                        DA_save_on_world["MOMIJI"]["alarm"].push({ time: JP_time, id: player.id, player: player, name: player.nameTag });
                    } else if (keywords[1].some(word => msg.includes(word))) {
                        const now_time = Get_now_date();
                        message = `${random_from_array(["わかった！タイマースタート！", "了解！数えるね！", "いいよ～測るね。スタート！", "それじゃあ、測り始めるね。"])}(${formatDateDiff(JP_time, now_time)})`;
                        DA_save_on_world["MOMIJI"]["timer"].push({ time: JP_time, then_time: now_time, id: player.id, player: player, name: player.nameTag, timer_string: formatDateDiff(JP_time, now_time) });
                        flag["timer"] = true;
                    };
                } else if (keywords[1].some(word => msg.includes(word))) {
                    DA_save_on_world["MOMIJI"]["stopwatch"].push({ time: Get_now_date(), id: player.id, player: player, name: player.nameTag });
                    message = `${random_from_array(["了解！時間を測り始めるね！", "おｋ！計測開始♪", "わかった、ストップウォッチで測り始めるね～", "えっと、、ストップウォッチスタートっと、♪", "わかった、カウントし始めるね♪"])}\n止めたいときは、「ストップウォッチを停止」って言ってね♪`;
                    flag["stopwatch"] = true;
                };
            };
            keywords = ["クリエ", "アドべ", "スペク", "サバイバル", "クリエイティブ", "スペクテーター", "スペクテイター", "アドベンチャー", "ゲームモード", "gamemode", "gc", "Gc", "GC", "Gamemode"];
            if (Object.values(flag).indexOf(true) == -1 && keywords.some(word => msg.includes(word))) {
                keywords = ["クリエ", "アドべ", "スペク", "サバイバル", "クリエイティブ", "スペクテーター", "スペクテイター", "アドベンチャー", "s", "c", "a", "spec", "spectator", "adventure", "survival", "creative"];
                const translate = {
                    c: ["c", "クリエ", "クリエイティブ", "creative"],
                    spectator: ["spec", "スペク", "スペクテイター", "スペクテーター", "spectator"],
                    s: ["s", "survival", "サバイバル"],
                    a: ["a", "アドべ", "アドベンチャー", "adventure"],
                };
                let matches_key = [];
                for (const key in translate) {
                    if (translate[key].some(word => msg.replaceAll("gc", "").replaceAll("Gc", "").replaceAll("GC", "").includes(word))) {
                        matches_key.push(key);
                    }
                }
                if (keywords.some(word => msg.includes(word))) {
                    keywords = [["を", "の"], ["にして", "plz", "plaese", "頼む", "change", "変えて"], ["ゲームモードを", "gamemodeを"]];
                    if (keywords[0].some(word => msg.includes(word)) && !keywords[2].some(word => msg.includes(word))) {
                        let target_players = [];
                        let texts = [];
                        const split_keyWord = ["　", " ", "と", "。", "、", "gamemode", "ゲームモード", "に", "を", "クリエ", "アドべ", "スペク", "サバイバル", "クリエイティブ", "スペクテーター", "スペクテイター", "アドベンチャー", "s", "c", "a", "spec", "spectator", "adventure", "survival", "creative"];
                        for (let i = 0; i < split_keyWord.length; i++) {
                            const splited = msg.split(`${split_keyWord[i]}`);
                            texts = texts.concat((splited.length > 1) ? splited : []);
                        }
                        let loop_num = 0;
                        for (let i = 0; i < texts.length; i++) {
                            for (let g = 0; g < All_players.length; g++) {
                                if (similarityPercentage(texts[i], All_players[g].nameTag) > 70) {
                                    target_players.push(All_players[g]);
                                }
                                loop_num++;
                            }
                            if (loop_num > 256) {
                                break;
                            }
                        }
                        if (target_players.length > 0) {
                            let mt = "";
                            for (let i = 0; i < target_players.length; i++) {
                                mt += `${(i != 0) ? "と、" : ""}§r${target_players[i].nameTag}§r`;
                            }
                            message = `${random_from_array(["了解！", "おｋ～", "えっと、", "", "ほいっ、"])}${mt}${random_from_array([`のゲームモードを${({ c: "クリエイティブ", s: "サバイバル", spectator: "スペクテーター", a: "アドベンチャー" })[matches_key[0]]}に変更だね！`, `を${({ c: "クリエイティブ", s: "サバイバル", spectator: "スペクテーター", a: "アドベンチャー" })[matches_key[0]]}にしといたよ～`, `をgamemode ${matches_key[0]} っと、`])}`;
                            flag["gamemode_change"] = true;
                        }
                        system.run(() => {
                            for (let i = 0; i < target_players.length; i++) {
                                run_command_player(target_players[i], `gamemode ${matches_key[0]} @s`);
                            }
                        })
                    } else if (keywords[1].some(word => msg.includes(word))) {
                        message = random_from_array([`おｋ～ gamemode ${matches_key[0]} ${player.nameTag}§rっと、`, `${({ c: "クリエイティブ", s: "サバイバル", spectator: "スペクテーター", a: "アドベンチャー" })[matches_key[0]]}ね、了解！`, `ほいっ、${({ c: "クリエイティブ", s: "サバイバル", spectator: "スペクテーター", a: "アドベンチャー" })[matches_key[0]]}っと♪`, `${({ c: "クリエイティブ", s: "サバイバル", spectator: "スペクテーター", a: "アドベンチャー" })[matches_key[0]]}だね、了解！`]);
                        if (matches_key.length > 0) {
                            system.run(() => {
                                run_command_player(player, `gamemode ${matches_key[0]} @s`);
                            })
                            flag["gamemode_change"] = true;
                        }
                    };
                }
            };
            keywords = ["今何時", "何時だ今", "今の時間は？", "今の時間は?", "今の時刻は?", "今の時刻は？", "現在時刻は?", "現在時刻は？", "現在時刻取得", "いま何時", "今なんじ", "いまなんじ"];
            if (Object.values(flag).indexOf(true) == -1 && keywords.some(word => msg.includes(word))) {
                const JP_time = Get_now_date();
                const pattern_1 = `${Get_now_date().getHours()}時${String(Get_now_date().getMinutes()).padStart(2, "0")}分`;
                const pattern_2 = `${Get_now_date().getHours()}:${String(Get_now_date().getMinutes()).padStart(2, "0")}`;
                message = random_from_array([`えっとねぇ、、今は${pattern_1}だね。`, `う～んっと、${pattern_2}かな、`, `見てみるね... ${pattern_1}だってさ♪`, `今？${pattern_2}だと思う。`, `${pattern_1}かな～`]);
                const All_time_self = {
                    0: [
                        "ふぇぇっ…もう0時だよ？　こんな夜更かしして大丈夫かな？",
                        "深夜の静けさに包まれて、なんだか物憂げだね。",
                        "今日もたくさん頑張ったね、そっと休もうか。",
                        "月明かりがひっそりと照らしているね…",
                        "静かな夜、そっと夢の世界へ行こうか。"
                    ],
                    1: [
                        "もう1時…眠気がじわっと来るね。",
                        "こんな時間、ひとりぼっちの気持ちになっちゃうね。",
                        "静かな夜に心がほっとするよ。",
                        "そろそろ目を閉じてもいいかもしれないね。",
                        "星たちが静かに見守っている感じだね。"
                    ],
                    2: [
                        "2時だよ…そろそろ夢の中へ行こうか。",
                        "夜の静寂が、心をやさしく包んでくれるね。",
                        "こんな時間に起きてると、ちょっと不思議な気分だね。",
                        "暗闇の中で、そっと自分を見つめ直すのもいいね。",
                        "眠りの扉が、少しずつ開き始めているよ。"
                    ],
                    3: [
                        "3時…もうすぐ夜明けが近づいているね。",
                        "静かな夜も、いずれ朝に変わるんだね。",
                        "眠れぬ時もあるけど、星が語りかけているみたいだね。",
                        "少しだけ、夜の静けさに耳を傾けてみようか。",
                        "もうすぐ朝だよ、もう少しだけ頑張ろう。"
                    ],
                    4: [
                        "おはよう、もう4時だよ。そろそろ目を覚ます時間かな？",
                        "朝の静けさが、新たな一日の始まりを告げてるね。",
                        "眠気がまだ残るけど、少しずつ明るくなっていくよ。",
                        "優しい朝風が、窓辺を撫でているね。",
                        "新しい日が、静かに始まろうとしてるよ。"
                    ],
                    5: [
                        "おはよう！5時、朝の光がほんのり感じられるね。",
                        "目覚めの時間、ゆっくりとストレッチしてみようか。",
                        "朝の風が心地いいね、今日も一緒に頑張ろう！",
                        "静かな朝だけど、心はすでにワクワクしてるよ。",
                        "新しい一日の始まりに、少しだけ希望を感じるね。"
                    ],
                    6: [
                        "おはよう、6時だよ！しっかり目覚めた？",
                        "朝日が昇り始めて、元気な一日が始まるよ。",
                        "爽やかな朝の光、すごく気持ちいいね。",
                        "今日も笑顔で、活力を感じながら過ごそう！",
                        "明るい朝に背中を押される感じがするね。"
                    ],
                    7: [
                        "7時、もうすっかり明るくなってきたね。",
                        "元気いっぱいな朝、すぐに動き出せそうだよ。",
                        "おはよう！新しい挑戦が待ってるね。",
                        "太陽の光が、希望を運んできてくれるよ。",
                        "明るい空の下で、一緒に頑張ろう！"
                    ],
                    8: [
                        "8時、いい朝だね！活動の始まりを感じるよ。",
                        "ちょっと忙しくなる時間だけど、笑顔でいこうね。",
                        "元気な声とともに、今日もスタートだよ。",
                        "朝のエネルギーをいっぱいに感じながら進もう。",
                        "新しい一日、どんな出来事が待っているかな？"
                    ],
                    9: [
                        "9時になったね、しっかり起きてる？",
                        "朝のリズムに合わせて、今日も歩き出そう。",
                        "活気ある時間、何か良いことが起きそうだね。",
                        "一歩ずつ前に進んで、素敵な一日を迎えよう！",
                        "明るい朝の空気が、心にしみるね。"
                    ],
                    10: [
                        "10時、午前の時間も充実してるね。",
                        "少し休憩して、またエネルギーチャージしようか。",
                        "順調に進んでる感じ、いい調子だよね。",
                        "元気な時間が続いて、何だか嬉しいね。",
                        "明るい日差しに包まれて、今日も頑張ろう！"
                    ],
                    11: [
                        "11時だよ、そろそろお昼の準備かな？",
                        "お日様も高くなって、元気がみなぎってるね。",
                        "ちょっとした休憩も、午後への活力になるよ。",
                        "今日の出来事も、じわじわと動き出してるね。",
                        "この時間、心が穏やかに感じられるね。"
                    ],
                    12: [
                        "12時、正午だね！お昼の時間だよ。",
                        "お腹がすいてきたかな？一緒にランチしようか。",
                        "明るい日差しの中で、元気が湧いてくるね。",
                        "昼休みはちょっとした息抜きの時間だよ。",
                        "午後に向けて、しっかりリフレッシュしよう！"
                    ],
                    13: [
                        "13時、午後が始まったね。",
                        "少し眠くなるかもしれないけど、気持ちは元気に！",
                        "午後の活動も、楽しみながら進めようね。",
                        "エネルギーを補給して、また頑張ろう！",
                        "この時間、少し落ち着いた雰囲気が心地いいね。"
                    ],
                    14: [
                        "14時、午後の時間がゆったりしてきたね。",
                        "少しリラックスして、心を休めるのもいいよ。",
                        "窓から差し込む光が、穏やかで暖かいね。",
                        "そろそろ一息ついて、ゆっくりした時間を過ごそう。",
                        "この穏やかな午後、ほっと一息できるね。"
                    ],
                    15: [
                        "15時、まだまだ午後は長いね。",
                        "元気はあるけど、時には休むことも大切だよ。",
                        "少しだけ目を閉じて、リフレッシュしてみよう。",
                        "午後の風が、心に静けさをもたらしてくれるね。",
                        "この時間、穏やかな気持ちで進めようね。"
                    ],
                    16: [
                        "16時、午後も終盤に差し掛かってきたね。",
                        "お疲れの頃かもしれないけど、あともうひと頑張り！",
                        "夕方の予感が、少しずつ感じられるね。",
                        "まだまだ元気でいよう、私が応援してるよ。",
                        "この時間なら、ゆっくりと心を整えられるね。"
                    ],
                    17: [
                        "17時、夕暮れが近づいてきたよ。",
                        "そろそろ日も落ち始める時間だね。",
                        "今日も一日、よく頑張ったね。",
                        "夕方の柔らかい光が、心を癒してくれるよ。",
                        "ほっと一息ついて、ゆったり過ごそうか。"
                    ],
                    18: [
                        "18時、もう夕方だね。",
                        "日が沈み始めるけど、まだまだ元気な時間だよ。",
                        "夕焼けがとても美しく、心に染みるね。",
                        "この時間は、そっとリラックスするのにぴったりだね。",
                        "夜の準備を始める、静かなひとときだね。"
                    ],
                    19: [
                        "19時、夜が近づいてきたね。",
                        "少し落ち着いた空気が漂ってるよ。",
                        "今夜も穏やかに過ごせそうな予感がするね。",
                        "夕食の準備やリラックスタイム、そろそろ始めよう。",
                        "暖かな灯りが、心を温めてくれるね。"
                    ],
                    20: [
                        "20時、もう夜だね。",
                        "心地よい夜風が、そっと頬をなでていくよ。",
                        "今日の疲れをゆっくり癒す時間だね。",
                        "リラックスして、一日の終わりを楽しもう。",
                        "静かな夜に、安心感が広がっていくね。"
                    ],
                    21: [
                        "21時、夜も深まってきたね。",
                        "今日も一日、よく頑張ったね。",
                        "ほっと一息、ゆったり過ごす時間だよ。",
                        "星空が静かに語りかけてくれるみたいだね。",
                        "そっと灯りをともして、心を休めよう。"
                    ],
                    22: [
                        "22時、そろそろ眠くなってきたね。",
                        "今日の出来事を、静かに振り返ってみようか。",
                        "夜は心を落ち着かせる大切な時間だね。",
                        "温かい布団が恋しくなる時間だよ。",
                        "明日もまた、素敵な一日になるといいね。"
                    ],
                    23: [
                        "23時、もう遅いね…",
                        "そろそろ夢の世界へと誘われる時間かな。",
                        "今日もたくさんの思い出があったね。",
                        "静かな夜に、心もゆっくり休もう。",
                        "また明日、元気に会えたら嬉しいな。"
                    ]
                };
                message += All_time_self[Get_now_date().getHours()][Math.floor(Math.random() * All_time_self[Get_now_date().getHours()].length)];
                flag["tell_time"] = true;
            };
            keywords = ["夜", "深夜", "昼", "朝", "夕方", "雨", "晴れ", "雷雨", "らいう", "時間を", "時間", "快晴"];
            if (Object.values(flag).indexOf(true) == -1 && keywords.some(word => msg.includes(word))) {
                keywords = ["にして", "にしよう", "に変更", "にへんこう", "進めて", "戻して", "設定して"];
                if (keywords.some(word => msg.includes(word))) {
                    keywords = ["夜", "深夜", "昼", "朝", "夕方", "時間"];
                    if (keywords.some(word => msg.includes(word))) {
                        let time = "";
                        let time_text = "";
                        if (msg.indexOf("深夜") != -1) {
                            time = "set midnight";
                            time_text = "深夜";
                        } else if (msg.indexOf("夜") != -1) {
                            time = "set night";
                            time_text = "夜";
                        } else if (msg.indexOf("朝") != -1) {
                            time = "set sunrise";
                            time_text = "朝";
                        } else if (msg.indexOf("昼") != -1) {
                            time = "set day";
                            time_text = "昼";
                        } else if (msg.indexOf("夕方") != -1) {
                            time = "set sunset";
                            time_text = "夕方";
                        } else if (msg.indexOf("時間") != -1) {
                            if (msg.indexOf("進めて") != -1 || msg.indexOf("すめて") != -1) {
                                time = "add 3000";
                                time_text = "時間を+3000";
                            } else {
                                time = "add -3000";
                                time_text = "時間を-3000";
                            }
                        }
                        system.run(() => {
                            run_command_player(player, `time ${time}`);
                        })
                        message = `${random_from_array(["了解、", "おｋ～", "時間の変更だね、！", "ほいっ、", "...", ""])}${time_text}${random_from_array(["にするね、", "にしておくね！", "に設定っと、", "っと♪", "ね～♪"])}`;
                        flag["tell_time"] = true;
                    } else {
                        let weather = null;
                        if (msg.indexOf("晴れ") != -1 || msg.indexOf("快晴") != -1) {
                            weather = "clear";
                            message = `${random_from_array(["おｋ～", "なるほど、", "...", "了解、！"])}天候を晴れ${random_from_array(["だね！", "にするね！", "っと、", "に変更するね"])}`;
                        } else if (msg.indexOf("雷雨") != -1 || msg.indexOf("らいう") != -1) {
                            weather = "thunder";
                            message = `${random_from_array(["おｋ～", "なるほど、", "...", "了解、！"])}天候を雷雨${random_from_array(["だね！", "にするね！", "っと、", "に変更するね"])}`;
                        } else if (msg.indexOf("雨") != -1) {
                            weather = "rain";
                            message = `${random_from_array(["おｋ～", "なるほど、", "...", "了解、！"])}天候を雨${random_from_array(["だね！", "にするね！", "っと、", "に変更するね"])}`;
                        }
                        if (weather != null) {
                            system.run(() => {
                                run_command_player(player, `weather ${weather}`);
                            })
                            flag["tell_time"] = true;
                        }
                    }
                };
            };
            keywords = ["にtp", "テレポート", "手レポ", "テレポ", "teleport", "へtp", "をtp", "行きたい", "行かせて", "連れて"];
            if (Object.values(flag).indexOf(true) == -1 && keywords.some(word => msg.includes(word))) {
                keywords = [["を"], ["のところ", "に", "へ", "の所", "の場所"]];
                const split_keyWord = ["のところに", "に", "へ", "を", "にtp", "テレポート", "手レポ", "テレポ", "teleport", "へtp", "をtp", "行きたい", "行かせて", "連れてって"];
                let target_players = { player: null, percent: 0 };
                let my_players = { player: null, percent: 0 };
                let texts = [];
                if (keywords[0].some(word => msg.includes(word))) {
                    const splited_text = msg.split("を");
                    for (let h = 0; h < splited_text.length; h++) {
                        texts = [];
                        for (let i = 0; i < split_keyWord.length; i++) {
                            const splited = splited_text[h].split(`${split_keyWord[i]}`);
                            texts = texts.concat((splited.length > 1) ? splited : []);
                        }
                        if (texts.length < 1) {
                            texts = [splited_text[h]];
                        }
                        let loop_num = 0;
                        for (let i = 0; i < texts.length; i++) {
                            for (let g = 0; g < All_players.length; g++) {
                                let nickname_percent = 0;
                                const TNN = DA_save_on_world["MOMIJI"]["Nickname"][All_players[g].id];
                                if (TNN != null) { for (let h = 0; h < Object.keys(TNN).length; h++) { nickname_percent = Math.max(nickname_percent, similarityPercentage(All_players[g].nameTag, TNN[Object.keys(TNN)[h]])) } }
                                const this_percent = Math.max(similarityPercentage(texts[i], All_players[g].nameTag), nickname_percent);
                                if (h == 0) {
                                    if (this_percent > my_players.percent) {
                                        my_players = { player: All_players[g], percent: this_percent };
                                    }
                                } else {
                                    if (this_percent > target_players.percent) {
                                        target_players = { player: All_players[g], percent: this_percent };
                                    }
                                }
                                loop_num++;
                            }
                            if (loop_num > 256) {
                                break;
                            }
                        }
                    }
                    if (msg.indexOf("ここに") != -1 || msg.indexOf("ここへ") != -1) {
                        my_players.percent = 100;
                        my_players.player = player;
                    }
                    if (target_players.percent > 10 && my_players.percent > 10) {
                        system.run(() => {
                            run_command_player(player, `tp "${my_players.player.nameTag}" "${target_players.player.nameTag}"`);
                        })
                        message = `${random_from_array(["ok~!", "えっと、", "...", "了解、！", "う～んと、", "よいしょ...っと♪"])}${target_players.player.nameTag}${random_from_array(["まで運ぶね♪", "のところにGo~!", "の所へ行こう♪", "の所にtpっと、"])}`;
                        flag["tp_me"] = true;
                    }
                } else if (keywords[1].some(word => msg.includes(word))) {
                    for (let i = 0; i < split_keyWord.length; i++) {
                        const splited = msg.split(`${split_keyWord[i]}`);
                        texts = texts.concat((splited.length > 1) ? splited : []);
                    }
                    let loop_num = 0;
                    for (let i = 0; i < texts.length; i++) {
                        for (let g = 0; g < All_players.length; g++) {
                            let nickname_percent = 0;
                            const TNN = DA_save_on_world["MOMIJI"]["Nickname"][All_players[g].id];
                            if (TNN != null) { for (let h = 0; h < Object.keys(TNN).length; h++) { nickname_percent = Math.max(nickname_percent, similarityPercentage(All_players[g].nameTag, TNN[Object.keys(TNN)[h]])) } }
                            const this_percent = Math.max(similarityPercentage(texts[i], All_players[g].nameTag), nickname_percent);
                            if (this_percent > target_players.percent) {
                                target_players = { player: All_players[g], percent: this_percent };
                            }
                            loop_num++;
                        }
                        if (loop_num > 256) {
                            break;
                        }
                    }
                    if (target_players.percent > 10) {
                        system.run(() => {
                            run_command_player(player, `tp @s "${target_players.player.nameTag}"`);
                        })
                        message = `${random_from_array(["ok~!", "えっと、", "...", "了解、！", "う～んと、", "よいしょ...っと♪"])}${target_players.player.nameTag}${random_from_array(["まで運ぶね♪", "のところにGo~!", "の所へ行こう♪", "の所にtpっと、"])}`;
                        flag["tp_me"] = true;
                    }
                }
            };
            keywords = ["付与", "エフェクト", "effect", "をつけて", "を付けて", "にして"];
            if (Object.values(flag).indexOf(true) == -1 && keywords.some(word => msg.includes(word))) {
                keywords = ["ずっと", "秒", "分", "時間", "tick", "無限", "永遠", "永久"];
                const inifinity_keywords = ["ずっと", "無限", "永遠", "永久"];
                const t_f = (msg.indexOf("false") != -1) ? false : true;
                if (keywords.some(word => msg.includes(word))) {
                    const time = (inifinity_keywords.some(word => msg.includes(word))) ? "infinite" : parseTime(msg);
                    if (time != null) {
                        const strength = extractStrength(msg) ?? 0;
                        const tick_time = (time == "infinite") ? "infinite" : Math.round((time.getTime() - (new Date).getTime()) / 1000);
                        let effect_text = null;
                        for (const key in effects_types) {
                            if (Object.prototype.hasOwnProperty.call(effects_types, key)) {
                                if (effects_types[key].some(word => msg.includes(word))) {
                                    effect_text = key;
                                    break;
                                }
                            }
                        }
                        if (effect_text != null) {
                            if (msg.indexOf("に") != -1) {
                                let target_players = { player: null, percent: 0 };
                                let texts = [];
                                const split_keyWord = ["付与", "エフェクト", "effect", "をつけて", "を付けて", "にして", "ずっと", "秒", "分", "時間", "tick", "無限", "永遠", "永久", "に"];
                                for (let i = 0; i < split_keyWord.length; i++) {
                                    const splited = msg.split(`${split_keyWord[i]}`);
                                    texts = texts.concat((splited.length > 1) ? splited : []);
                                }
                                let loop_num = 0;
                                for (let i = 0; i < texts.length; i++) {
                                    for (let g = 0; g < All_players.length; g++) {
                                        const this_percent = similarityPercentage(texts[i], All_players[g].nameTag);
                                        if (this_percent > target_players.percent) {
                                            target_players = { player: All_players[g], percent: this_percent };
                                        }
                                        loop_num++;
                                    }
                                    if (loop_num > 256) {
                                        break;
                                    }
                                }
                                if (target_players.percent > 10) {
                                    system.run(() => {
                                        run_command_player(player, `effect "${target_players.player.nameTag}" ${effect_text} ${tick_time} ${strength} ${t_f}`);
                                    })
                                    message = `${random_from_array(["ok~!", "えっと、", "...", "了解、！", "う～んと、", "ほい...っと♪"])}${target_players.player.nameTag}${random_from_array(["に効果を与えるね、", "にeffect付与♪"])}`;
                                    flag["effect_target"] = true;
                                }
                            } else {
                                system.run(() => {
                                    run_command_player(player, `effect @s ${effect_text} ${tick_time} ${strength} ${t_f}`);
                                })
                                message = `${random_from_array(["ok~!", "えっと、", "...", "了解、！", "う～んと、", "ほい...っと♪"])}${random_from_array(["効果を与えるね、", "effect付与♪"])}`;
                                flag["effect_me"] = true;
                            }
                        }
                    }
                }
            };
            keywords = ["エフェクト", "effect", "解除", "無くし"];
            if (Object.values(flag).indexOf(true) == -1 && keywords.some(word => msg.includes(word))) {
                let effect_text = null;
                for (const key in effects_types) {
                    if (Object.prototype.hasOwnProperty.call(effects_types, key)) {
                        if (effects_types[key].some(word => msg.includes(word))) {
                            effect_text = key;
                            break;
                        }
                    }
                }
                if (effect_text != null) {
                    if (msg.indexOf("の") != -1) {
                        let target_players = { player: null, percent: 0 };
                        let texts = [];
                        const split_keyWord = ["の", "エフェクト", "effect", "解除", "無くし"];
                        for (let i = 0; i < split_keyWord.length; i++) {
                            const splited = msg.split(`${split_keyWord[i]}`);
                            texts = texts.concat((splited.length > 1) ? splited : []);
                        }
                        let loop_num = 0;
                        for (let i = 0; i < texts.length; i++) {
                            for (let g = 0; g < All_players.length; g++) {
                                const this_percent = similarityPercentage(texts[i], All_players[g].nameTag);
                                if (this_percent > target_players.percent) {
                                    target_players = { player: All_players[g], percent: this_percent };
                                }
                                loop_num++;
                            }
                            if (loop_num > 256) {
                                break;
                            }
                        }
                        if (target_players.percent > 10) {
                            system.run(() => {
                                run_command_player(player, `effect "${target_players.player.nameTag}" ${effect_text} 0 0`);
                            })
                            message = `${random_from_array(["ok~!", "えっと、", "...", "了解、！", "う～んと、", "ほい...っと♪"])}${target_players.player.nameTag}${random_from_array(["効果を解除するね～", "無くしといたよ～♪"])}`;
                            flag["effect_target"] = true;
                        }
                    } else {
                        system.run(() => {
                            run_command_player(player, `effect @s ${effect_text} 0 0`);
                        })
                        message = `${random_from_array(["ok~!", "えっと、", "...", "了解、！", "う～んと、", "ほい...っと♪"])}${random_from_array(["効果を解除するね～", "無くしといたよ～♪"])}`;
                        flag["effect_me"] = true;
                    }
                }
            }
            if (Object.values(flag).indexOf(true) == -1 && msg.indexOf("椛") != -1) {
                keywords = [["呼び名", "あだ名", "呼", "名前", "ニックネーム"], ["無かった", "なかった", "忘れて", "じゃない", "ではない"], ["という", "の"]];
                if (Object.values(flag).indexOf(true) == -1 && keywords[0].some(word => msg.includes(word)) && keywords[1].some(word => msg.includes(word)) && keywords[2].some(word => msg.includes(word))) {
                    let target_players = { player: null, percent: 0 };
                    let texts = [];
                    const split_keyWord = ["呼び名", "あだ名", "呼", "名前", "ニックネーム", "無かった", "なかった", "忘れて", "じゃない", "ではない", "という", "の"];
                    for (let i = 0; i < split_keyWord.length; i++) {
                        const splited = msg.split(`${split_keyWord[i]}`);
                        texts = texts.concat((splited.length > 1) ? splited : []);
                    }
                    let loop_num = 0;
                    for (let i = 0; i < texts.length; i++) {
                        for (let g = 0; g < All_players.length; g++) {
                            const this_percent = similarityPercentage(texts[i], All_players[g].nameTag);
                            if (this_percent > target_players.percent) {
                                target_players = { player: All_players[g], percent: this_percent };
                            }
                            loop_num++;
                        }
                        if (loop_num > 256) {
                            break;
                        }
                    }
                    if (target_players.percent > 66 && (String(msg).match(/「(.*?)」/) == null) ? false : String(msg).match(/「(.*?)」/).length > 1) {
                        if (DA_save_on_world["MOMIJI"]["Nickname"][target_players.player.id] == null) {
                            DA_save_on_world["MOMIJI"]["Nickname"][target_players.player.id] = {};
                        }
                        delete DA_save_on_world["MOMIJI"]["Nickname"][target_players.player.id][String(msg).match(/「(.*?)」/)[1]];
                        message = `${random_from_array(["了解！", "おｋ～"])}${target_players.player.nameTag}§rの呼び名${String(msg).match(/「(.*?)」/)[1]}ってことは${random_from_array(["無かったことに！", "忘れるね、", "違うんだね♪"])}`;
                        flag["nick_name"] = true;
                        save_DASOW_on_world();
                    }
                }
                keywords = [["呼び名", "あだ名", "呼", "名前", "ニックネーム"], ["一覧", "一通り", "全て"]];
                if (Object.values(flag).indexOf(true) == -1 && keywords[0].some(word => msg.includes(word)) && keywords[1].some(word => msg.includes(word))) {
                    let target_players = { player: null, percent: 0 };
                    let texts = [];
                    const split_keyWord = ["呼び名", "あだ名", "呼", "名前", "ニックネーム", "無かった", "なかった", "忘れて", "じゃない", "ではない", "という", "の"];
                    for (let i = 0; i < split_keyWord.length; i++) {
                        const splited = msg.split(`${split_keyWord[i]}`);
                        texts = texts.concat((splited.length > 1) ? splited : []);
                    }
                    let loop_num = 0;
                    for (let i = 0; i < texts.length; i++) {
                        for (let g = 0; g < All_players.length; g++) {
                            const this_percent = similarityPercentage(texts[i], All_players[g].nameTag);
                            if (this_percent > target_players.percent) {
                                target_players = { player: All_players[g], percent: this_percent };
                            }
                            loop_num++;
                        }
                        if (loop_num > 256) {
                            break;
                        }
                    }
                    if (target_players.percent > 66) {
                        if (DA_save_on_world["MOMIJI"]["Nickname"][target_players.player.id] == null) {
                            DA_save_on_world["MOMIJI"]["Nickname"][target_players.player.id] = {};
                        }
                        let txt = "";
                        const nicknames = DA_save_on_world["MOMIJI"]["Nickname"][target_players.player.id];
                        for (const key in nicknames) {
                            if (Object.prototype.hasOwnProperty.call(nicknames, key)) {
                                txt += `\n・${key}`;
                            }
                        }
                        message = ((txt == "") ? `${target_players.player.nameTag}§rにまだ呼び名はないみたい、、` : (`${target_players.player.nameTag}§rの呼び名一覧は以下のとうりだよ${txt}`));
                        flag["nick_name"] = true;
                        save_DASOW_on_world();
                    }
                }
                keywords = [["呼び名", "あだ名", "として覚えて", "呼ぶ", "名前は", "ニックネームは"], ["の", "だよ", "は", "を"]];
                if (Object.values(flag).indexOf(true) == -1 && keywords[0].some(word => msg.includes(word)) && keywords[1].some(word => msg.includes(word))) {
                    let target_players = { player: null, percent: 0 };
                    let texts = [];
                    const split_keyWord = ["は", "のこと", "呼", "覚えて", "名", "椛", "、", "を", "は"];
                    for (let i = 0; i < split_keyWord.length; i++) {
                        const splited = msg.split(`${split_keyWord[i]}`);
                        texts = texts.concat((splited.length > 1) ? splited : []);
                    }
                    let loop_num = 0;
                    for (let i = 0; i < texts.length; i++) {
                        for (let g = 0; g < All_players.length; g++) {
                            const this_percent = similarityPercentage(texts[i], All_players[g].nameTag);
                            if (this_percent > target_players.percent) {
                                target_players = { player: All_players[g], percent: this_percent };
                            }
                            loop_num++;
                        }
                        if (loop_num > 256) {
                            break;
                        }
                    }
                    if (target_players.percent > 66 && (String(msg).match(/「(.*?)」/) == null) ? false : String(msg).match(/「(.*?)」/).length > 1) {
                        if (DA_save_on_world["MOMIJI"]["Nickname"][target_players.player.id] == null) {
                            DA_save_on_world["MOMIJI"]["Nickname"][target_players.player.id] = {};
                        }
                        DA_save_on_world["MOMIJI"]["Nickname"][target_players.player.id][String(msg).match(/「(.*?)」/)[1]] = target_players.player.nameTag;
                        message = `${random_from_array(["なるほど、、", "おｋ～", "", "了解！", "ほうほう、"])}${target_players.player.nameTag}§r${random_from_array(["のことを", "を", "は"])}${String(msg).match(/「(.*?)」/)[1]}って呼ぶんだね。`;
                        flag["nick_name"] = true;
                        save_DASOW_on_world();
                    }
                }
                if (Object.values(flag).indexOf(true) == -1 && ((new Date).getTime() - cool_down_MOMIJI) > 10000) {
                    cool_down_MOMIJI = (new Date).getTime();
                    keywords = [
                        ["できること", "やれること", "help", "ヘルプ", "ができる"],
                    ];
                    if (msg.indexOf("自己紹介") != -1) {
                        const about_me = [`自己紹介、？いいよ～
私の名前は椛、白狼天狗だよ。
「もみじ」って読むよ。
ここでは、ちょっとした事を手伝う役割を任されたんだ♪
いつも山でパトロールしてるけど、大抵何も起こらなくて暇だったから、
上層部の天狗に言ったらこの新しい仕事がわり触れられたの。
この仕事はパトロールしながらでも簡単にこなせるから、
色々な事を頼んで見てね♪
よろしく！`,
                            `自己紹介ね...
私は椛、『もみじ』って呼んでね。
元々は山でパトロールしてたんだけど、毎日が退屈すぎてたの。
そんな時、上の方から新しい仕事を任されちゃって、今はみんなのちょっとしたサポート役をしてるよ。
これからも、どんな小さなことでも頼ってくれると嬉しいな♪`,
                            `やあ、はじめまして。
私の名前は椛、『もみじ』って読むんだ。
山をパトロールしているけど、なかなか事件が起こらなくて暇な毎日だったの。
そんな中、上層部の天狗に頼まれて、新しいお仕事に挑戦中。
みんなの力になれるよう、これからも頑張るよ。
よろしくね！`,
                            `どうも、自己紹介するね。
名前は椛、読みは『もみじ』だよ。
山でのパトロールはいつも静かすぎて、時間を持て余してたんだ。
そこで、上の方から『何かしてみなよ』って新しい仕事をもらって、今はお手伝い役として動いてるの。
どんな小さなことでも力になれるように、これからも頑張るね。
よろしく♪`];
                        message = `§8注意:椛と聞くと東方キャラクターの犬走椛を想像する可能性がありますが、本家とは表現および性格など、異なる点がございます。ご了承ください。そのため【犬走椛】ではなく【椛】としております。§r\n${random_from_array(about_me)}`;
                        flag["tp_me"] = true;
                    } else if (keywords[0].some(word => msg.includes(word))) {
                        message = `私ができること一覧だよ:
・タイマー/アラーム/ストップウォッチを使う
・他人をテレポートさせる/自分をテレポートさせる
・天候/時間を変更する。現在時刻を言う。
・計算をする。
・ゲームモードを変更する。
`;
                        flag["tp_me"] = true;
                    }
                } else if (Object.values(flag).indexOf(true) == -1) {
                    message = random_from_array(["ちょっとまってね..."]);
                    flag["await"] = true;
                }
            }

            for (const key in flag) {
                if (Object.prototype.hasOwnProperty.call(flag, key)) {
                    if (flag[key] == true) {
                        const t_date = (new Date).getTime() + ((Math.floor(Math.random()) * 2000) + 1000);
                        function one_tick_loop() {
                            const s_d = t_date - (new Date).getTime();
                            if (s_d < 0 || s_d > 10000) {
                                run_command(`tellraw @a {"rawtext":[{"text":"§6<§f椛§r§6>§r ${message}"}]}`);
                            } else {
                                system.runTimeout(one_tick_loop, 1);
                            }
                        }
                        one_tick_loop();
                        break;
                    }
                }
            }
        }
    }
}

system.runInterval(() => {
    if (DA_save_on_world["About"] != null) {
        const All_players = world.getAllPlayers();
        for (let i = 0; i < All_players; i++) {
            if (DA_save_on_world["About"][All_players[i].id] != null) {
                DA_save_on_world["About"][All_players[i].id]["Last_login"] = (new Date).getTime();
            }
        }
    }
}, 1200)

function baritone(player, goalPos, try_num = 5) {
    system.run(() => {
        let b_time = (new Date).getTime();
        function posToString(pos) {
            return `${pos.x},${pos.y},${pos.z}`;
        }

        function getNeighbors(pos) {
            return [
                { x: pos.x + 1, y: pos.y, z: pos.z, is_diagonal: false },
                { x: pos.x, y: pos.y + 1, z: pos.z, is_diagonal: false },
                { x: pos.x, y: pos.y - 1, z: pos.z, is_diagonal: false },
                { x: pos.x, y: pos.y, z: pos.z + 1, is_diagonal: false },
                { x: pos.x, y: pos.y, z: pos.z - 1, is_diagonal: false },
                { x: pos.x - 1, y: pos.y, z: pos.z, is_diagonal: false },

                { x: pos.x + 1, y: pos.y + 1, z: pos.z, is_diagonal: false },
                { x: pos.x, y: pos.y + 1, z: pos.z + 1, is_diagonal: false },
                { x: pos.x, y: pos.y + 1, z: pos.z - 1, is_diagonal: false },
                { x: pos.x - 1, y: pos.y + 1, z: pos.z, is_diagonal: false },
                { x: pos.x + 1, y: pos.y - 1, z: pos.z, is_diagonal: false },
                { x: pos.x, y: pos.y - 1, z: pos.z + 1, is_diagonal: false },
                { x: pos.x, y: pos.y - 1, z: pos.z - 1, is_diagonal: false },
                { x: pos.x - 1, y: pos.y - 1, z: pos.z, is_diagonal: false },
                { x: pos.x + 1, y: pos.y - 2, z: pos.z, is_diagonal: false },
                { x: pos.x, y: pos.y - 2, z: pos.z + 1, is_diagonal: false },
                { x: pos.x, y: pos.y - 2, z: pos.z - 1, is_diagonal: false },
                { x: pos.x - 1, y: pos.y - 2, z: pos.z, is_diagonal: false },
                { x: pos.x + 1, y: pos.y, z: pos.z + 1, is_diagonal: true },
                { x: pos.x + 1, y: pos.y, z: pos.z - 1, is_diagonal: true },
                { x: pos.x - 1, y: pos.y, z: pos.z + 1, is_diagonal: true },
                { x: pos.x - 1, y: pos.y, z: pos.z - 1, is_diagonal: true },

                { x: pos.x + 1, y: pos.y + 1, z: pos.z + 1, is_diagonal: true },
                { x: pos.x + 1, y: pos.y + 1, z: pos.z - 1, is_diagonal: true },
                { x: pos.x + 1, y: pos.y - 1, z: pos.z + 1, is_diagonal: true },
                { x: pos.x + 1, y: pos.y - 1, z: pos.z - 1, is_diagonal: true },
                { x: pos.x - 1, y: pos.y + 1, z: pos.z - 1, is_diagonal: true },
                { x: pos.x - 1, y: pos.y + 1, z: pos.z + 1, is_diagonal: true },
                { x: pos.x - 1, y: pos.y - 1, z: pos.z + 1, is_diagonal: true },
                { x: pos.x - 1, y: pos.y - 1, z: pos.z - 1, is_diagonal: true },
            ];
        }
        let tickingarea_pos = { x: Infinity, z: Infinity };
        async function getBlockSafe(dimension, pos) {
            let block = dimension.getBlock(pos);
            if (block !== undefined) return block;
            const areaName = "tempLoader";
            let is_load_tickingarea = false;
            if (Math.abs(tickingarea_pos.x - pos.x) > 32 || Math.abs(tickingarea_pos.z - pos.z) > 32) {
                tickingarea_pos.x = pos.x;
                tickingarea_pos.z = pos.z;
                is_load_tickingarea = true;
                run_command(`tickingarea remove ${areaName}`);
            }
            let tick_num = 0;
            return await new Promise(resolve => {
                system.runTimeout(() => {
                    function check() {
                        if (is_load_tickingarea) { run_command(`tickingarea add ${pos.x - 36} -64 ${pos.z - 36} ${pos.x + 36} 310 ${pos.z + 36} ${areaName} true`); is_load_tickingarea = false; }
                        if (tick_num > 3) {
                            tick_num = 0;
                            tickingarea_pos.x = pos.x;
                            tickingarea_pos.z = pos.z;
                            is_load_tickingarea = true;
                            run_command(`tickingarea remove ${areaName}`);
                        }
                        let b = dimension.getBlock(pos);
                        if (b !== undefined) {
                            resolve(b);
                        } else {
                            tick_num++;
                            system.runTimeout(check, 1);
                        }
                    }
                    check();
                })
            });
        }

        function can_pass(block) {
            let result = !block.isSolid;
            let keywords = ["leaves", "ice", "lava", "glass"];
            if (keywords.some(word => block.typeId.includes(word))) { result = false };
            return result;
        }

        async function isPassable(dimension, pos, current) {
            const below = await getBlockSafe(dimension, { x: Math.floor(pos.x), y: Math.floor(pos.y) - 1, z: Math.floor(pos.z) });
            let search_pos = [[0, 0, 0]];
            if (pos.is_diagonal) {
                search_pos = [[1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1], [1, 0, 1], [-1, 0, -1], [1, 0, 1], [-1, 0, -1], [0, 0, 0]];
            }
            let is_can = true;
            for (let i = 0; i < search_pos.length; i++) {
                const cell = await getBlockSafe(dimension, { x: Math.floor(pos.x) + search_pos[i][0], y: Math.floor(pos.y) + search_pos[i][1], z: Math.floor(pos.z) + search_pos[i][2] });
                const above = await getBlockSafe(dimension, { x: Math.floor(pos.x) + search_pos[i][0], y: Math.floor(pos.y) + search_pos[i][1] + 1, z: Math.floor(pos.z) + search_pos[i][2] });
                if (!(can_pass(cell) && can_pass(above))) { is_can = false; break; };
            }
            if (is_can && can_pass(below)) {
                if ((can_pass(below)) && ((current.BIG_jump_y >= pos.y) ? (current.BIG_jump_index < 3) : false)) return 2;
            }
            if (is_can && !can_pass(below)) {
                return 1;
            } else {
                return 0;
            }
        }

        function heuristic(pos, goal) {
            return (Math.sqrt(Math.pow(pos.x - goal.x, 2) + Math.pow(pos.y - goal.y, 2) + Math.pow(pos.z - goal.z, 2)) + (Math.abs(pos.x - goal.x) + Math.abs(pos.y - goal.y) + Math.abs(pos.z - goal.z))) / 2;
        }

        function reconstructPath(node) {
            const path = [];
            while (node) {
                path.push(node);
                node = node.parent;
            }
            return path.reverse();
        }
        function aStarSearch(dimension, start, goal, player) {
            const openSet = [{ pos: start, g: 0, f: heuristic(start, goal), parent: null, BIG_jump_index: 0, BIG_jump_y: null, distance: Infinity }];
            const closedSet = new Set();
            let most_near = { distance: Infinity };
            async function step() {
                const now_time = (new Date).getTime();
                for (let j = 0; j < 50; j++) {
                    if (openSet.length === 0 || (now_time - b_time) > ((6 - try_num) * 10 * 1000)) {
                        j = 100;
                        run_command_player(player, `tellraw @s {"rawtext":[{"text":"<§bDA§r> Step ${try_num}/5"}]}`);
                        if ((now_time - b_time) > (1 * 10 * 1000)) {
                            const path = reconstructPath(most_near);
                            showPathParticles(dimension, path, player, try_num - 1);
                        }
                        return;
                    }
                    openSet.sort((a, b) => a.f - b.f);
                    const current = openSet.shift();
                    closedSet.add(posToString(current.pos));
                    run_command(`particle minecraft:basic_crit_particle ${current.pos.x} ${current.pos.y + 0.5} ${current.pos.z}`);
                    if (current.pos.x === goal.x && current.pos.y === goal.y && current.pos.z === goal.z) {
                        const path = reconstructPath(current);
                        showPathParticles(dimension, path, player);
                        j = 100;
                        return;
                    }
                    const neighbors = getNeighbors(current.pos);
                    for (const nb of neighbors) {
                        if (nb.y < -62 || nb.y > 340) continue;
                        const nbKey = posToString(nb);
                        if (closedSet.has(nbKey)) continue;
                        const can_pass = await isPassable(dimension, nb, current);
                        if ((can_pass == 0)) continue;
                        const tentativeG = current.g + cost(current.pos, nb, goal, try_num);
                        let neighborNode = openSet.find(n => posToString(n.pos) === nbKey);
                        if (!neighborNode) {
                            const HNG = heuristic(nb, goal);
                            neighborNode = {
                                pos: nb,
                                g: tentativeG,
                                f: tentativeG + HNG,
                                parent: current,
                                distance: HNG,
                                BIG_jump_index: (can_pass == 2) ? (current.BIG_jump_index + 1) : 0,
                                BIG_jump_y: ((current.BIG_jump_index == 0) ? current.pos.y : (current.BIG_jump_y ?? current.pos.y)),
                            };
                            if (most_near.distance > HNG) {
                                most_near = neighborNode;
                            }
                            openSet.push(neighborNode);
                        } else if (tentativeG < neighborNode.g) {
                            neighborNode.g = tentativeG;
                            neighborNode.f = tentativeG + heuristic(nb, goal);
                            neighborNode.parent = current;
                        }
                    }
                }
                system.runTimeout(step, 1);
            }
            step();
        }

        function cost(a, b, goal, try_num = 1) {
            const c = Math.sqrt(Math.pow(a.x - goal.x, 2) + Math.pow(a.y - goal.y, 2) + Math.pow(a.z - goal.z, 2));
            const d = Math.sqrt(Math.pow(b.x - goal.x, 2) + Math.pow(b.y - goal.y, 2) + Math.pow(b.z - goal.z, 2));
            return Math.pow(Math.abs(Math.floor((c - d) * 100) / 100) + 1, ((c - d < 0) ? try_num : 1)) - 1;
            // return 1;
        }

        function showPathParticles(dimension, path, player, one_more = 0) {
            let now_index = 0;
            let Route_index = 0;
            let jumped = 0;
            let uped = 0;
            let jumped_strength = 0.9;
            let last_strength = 0.75;
            let big_jump_challenge = 0;
            let all_cool_down = 0;
            const big_jump = {
                start: null,
                fin: null,
                status: null,
                min_y: Infinity,
                is_reach: false
            }
            let time_limit = (new Date).getTime();
            function player_move() {
                if (DA_data[player.id]["baritone_stop"] != null) { DA_data[player.id]["baritone_stop"] = null; return };
                const P_pos = player.location;
                const N_pos = (path[now_index] == undefined) ? undefined : path[now_index].pos;
                const R_pos = (path[now_index + 1] == undefined) ? undefined : path[now_index + 1]["pos"];
                for (let i = 0; i < Math.min(Route_index + 1, path.length - Route_index); i++) {
                    player.runCommand(`particle minecraft:blue_flame_particle ${path[Route_index + i].pos.x} ${path[Route_index + i].pos.y + 0.5} ${path[Route_index + i].pos.z}`)
                }
                if ((new Date).getTime() - all_cool_down < 1000 && !(big_jump.min_y > (player.location.y + 0.5))) { system.runTimeout(player_move, 1); return; }
                Route_index += 1;
                if (Route_index >= path.length) { Route_index = now_index }
                if (path[now_index] != null) {
                    if ((Math.abs((N_pos.x + 0.5) - P_pos.x) < last_strength && Math.abs((N_pos.y + 0.5) - P_pos.y) < 10 && Math.abs((N_pos.z + 0.5) - P_pos.z) < last_strength) || ((new Date).getTime() - time_limit > (10 * 1000))) {
                        time_limit = (new Date).getTime();
                        now_index++;
                        big_jump_challenge = 0;
                        if (big_jump.status == "wait" || ((new Date).getTime() - time_limit > (10 * 1000))) {
                            player.runCommand(`tp @s ${N_pos.x} ~ ${N_pos.z}`);
                            all_cool_down = (new Date).getTime() - 750;
                        }
                        if (R_pos != null) {
                            const dx = P_pos.x - (R_pos.x + 0.5);
                            const dz = P_pos.z - (R_pos.z + 0.5);
                            let player_ra = ((Math.atan2(dx, -dz) * 180 / Math.PI) + 360 % 360);
                            if (Math.abs(player_ra - player.getRotation().y) > 15 && Math.floor(Math.random() * 5) == 0) {
                                player.runCommand(`playsound place.amethyst_cluster @s ~~~ 100 1`)
                                player.runCommand(`tp @s ~~~ ~${(player_ra - player.getRotation().y)}~`)
                            }
                        }
                        big_jump.start = null;
                        big_jump.status = null;
                        big_jump.is_reach = false;
                        big_jump.min_y = Infinity;
                        system.runTimeout(() => {
                            const N_block = (player.dimension).getBlock(N_pos);
                            const block_parameter = N_block.permutation.getAllStates();
                            if (block_parameter["open_bit"] != null) {
                                block_parameter["open_bit"] = false;
                                const permutation = BlockPermutation.resolve(N_block.typeId, block_parameter);
                                world.getDimension(player.dimension.id).setBlockPermutation(N_block.location, permutation);
                            }
                        }, 10)
                    } else {
                        const N_block_blow = (player.dimension).getBlock({ x: N_pos.x, y: N_pos.y - 1, z: N_pos.z });
                        if (R_pos != null) {
                            if ((path[now_index + 1].BIG_jump_index >= 1) && N_block_blow.typeId == "minecraft:air") {
                                if (big_jump.start == null) {
                                    big_jump.start = JSON.parse(JSON.stringify(N_pos));
                                }
                                if (R_pos.y < big_jump.min_y) {
                                    big_jump.min_y = R_pos.y;
                                }
                                now_index++;
                                system.runTimeout(player_move, 1);
                                return;
                            }
                        }
                        if (N_pos != null) {
                            player.runCommand(`particle minecraft:basic_flame_particle ${N_pos.x} ${N_pos.y + 0.5} ${N_pos.z}`)
                        }
                        if (big_jump.start != null && ((big_jump.status != "wait" || ((new Date).getTime() - big_jump_challenge) > 2000 || big_jump.min_y > player.location.y + 0.1) || (N_block_blow.typeId != "minecraft:air" && ((new Date).getTime() - big_jump_challenge) > 2000))) {
                            if (big_jump.is_reach == false) {
                                big_jump.is_reach = true;
                                now_index++;
                                system.runTimeout(player_move, 1);
                                return;
                            }
                            big_jump_challenge = (new Date).getTime();
                            last_strength = 0.4;
                            const Jump_pos = JSON.parse(JSON.stringify(big_jump.start));
                            big_jump.status = "wait";
                            big_jump.fin = (R_pos ?? N_pos) ?? P_pos;
                            const dx = P_pos.x - (N_pos.x + 0.5);
                            const dz = P_pos.z - (N_pos.z + 0.5);
                            let player_ra = Math.atan2(dx, -dz) * 180 / Math.PI;
                            if (player_ra < 0) player_ra += 360;
                            let rotate = (player_ra) % 360;
                            let vec = {
                                x: Math.sin((rotate + 180) * (Math.PI / 180)),
                                z: Math.cos(rotate * (Math.PI / 180)),
                            }
                            const N_block = (player.dimension).getBlock(N_pos);
                            const block_parameter = N_block.permutation.getAllStates();
                            if (block_parameter["open_bit"] != null) {
                                block_parameter["open_bit"] = true;
                                const permutation = BlockPermutation.resolve(N_block.typeId, block_parameter);
                                world.getDimension(player.dimension.id).setBlockPermutation(N_block.location, permutation);
                            }
                            const strength = Math.sqrt(Math.pow(big_jump.fin.x - Jump_pos.x, 2) + Math.pow(big_jump.fin.y - Jump_pos.y, 2) + Math.pow(big_jump.fin.z - Jump_pos.z, 2)) / 1;
                            let gradually_index = 0;
                            player.applyKnockback(vec.x, vec.z, 0.68 * strength - 0.7, 0.475);
                        } else if (big_jump.status != "wait") {
                            const dx = P_pos.x - (N_pos.x + 0.5);
                            const dz = P_pos.z - (N_pos.z + 0.5);
                            let player_ra = Math.atan2(dx, -dz) * 180 / Math.PI;
                            if (player_ra < 0) player_ra += 360;
                            let rotate = (player_ra) % 360;
                            if (R_pos != null) {
                                const dx = P_pos.x - (R_pos.x + 0.5);
                                const dz = P_pos.z - (R_pos.z + 0.5);
                                let player_ra = ((Math.atan2(dx, -dz) * 180 / Math.PI) + 360 % 360);
                                if (Math.abs(player_ra - player.getRotation().y) > 15 && Math.floor(Math.random() * 5) == 0) {
                                    player.runCommand(`playsound place.amethyst_cluster @s ~~~ 100 1`)
                                    player.runCommand(`tp @s ~~~ ~${(player_ra - player.getRotation().y)}~`)
                                }
                            }
                            let angle = 0;
                            let vec = {
                                x: Math.sin((rotate + 180) * (Math.PI / 180)),
                                y: 0,
                                z: Math.cos(rotate * (Math.PI / 180)),
                            }
                            const N_block = (player.dimension).getBlock(N_pos);
                            const block_parameter = N_block.permutation.getAllStates();
                            if (block_parameter["open_bit"] != null) {
                                block_parameter["open_bit"] = true;
                                const permutation = BlockPermutation.resolve(N_block.typeId, block_parameter);
                                world.getDimension(player.dimension.id).setBlockPermutation(N_block.location, permutation);
                            }
                            if ((N_pos.y - P_pos.y) > 0.5) {
                                vec.y = jumped_strength;
                                jumped_strength += 0.1;
                                jumped = (new Date).getTime()
                                uped = (new Date).getTime()
                            } else if ((N_pos.y - P_pos.y) < -1) {
                                vec.y = -0.1;
                                jumped_strength = 0.9;
                                jumped = (new Date).getTime();
                            } else {
                                jumped_strength = 0.9;
                            }
                            const strength = Math.max(Math.min((((new Date).getTime() - jumped) / 1000), 0.75), 0.1);
                            last_strength = Math.max(Math.min((((new Date).getTime() - uped) / 1000), 0.75), 0.25);
                            player.applyKnockback(vec.x, vec.z, Number(strength) * (1 - Math.abs(-angle / 90)), (vec.y));
                        } else {

                        }
                    }
                    system.runTimeout(player_move, 1);
                } else {
                    if (one_more > 0) {
                        baritone(player, goalPos, one_more);
                    } else {
                        run_command_player(player, `tellraw @s {"rawtext":[{"text":"<§bDA§r> Finish"}]}`);
                    }
                }
            }
            player_move();
        }

        const startPos = { x: Math.floor(player.location.x), y: Math.floor(player.location.y), z: Math.floor(player.location.z) };
        aStarSearch(player.dimension, startPos, goalPos, player);
    })
}

let cool_down = (new Date).getTime();

world.beforeEvents.playerInteractWithEntity.subscribe(ev => {
    const entity = ev.target;
    const entity_pos = entity.location;
    const block_pos = { x: Math.floor(entity_pos.x), y: Math.floor(entity_pos.y), z: Math.floor(entity_pos.z) };
    const player = ev.player;
    const item = ev.itemStack;
    if (item != null && ((new Date).getTime() - cool_down) > 250) {
        system.run(() => {
            if (item.typeId == "da:da_art" && player.isSneaking && get_authority_num(player) == 0) {
                let data = "";
                data += entity.nameTag.replaceAll("|%+;|", "\"");
                entity.kill();
                ev.cancel = true;
                cool_down = (new Date).getTime();
                for (let i = 1; i <= 64; i++) {
                    const entitys = (player.dimension).getEntities({ type: "armor_stand" });
                    let isset = false;
                    for (let n = 0; n < entitys.length; n++) {
                        const ep = entitys[n].location;
                        if (Math.abs(ep.x - (entity_pos.x - i)) < 0.25 && Math.abs(ep.y - entity_pos.y) < 0.25 && Math.abs(ep.z - entity_pos.z) < 0.25) {
                            isset = true;
                            const txt = (entitys[n].nameTag.replaceAll("|%+;|", "\""));
                            data += txt;
                            entitys[n].kill();
                            break;
                        }
                    }
                    if (!isset) {
                        break;
                    }
                }
                data = JSON.parse(data);
                let now_pos = {
                    x: 0,
                    y: 0,
                    z: 0
                }
                let index = 0;
                let tickingarea_pos = { x: Infinity, z: Infinity };
                let memory = [[]];
                let this_pos = { x: 0, z: 0 }
                for (let i_n = 0; i_n < data.data.length; i_n += 0) {
                    let looped_num = 1;
                    let loop_num = 1;
                    let num = "";
                    for (let g = i_n + 1; g < data.data.length; g++) {
                        if (Number(data.data[g]) >= 0) {
                            looped_num++;
                            num += data.data[g];
                        } else {
                            if (num != "") {
                                loop_num = Number(num) + 1;
                            }
                            break;
                        }
                    }
                    if (num != "") {
                        loop_num = Number(num) + 1;
                    }
                    for (let h = 0; h < loop_num; h++) {
                        memory[memory.length - 1].push((data.data[i_n]));
                        this_pos.x++;
                        if (this_pos.x >= data.size.w) {
                            memory.push([]);
                            this_pos.x = 0;
                            this_pos.z++;
                        }
                    }
                    i_n += looped_num;
                }
                const chunk = 32;
                for (let i = 0; i < 128; i++) {
                    player.sendMessage(`§r\n§r\n§r\n§r\n§r\n§r\n`);
                }
                async function one_tick_loop() {
                    if (now_pos.z < data.size.h) {
                        for (let x = now_pos.x; ((x - now_pos.x) < chunk && x < data.size.w); x++) {
                            for (let z = now_pos.z; ((z - now_pos.z) < chunk && z < data.size.h); z++) {
                                if (Math.abs(tickingarea_pos.x - (x + block_pos.x)) > 60 || Math.abs(tickingarea_pos.z - (z + block_pos.z)) > 60) {
                                    tickingarea_pos.x = (x + block_pos.x);
                                    tickingarea_pos.z = (z + block_pos.z);
                                    player.runCommand(`tickingarea remove test1`);
                                    await await_one_tick();
                                    player.runCommand(`tickingarea add ${tickingarea_pos.x} -64 ${tickingarea_pos.z} ${tickingarea_pos.x + 62} 310 ${tickingarea_pos.z + 62} test1`);
                                    await wait_for_load(player, { x: tickingarea_pos.x, y: block_pos.y, z: tickingarea_pos.z }, { x: tickingarea_pos.x + 60, y: block_pos.y, z: tickingarea_pos.z + 60 })
                                }
                                if (memory[z] == null) {
                                    throw new Error(`wow ${z}`);
                                }
                                player.runCommand(`setblock ${x + block_pos.x} ${block_pos.y} ${z + block_pos.z} ${Object.entries(data.pallet).find(([k, v]) => v === (memory[z][x]))?.[0] || "air"}`);
                            }
                        }
                        now_pos.x += chunk;
                        if (now_pos.x >= data.size.w) {
                            now_pos.z += chunk;
                            now_pos.x = 0;
                        }
                        system.runTimeout(one_tick_loop, 1);
                    }
                }
                system.runTimeout(one_tick_loop, 1);
            }
        })
    }
})

system.runTimeout(() => {
    const all_structures = world.structureManager.getWorldStructureIds();
    let is_world_load = true;
    for (let i = 0; i < all_structures.length; i++) {
        if (all_structures[i].indexOf("DA:") != -1) {
            is_world_load = false;
            break;
        }
    }
    if (is_world_load) {
        DA_structures = {};
        world.setDynamicProperty(`DA_structures`, JSON.stringify(DA_structures));
    }
}, 10)