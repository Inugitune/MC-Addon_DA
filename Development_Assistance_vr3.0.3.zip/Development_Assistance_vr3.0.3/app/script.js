let data = {
    discord: {}
};

function change_Dbot_opt(D_name = null) {
    setTimeout(() => {
        document.getElementById("Discord_bot_id").innerHTML = (`<option value="">選択してください</option>`);
        for (const key in data.discord) {
            document.getElementById("Discord_bot_id").insertAdjacentHTML("afterbegin", `
            <option value="${key}" ${(D_name == key) ? "selected" : ""}>${key}</option>
        `)
            if (D_name == key) {
                data["last_select_discord_id"] = key;
            }
        }
        saveState();
    });
};

const aiEnabled = document.getElementById('aiEnabled');
const backupEnabled = document.getElementById('backupEnabled');
const aiCards = Array.from(document.querySelectorAll('.ai-card'));
const aiStatus = document.getElementById('aiStatus');
const endpointInput = document.getElementById('endpoint');

const discordStart = document.getElementById('discordStart');
const discordState = document.getElementById('discordState');
const botNameEl = document.getElementById('botName');

const saveBotBtn = document.getElementById('saveBot');
const testBotBtn = document.getElementById('testBot');
const botToken = document.getElementById('botToken');
const botPrefix = document.getElementById('botPrefix');
const allowedChannel = document.getElementById('allowedChannel');

const toast = document.getElementById('toast');

// Modal
const modal = document.getElementById('modal');
const openBotSettings = document.getElementById('openBotSettings');
const closeModal = document.getElementById('closeModal');
const generateLink = document.getElementById('generateLink');
const copyLink = document.getElementById('copyLink');
const generatedLink = document.getElementById('generatedLink');
const inviteScope = document.getElementById('inviteScope');

// clock
const clock = document.getElementById('clock');

aiCards.forEach(card => {
    card.addEventListener('click', () => {
        aiCards.forEach(c => c.setAttribute('aria-pressed', 'false'));
        card.setAttribute('aria-pressed', 'true');
        card.animate([{ transform: 'translateY(-6px)' }, { transform: 'translateY(0)' }], { duration: 220, easing: 'ease-out' });
        showToast(`${card.querySelector('.ai-name').textContent} を選択しました`);
        document.getElementById(`soa_${card.getAttribute("data-ai")}`).classList.add("show_soa");
        saveState();
    });
});
document.getElementById("ai_option").style.pointerEvents = ("none")
aiCards.forEach(c => c.style.opacity = aiEnabled.checked ? '1' : '0.2');
let aic_cool_time = (new Date).getTime();
let aic_last_enabled = false;
// AI 有効トグル
aiEnabled.addEventListener('change', () => {
    if ((new Date).getTime() - aic_cool_time < 1000) {
        aiEnabled.checked = aic_last_enabled;
        return;
    }
    aic_cool_time = (new Date).getTime();
    aic_last_enabled = aiEnabled.checked;
    aiStatus.textContent = aiEnabled.checked ? 'オンライン' : 'オフライン';
    aiCards.forEach(c => c.style.opacity = aiEnabled.checked ? '1' : '0.2');
    showToast(`AIを${aiEnabled.checked ? '有効' : '無効'}にしました`);
    if (!aiEnabled.checked) {
        document.getElementById("ai_option").style.pointerEvents = ("none")
        setTimeout(() => {
            sendToPython("request_stop_receive_ai");
        }, 100)
    } else {
        document.getElementById("ai_option").style.pointerEvents = ("")
    }
});


let buc_cool_time = (new Date).getTime();
let buc_last_enabled = false;
backupEnabled.addEventListener('change', () => {
    if ((new Date).getTime() - buc_cool_time < 1000) {
        backupEnabled.checked = buc_last_enabled;
        return;
    }
    buc_cool_time = (new Date).getTime();
    buc_last_enabled = backupEnabled.checked;
    showToast(`バックアップを${backupEnabled.checked ? '有効' : '無効'}にしました`);
    if (!backupEnabled.checked) {
        setTimeout(() => {
            sendToPython("request_stop_backup");
        }, 100)
    } else {
        setTimeout(() => {
            sendToPython(`request_start_backup|${document.getElementById("back_up_interval").value}`);
        }, 100)
    }
});


discordStart.addEventListener("click", () => {
    if (document.getElementById("Discord_bot_id").value != "") {
        data["last_select_discord_id"] = document.getElementById("Discord_bot_id").value;
        const token = data.discord[`${document.getElementById("Discord_bot_id").value}`].token;
        const prefix = data.discord[`${document.getElementById("Discord_bot_id").value}`].prefix;
        sendToPython(`discordStart|${token}|${prefix}`);
        document.getElementById("discordState").innerHTML = ("起動中");
        document.getElementById("discordState").style.color = ("#ffff00ff");
        document.getElementById("disconnectDiscord").classList.add("cant_use_btn");
        document.getElementById("discordStart").classList.add("cant_use_btn");
    } else {
        alert("Botを選択してください");
    }
})

function setDiscordState(connected, botName) {
    discordState.textContent = connected ? '接続済み' : '未接続';
    botNameEl.textContent = connected ? botName : '未設定';
}

document.getElementById("add_Dbot").addEventListener('click', () => {
    const name = document.getElementById("A_botName").value.trim();
    const token = document.getElementById("A_botToken").value.trim();
    const prefix = document.getElementById("A_botPrefix").value.trim() || '!';
    if (!token) {
        showToast('Bot Token を入力してください');
        return;
    }
    if (!name) {
        showToast('Bot Name を入力してください');
        return;
    }
    change_Dbot_opt(`${name}`);
    data.discord[`${name}`] = { token: token, prefix: prefix };
    botNameEl.textContent = name;
    showToast('ボット設定を保存しました');
    document.getElementById("discord_bot_add").style.display = ("none");
});
document.getElementById("change_Dbot").addEventListener('click', () => {
    const token = document.getElementById("C_botToken").value.trim();
    const prefix = document.getElementById("C_botPrefix").value.trim() || '!';
    if (!token) {
        showToast('Bot Token を入力してください');
        return;
    }
    change_Dbot_opt();
    data.discord[`${document.getElementById("Discord_bot_id").value}`] = { token: token, prefix: prefix };
    botNameEl.textContent = `${document.getElementById("Discord_bot_id").value}`;
    showToast('ボット設定を保存しました');
    document.getElementById("discord_bot_change").style.display = ("none");
});

// Toast
let toastTimer = null;
function showToast(msg, ms = 2200) {
    toast.textContent = msg;
    toast.style.display = 'block';
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.style.display = 'none', ms);
}

closeModal.addEventListener('click', () => {
    modal.setAttribute('aria-hidden', 'true');
    modal.style.pointerEvents = 'none';
});

generateLink.addEventListener('click', () => {
    const scope = inviteScope.value;
    // ダミーリンク生成
    const base = 'https://discord.com/oauth2/authorize';
    const client = 'CLIENT_ID_PLACEHOLDER';
    const perms = scope === 'bot' ? '0' : '0';
    const link = `${base}?client_id=${client}&scope=${encodeURIComponent(scope)}&permissions=${perms}`;
    generatedLink.textContent = link;
    copyLink.disabled = false;
});

copyLink.addEventListener('click', async () => {
    const text = generatedLink.textContent;
    if (!text) return;
    try {
        await navigator.clipboard.writeText(text);
        showToast('招待リンクをコピーしました');
    } catch (e) {
        showToast('コピーに失敗しました');
    }
});

function updateClock() {
    const now = new Date();
    const hh = String(now.getHours()).padStart(2, '0');
    const mm = String(now.getMinutes()).padStart(2, '0');
    clock.textContent = `${hh}:${mm}`;
}
setInterval(updateClock, 1000);
updateClock();
window.addEventListener('beforeunload', saveState);

document.getElementById("open_DBot_change").addEventListener("click", () => {
    if (document.getElementById("Discord_bot_id").value == "") {
        alert("変更したいBotを先に選択してください。")
        return;
    }
    const discord_setting = data.discord[`${document.getElementById("Discord_bot_id").value}`];
    document.getElementById("C_botToken").value = discord_setting.token;
    document.getElementById("C_botPrefix").value = discord_setting.prefix;
    document.getElementById("discord_bot_change").style.display = ("");
})

document.getElementById("open_DBot_add").addEventListener("click", () => {
    document.getElementById("discord_bot_add").style.display = ("");
})

document.getElementById("cancel_DBot_change").addEventListener("click", () => {
    document.getElementById("discord_bot_change").style.display = ("none");
})

document.getElementById("cancel_DBot_add").addEventListener("click", () => {
    document.getElementById("discord_bot_add").style.display = ("none");
})

document.getElementById("open_DBot_delete").addEventListener("click", () => {
    if (window.confirm("本当に選択中のボットを削除しますか？")) {
        delete data.discord[`${document.getElementById("Discord_bot_id").value}`];
        change_Dbot_opt();
    }
})

let request_AI_setting_now = false;
document.getElementById("AI_GPT_on").addEventListener("click", async () => {
    if (request_AI_setting_now) { return } else { request_AI_setting_now = true };
    const res = await sendToPython(`AI_setting|gpt|${document.getElementById("gpt_type").value}|${document.getElementById("ChatGPT_APIKey").value}`);
    console.log(res);
    request_AI_setting_now = false;
    data["AI_GPT_API"] = document.getElementById("ChatGPT_APIKey").value;
    saveState();
    cancel_soa();
})
document.getElementById("AI_llama_on").addEventListener("click", async () => {
    if (request_AI_setting_now) { return } else { request_AI_setting_now = true };
    const res = await sendToPython(`AI_setting|local`);
    console.log(res);
    request_AI_setting_now = false;
    document.getElementById("Xaleid").style.display = ("");
    cancel_soa();
})
document.getElementById("AI_custom_on").addEventListener("click", async () => {
    if (request_AI_setting_now) { return } else { request_AI_setting_now = true };
    const res = await sendToPython(`AI_setting|custom|${document.getElementById("ai_endpoint").value}`);
    console.log(res);
    request_AI_setting_now = false;
    cancel_soa();
})
document.getElementById("AI_other_on").addEventListener("click", async () => {
    if (request_AI_setting_now) { return } else { request_AI_setting_now = true };
    data["AI_other_IP"] = ai_ip;
    const res = await sendToPython(`AI_setting|other|${ai_ip}`);
    console.log(res);
    request_AI_setting_now = false;
    cancel_soa();
})

function cancel_soa() {
    const aiCards = Array.from(document.querySelectorAll('.ai-card'));
    aiCards.forEach(c => c.setAttribute('aria-pressed', 'false'));
    document.querySelectorAll(".setting_of_ai").forEach(elm => {
        elm.classList.remove("show_soa");
    })
}


const ring = document.getElementById('ring');
const percentEl = document.getElementById('percent');
const statusEl = document.getElementById('status');
const descEl = document.getElementById('desc');
const bar = document.getElementById('bar');
const itemsEl = document.getElementById('items');
const speedEl = document.getElementById('speed');
const etaEl = document.getElementById('eta');

const C = 2 * Math.PI * 40;
ring.style.strokeDasharray = C;

function clamp(v, a = 0, b = 100) { return Math.min(b, Math.max(a, v)); }

window.setLoaderProgress = function (percent, info = {}) {
    const p = clamp(Math.round(percent));
    const offset = C * (1 - p / 100);
    ring.style.strokeDashoffset = offset;
    percentEl.textContent = p + '%';
    if (info.status !== undefined) statusEl.textContent = info.status;
    if (info.desc !== undefined) descEl.textContent = info.desc;
    if (info.items !== undefined) itemsEl.textContent = info.items;
    if (info.speed !== undefined) speedEl.textContent = info.speed + '/s';
    if (info.eta !== undefined) etaEl.textContent = 'ETA: ' + info.eta;
    bar.style.width = p + '%';
    const root = document.getElementById('my-loader');
    if (root) root.setAttribute('aria-busy', p < 100 ? 'true' : 'false');
}

document.querySelectorAll(".attention_template").forEach(elm => {
    elm.style.display = ("none");
})

let midi_file = null
document.getElementById("midi_file").addEventListener("change", async (ev) => {
    midi_file = ev.target.files[0];
    document.getElementById("midi_file_name").innerHTML = midi_file.name;
});

document.getElementById("midi_play_btn").addEventListener("click", async () => {
    if (!midi_file) return;
    try {
        const cmd = await midiFileToDaCommand(midi_file);
        bridge.receive_only(`mcmd|${cmd}`)
        setTimeout(() => {
            const midi_selector = document.getElementById("midi_selector").value ?? "@a";
            const midi_shownote = document.getElementById("midi_shownote").value ?? "x軸";
            const midi_bar = document.getElementById("midi_bar").value ?? "ノーマル";
            const midi_max = document.getElementById("midi_max").value ?? 5;
            const midi_volume = document.getElementById("midi_volume").value ?? 100;
            const midi_type = document.getElementById("midi_type").value ?? "HZ型";
            const midi_pitch = document.getElementById("midi_pitch").value ?? 1;
            const midi_speed = document.getElementById("midi_speed").value ?? 1;
            bridge.receive_only(`mcmd|da:d_midi_setting ${midi_selector} "${midi_shownote}" "${midi_bar}" ${midi_max} ${midi_volume} "${midi_type}" ${midi_pitch} ${midi_speed}`);
        }, 50);
    } catch (err) {
        console.error(err);
        alert('変換に失敗しました: ' + err.message);
    }
})

let img_file = null
let img = new Image();
document.getElementById("img_file").addEventListener("change", async (ev) => {
    img_file = ev.target.files[0];
    document.getElementById("img_file_name").innerHTML = img_file.name;
    const reader = new FileReader();
    reader.onload = function (event) {
        img = new Image();
        img.onload = function () {
            scale = resolutionSlider.value / 100;
            document.getElementById(`show_block_num`).innerHTML = (`${Math.floor(img.width * scale)}×${Math.floor(img.height * scale)} ブロック`);
        }
        img.src = event.target.result;
    }
    reader.readAsDataURL(img_file);
});

document.getElementById("img_summon_btn").addEventListener("click", async () => {
    if (!img_file) return;
    try {
        const scale = Number(document.getElementById("img_scale").value ?? 100) / 100;
        const opt = document.getElementById("img_opt").value ?? "";
        const x = document.getElementById("img_pos_x").value ?? "~";
        const y = document.getElementById("img_pos_y").value ?? "~";
        const z = document.getElementById("img_pos_z").value ?? "~";
        let before_per = 0;
        let started = false, startT = 0, prevRem = null, A = 0.2;
        const fmt = ms => ms < 1000 ? `${ms | 0}ms` : (s = (ms / 1000) | 0, s < 60 ? `${s}s` : (m = (s / 60) | 0, m < 60 ? `${m}m ${s % 60}s` : `${(m / 60) | 0}h ${m % 60}m`));
        document.getElementById("Xaleid").style.display = ("");
        const data = await imageFileToSummonCommand(img_file, color_template, { colorJudgeType: opt, scale: scale, x: ((x == "") ? "~" : x), y: ((y == "") ? "~" : y), z: ((z == "") ? "~" : z) }, (per, max) => {
            if (!started) { started = true; startT = performance.now(); }
            const frac = (typeof 100 === 'number' && 100 > 0) ? per / 100 : (per <= 1 ? per : per / 100);
            if (!frac) return;
            const elapsed = performance.now() - startT;
            let rem = Math.max(0, elapsed * (1 / frac - 1));
            prevRem = prevRem == null ? rem : A * rem + (1 - A) * prevRem;
            if (before_per != per) {
                before_per = per;
                setLoaderProgress(per, { "status": "画像変換中", "desc": "召喚後は、防具立てを建築選択コンパスでスニークしながら右クリックしてください。", "eta": fmt(prevRem), "speed": "-", "items": max })
            }
        });
        document.getElementById("Xaleid").style.display = ("none");
        bridge.receive_only(`mcmd|${data}`);
    } catch (err) {
        console.error(err);
        alert('変換に失敗しました: ' + err.message);
    }
})

function updateResolution() {
    if (!img.src) return;
    scale = resolutionSlider.value / 100;
    document.getElementById(`show_block_num`).innerHTML = (`${Math.floor(img.width * scale)}×${Math.floor(img.height * scale)} ブロック`);
}

const resolutionSlider = document.getElementById('img_scale');
resolutionSlider.addEventListener('input', updateResolution, false);















var bridge;
let time_out_ws = null;
new QWebChannel(qt.webChannelTransport, function (channel) {
    bridge = channel.objects.bridge;
});

async function sendToPython(msg) {
    return new Promise((resolve, reject) => {
        bridge.from_js(msg, function (response) {
            resolve(response);
        });
    })
}

function formatBytes(bytes, { binary = true, decimals = 2, locale = null } = {}) {
    if (!Number.isFinite(bytes)) return String(bytes);
    const thresh = binary ? 1024 : 1000;
    if (Math.abs(bytes) < thresh) return `${bytes} B`;
    const units = ['KB', 'MB', 'GB', 'TB', 'PB', 'EB'];
    let value = bytes / thresh;
    let i = 0;
    while (Math.abs(value) >= thresh && i < units.length - 1) {
        value /= thresh;
        i++;
    }
    const fixed = Number(value.toFixed(decimals));
    if (locale) {
        return `${new Intl.NumberFormat(locale, { minimumFractionDigits: 0, maximumFractionDigits: decimals }).format(fixed)} ${units[i]}`;
    } else {
        return `${fixed} ${units[i]}`;
    }
}

function fromPython(msg) {
    if (msg["code"] == "00") {
        clearTimeout(time_out_ws);
        document.getElementById("mcStatus").innerHTML = ("使用不可");
        document.getElementById("mcStatus").style.color = "red";
        document.getElementById("mcConnect").classList.add("cant_use_btn");
        const wc = window.confirm("ポート6752を何かしらのアプリが使用しているため、起動できません。\nそのアプリを終了させますか？");
        if (wc) {
            document.getElementById("mcStatus").innerHTML = ("未接続");
            document.getElementById("mcStatus").style.color = "#e1fdff";
            document.getElementById("mcConnect").classList.remove("cant_use_btn");
            bridge.receive_only("task_kill_port_in_use")
        }
    } else if (msg["code"] == "01") {
        clearTimeout(time_out_ws);
        document.getElementById("mcStatus").innerHTML = ("エラー:もう一度お試しください。");
        document.getElementById("mcStatus").style.color = "red";
        document.getElementById("mcConnect").classList.remove("cant_use_btn");
        setTimeout(() => {
            const wc = window.confirm("エラー:もう一度試しますか？");
            if (wc) {
                document.getElementById("mcConnect").click();
            }
        }, 10)
    } else if (msg["code"] == "02") {
        clearTimeout(time_out_ws);
        document.getElementById("mcStatus").innerHTML = ("接続終了");
        document.getElementById("mcStatus").style.color = "yellow";
        document.getElementById("mcConnect").classList.remove("cant_use_btn");
        document.getElementById("mcDisconnect").classList.add("cant_use_btn");
    } else if (msg["code"] == "03") {
        clearTimeout(time_out_ws);
        document.getElementById("mcStatus").innerHTML = ("接続成功");
        document.getElementById("mcStatus").style.color = "#a4ffc1";
        document.getElementById("mcConnect").classList.add("cant_use_btn");
        document.getElementById("mcDisconnect").classList.remove("cant_use_btn");
    } else if (msg["code"] == "04") {
        document.getElementById("discordState").innerHTML = ("エラー:Bot Tokenが無効です。");
        document.getElementById("discordState").style.color = ("red");
        document.getElementById("disconnectDiscord").classList.add("cant_use_btn")
        document.getElementById("discordStart").classList.remove("cant_use_btn")
    } else if (msg["code"] == "05") {
        document.getElementById("discordState").innerHTML = ("エラー:discord_http_exception");
        document.getElementById("discordState").style.color = ("red");
        document.getElementById("disconnectDiscord").classList.add("cant_use_btn")
        document.getElementById("discordStart").classList.remove("cant_use_btn")
    } else if (msg["code"] == "06") {
        document.getElementById("discordState").innerHTML = ("エラー:起動失敗");
        document.getElementById("discordState").style.color = ("red");
        document.getElementById("disconnectDiscord").classList.add("cant_use_btn")
        document.getElementById("discordStart").classList.remove("cant_use_btn")
    } else if (msg["code"] == "07") {
        clearTimeout(time_out_ws);
        const wc = window.confirm("ポート6753を何かしらのアプリが使用しているため、AIを起動できません。\nそのアプリを終了させますか？");
        if (wc) {
            bridge.receive_only("task_kill_port_in_use_ai")
        }
    } else if (msg["code"] == "08") {
        document.getElementById("discordState").innerHTML = ("接続成功");
        document.getElementById("discordState").style.color = ("#a4ffc1");
        document.getElementById("disconnectDiscord").classList.remove("cant_use_btn")
        document.getElementById("discordStart").classList.add("cant_use_btn")
    } else if (msg["code"] == "09") {
        document.getElementById("discordState").innerHTML = ("接続終了");
        document.getElementById("discordState").style.color = ("#ffaa00ff");
        document.getElementById("disconnectDiscord").classList.add("cant_use_btn")
        document.getElementById("discordStart").classList.remove("cant_use_btn")
    }
    if (msg["type"] == "js_per_ra") {
        console.log(msg["msg"]);
        setLoaderProgress(msg["msg"].p, { "status": msg["msg"].status, "desc": (Number(msg["msg"].desc) > -Infinity) ? formatBytes(Number(msg["msg"].desc)) : msg["msg"].desc, "eta": msg["msg"].eta, "speed": formatBytes(msg["msg"].speed), "items": msg["msg"].items })
        if (msg["msg"].p == 100) {
            setTimeout(() => {
                document.getElementById("Xaleid").style.display = ("none");
            }, 1000);
        }
    } else if (msg["type"] == "error_ra") {
        window.alert(msg["msg"]);
    }
}


document.getElementById("mcc_enter").addEventListener("click", async () => {
    document.getElementById("attention_mcc").style.display = ("none");
    IP = await sendToPython("connect_minecraft");
    document.getElementById("mcHost").value = (JSON.parse(IP)["IP"]);
    clearTimeout(time_out_ws);
    time_out_ws = setTimeout(() => {
        document.getElementById("mcStatus").innerHTML = ("エラー:もう一度お試しください。");
        document.getElementById("mcStatus").style.color = "red";
        document.getElementById("mcConnect").classList.remove("cant_use_btn");
        const wc = window.confirm("エラー:もう一度試しますか？");
        if (wc) {
            document.getElementById("mcConnect").click();
        }
    }, 1000 * 10);
})

document.getElementById("mcConnect").addEventListener("click", () => {
    document.getElementById("attention_mcc").style.display = ("");
    document.getElementById("mcStatus").innerHTML = ("接続中・・・");
    document.getElementById("mcStatus").style.color = "#e1fdff";
    document.getElementById("mcConnect").classList.add("cant_use_btn");
})

document.getElementById("mcDisconnect").addEventListener("click", () => {
    sendToPython("disconnect_minecraft");
    document.getElementById("mcStatus").innerHTML = ("切断中・・・");
    document.getElementById("mcDisconnect").classList.add("cant_use_btn");
})

document.getElementById("disconnectDiscord").addEventListener("click", () => {
    sendToPython("disconnect_Discord")
})

function parseTimestampLabel(str) {
    const ts = str.slice(0, 13);
    const year = ts.slice(0, 4);
    const month = ts.slice(4, 6);
    const day = ts.slice(6, 8);
    const hour = ts.slice(9, 11);
    const minute = ts.slice(11, 13);

    return `${year}年 ${parseInt(month)}月${parseInt(day)}日 ${parseInt(hour)}時${parseInt(minute)}分`;
}

function close_bg_ui() {
    document.getElementById("bu_ui").style.display = ("none");
}
function splitWithMax(s, sep, maxsplit) {
    const parts = s.split(sep);
    if (parts.length <= maxsplit) return parts;
    return [
        ...parts.slice(0, maxsplit),
        parts.slice(maxsplit).join(sep)
    ];
}
async function load_backup(zip_name) {
    if (window.confirm("ワールドを閉じて、OKボタンを押してください。")) {
        document.getElementById("bu_ui").style.display = ("none");
        setTimeout(async () => {
            const res = await sendToPython(`load_backup|${zip_name}`)
            if (res == "Success") {
                alert(`バックアップの復元成功`)
            } else {
                alert(`バックアップの復元に失敗しました。\n${res}`)
            }
        }, 100);
    }
}

document.getElementById("read_backup").addEventListener("click", async () => {
    document.getElementById("bu_ui").innerHTML = (``)
    document.getElementById("bu_ui").style.display = ("");
    let data = JSON.parse(await sendToPython("read_backup_info"));
    data.forEach(elm => {
        document.getElementById("bu_ui").insertAdjacentHTML("afterbegin", `
            <div>
            <p>ワールド名:${splitWithMax(elm, "_", 2)[2]}</p>
            <p>日付:${parseTimestampLabel(elm)}</p>
            <button class="btn primary btn_white" onclick="load_backup('${elm}')">読み込む</button>
            </div>
            `)
    })
    document.getElementById("bu_ui").insertAdjacentHTML("afterbegin", `
        <div>
            <button class="btn ghost" onclick="close_bg_ui()">close</button>
        </div>
    `)
})

function saveState() {
    sendToPython(`save|${JSON.stringify(data)}`);
}
async function loadState() {
    const res = await sendToPython(`load_data`);
    if (res != null) {
        data = JSON.parse(res);
    }
    if (data["discord"] == null) { data["discord"] = {} };
    if (data["AI_GPT_API"] != null) { document.getElementById("ChatGPT_APIKey").value = data["AI_GPT_API"] };
    if (data["AI_other_IP"] != null) { document.getElementById("ai_ip").value = data["AI_other_IP"] };
    change_Dbot_opt(data["last_select_discord_id"] ?? null);
}
setTimeout(() => {
    loadState();
}, 10);

document.getElementById("helpBtn").addEventListener("click", () => {
    sendToPython("open_web|https://ud-autumn.site/DA/app/help");
})