from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5.QtWebEngineWidgets import QWebEngineView
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import QUrl, QObject, pyqtSlot, pyqtSignal
from PyQt5.QtWebChannel import QWebChannel
import sys, os
import platform
import time
import logging
import subprocess
import pyautogui
import asyncio
import re
from typing import Tuple, Optional,List, Literal
import locale
import threading
import json
import signal
import zipfile
import tempfile
import shutil
from pathlib import Path
from pathlib import Path
import webbrowser
import ctypes
import argparse
import shlex
try:
    import pygetwindow as gw
except Exception:
    gw = None
try:
    import pyperclip
    _HAS_PYPERCLIP = True
except Exception:
    pyperclip = None
    _HAS_PYPERCLIP = False
receive_ai = None
global_window = None
def default_minecraft_worlds_path():
    local = os.environ.get("LOCALAPPDATA")
    if not local:
        local = os.path.join(os.path.expanduser("~"), "AppData", "Local")
    return os.path.join(local,
                        "Packages",
                        "Microsoft.MinecraftUWP_8wekyb3d8bbwe",
                        "LocalState",
                        "games",
                        "com.mojang",
                        "minecraftWorlds")

_uuid_re = re.compile(r'[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}')

DA_WORLD_RE = re.compile(r'DA_world_UUID', re.IGNORECASE)
_uuid_re = re.compile(r'[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}')

def extract_uuid_after_da_world(text):
    if not text:
        return []
    m = re.search(r'DA_world_UUID\s*[:=]\s*["\']?\s*([0-9a-fA-F\-]{32,36})\s*["\']?', text, flags=re.IGNORECASE)
    if m:
        candidate = m.group(1)
        mm = _uuid_re.search(candidate)
        if mm:
            return [mm.group(0).lower()]
        return []
    pos = None
    dm = DA_WORLD_RE.search(text)
    if dm:
        pos = dm.end()
    if pos is not None:
        window = text[pos: pos + 200]
        mm = _uuid_re.search(window)
        if mm:
            return [mm.group(0).lower()]

    return []
def find_worlds_by_uuid(target_uuid, base_dir=None):
    if not target_uuid:
        raise ValueError("TARGET_UUID が空です。")
    target_uuid = target_uuid.strip().lower()
    if base_dir is None:
        base_dir = default_minecraft_worlds_path()

    results = []
    if not os.path.isdir(base_dir):
        raise FileNotFoundError(f"minecraftWorlds フォルダが見つかりません: {base_dir}")

    for world_name in os.listdir(base_dir):
        if looks_like_backup_folder(world_name):
            continue
        world_dir = os.path.join(base_dir, world_name)
        if not os.path.isdir(world_dir):
            continue
        db_dir = os.path.join(world_dir, "db")
        if not os.path.isdir(db_dir):
            continue

        matched = False
        found_uuid = None
        matched_log = None

        for fname in os.listdir(db_dir):
            if not fname.lower().endswith(".log"):
                continue
            log_path = os.path.join(db_dir, fname)
            try:
                with open(log_path, "rb") as f:
                    raw = f.read()
                text = raw.decode("utf-8", errors="ignore")
            except Exception as e:
                results.append({
                    "world_folder": world_dir,
                    "log_file": log_path,
                    "error": f"read error: {e}",
                })
                continue
            da_uuids = extract_uuid_after_da_world(text)
            if da_uuids:
                if not found_uuid:
                    found_uuid = da_uuids[0]
                for u in da_uuids:
                    if u and u.strip() and u.lower() == target_uuid:
                        matched = True
                        matched_log = log_path
                        break
                if matched:
                    break
            else:
                continue
        entry = {
            "world_folder": world_dir,
            "log_file": matched_log,
            "found_uuid": found_uuid,
            "matched": matched,
        }
        if matched:
            levelname_path = os.path.join(world_dir, "levelname.txt")
            if os.path.isfile(levelname_path):
                try:
                    with open(levelname_path, "r", encoding="utf-8", errors="ignore") as lf:
                        levelname = lf.read().strip()
                except Exception as e:
                    levelname = f"<error reading levelname.txt: {e}>"
            else:
                levelname = None
            entry["levelname"] = levelname

        results.append(entry)

    return results

def extract_da_colon_fallback(text):
    if not text:
        return []
    pat = re.compile(r'\bDA\s*[:=]\s*["\']?([0-9a-fA-F\-]{8,36})["\']?', flags=re.IGNORECASE)
    found = pat.findall(text)
    uuids = []
    for f in found:
        m = _uuid_re.search(f)
        uuids.append(m.group(0).lower() if m else f.lower())
    return list(dict.fromkeys(uuids))
def looks_like_backup_folder(name):
    ln = name.lower()
    return ("_backup_" in ln) or (ln.startswith("backup")) or (ln.endswith("_backup"))
def copytree_exclude_backups(src, dst, exclude_backup_names=True):
    os.makedirs(dst, exist_ok=True)
    for name in os.listdir(src):
        if exclude_backup_names:
            ln = name.lower()
            if ("_backup_" in ln) or ln.startswith("backup") or ln.endswith("_backup"):
                continue
        s = os.path.join(src, name)
        d = os.path.join(dst, name)
        if os.path.isdir(s):
            shutil.copytree(s, d)
        else:
            shutil.copy2(s, d)
def make_world_backup(world_folder, backup_root=None):
    if not os.path.isdir(world_folder):
        raise FileNotFoundError("world_folder が存在しません: " + world_folder)

    bn = os.path.basename(world_folder)
    if looks_like_backup_folder(bn):
        raise RuntimeError("対象フォルダがバックアップっぽい名前なのでバックアップは作成しません。")

    parent = os.path.dirname(world_folder)
    if backup_root is None:
        backup_root = parent

    timestamp = time.strftime("%Y%m%d_%H%M%S")
    backup_name = f"{bn}_backup_{timestamp}"
    backup_path = os.path.join(backup_root, backup_name)
    os.makedirs(backup_path)
    for name in os.listdir(world_folder):
        ln = name.lower()
        if ("_backup_" in ln) or ln.startswith("backup") or ln.endswith("_backup"):
            continue
        s = os.path.join(world_folder, name)
        d = os.path.join(backup_path, name)
        if os.path.isdir(s):
            shutil.copytree(s, d)
        else:
            shutil.copy2(s, d)

    return backup_path
def restore_world_from_zip(zip_path, minecraft_worlds_dir=None, make_backup=False, backup_root=None):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    candidate = Path(zip_path)
    if not candidate.is_absolute():
        candidate = Path(script_dir) / candidate
    zip_path_resolved = str(candidate)

    if not os.path.isfile(zip_path_resolved):
        raise FileNotFoundError(f"zip が見つかりません: {zip_path_resolved}")
    if not zipfile.is_zipfile(zip_path_resolved):
        raise ValueError(f"指定されたファイルは zip 形式ではありません: {zip_path_resolved}")

    if minecraft_worlds_dir is None:
        minecraft_worlds_dir = default_minecraft_worlds_path()

    results = {
        "zip_path": zip_path_resolved,
        "extracted_dir": None,
        "found_uuids": [],
        "matches": [],
        "errors": [],
    }

    with tempfile.TemporaryDirectory(prefix="mc_restore_") as tmpdir:
        try:
            with zipfile.ZipFile(zip_path_resolved, "r") as z:
                z.extractall(tmpdir)
        except Exception as e:
            raise RuntimeError(f"zip の解凍に失敗しました: {e}")
        results["extracted_dir"] = tmpdir

        log_files = []
        for root, dirs, files in os.walk(tmpdir):
            for f in files:
                if f.lower().endswith(".log"):
                    log_files.append(os.path.join(root, f))

        if not log_files:
            results["errors"].append("解凍された中に .log ファイルが見つかりませんでした。")
            return results

        found_uuids = []
        for lp in log_files:
            try:
                with open(lp, "rb") as f:
                    raw = f.read()
                text = raw.decode("utf-8", errors="ignore")
            except Exception as e:
                results["errors"].append(f"ログ読み取り失敗: {lp} : {e}")
                continue
            uuids = extract_uuid_after_da_world(text)
            if not uuids:
                continue
            for u in uuids:
                if u and u.strip():
                    found_uuids.append(u.lower())

        found_uuids = list(dict.fromkeys(found_uuids))
        results["found_uuids"] = found_uuids

        if not found_uuids:
            results["errors"].append("ログから DA_world_UUID を抽出できませんでした。")
            return results
        print(f"UUID:{found_uuids}")
        for uuid in found_uuids:
            try:
                worlds = find_worlds_by_uuid(uuid, base_dir=minecraft_worlds_dir)
            except Exception as e:
                results["errors"].append(f"世界検索でエラー (uuid={uuid}): {e}")
                continue

            matched_any = False
            for w in worlds:
                if not w.get("matched"):
                    continue
                world_folder = w["world_folder"]
                db_dir = os.path.join(world_folder, "db")
                confirmed = False
                matched_log_file = None
                text = ""
                if os.path.isdir(db_dir):
                    for fname in os.listdir(db_dir):
                        if not fname.lower().endswith(".log"):
                            continue
                        log_path = os.path.join(db_dir, fname)
                        try:
                            with open(log_path, "rb") as f:
                                raw = f.read()
                            text = raw.decode("utf-8", errors="ignore")
                        except Exception as e:
                            continue
                        uuids_here = extract_uuid_after_da_world(text)
                        for u in uuids_here:
                            print(f"match {u and u.strip() and u.lower() == uuid}:{uuid} => {u and u.strip() and u.lower()} {log_path}")
                            if u and u.strip() and u.lower() == uuid:
                                confirmed = True
                                matched_log_file = log_path
                                break
                        if confirmed:
                            break

                if not confirmed:
                    results["matches"].append({
                        "uuid": uuid,
                        "world_folder": world_folder,
                        "note": "log の厳密比較で不一致のため置換をスキップしました。",
                        "found_uuid_reported": w.get("found_uuid"),
                    })
                    continue

                matched_any = True
                entry = {
                    "uuid": uuid,
                    "world_folder": world_folder,
                    "log_file": matched_log_file,
                    "replaced": False,
                    "backup_path": None,
                    "error": None,
                }
                try:
                    if make_backup:
                        try:
                            backup_path = make_world_backup(world_folder, backup_root=backup_root)
                            entry["backup_path"] = backup_path
                        except Exception as be:
                            entry["error"] = f"backup failed: {be}"
                            results["matches"].append(entry)
                            continue
                    for child in os.listdir(world_folder):
                        child_path = os.path.join(world_folder, child)
                        if looks_like_backup_folder(child):
                            continue
                        if os.path.isdir(child_path):
                            shutil.rmtree(child_path)
                        else:
                            os.remove(child_path)
                    copytree_exclude_backups(tmpdir, world_folder, exclude_backup_names=True)
                    entry["replaced"] = True
                except Exception as e:
                    entry["error"] = str(e)
                results["matches"].append(entry)

            if not matched_any:
                results["matches"].append({
                    "uuid": uuid,
                    "world_folder": None,
                    "note": "一致する世界が見つかりませんでした。",
                })

    return results

def list_backup_zips(
    base_file: Optional[str] = None,
    backup_subpath: str = "py/backup",
    include_ext: bool = False,
    sort_by: Literal["name", "mtime"] = "mtime",
    reverse: bool = False
) -> List[str]:
    if base_file:
        base = Path(base_file).resolve().parent
    else:
        try:
            base = Path(__file__).resolve().parent
        except NameError:
            base = Path.cwd()

    backup_dir = base.joinpath(backup_subpath)

    if not backup_dir.exists() or not backup_dir.is_dir():
        return []

    zips = list(backup_dir.glob("*.zip"))

    if sort_by == "mtime":
        zips.sort(key=lambda p: p.stat().st_mtime, reverse=reverse)
    else:
        zips.sort(key=lambda p: p.name, reverse=reverse)

    if include_ext:
        return [p.name for p in zips]
    else:
        return [p.stem for p in zips]

class CoreProcess:
    def __init__(self, path="./py/core.py", suppress_stdout: bool = False):
        self.path = os.path.abspath(path)
        self.proc = None
        self.stdout_thread = None
        self.stderr_thread = None
        self._running = False
        self._lock = threading.Lock()
        self.on_message = None
        self.suppress_stdout = bool(suppress_stdout)
        self.name = os.path.basename(self.path)

    def start(self):
        cwd = os.path.dirname(self.path)
        self.proc = subprocess.Popen(
            [sys.executable, "-u", os.path.basename(self.path)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            stdin=subprocess.PIPE,
            cwd=cwd,
            bufsize=1,
            universal_newlines=True
        )
        self._running = True
        self.stdout_thread = threading.Thread(target=self._read_stdout_loop, daemon=True)
        self.stdout_thread.start()
        self.stderr_thread = threading.Thread(target=self._read_stderr_loop, daemon=True)
        self.stderr_thread.start()

    def _read_stdout_loop(self):
        assert self.proc is not None
        for raw in self.proc.stdout:
            line = raw.rstrip("\n")
            try:
                j = json.loads(line)
            except Exception:
                if not self.suppress_stdout:
                    print(f"[{self.name} stdout]", line)
                continue
            if self.on_message:
                try:
                    self.on_message(j)
                except Exception:
                    pass

    def _read_stderr_loop(self):
        assert self.proc is not None
        for raw in self.proc.stderr:
            line = raw.rstrip("\n")
            print("[core stderr]", line)

    def send(self, obj: dict) -> bool:
        if not self.proc:
            print("[CoreProcess] proc is None")
            return False
        if self.proc.poll() is not None:
            print("[CoreProcess] proc has exited, rc=", self.proc.poll())
            return False
        try:
            s = json.dumps(obj, ensure_ascii=False) + "\n"
            self.proc.stdin.write(s)
            self.proc.stdin.flush()
            return True
        except BrokenPipeError as e:
            print("[CoreProcess] BrokenPipeError while writing to core stdin:", repr(e))
            return False
        except ValueError as e:
            print("[CoreProcess] ValueError while writing to core stdin:", repr(e))
            return False
        except Exception as e:
            print("[CoreProcess] Unexpected error while writing to core stdin:", repr(e))
            return False


    def stop(self, kill_if_needed=False):
        if not self.proc:
            return
        try:
            self.send({"cmd":"shutdown"})
            try:
                self.proc.wait(timeout=2)
            except Exception:
                if kill_if_needed:
                    try:
                        self.proc.kill()
                    except Exception:
                        pass
        except Exception:
            pass

    def is_alive(self):
        return self.proc and (self.proc.poll() is None)

class Bridge(QObject):
    messageFromCore = pyqtSignal(dict)
    def __init__(self, core_proc: CoreProcess, view):
        super().__init__()
        self._core = core_proc
        self._view = view
        self._ready = False
        self._pending = []
        self.messageFromCore.connect(self._on_core_message)
        try:
            self._view.loadFinished.connect(self._on_load_finished)
        except Exception:
            pass

    def _on_load_finished(self, ok):
        self._ready = True
        while self._pending:
            msg = self._pending.pop(0)
            self._do_send_to_js(msg)

    @pyqtSlot(dict)
    def _on_core_message(self, message):
        if not self._ready:
            self._pending.append(message)
            return
        self._do_send_to_js(message)

    def _do_send_to_js(self, message):
        try:
            js = json.dumps(message, ensure_ascii=False)
        except Exception:
            js = json.dumps({"error":"non_serializable","raw":str(message)}, ensure_ascii=False)
        try:
            self._view.page().runJavaScript(f'fromPython({js})')
        except Exception as e:
            print("[Bridge] runJavaScript failed:", e)

    @pyqtSlot(str, result=str)
    def from_js(self, msg):
        global re_auto
        print("JSから:", msg)
        if msg == "connect_minecraft":
            open_minecraft_chat_and_send_via_clipboard()
            re_auto = 0
            return json.dumps({"IP":"127.0.0.1:6752"})
        if msg == "disconnect_minecraft":
            ok = False
            try:
                ok = self._core.send({"cmd":"stop_websocket"})
            except Exception as e:
                print("from_js stop_websocket send failed:", repr(e))
            return f"sent_stop_websocket:{ok}"
        if msg == "connect_Discord":
                ok = self._core.send({"cmd":"connect_discord"})
        if msg == "disconnect_Discord":
                ok = self._core.send({"cmd":"disconnect_discord"})
        if msg.startswith("AI_setting"):
                ok = self._core.send({"cmd":f"{msg}"})
                return "sended"
        if msg.startswith("discordStart"):
                ok = self._core.send({"cmd":f"{msg}"})
                return "sended"
        if msg == "request_stop_receive_ai":
            ok = self._core.send({"cmd":f"AI_setting|stop"})
            print("request_catch_stop")
            if receive_ai != None:
                print("enter_ra_stop")
                try:
                    receive_ai.stop()
                except:
                    pass
        if msg.startswith("request_stop_backup"):
            ok = self._core.send({"cmd":f"{msg}"})
            return "sended"
        if msg.startswith("request_start_backup"):
            ok = self._core.send({"cmd":f"{msg}"})
            return "sended"
        if msg == "read_backup_info":
            return json.dumps(list_backup_zips(), ensure_ascii=False)
        if msg.startswith("load_backup"):
            z = f"./py/backup/{msg.split('|',1)[1]}.zip"
            try:
                res = restore_world_from_zip(z)
                return f"Success"
            except Exception as e:
                print("エラー:", e)
                return f"Error:{e}"
        if msg.startswith("save|"):
            filename = "data.json"
            data = json.loads(msg.split("|",1)[1])
            with open(filename, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        if msg.startswith("open_web|"):
            url = msg.split("|",1)[1]
            webbrowser.open(url)
        if msg == ("load_data"):
            filename = "data.json"
            if os.path.exists(filename):
                try:
                    with open(filename, "r", encoding="utf-8") as f:
                        content = f.read().strip()
                        if content:
                            data = json.loads(content)
                        else:
                            data = {}
                except json.JSONDecodeError:
                    data = {}
            else:
                data = {"discord": {}}

            json_str = json.dumps(data, ensure_ascii=False, indent=2)
            return json_str
        try:
            j = json.loads(msg)
            cmd = j.get("cmd")
            if cmd == "kill_must_port":
                self._core.send({"cmd":"kill_must_port"})
                return "kill_must_port_sent"
            elif cmd == "send":
                text = j.get("text","")
                self._core.send({"cmd":"send","text":text})
                return "sent"
            else:
                return "unknown_js_cmd"
        except Exception:
            return "Catch"

    @pyqtSlot(str)
    @pyqtSlot(str)
    def receive_only(self, message):
        if message == "task_kill_port_in_use":
            ok = False
            try:
                if self._core and self._core.is_alive():
                    ok = self._core.send({"cmd": "kill_must_port"})
                else:
                    print("Core not running or not available")
            except Exception as e:
                print("Failed to send to core:", e)
            if ok:
                print("kill_must_port sent to core")
            else:
                print("failed to write to core stdin")
        if message == "task_kill_port_in_use_ai":
            pids = find_pids_by_port(6753)
            if not pids:
                # send_to_ui({"type":"info","msg":"no_pids_found","port":PORT})
                pass
            else:
                results = []
                for pid in pids:
                    ok, reason = kill_pid(pid)
                    results.append({"pid":pid,"ok":ok,"reason":reason})
                print(results)
                # send_to_ui({"type":"kill_result","port":PORT,"results":results})
        if message.startswith("mcmd"):
            ok = self._core.send({"cmd": message})
        print("JSから受信:", message)


    def send_to_js(self, view, message):
        if not self._ready:
            self._pending.append(message)
        else:
            self._do_send_to_js(message)

class MainWindow(QMainWindow):
    def __init__(self, core_proc: CoreProcess):
        super().__init__()
        self.setWindowTitle("Development Assistance")
        self.setWindowIcon(QIcon("da_icon.ico"))
        self.resize(1200, 600)
        view = QWebEngineView()

        file_path = os.path.abspath("index.html")
        view.load(QUrl.fromLocalFile(file_path))

        self.setCentralWidget(view)
        self.channel = QWebChannel()
        self.bridge = Bridge(core_proc, view)
        self.channel.registerObject("bridge", self.bridge)
        view.page().setWebChannel(self.channel)
        self.view = view

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("mc_typist")

def activate_minecraft_window(app_name="Minecraft"):
    system = platform.system()
    if system == "Windows" and gw:
        titles = gw.getWindowsWithTitle(app_name)
        if not titles:
            for t in gw.getAllTitles():
                if t and app_name.lower() in t.lower():
                    titles = gw.getWindowsWithTitle(t)
                    break
        if titles:
            w = titles[0]
            try:
                w.minimize()
                time.sleep(0.08)
                w.restore()
            except Exception:
                pass
            try:
                w.activate()
            except Exception:
                try:
                    w.moveTo(0,0)
                    w.activate()
                except Exception:
                    pass
            return True
        return False
    elif system == "Darwin":
        try:
            subprocess.run(["osascript", "-e", f'tell application "{app_name}" to activate'], check=True)
            return True
        except Exception:
            return False
    else:
        return False

def find_pids_by_port(port: int):
    system = platform.system()
    pids = []
    try:
        if system == "Windows":
            proc = subprocess.run(["netstat","-ano"], capture_output=True, text=True)
            out = proc.stdout
            for line in out.splitlines():
                if f":{port} " in line or f":{port}\t" in line:
                    parts = re.split(r"\s+", line.strip())
                    if len(parts) >= 5:
                        pid = parts[-1]
                        try:
                            pids.append(int(pid))
                        except Exception:
                            pass
        else:
            proc = subprocess.run(["which","lsof"], capture_output=True, text=True)
            if proc.returncode == 0:
                proc2 = subprocess.run(["lsof","-iTCP:%d" % port,"-sTCP:LISTEN","-t"], capture_output=True, text=True)
                out = proc2.stdout
                for line in out.splitlines():
                    try:
                        pids.append(int(line.strip()))
                    except Exception:
                        pass
            else:
                proc3 = subprocess.run(["ss","-ltnp"], capture_output=True, text=True)
                out = proc3.stdout
                for line in out.splitlines():
                    if f":{port} " in line or f":{port}\t" in line:
                        m = re.search(r"pid=(\d+),", line)
                        if m:
                            try:
                                pids.append(int(m.group(1)))
                            except Exception:
                                pass
    except Exception as e:
        pass
    return list(dict.fromkeys(pids))
def kill_pid(pid: int):
    system = platform.system()
    try:
        if system == "Windows":
            proc = subprocess.run(["taskkill","/PID",str(pid),"/F"], capture_output=True, text=True)
            if proc.returncode == 0:
                return True, "killed"
            else:
                return False, proc.stdout + proc.stderr
        else:
            try:
                os.kill(pid, signal.SIGTERM)
                time.sleep(0.2)
                try:
                    os.kill(pid, 0)
                    os.kill(pid, signal.SIGKILL)
                    return True, "killed_sigkill"
                except OSError:
                    return True, "killed_sigterm"
            except Exception as e:
                return False, str(e)
    except Exception as e:
        return False, str(e)
    

def set_clipboard(text: str):
    if _HAS_PYPERCLIP:
        prev = None
        try:
            prev = pyperclip.paste()
        except Exception:
            prev = None
        pyperclip.copy(text)
        return prev
    system = platform.system()
    if system == "Darwin":
        p = subprocess.Popen(["pbcopy"], stdin=subprocess.PIPE)
        p.stdin.write(text.encode("utf-8"))
        p.stdin.close()
        p.wait()
        return None
    elif system == "Windows":
        p = subprocess.Popen(["clip"], stdin=subprocess.PIPE)
        p.stdin.write(text.encode("utf-8"))
        p.stdin.close()
        p.wait()
        return None
    else:
        try:
            p = subprocess.Popen(["xclip","-selection","clipboard"], stdin=subprocess.PIPE)
            p.stdin.write(text.encode("utf-8"))
            p.stdin.close()
            p.wait()
            return None
        except Exception:
            try:
                p = subprocess.Popen(["xsel","--clipboard","--input"], stdin=subprocess.PIPE)
                p.stdin.write(text.encode("utf-8"))
                p.stdin.close()
                p.wait()
                return None
            except Exception:
                raise RuntimeError("clipboard not available: install pyperclip or xclip/xsel")

def restore_clipboard(prev):
    if prev is None:
        return
    if _HAS_PYPERCLIP:
        try:
            pyperclip.copy(prev)
        except Exception:
            pass
    else:
        try:
            set_clipboard(prev)
        except Exception:
            pass

def do_typing(text: str, delay: float = 0.0, chunk_size: int = 40):
    try:
        pyautogui.FAILSAFE = True
        time.sleep(max(0.0, delay))
        paste_modifier = 'command' if sys.platform == 'darwin' else 'ctrl'
        buffer = []

        def flush_buffer():
            if not buffer:
                return
            s = ''.join(buffer)
            set_clipboard(s)
            time.sleep(0.5)
            pyautogui.hotkey(paste_modifier, 'v')
            time.sleep(0.02)
            buffer.clear()

        for ch in text:
            if ch == '@':
                flush_buffer()
                pyautogui.press('backspace')
                time.sleep(0.02)
            elif ch == '\n':
                flush_buffer()
                pyautogui.press('enter')
                time.sleep(0.02)
            else:
                buffer.append(ch)
                if len(buffer) >= chunk_size:
                    flush_buffer()
        flush_buffer()
        logger.info("Typing finished.")
    except Exception as e:
        logger.exception("Typing error: %s", e)

def open_minecraft_chat_and_send_via_clipboard(
    command: str = "wsserver ws://127.0.0.1:6752",
    chat_key: str = '/',
    app_name: str = "Minecraft",
    pre_delay: float = 0.6,
    after_activate_delay: float = 3,
    restore_prev_clipboard: bool = True,
    to_active: bool = True
):
    time.sleep(pre_delay)
    prev_clip = None
    try:
        if _HAS_PYPERCLIP:
            try:
                prev_clip = pyperclip.paste()
            except Exception:
                prev_clip = None
    except Exception:
        prev_clip = None
    if to_active:
        activated = activate_minecraft_window(app_name)
    time.sleep(after_activate_delay)
    if not activated:
        logger.warning("Could not reliably activate window '%s'. Ensure Minecraft has focus.", app_name)
        global_window.bridge.messageFromCore.emit({"code":"01"})
        return
    
    pyautogui.press(chat_key)
    time.sleep(0.12)
    do_typing(command + "\n", delay=0.0)
    if restore_prev_clipboard and prev_clip is not None:
        time.sleep(0.12)
        try:
            restore_clipboard(prev_clip)
        except Exception:
            pass

    logger.info("Command sent: %s", command)

def main():
    global receive_ai,global_window
    core = CoreProcess(path="./py/core.py")
    receive_ai = CoreProcess(path="./py/receive_ai.py", suppress_stdout=True)
    app = QApplication(sys.argv)
    app.setWindowIcon(QIcon("./DA_logo2.ico"))
    window = MainWindow(core)
    window.show()
    core.on_message = lambda j: handle_core_message(core, j,window)
    receive_ai.on_message = lambda j: handle_receive_ai_message(receive_ai, j,window)
    global_window = window
    core.start()
    def on_about_to_quit():
        try:
            core.stop(kill_if_needed=True)
        except Exception:
            pass
    app.aboutToQuit.connect(on_about_to_quit)
    try:
        rc = app.exec_()
        try:
            core.stop(kill_if_needed=True)
        except Exception:
            pass
        sys.exit(rc)
    except KeyboardInterrupt:
        core.stop(kill_if_needed=True)
        sys.exit(0)
re_auto = 0
def handle_core_message(core_proc: CoreProcess, msg: dict,window):
    global re_auto
    t = msg.get("type")
    if t == "status":
        if(msg.get("msg") == "waiting_for_kill_command_or_parent_close"):
            window.bridge.messageFromCore.emit({"code":"00"})
        elif(msg.get("msg") == "1002"):
            print("A")
            print(re_auto)
            if re_auto < 1:
                print("B")
                time.sleep(0.25)
                open_minecraft_chat_and_send_via_clipboard(to_active = False)
            else:
                print("C")
                window.bridge.messageFromCore.emit({"code":"01"})
            re_auto+=1
        elif(msg.get("msg") == "finish_handler"):
            window.bridge.messageFromCore.emit({"code":"02"})
        elif(msg.get("msg") == "Success_connect"):
            window.bridge.messageFromCore.emit({"code":"03"})
        elif(msg.get("msg") == "request_start_receive_ai"):
            print("request_catch")
            if receive_ai != None:
                print("enter")
                receive_ai.start()
        elif(msg.get("msg") == "request_stop_receive_ai"):
            print("request_catch_stop")
            if receive_ai != None:
                print("enter_ra_stop")
                try:
                    receive_ai.stop()
                except:
                    pass
        elif(msg.get("msg") == "Success_discord_bot_start"):
            window.bridge.messageFromCore.emit({"code":"08"})
        elif(msg.get("msg") == "disconnect_discord"):
            window.bridge.messageFromCore.emit({"code":"09"})
    if t == "error":
        if msg.get("error") != None:
            if msg.get("error") == "invalid_discord_token":
                window.bridge.messageFromCore.emit({"code":"04"})
            elif msg.get("error") == "discord_http_exception":
                window.bridge.messageFromCore.emit({"code":"05"})
            elif msg.get("error") == "discord_start_failed":
                window.bridge.messageFromCore.emit({"code":"06"})
    print("[core msg]", msg)
def handle_receive_ai_message(proc: CoreProcess, msg: dict, window):
    try:
        t = msg.get("type")
        if t == "status_ra":
            print(msg)
            if(msg.get("msg") == "waiting_for_kill_command_or_parent_close"):
                window.bridge.messageFromCore.emit({"code":"07"})
            if(msg.get("msg") == ""):
                pass
        if t == "error_ra":
            window.bridge.messageFromCore.emit(msg)
            print(msg)
            print("request_catch_stop")
            if receive_ai != None:
                print("enter_ra_stop")
                try:
                    receive_ai.stop()
                except:
                    pass
        if t == "js_per_ra":
            window.bridge.messageFromCore.emit(msg)
    except Exception:
        pass


if __name__ == "__main__":
    main()
