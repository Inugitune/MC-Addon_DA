from difflib import SequenceMatcher
def is_similar(a: str, b: str, threshold: float = 0.8) -> bool:
    ratio = SequenceMatcher(None, a, b).ratio()
    return ratio >= threshold
from datetime import datetime
from zoneinfo import ZoneInfo
import requests
from bs4 import BeautifulSoup
from urllib.parse import urlparse, parse_qs, unquote
import time
import os
import re
import socket
import ipaddress
import hashlib
from gpt4all import GPT4All
import shutil
import sys
import threading
import signal
import queue
import tkinter as tk
from tkinter import ttk
import json
from typing import Optional
import subprocess
import psutil as _psutil
_popup_queue = queue.Queue()
def send_to_ui(obj: dict):
    try:
        print(json.dumps(obj, ensure_ascii=False), flush=True)
    except Exception:
        pass
send_to_ui({"type":"status_ra","msg":"起動開始"})
send_to_ui({"type":"js_per_ra","msg":{"p":0,"status":"起動中","desc":"","eta":0,"speed":0,"items":0}})
def _tk_worker():
    root = tk.Tk()
    root.withdraw()
    def _poll_queue():
        try:
            while True:
                msg, timeout = _popup_queue.get_nowait()
                win = tk.Toplevel(root)
                win.title("通知")
                win.attributes("-topmost", True)
                win.resizable(False, False)
                frm = ttk.Frame(win, padding=12)
                frm.pack(fill="both", expand=True)
                label = ttk.Label(frm, text=msg, anchor="center", justify="center", wraplength=400)
                label.pack(padx=6, pady=(0,8))
                btn = ttk.Button(frm, text="OK", command=win.destroy)
                btn.pack()
                if timeout is not None and timeout > 0:
                    root.after(int(timeout * 1000), lambda w=win: (w.destroy() if w.winfo_exists() else None))
        except queue.Empty:
            pass
        root.after(200, _poll_queue)
    root.after(200, _poll_queue)
    root.mainloop()
_tk_thread = threading.Thread(target=_tk_worker, daemon=True)
_tk_thread.start()
def popup(msg: str, timeout: float | None = None):
    _popup_queue.put((str(msg), timeout))
jst_now = datetime.now(ZoneInfo("Asia/Tokyo"))
inference_mode = False
setting_ctx = 256
if inference_mode:
    setting_ctx = 2048
MIN_FREE_GB = 7.5
MIN_FREE_BYTES = int(MIN_FREE_GB * 1024**3)
BASE_DIR = globals().get("BASE_DIR", os.path.dirname(__file__))
def _ensure_min_free_space(path: str, min_bytes: int = MIN_FREE_BYTES):
    try:
        usage = shutil.disk_usage(path)
        free = usage.free
    except Exception as e:
        sys.stderr.write(f"[ERROR] ディスク容量の取得に失敗しました: {e}\n")
        sys.exit(1)
    if free < min_bytes:
        sys.stderr.write(
            f"[ERROR] 空き容量が不足しています: {free / (1024**3):.2f} GiB 利用可能、"
            f"{MIN_FREE_GB} GiB が必要です。\n"
        )
        send_to_ui({"type":"error_ra","msg":"空き容量が不足しています。"})
        sys.exit(1)

BASE_DIR = globals().get("BASE_DIR", os.path.dirname(__file__))
MODEL_MAP = {
    "Llama-3-ELYZA-JP-8B-q4_k_m.gguf": "https://huggingface.co/elyza/Llama-3-ELYZA-JP-8B-GGUF/resolve/main/Llama-3-ELYZA-JP-8B-q4_k_m.gguf",
    "tinyswallow-1.5b-instruct-q5_k_m.gguf": "https://huggingface.co/SakanaAI/TinySwallow-1.5B-Instruct-GGUF/resolve/main/tinyswallow-1.5b-instruct-q5_k_m.gguf",
    "sarashina2.2-3b-instruct-v0.1-Q3_K_M.gguf": "https://huggingface.co/mmnga/sarashina2.2-3b-instruct-v0.1-gguf/resolve/main/sarashina2.2-3b-instruct-v0.1-Q3_K_M.gguf",
}
CHUNK_SIZE = 2 * 1024 * 1024
try:
    import requests
except Exception as e:
    raise RuntimeError("requests が必要です。`pip install requests` で入れてください") from e
try:
    from tqdm import tqdm
    _HAS_TQDM = True
except Exception:
    _HAS_TQDM = False

def sizeof_fmt(num, suffix="B"):
    for unit in ["", "Ki", "Mi", "Gi", "Ti"]:
        if abs(num) < 1024.0:
            return f"{num:3.1f}{unit}{suffix}"
        num /= 1024.0
    return f"{num:.1f}Yi{suffix}"
download_num = 0
def download_file(url: str, dest_path: str, show_progress: bool = True, timeout: int = 30,
                  status: Optional[dict] = None, lock: Optional[threading.Lock] = None):
    global download_num
    if status is None:
        status = {}
    def sset(k, v):
        if lock:
            with lock:
                status[k] = v
        else:
            status[k] = v

    sset("total", None)
    sset("written", 0)
    sset("pct", 0.0)
    sset("speed", 0.0)
    sset("eta", None)
    sset("done", False)
    sset("error", None)

    os.makedirs(os.path.dirname(dest_path), exist_ok=True)
    tmp = dest_path + ".part"
    resume = 0
    if os.path.exists(tmp):
        resume = os.path.getsize(tmp)

    headers = {}
    if resume > 0:
        headers["Range"] = f"bytes={resume}-"
    start = time.time()
    written = resume
    try:
        with requests.Session() as sess:
            r = sess.get(url, stream=True, headers=headers, timeout=timeout)
            if r.status_code in (403, 404):
                raise RuntimeError(f"ダウンロード失敗: HTTP {r.status_code} for {url}")
            if r.status_code == 200 and resume > 0:
                resume = 0
                mode = "wb"
            else:
                mode = "ab" if resume > 0 else "wb"

            total = None
            if "Content-Range" in r.headers:
                try:
                    total = int(r.headers["Content-Range"].split("/")[-1])
                except Exception:
                    total = None
            elif "Content-Length" in r.headers:
                try:
                    total = int(r.headers["Content-Length"]) + resume
                except Exception:
                    total = None
            sset("total", total)
            CHUNK = CHUNK_SIZE

            if show_progress and _HAS_TQDM and total:
                with open(tmp, mode) as f, tqdm(total=total, initial=resume, unit="B", unit_scale=True, desc=os.path.basename(dest_path)) as pbar:
                    for chunk in r.iter_content(chunk_size=CHUNK):
                        if not chunk:
                            continue
                        f.write(chunk)
                        written += len(chunk)
                        pbar.update(len(chunk))
                        elapsed = time.time() - start
                        speed = written / elapsed if elapsed > 0 else 0
                        eta = int((total - written) / speed) if (speed > 0 and total) else None
                        sset("written", written)
                        sset("speed", speed)
                        sset("eta", eta)
                        sset("pct", written / total * 100 if total else 0.0)
                        send_to_ui({"type":"js_per_ra","msg":{"p":(((written / total * 100 if total else 0.0) / 4) + (download_num * 25)),"status":"データをダウンロード中","desc":f"{written}","eta":eta,"speed":speed,"items":f"{download_num + 1}/3"}})
            elif show_progress:
                with open(tmp, mode) as f:
                    last = 0
                    start = time.time()
                    for chunk in r.iter_content(chunk_size=CHUNK):
                        if not chunk:
                            continue
                        f.write(chunk)
                        written += len(chunk)
                        if time.time() - last > 0.2:
                            elapsed = time.time() - start
                            speed = written / elapsed if elapsed > 0 else 0
                            eta = int((total - written) / speed) if (speed > 0 and total) else None
                            sset("written", written)
                            sset("speed", speed)
                            sset("eta", eta)
                            sset("pct", written / total * 100 if total else 0.0)
                            send_to_ui({"type":"js_per_ra","msg":{"p":(((written / total * 100 if total else 0.0) / 4) + (download_num * 25)),"status":"データをダウンロード中","desc":f"{written}","eta":eta,"speed":speed,"items":f"{download_num + 1}/3"}})
                            last = time.time()
                    elapsed = time.time() - start
                    speed = written / elapsed if elapsed > 0 else 0
                    eta = 0 if total and written >= total else None
                    sset("written", written)
                    sset("speed", speed)
                    sset("eta", eta)
                    sset("pct", written / total * 100 if total else 0.0)
            else:
                with open(tmp, mode) as f:
                    for chunk in r.iter_content(chunk_size=CHUNK):
                        if chunk:
                            f.write(chunk)
                            written += len(chunk)
                    sset("written", written)

        os.replace(tmp, dest_path)
        sset("done", True)
        if total:
            sset("pct", 100.0)
            sset("eta", 0)
            sset("written", total)
        return dest_path
    except Exception as e:
        sset("error", str(e))
        sset("done", True)
        raise
def ensure_models_downloaded(model_map, base_dir=BASE_DIR, show_progress=True, cleanup_on_failure=True):
    global download_num
    paths = {}
    def _safe_remove(path):
        try:
            if os.path.exists(path):
                os.remove(path)
                send_to_ui({"type":"status_ra","msg":f"削除しました: {path}"})
                print(f"[INFO] 削除しました: {path}")
        except Exception as ex:
            print(f"[WARN] ファイル削除に失敗しました: {path} -> {ex}")

    for fname, url in model_map.items():
        dest = os.path.join(base_dir, fname)
        paths[fname] = dest
        tmp = dest + ".part"
        if not os.path.exists(dest):
            send_to_ui({"type":"status_ra","msg":f"{fname} が見つかりません。ダウンロードを開始します"})
            print(f"[INFO] {fname} が見つかりません。ダウンロードを開始します: {url}")
            _ensure_min_free_space(base_dir)
            try:
                download_file(url, dest, show_progress=show_progress)
                download_num += 1
            except KeyboardInterrupt:
                send_to_ui({"type":"error_ra","msg":"AIのデータダウンロードに失敗しました。もう一度お試しください。"})
                if cleanup_on_failure:
                    _safe_remove(tmp)
                    _safe_remove(dest)
                raise
            except Exception as e:
                send_to_ui({"type":"error_ra","msg":"AIのデータダウンロードに失敗しました。もう一度お試しください。"})
                if cleanup_on_failure:
                    _safe_remove(tmp)
                    _safe_remove(dest)
                raise RuntimeError(f"{fname} のダウンロードに失敗しました: {e}") from e
            else:
                try:
                    size = sizeof_fmt(os.path.getsize(dest))
                except Exception:
                    size = "不明"
                print(f"[OK] ダウンロード完了: {dest} ({size})")
        else:
            pass
    return paths


_model_paths = ensure_models_downloaded(MODEL_MAP, BASE_DIR, show_progress=True)

model_path = _model_paths["Llama-3-ELYZA-JP-8B-q4_k_m.gguf"]
model_web_path = _model_paths["tinyswallow-1.5b-instruct-q5_k_m.gguf"]
model_little_path = _model_paths["sarashina2.2-3b-instruct-v0.1-Q3_K_M.gguf"]

BASE_DIR = os.path.dirname(__file__)
model = GPT4All(
    os.path.join(BASE_DIR, "Llama-3-ELYZA-JP-8B-q4_k_m.gguf"),
    n_ctx=setting_ctx,
    verbose=True
)

model_web = GPT4All(
    os.path.join(BASE_DIR, "tinyswallow-1.5b-instruct-q5_k_m.gguf"),
    n_ctx=600,
    verbose=True
)

model_little = GPT4All(
    os.path.join(BASE_DIR, "sarashina2.2-3b-instruct-v0.1-Q3_K_M.gguf"),
    n_ctx=1024,
    verbose=True
)

def get_local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
    except Exception:
        ip = "127.0.0.1"
    finally:
        s.close()
    return ip
local_ip = get_local_ip()
print(f"【IP】{local_ip}")
HOST = local_ip
PORT = 6753
SECRET_TOKEN = "2c445db3-12a6-4736-b04a-bd5ef9e9a3f2"
# SECRET_TOKEN = hashlib.sha256(local_ip.encode("utf-8")).hexdigest()

BASE_DIR = os.path.dirname(__file__)
model = GPT4All(os.path.join(BASE_DIR, "Llama-3-ELYZA-JP-8B-q4_k_m.gguf"), n_ctx=2048, verbose=True)

def same_subnet(ip1, ip2, mask_len=24):
    try:
        net = ipaddress.ip_network(f"{ip1}/{mask_len}", strict=False)
        return ipaddress.ip_address(ip2) in net
    except Exception:
        return False
    
def ask_for_Momiji(question,call_back):
    global inference_mode
    call_back("受信！")
    fixed_question = ""
    need_info = ""

    def search_web(query):
        call_back("WEBを検索中")
        max_chars_per_page = 1023

        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                        "(KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36"
        }
        url = f"https://html.duckduckgo.com/html/?q={query}"
        res = requests.get(url, headers=headers)
        soup = BeautifulSoup(res.text, "html.parser")
        results = []
        for a in soup.find_all("a", class_="result__a"):
            href = a.get("href")
            if href.startswith("//duckduckgo.com/l/?uddg="):
                parsed = urlparse(href)
                qs = parse_qs(parsed.query)
                link = unquote(qs["uddg"][0]) if "uddg" in qs else href
            else:
                link = href

            print("取得したリンク:", link)
            results.append(link)
            call_back(f"WEBを検索中({len(results)}/2)")
            if len(results) >= 2:
                break
        def split_text(text, max_chars=1000):
            """長いテキストを max_chars ごとに分割"""
            parts = []
            while len(text) > max_chars:
                parts.append(text[:max_chars])
                text = text[max_chars:]
            if text:
                parts.append(text)
            return parts
        page_summaries = []
        for link in results:
            try:
                call_back(f"WEBを検索中(内容取得中)")
                r = requests.get(link, headers=headers, timeout=5)
                r.encoding = r.apparent_encoding
                page_soup = BeautifulSoup(r.text, "html.parser")
                for iframe in page_soup.find_all("iframe"):
                    iframe.decompose()
                with_search = ["strong","h1", "h2", "h3", "th", "td"]
                if str(link).find("pixiv") != -1 or str(link).find("nicovideo") != -1 or str(link).find("yahoo") != -1:
                    with_search = ["p","strong","h1", "h2", "h3", "th", "td"]
                texts = [tag.get_text(strip=True) for tag in page_soup.find_all(
                    with_search) if tag.get_text(strip=True)]
                page_text = "\n".join(texts)
                page_text = page_text[:max_chars_per_page]
                print(page_text)
                if page_text.strip() and len(page_text.strip()) > 10:
                    for part in split_text(page_text, max_chars=512):
                        with model_web.chat_session():
                            call_back(f"WEBを検索中(内容まとめ中)")
                            summary = model_web.generate(f"以下の内容を基に、「{query}」についてわかりやすくまとめてください。情報がない場合は、空白を出力してください。\n{part}",
                            max_tokens=256,
                            temp=0.7,
                            top_k=20
                        )
                            print("===小まとめ===")
                            print(summary)
                            page_summaries.append(summary)
                else:
                    print(f"リンク取得スキップ: {link} (テキストが短すぎるか取得できず)")
                time.sleep(2)

            except Exception as e:
                print(f"リンク取得失敗: {link} ({e})")
        if page_summaries:
            final_text = "\n".join(page_summaries)
            call_back(f"まとめ中")
            prompt = f"以下の内容を基に、「{query}」についてわかりやすく短くまとめてください。\n\n" + final_text
            with model_little.chat_session():
                final_summary = model_little.generate(prompt,
                    max_tokens=1024,
                    temp=0.7,
                    top_k=20
                )
                print("\n=== まとめ ===")
                print(final_summary)
            return final_summary


        else:
            print("取得できるページがありませんでした。")

    if str(question).find("推論") != -1 and (str(question).find("ON") != -1 or str(question).find("して") != -1 or str(question).find("オン") != -1):
        inference_mode = True
        return "了解！深く考えたり調べるね！"
    elif str(question).find("推論") != -1 and (str(question).find("OFF") != -1 or str(question).find("解除") != -1 or str(question).find("オフ") != -1 or str(question).find("じゃない") != -1 or str(question).find("外") != -1):
        inference_mode = False
        return "おｋ～！なるべく早く答えるね！"
    else:
        if inference_mode:
            call_back(f"誤字・脱字修正中")
            with model.chat_session():
                fixed_question = model.generate("以下の文章に誤字・脱字がある場合、修正して、修正後の文だけを出力してください。また、無い場合は原文をそのまま出力してください。\n"
                                    f"{question}")
                if not is_similar(question,fixed_question):
                    fixed_question = question
                fixed_question = re.sub(r"^椛[、。!？!？ ]?", "", fixed_question)
                print(fixed_question)
            call_back(f"必要な情報を取得中")
            with model.chat_session():
                need_info = model.generate("すこしでも「日時」の情報が必要な場合(何時かを聞かれた、知りたい場合)は「get_date」と出力してください。それ以外の場合、「None」と出力してください。\n"
                                    f"{fixed_question}")
                print(need_info)
                if need_info.find("get_date") != -1:
                    now_date = jst_now.strftime("%Y-%m-%d %H:%M:%S")
                    need_info += f"現在時刻:{now_date}"
            with model.chat_session():
                need_info = model.generate("少しでも「web検索」が必要な場合(最新の情報や正確な情報が必要な場合)は「web_search:検索内容」と出力してください。それ以外の場合、「None」と出力してください。\n"
                                    f"{fixed_question}")
                print(need_info)
                if "web_search:" in need_info:
                    start_idx = need_info.find("web_search:") + len("web_search:")
                    end_idx = need_info.find("\n", start_idx)
                    if end_idx == -1:
                        end_idx = len(need_info)
                    query = need_info[start_idx:end_idx].strip()
                    print("取得した文字列:", query)
                    need_info += "\n"
                    result = search_web(query)
                    if result is not None:
                        need_info += "\n" + result
            need_info = f"\n必要に応じて、以下の情報を使ってください。\n{need_info}"
        else:
            fixed_question = question
        # with model.chat_session():
        #     print(model.generate("あなたは東方キャラクター犬走椛です。気軽で頼れる白狼天狗な女の子の友達な感じです。チャット風で、回答は短め。以下の会話に答えてください。\n"
        #                          f"{fixed_question}{need_info}"))

        call_back(f"タイピング中")
        mm_res = ""
        with model.chat_session():
            for token in model.generate(
                "あなたは東方キャラクター犬走椛です。あなたは気軽で頼れる白狼天狗な女の子の友達な感じです。あなたの一人称は「私」です。チャット風で、回答は短め。\n"
                f"{fixed_question}{need_info}",
                max_tokens=96,    # 少なめに
                temp=0.7,         # 落ち着いたサンプリング
                top_k=40          # 探索幅を狭める
            ):
                mm_res += token
                # print(token, end="", flush=True)
                # time.sleep(0.2)
        send_to_ui({"type": "status_ra", "msg": f"{mm_res}"})
        return mm_res

shutdown_event = threading.Event()

def _signal_handler(sig, frame):
    print(f"[signal] 受信: {sig} -> 終了フラグをセットします")
    popup("サーバーを終了します（Ctrl+C）")
    shutdown_event.set()
signal.signal(signal.SIGINT, _signal_handler)
try:
    signal.signal(signal.SIGTERM, _signal_handler)
except Exception:
    pass
def _cleanup_and_exit(srv=None, code=0):
    print("[shutdown] クリーンアップ中...")
    try:
        popup("サーバーを終了します。")
    except Exception:
        pass
    try:
        for m in (model, model_web, model_little):
            try:
                m.close()
            except Exception:
                pass
    except Exception:
        pass
    try:
        if srv:
            try:
                srv.close()
            except Exception:
                pass
    except Exception:
        pass
    sys.exit(code)

def handle_client(conn, addr):
    print(f"[worker] handling {addr}")
    with conn:
        try:
            data = conn.recv(4096).decode("utf-8", errors="replace")
            if shutdown_event.is_set():
                return
            if not data or not data.startswith("TOKEN:"):
                try:
                    conn.sendall(b"REJECT: no-token\n")
                except Exception:
                    pass
                return

            header, body = data.split("\n", 1)
            token = header.split(":", 1)[1].strip()
            if token != SECRET_TOKEN:
                try:
                    conn.sendall(b"REJECT: invalid-token\n")
                except Exception:
                    pass
                return

            question = body.strip()
            print(f"[worker] received question: {question}")

            def call_back(task):
                conn.sendall(task.encode("utf-8", errors="replace"))
            result = ask_for_Momiji(question, call_back)
            conn.sendall(result.encode("utf-8", errors="replace") + b"\n===END===\n")
        except Exception as e:
            print("[worker] error:", e)




WAIT_PORT_RETRY_INTERVAL = float(os.environ.get("WAIT_PORT_RETRY_INTERVAL", "1.0"))
WAIT_PORT_MAX_SECONDS = os.environ.get("WAIT_PORT_MAX_SECONDS")
if WAIT_PORT_MAX_SECONDS is not None:
    try:
        WAIT_PORT_MAX_SECONDS = float(WAIT_PORT_MAX_SECONDS)
    except Exception:
        WAIT_PORT_MAX_SECONDS = None
WAIT_PORT_AUTO_KILL = os.environ.get("WAIT_PORT_AUTO_KILL", "0") == "1"
def find_listening_pids(port: int):
    pids = set()
    try:
        for c in _psutil.net_connections(kind='inet'):
            if c.laddr and c.laddr.port == port and c.status == 'LISTEN':
                if c.pid:
                    pids.add(c.pid)
    except Exception:
        try:
            out = subprocess.check_output(['netstat', '-ano'], text=True, stderr=subprocess.DEVNULL)
        except Exception:
            try:
                out = subprocess.check_output(['netstat', '-anp'], text=True, stderr=subprocess.DEVNULL)
            except Exception:
                out = ""
        import re
        for line in out.splitlines():
            # Windows: TCP    192.168.0.72:6753    0.0.0.0:0    LISTENING    24640
            m = re.search(r'\s+TCP\s+\S+:(\d+)\s+\S+\s+LISTEN(?:ING)?\s+(\d+)', line, re.IGNORECASE)
            if not m:
                # UNIX: tcp        0      0 0.0.0.0:6753       0.0.0.0:*      LISTEN      24640/python
                m = re.search(r'\s+(\d+)\s*/\S+$', line)
            if m:
                try:
                    p = int(m.group(2))
                except Exception:
                    continue
                if int(m.group(1)) == port:
                    pids.add(p)
    return sorted(pids)
pidfile = os.path.join(BASE_DIR, f"server_port_{PORT}.pid")
def write_pidfile_and_check():
    if os.path.exists(pidfile):
        try:
            with open(pidfile, "r") as f:
                old = int(f.read().strip())
            if _psutil and _psutil.pid_exists(old):
                print(f"[pidfile] existing pid {old} is alive. aborting to avoid duplicate.")
                return False
        except Exception:
            pass
    try:
        with open(pidfile, "w") as f:
            f.write(str(os.getpid()))
    except Exception:
        pass
    return True






send_to_ui({"type":"js_per_ra","msg":{"p":85,"status":"サーバを開始中","desc":"portを確認中","eta":"0","speed":"0","items":"0"}})
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as srv:
    sending_task_kill = False
    if not write_pidfile_and_check():
        send_to_ui({"type": "status_ra", "msg": f"waiting_for_kill_command_or_parent_close"})
        send_to_ui({"type":"status_ra","msg":"既に同ポートでサーバが動作しています。終了してください。"})
        sending_task_kill  = True
        # sys.exit(1)
    start_wait = time.time()
    send_to_ui({"type":"status_ra","msg":"TT=C"})
    while True:
        send_to_ui({"type":"status_ra","msg":"TT=D"})
        pids = find_listening_pids(PORT)
        if pids:
            print(f"[port-check] port {PORT} is listened by pids: {pids}")
            send_to_ui({"type":"status_ra","msg":f"ポート {PORT} を使用中のプロセス: {pids}"})
            try:
                if not sending_task_kill:
                    sending_task_kill = True
                    send_to_ui({"type": "status_ra", "msg": f"waiting_for_kill_command_or_parent_close"})
                # popup(f"ポート {PORT} を使用中のプロセスがいます: {pids}", timeout=4)
            except Exception:
                pass
            if WAIT_PORT_MAX_SECONDS is not None and (time.time() - start_wait) >= WAIT_PORT_MAX_SECONDS:
                send_to_ui({"type":"error_ra","msg":f"ポート {PORT} が {WAIT_PORT_MAX_SECONDS} 秒経っても解放されませんでした。"})
                raise TimeoutError(f"port {PORT} busy")
            time.sleep(WAIT_PORT_RETRY_INTERVAL)
            continue
        try:
            send_to_ui({"type":"status_ra","msg":"TT=E"})
            srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            send_to_ui({"type":"status_ra","msg":"TT=E-1"})
            srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            send_to_ui({"type":"status_ra","msg":"TT=E-2"})
            srv.bind((HOST, PORT))
            send_to_ui({"type":"status_ra","msg":"TT=F"})
            break
        except OSError as e:
            print(f"[bind] failed: {e}; retrying...")
            try:
                srv.close()
            except Exception:
                pass
            if WAIT_PORT_MAX_SECONDS is not None and (time.time() - start_wait) >= WAIT_PORT_MAX_SECONDS:
                raise TimeoutError(f"port {PORT} busy (bind failed repeatedly)")
            time.sleep(WAIT_PORT_RETRY_INTERVAL)
        except Exception as e:
            try:
                srv.close()
            except Exception:
                pass
            raise
    send_to_ui({"type":"js_per_ra","msg":{"p":100,"status":"準備完了","desc":"","eta":"0","speed":"0","items":"0"}})
    send_to_ui({"type":"status_ra","msg":"準備完了!"})
    srv.listen(5)
    srv.settimeout(1.0)
    print(f"[server] listening on {HOST or '0.0.0.0'}:{PORT}")
    popup(f"IP {HOST or '0.0.0.0'}")
    worker_threads = []
    try:
        while not shutdown_event.is_set():
            try:
                conn, addr = srv.accept()
            except socket.timeout:
                continue
            except OSError as e:
                print("[server] socket error:", e)
                break
            t = threading.Thread(target=handle_client, args=(conn, addr), daemon=True)
            t.start()
            worker_threads.append(t)
    except KeyboardInterrupt:
        shutdown_event.set()
    finally:
        print("[server] シャットダウン開始。ワーカースレッドの終了を待機します...")
        shutdown_event.set()
        for t in worker_threads:
            t.join(timeout=1.0)
        _cleanup_and_exit(srv)

