const color_template = {
    "black_concrete.png": {
        "hsl": "hsl(223, 30%, 5%)",
        "rgb": "rgb(8, 10, 15)",
        "sharp": "#080a0f",
        "max": "rgb(9, 11, 16)"
    },
    "blue_concrete.png": {
        "hsl": "hsl(239, 52%, 37%)",
        "rgb": "rgb(45, 47, 143)",
        "sharp": "#2d2f8f",
        "max": "rgb(44, 46, 143)"
    },
    "brown_concrete.png": {
        "hsl": "hsl(26, 50%, 25%)",
        "rgb": "rgb(96, 60, 32)",
        "sharp": "#603c20",
        "max": "rgb(97, 60, 32)"
    },
    "cyan_concrete.png": {
        "hsl": "hsl(189, 73%, 31%)",
        "rgb": "rgb(21, 119, 136)",
        "sharp": "#157788",
        "max": "rgb(21, 119, 136)"
    },
    "gray_concrete.png": {
        "hsl": "hsl(214, 6%, 23%)",
        "rgb": "rgb(55, 58, 62)",
        "sharp": "#373a3e",
        "max": "rgb(55, 58, 62)"
    },
    "green_concrete.png": {
        "hsl": "hsl(80, 43%, 25%)",
        "rgb": "rgb(73, 91, 36)",
        "sharp": "#495b24",
        "max": "rgb(73, 91, 36)"
    },
    "light_blue_concrete.png": {
        "hsl": "hsl(203, 69%, 46%)",
        "rgb": "rgb(36, 137, 199)",
        "sharp": "#2489c7",
        "max": "rgb(35, 137, 199)"
    },
    "lime_concrete.png": {
        "hsl": "hsl(91, 74%, 38%)",
        "rgb": "rgb(94, 169, 25)",
        "sharp": "#5ea919",
        "max": "rgb(94, 169, 24)"
    },
    "magenta_concrete.png": {
        "hsl": "hsl(305, 56%, 43%)",
        "rgb": "rgb(169, 48, 159)",
        "sharp": "#a9309f",
        "max": "rgb(169, 48, 159)"
    },
    "orange_concrete.png": {
        "hsl": "hsl(26, 99%, 44%)",
        "rgb": "rgb(224, 97, 1)",
        "sharp": "#e06101",
        "max": "rgb(225, 97, 0)"
    },
    "pink_concrete.png": {
        "hsl": "hsl(338, 58%, 62%)",
        "rgb": "rgb(214, 101, 143)",
        "sharp": "#d6658f",
        "max": "rgb(214, 101, 143)"
    },
    "black_concrete_powder.png": {
        "hsl": "hsl(223, 12%, 11%)",
        "rgb": "rgb(25, 27, 32)",
        "sharp": "#191b20",
        "max": "rgb(28, 30, 34)"
    },
    "blue_concrete_powder.png": {
        "hsl": "hsl(238, 41%, 46%)",
        "rgb": "rgb(70, 73, 167)",
        "sharp": "#4649a7",
        "max": "rgb(69, 72, 165)"
    },
    "brown_concrete_powder.png": {
        "hsl": "hsl(26, 40%, 35%)",
        "rgb": "rgb(126, 85, 54)",
        "sharp": "#7e5536",
        "max": "rgb(124, 82, 52)"
    },
    "cyan_concrete_powder.png": {
        "hsl": "hsl(185, 62%, 38%)",
        "rgb": "rgb(37, 148, 157)",
        "sharp": "#25949d",
        "max": "rgb(37, 140, 154)"
    },
    "gray_concrete_powder.png": {
        "hsl": "hsl(210, 5%, 32%)",
        "rgb": "rgb(77, 81, 85)",
        "sharp": "#4d5155",
        "max": "rgb(76, 80, 83)"
    },
    "green_concrete_powder.png": {
        "hsl": "hsl(78, 45%, 32%)",
        "rgb": "rgb(97, 119, 45)",
        "sharp": "#61772d",
        "max": "rgb(93, 113, 48)"
    },
    "light_blue_concrete_powder.png": {
        "hsl": "hsl(194, 62%, 56%)",
        "rgb": "rgb(74, 181, 213)",
        "sharp": "#4ab5d5",
        "max": "rgb(74, 182, 212)"
    },
    "lime_concrete_powder.png": {
        "hsl": "hsl(86, 64%, 45%)",
        "rgb": "rgb(125, 189, 42)",
        "sharp": "#7dbd2a",
        "max": "rgb(122, 186, 40)"
    },
    "magenta_concrete_powder.png": {
        "hsl": "hsl(304, 47%, 54%)",
        "rgb": "rgb(193, 84, 185)",
        "sharp": "#c154b9",
        "max": "rgb(197, 91, 188)"
    },
    "orange_concrete_powder.png": {
        "hsl": "hsl(31, 78%, 51%)",
        "rgb": "rgb(227, 132, 32)",
        "sharp": "#e38420",
        "max": "rgb(222, 121, 19)"
    },
    "pink_concrete_powder.png": {
        "hsl": "hsl(338, 59%, 75%)",
        "rgb": "rgb(229, 153, 181)",
        "sharp": "#e599b5",
        "max": "rgb(230, 149, 179)"
    },
    "purple_concrete_powder.png": {
        "hsl": "hsl(277, 52%, 46%)",
        "rgb": "rgb(132, 56, 178)",
        "sharp": "#8438b2",
        "max": "rgb(124, 51, 172)"
    },
    "red_concrete_powder.png": {
        "hsl": "hsl(2, 53%, 43%)",
        "rgb": "rgb(168, 54, 51)",
        "sharp": "#a83633",
        "max": "rgb(164, 51, 50)"
    },
    "light_gray_concrete_powder.png": {
        "hsl": "hsl(60, 3%, 59%)",
        "rgb": "rgb(155, 155, 148)",
        "sharp": "#9b9b94",
        "max": "rgb(157, 157, 151)"
    },
    "white_concrete_powder.png": {
        "hsl": "hsl(210, 4%, 89%)",
        "rgb": "rgb(226, 227, 228)",
        "sharp": "#e2e3e4",
        "max": "rgb(224, 226, 226)"
    },
    "yellow_concrete_powder.png": {
        "hsl": "hsl(49, 80%, 56%)",
        "rgb": "rgb(233, 199, 55)",
        "sharp": "#e9c737",
        "max": "rgb(237, 201, 51)"
    },
    "purple_concrete.png": {
        "hsl": "hsl(273, 66%, 37%)",
        "rgb": "rgb(100, 32, 156)",
        "sharp": "#64209c",
        "max": "rgb(101, 32, 157)"
    },
    "red_concrete.png": {
        "hsl": "hsl(0, 62%, 34%)",
        "rgb": "rgb(142, 33, 33)",
        "sharp": "#8e2121",
        "max": "rgb(142, 32, 32)"
    },
    "light_gray_concrete.png": {
        "hsl": "hsl(60, 4%, 47%)",
        "rgb": "rgb(125, 125, 115)",
        "sharp": "#7d7d73",
        "max": "rgb(125, 125, 115)"
    },
    "white_concrete.png": {
        "hsl": "hsl(189, 8%, 83%)",
        "rgb": "rgb(207, 213, 214)",
        "sharp": "#cfd5d6",
        "max": "rgb(207, 213, 214)"
    },
    "yellow_concrete.png": {
        "hsl": "hsl(42, 89%, 51%)",
        "rgb": "rgb(241, 175, 21)",
        "sharp": "#f1af15",
        "max": "rgb(241, 175, 21)"
    },
    "waxed_copper.png": {
        "hsl": "hsl(15, 47%, 53%)",
        "rgb": "rgb(192, 108, 80)",
        "sharp": "#c06c50",
        "max": "rgb(200, 116, 86)"
    },
    "waxed_copper_bulb.png": {
        "hsl": "hsl(18, 46%, 42%)",
        "rgb": "rgb(156, 87, 57)",
        "sharp": "#9c5739",
        "max": "rgb(95, 51, 21)"
    },
    "copper_ore.png": {
        "hsl": "hsl(70, 2%, 48%)",
        "rgb": "rgb(125, 126, 120)",
        "sharp": "#7d7e78",
        "max": "rgb(127, 127, 127)"
    },
    "cracked_nether_bricks.png": {
        "hsl": "hsl(348, 33%, 12%)",
        "rgb": "rgb(40, 20, 24)",
        "sharp": "#281418",
        "max": "rgb(25, 13, 16)"
    },
    "cracked_polished_blackstone_bricks.png": {
        "hsl": "hsl(300, 7%, 16%)",
        "rgb": "rgb(44, 38, 44)",
        "sharp": "#2c262c",
        "max": "rgb(49, 44, 54)"
    },
    "crying_obsidian.png": {
        "hsl": "hsl(268, 71%, 14%)",
        "rgb": "rgb(33, 10, 60)",
        "sharp": "#210a3c",
        "max": "rgb(6, 3, 11)"
    },
    "diamond_block.png": {
        "hsl": "hsl(176, 79%, 66%)",
        "rgb": "rgb(98, 237, 228)",
        "sharp": "#62ede4",
        "max": "rgb(101, 245, 227)"
    },
    "dirt.png": {
        "hsl": "hsl(26, 33%, 39%)",
        "rgb": "rgb(134, 96, 67)",
        "sharp": "#866043",
        "max": "rgb(121, 85, 58)"
    },
    "gilded_blackstone.png": {
        "hsl": "hsl(17, 19%, 18%)",
        "rgb": "rgb(56, 43, 38)",
        "sharp": "#382b26",
        "max": "rgb(39, 34, 28)"
    },
    "glowstone.png": {
        "hsl": "hsl(32, 35%, 50%)",
        "rgb": "rgb(172, 131, 84)",
        "sharp": "#ac8354",
        "max": "rgb(111, 69, 34)"
    },
    "gold_block.png": {
        "hsl": "hsl(48, 91%, 60%)",
        "rgb": "rgb(246, 208, 62)",
        "sharp": "#f6d03e",
        "max": "rgb(255, 216, 62)"
    },
    "gold_ore.png": {
        "hsl": "hsl(43, 15%, 49%)",
        "rgb": "rgb(145, 134, 107)",
        "sharp": "#91866b",
        "max": "rgb(127, 127, 127)"
    },
    "hardened_clay.png": {
        "hsl": "hsl(19, 38%, 43%)",
        "rgb": "rgb(152, 94, 68)",
        "sharp": "#985e44",
        "max": "rgb(150, 93, 67)"
    },
    "black_terracotta.png": {
        "hsl": "hsl(20, 40%, 10%)",
        "rgb": "rgb(37, 23, 16)",
        "sharp": "#251710",
        "max": "rgb(37, 22, 16)"
    },
    "blue_terracotta.png": {
        "hsl": "hsl(267, 21%, 30%)",
        "rgb": "rgb(74, 60, 91)",
        "sharp": "#4a3c5b",
        "max": "rgb(74, 59, 91)"
    },
    "brown_terracotta.png": {
        "hsl": "hsl(22, 36%, 22%)",
        "rgb": "rgb(77, 51, 36)",
        "sharp": "#4d3324",
        "max": "rgb(77, 52, 36)"
    },
    "cyan_terracotta.png": {
        "hsl": "hsl(180, 2%, 35%)",
        "rgb": "rgb(87, 91, 91)",
        "sharp": "#575b5b",
        "max": "rgb(86, 90, 90)"
    },
    "gray_terracotta.png": {
        "hsl": "hsl(16, 23%, 18%)",
        "rgb": "rgb(58, 42, 36)",
        "sharp": "#3a2a24",
        "max": "rgb(58, 43, 36)"
    },
    "green_terracotta.png": {
        "hsl": "hsl(70, 33%, 25%)",
        "rgb": "rgb(76, 83, 42)",
        "sharp": "#4c532a",
        "max": "rgb(75, 82, 41)"
    },
    "light_blue_terracotta.png": {
        "hsl": "hsl(248, 12%, 48%)",
        "rgb": "rgb(113, 109, 138)",
        "sharp": "#716d8a",
        "max": "rgb(112, 108, 138)"
    },
    "lime_terracotta.png": {
        "hsl": "hsl(73, 38%, 34%)",
        "rgb": "rgb(104, 118, 53)",
        "sharp": "#687635",
        "max": "rgb(103, 117, 52)"
    },
    "magenta_terracotta.png": {
        "hsl": "hsl(340, 26%, 47%)",
        "rgb": "rgb(150, 88, 109)",
        "sharp": "#96586d",
        "max": "rgb(149, 87, 108)"
    },
    "orange_terracotta.png": {
        "hsl": "hsl(22, 62%, 39%)",
        "rgb": "rgb(162, 84, 38)",
        "sharp": "#a25426",
        "max": "rgb(159, 82, 36)"
    },
    "pink_terracotta.png": {
        "hsl": "hsl(359, 35%, 47%)",
        "rgb": "rgb(162, 78, 79)",
        "sharp": "#a24e4f",
        "max": "rgb(160, 77, 78)"
    },
    "purple_terracotta.png": {
        "hsl": "hsl(340, 26%, 37%)",
        "rgb": "rgb(118, 70, 86)",
        "sharp": "#764656",
        "max": "rgb(115, 68, 84)"
    },
    "red_terracotta.png": {
        "hsl": "hsl(9, 51%, 37%)",
        "rgb": "rgb(143, 61, 47)",
        "sharp": "#8f3d2f",
        "max": "rgb(141, 59, 46)"
    },
    "light_gray_terracotta.png": {
        "hsl": "hsl(15, 16%, 46%)",
        "rgb": "rgb(135, 107, 98)",
        "sharp": "#876b62",
        "max": "rgb(135, 107, 98)"
    },
    "white_terracotta.png": {
        "hsl": "hsl(21, 35%, 73%)",
        "rgb": "rgb(210, 178, 161)",
        "sharp": "#d2b2a1",
        "max": "rgb(210, 177, 161)"
    },
    "yellow_terracotta.png": {
        "hsl": "hsl(39, 68%, 43%)",
        "rgb": "rgb(186, 133, 35)",
        "sharp": "#ba8523",
        "max": "rgb(184, 131, 34)"
    },
    "honeycomb_block.png": {
        "hsl": "hsl(36, 79%, 51%)",
        "rgb": "rgb(229, 148, 30)",
        "sharp": "#e5941e",
        "max": "rgb(232, 140, 8)"
    },
    "packed_ice.png": {
        "hsl": "hsl(219, 92%, 77%)",
        "rgb": "rgb(142, 180, 250)",
        "sharp": "#8eb4fa",
        "max": "rgb(146, 185, 254)"
    },
    "iron_block.png": {
        "hsl": "hsl(0, 0%, 86%)",
        "rgb": "rgb(220, 220, 220)",
        "sharp": "#dcdcdc",
        "max": "rgb(230, 230, 230)"
    },
    "iron_ore.png": {
        "hsl": "hsl(28, 5%, 51%)",
        "rgb": "rgb(136, 129, 123)",
        "sharp": "#88817b",
        "max": "rgb(127, 127, 127)"
    },
    "obsidian.png": {
        "hsl": "hsl(257, 39%, 7%)",
        "rgb": "rgb(15, 11, 25)",
        "sharp": "#0f0b19",
        "max": "rgb(6, 3, 11)"
    },
    "acacia_planks.png": {
        "hsl": "hsl(20, 54%, 43%)",
        "rgb": "rgb(168, 90, 50)",
        "sharp": "#a85a32",
        "max": "rgb(186, 99, 55)"
    },
    "dark_oak_planks.png": {
        "hsl": "hsl(29, 54%, 17%)",
        "rgb": "rgb(67, 43, 20)",
        "sharp": "#432b14",
        "max": "rgb(79, 50, 24)"
    },
    "birch_planks.png": {
        "hsl": "hsl(46, 36%, 61%)",
        "rgb": "rgb(192, 175, 121)",
        "sharp": "#c0af79",
        "max": "rgb(215, 193, 133)"
    },
    "jungle_planks.png": {
        "hsl": "hsl(26, 33%, 47%)",
        "rgb": "rgb(160, 115, 81)",
        "sharp": "#a07351",
        "max": "rgb(184, 135, 100)"
    },
    "oak_planks.png": {
        "hsl": "hsl(38, 34%, 47%)",
        "rgb": "rgb(162, 131, 79)",
        "sharp": "#a2834f",
        "max": "rgb(184, 148, 95)"
    },
    "spruce_planks.png": {
        "hsl": "hsl(33, 40%, 32%)",
        "rgb": "rgb(115, 85, 49)",
        "sharp": "#735531",
        "max": "rgb(130, 97, 58)"
    },
    "quartz_bricks.png": {
        "hsl": "hsl(32, 25%, 90%)",
        "rgb": "rgb(235, 229, 222)",
        "sharp": "#ebe5de",
        "max": "rgb(238, 234, 230)"
    },
    "raw_copper_block.png": {
        "hsl": "hsl(22, 32%, 46%)",
        "rgb": "rgb(154, 106, 79)",
        "sharp": "#9a6a4f",
        "max": "rgb(157, 87, 63)"
    },
    "raw_gold_block.png": {
        "hsl": "hsl(42, 73%, 53%)",
        "rgb": "rgb(222, 169, 47)",
        "sharp": "#dea92f",
        "max": "rgb(201, 140, 28)"
    },
    "red_nether_brick.png": {
        "hsl": "hsl(358, 82%, 15%)",
        "rgb": "rgb(70, 7, 9)",
        "sharp": "#460709",
        "max": "rgb(68, 5, 7)"
    },
    "red_sand.png": {
        "hsl": "hsl(27, 71%, 44%)",
        "rgb": "rgb(191, 103, 33)",
        "sharp": "#bf6721",
        "max": "rgb(191, 103, 33)"
    },
    "redstone_block.png": {
        "hsl": "hsl(7, 94%, 35%)",
        "rgb": "rgb(176, 25, 5)",
        "sharp": "#b01905",
        "max": "rgb(230, 32, 8)"
    },
    "redstone_ore.png": {
        "hsl": "hsl(0, 12%, 49%)",
        "rgb": "rgb(140, 110, 110)",
        "sharp": "#8c6e6e",
        "max": "rgb(127, 127, 127)"
    },
    "sculk.png": {
        "hsl": "hsl(196, 47%, 10%)",
        "rgb": "rgb(13, 30, 36)",
        "sharp": "#0d1e24",
        "max": "rgb(13, 18, 23)"
    },
    "shroomlight.png": {
        "hsl": "hsl(27, 86%, 61%)",
        "rgb": "rgb(241, 147, 71)",
        "sharp": "#f19347",
        "max": "rgb(254, 172, 109)"
    },
    "slime.png": {
        "hsl": "hsl(108, 44%, 56%)",
        "rgb": "rgb(112, 192, 92)",
        "sharp": "#70c05c",
        "max": "rgb(115, 194, 98)"
    },
    "black_wool.png": {
        "hsl": "hsl(240, 11%, 9%)",
        "rgb": "rgb(21, 21, 26)",
        "sharp": "#15151a",
        "max": "rgb(28, 28, 32)"
    },
    "blue_wool.png": {
        "hsl": "hsl(238, 50%, 41%)",
        "rgb": "rgb(53, 57, 157)",
        "sharp": "#35399d",
        "max": "rgb(62, 77, 178)"
    },
    "brown_wool.png": {
        "hsl": "hsl(25, 47%, 30%)",
        "rgb": "rgb(114, 72, 41)",
        "sharp": "#724829",
        "max": "rgb(126, 80, 47)"
    },
    "cyan_wool.png": {
        "hsl": "hsl(183, 75%, 33%)",
        "rgb": "rgb(21, 138, 145)",
        "sharp": "#158a91",
        "max": "rgb(22, 150, 152)"
    },
    "gray_wool.png": {
        "hsl": "hsl(207, 7%, 26%)",
        "rgb": "rgb(63, 68, 72)",
        "sharp": "#3f4448",
        "max": "rgb(71, 79, 82)"
    },
    "green_wool.png": {
        "hsl": "hsl(78, 59%, 27%)",
        "rgb": "rgb(85, 110, 28)",
        "sharp": "#556e1c",
        "max": "rgb(101, 134, 25)"
    },
    "light_blue_wool.png": {
        "hsl": "hsl(196, 68%, 54%)",
        "rgb": "rgb(58, 175, 217)",
        "sharp": "#3aafd9",
        "max": "rgb(78, 197, 231)"
    },
    "lime_wool.png": {
        "hsl": "hsl(88, 75%, 41%)",
        "rgb": "rgb(112, 185, 26)",
        "sharp": "#70b91a",
        "max": "rgb(134, 204, 38)"
    },
    "magenta_wool.png": {
        "hsl": "hsl(305, 48%, 51%)",
        "rgb": "rgb(190, 69, 180)",
        "sharp": "#be45b4",
        "max": "rgb(214, 96, 209)"
    },
    "orange_wool.png": {
        "hsl": "hsl(27, 89%, 51%)",
        "rgb": "rgb(241, 118, 20)",
        "sharp": "#f17614",
        "max": "rgb(249, 147, 43)"
    },
    "pink_wool.png": {
        "hsl": "hsl(341, 74%, 74%)",
        "rgb": "rgb(238, 141, 172)",
        "sharp": "#ee8dac",
        "max": "rgb(244, 178, 201)"
    },
    "purple_wool.png": {
        "hsl": "hsl(277, 61%, 42%)",
        "rgb": "rgb(122, 42, 173)",
        "sharp": "#7a2aad",
        "max": "rgb(151, 67, 205)"
    },
    "red_wool.png": {
        "hsl": "hsl(2, 64%, 38%)",
        "rgb": "rgb(161, 39, 35)",
        "sharp": "#a12723",
        "max": "rgb(184, 52, 44)"
    },
    "light_gray_wool.png": {
        "hsl": "hsl(60, 3%, 54%)",
        "rgb": "rgb(142, 142, 135)",
        "sharp": "#8e8e87",
        "max": "rgb(153, 153, 147)"
    },
    "white_wool.png": {
        "hsl": "hsl(200, 8%, 92%)",
        "rgb": "rgb(234, 236, 237)",
        "sharp": "#eaeced",
        "max": "rgb(254, 254, 254)"
    },
    "yellow_wool.png": {
        "hsl": "hsl(45, 95%, 57%)",
        "rgb": "rgb(249, 198, 40)",
        "sharp": "#f9c628",
        "max": "rgb(254, 217, 63)"
    },
    //V2
    "gravel.png": {
        "hsl": "hsl(0, 2%, 51%)",
        "rgb": "rgb(132, 127, 127)",
        "sharp": "#847f7f",
        "max": "rgb(129, 127, 127)"
    },
    "lodestone.png": {
        "hsl": "hsl(220, 3%, 59%)",
        "rgb": "rgb(147, 149, 153)",
        "sharp": "#939599",
        "max": "rgb(171, 177, 184)"
    },
    "acacia_log.png": {
        "hsl": "hsl(21, 47%, 40%)",
        "rgb": "rgb(151, 89, 55)",
        "sharp": "#975937",
        "max": "rgb(173, 93, 50)"
    },
    "birch_log.png": {
        "hsl": "hsl(46, 32%, 64%)",
        "rgb": "rgb(193, 179, 135)",
        "sharp": "#c1b387",
        "max": "rgb(200, 183, 122)"
    },
    "jungle_log.png": {
        "hsl": "hsl(29, 36%, 43%)",
        "rgb": "rgb(150, 109, 71)",
        "sharp": "#966d47",
        "max": "rgb(170, 121, 84)"
    },
    "oak_log.png": {
        "hsl": "hsl(38, 35%, 44%)",
        "rgb": "rgb(151, 122, 73)",
        "sharp": "#977a49",
        "max": "rgb(175, 143, 85)"
    },
    "spruce_log.png": {
        "hsl": "hsl(32, 40%, 31%)",
        "rgb": "rgb(109, 80, 47)",
        "sharp": "#6d502f",
        "max": "rgb(122, 90, 52)"
    },
    "mangrove_log.png": {
        "hsl": "hsl(7, 42%, 28%)",
        "rgb": "rgb(103, 49, 42)",
        "sharp": "#67312a",
        "max": "rgb(111, 42, 45)"
    },
    "mangrove_planks.png": {
        "hsl": "hsl(4, 41%, 33%)",
        "rgb": "rgb(118, 54, 49)",
        "sharp": "#763631",
        "max": "rgb(127, 66, 52)"
    },
    "melon_block.png": {
        "hsl": "hsl(78, 65%, 35%)",
        "rgb": "rgb(111, 145, 31)",
        "sharp": "#6f911f",
        "max": "rgb(111, 147, 35)"
    },
    "moss_block.png": {
        "hsl": "hsl(79, 42%, 30%)",
        "rgb": "rgb(89, 110, 45)",
        "sharp": "#596e2d",
        "max": "rgb(100, 114, 51)"
    },
    "mud.png": {
        "hsl": "hsl(285, 3%, 23%)",
        "rgb": "rgb(60, 57, 61)",
        "sharp": "#3c393d",
        "max": "rgb(51, 50, 58)"
    },
    "mud_bricks.png": {
        "hsl": "hsl(26, 27%, 42%)",
        "rgb": "rgb(137, 104, 79)",
        "sharp": "#89684f",
        "max": "rgb(149, 113, 80)"
    },
    "quartz_block.png": {
        "hsl": "hsl(32, 25%, 90%)",
        "rgb": "rgb(236, 230, 223)",
        "sharp": "#ece6df",
        "max": "rgb(238, 234, 230)"
    },
    "sandstone.png": {
        "hsl": "hsl(49, 47%, 77%)",
        "rgb": "rgb(224, 214, 170)",
        "sharp": "#e0d6aa",
        "max": "rgb(227, 219, 176)"
    },
    "stone.png": {
        "hsl": "hsl(0, 0%, 49%)",
        "rgb": "rgb(126, 126, 126)",
        "sharp": "#7e7e7e",
        "max": "rgb(128, 128, 128)"
    },
    "andesite.png": {
        "hsl": "hsl(240, 0%, 54%)",
        "rgb": "rgb(136, 136, 137)",
        "sharp": "#888889",
        "max": "rgb(138, 138, 142)"
    },
    "diorite.png": {
        "hsl": "hsl(300, 1%, 74%)",
        "rgb": "rgb(189, 188, 189)",
        "sharp": "#bdbcbd",
        "max": "rgb(233, 233, 233)"
    },
    "granite.png": {
        "hsl": "hsl(16, 27%, 46%)",
        "rgb": "rgb(149, 103, 86)",
        "sharp": "#956756",
        "max": "rgb(159, 107, 88)"
    },
    "stonebrick.png": {
        "hsl": "hsl(0, 0%, 48%)",
        "rgb": "rgb(122, 122, 122)",
        "sharp": "#7a7a7a",
        "max": "rgb(127, 127, 127)"
    },
    "mossy_stone_bricks.png": {
        "hsl": "hsl(82, 7%, 44%)",
        "rgb": "rgb(115, 121, 105)",
        "sharp": "#737969",
        "max": "rgb(127, 127, 127)"
    },
    "stripped_acacia_log.png": {
        "hsl": "hsl(21, 52%, 43%)",
        "rgb": "rgb(166, 91, 52)",
        "sharp": "#a65b34",
        "max": "rgb(173, 93, 50)"
    },
    "stripped_bamboo_block.png": {
        "hsl": "hsl(49, 42%, 49%)",
        "rgb": "rgb(178, 159, 73)",
        "sharp": "#b29f49",
        "max": "rgb(217, 194, 94)"
    },
    "stripped_birch_log.png": {
        "hsl": "hsl(45, 37%, 60%)",
        "rgb": "rgb(191, 172, 116)",
        "sharp": "#bfac74",
        "max": "rgb(200, 183, 122)"
    },
    "stripped_cherry_log.png": {
        "hsl": "hsl(7, 48%, 74%)",
        "rgb": "rgb(221, 165, 158)",
        "sharp": "#dda59e",
        "max": "rgb(230, 181, 173)"
    },
    "stripped_dark_oak_log.png": {
        "hsl": "hsl(29, 48%, 17%)",
        "rgb": "rgb(66, 44, 23)",
        "sharp": "#422c17",
        "max": "rgb(73, 47, 23)"
    },
    "stripped_jungle_log.png": {
        "hsl": "hsl(29, 34%, 49%)",
        "rgb": "rgb(166, 123, 82)",
        "sharp": "#a67b52",
        "max": "rgb(170, 121, 84)"
    },
    "stripped_oak_log.png": {
        "hsl": "hsl(38, 35%, 46%)",
        "rgb": "rgb(160, 130, 77)",
        "sharp": "#a0824d",
        "max": "rgb(175, 143, 85)"
    },
    //V3
    "ancient_debris.png": {
        "hsl": "hsl(13, 24%, 30%)",
        "rgb": "rgb(95, 66, 58)",
        "sharp": "#5f423a",
        "max": "rgb(149, 134, 126)"
    },
    "bedrock.png": {
        "hsl": "hsl(0, 0%, 33%)",
        "rgb": "rgb(85, 85, 85)",
        "sharp": "#555555",
        "max": "rgb(51, 51, 51)"
    },
    "bee_nest.png": {
        "hsl": "hsl(40, 55%, 54%)",
        "rgb": "rgb(202, 160, 75)",
        "sharp": "#caa04b",
        "max": "rgb(251, 220, 117)"
    },
    "beehive.png": {
        "hsl": "hsl(37, 37%, 53%)",
        "rgb": "rgb(179, 145, 89)",
        "sharp": "#b39159",
        "max": "rgb(184, 148, 95)"
    },
    "blackstone.png": {
        "hsl": "hsl(310, 8%, 15%)",
        "rgb": "rgb(42, 36, 41)",
        "sharp": "#2a2429",
        "max": "rgb(39, 34, 28)"
    },
    "calcite.png": {
        "hsl": "hsl(80, 5%, 87%)",
        "rgb": "rgb(223, 224, 221)",
        "sharp": "#dfe0dd",
        "max": "rgb(217, 219, 215)"
    },
    "chiseled_tuff_bricks.png": {
        "hsl": "hsl(86, 3%, 43%)",
        "rgb": "rgb(111, 114, 107)",
        "sharp": "#6f726b",
        "max": "rgb(118, 119, 111)"
    },
    "chiseled_tuff.png": {
        "hsl": "hsl(97, 4%, 37%)",
        "rgb": "rgb(94, 99, 91)",
        "sharp": "#5e635b",
        "max": "rgb(75, 81, 69)"
    },
    "coal_block.png": {
        "hsl": "hsl(0, 0%, 6%)",
        "rgb": "rgb(16, 16, 16)",
        "sharp": "#101010",
        "max": "rgb(21, 21, 21)"
    },
    "dripstone_block.png": {
        "hsl": "hsl(22, 18%, 45%)",
        "rgb": "rgb(134, 108, 93)",
        "sharp": "#866c5d",
        "max": "rgb(146, 121, 101)"
    },
    "end_bricks.png": {
        "hsl": "hsl(66, 50%, 76%)",
        "rgb": "rgb(218, 224, 162)",
        "sharp": "#dae0a2",
        "max": "rgb(232, 244, 178)"
    },
    "end_stone.png": {
        "hsl": "hsl(63, 50%, 75%)",
        "rgb": "rgb(220, 223, 158)",
        "sharp": "#dcdf9e",
        "max": "rgb(213, 218, 148)"
    },
    "grass_path.png": {
        "hsl": "hsl(41, 39%, 42%)",
        "rgb": "rgb(148, 122, 65)",
        "sharp": "#947a41",
        "max": "rgb(144, 117, 64)"
    },
    "netherrack.png": {
        "hsl": "hsl(0, 44%, 27%)",
        "rgb": "rgb(98, 38, 38)",
        "sharp": "#622626",
        "max": "rgb(101, 40, 40)"
    },
    "obsidian.png": {
        "hsl": "hsl(257, 39%, 7%)",
        "rgb": "rgb(15, 11, 25)",
        "sharp": "#0f0b19",
        "max": "rgb(6, 3, 11)"
    },
    "warped_wart_block.png": {
        "hsl": "hsl(181, 68%, 28%)",
        "rgb": "rgb(23, 120, 121)",
        "sharp": "#177879",
        "max": "rgb(22, 126, 134)"
    },
    "waxed_oxidized_copper.png": {
        "hsl": "hsl(158, 33%, 48%)",
        "rgb": "rgb(82, 163, 133)",
        "sharp": "#52a385",
        "max": "rgb(89, 178, 146)"
    },
    //V4
    "brick_block.png": {
        "hsl": "hsl(13, 29%, 46%)",
        "rgb": "rgb(151, 98, 83)",
        "sharp": "#976253",
        "max": "rgb(155, 86, 67)"
    },
    "crimson_nylium.png": {
        "hsl": "hsl(0, 62%, 32%)",
        "rgb": "rgb(131, 31, 31)",
        "sharp": "#831f1f",
        "max": "rgb(123, 0, 0)"
    },
    "lapis_block.png": {
        "hsl": "hsl(220, 64%, 34%)",
        "rgb": "rgb(31, 67, 140)",
        "sharp": "#1f438c",
        "max": "rgb(30, 66, 133)"
    },
    "pale_oak_log.png": {
        "hsl": "hsl(5, 9%, 76%)",
        "rgb": "rgb(199, 189, 188)",
        "sharp": "#c7bdbc",
        "max": "rgb(231, 227, 225)"
    },
    "pale_oak_planks.png": {
        "hsl": "hsl(10, 18%, 87%)",
        "rgb": "rgb(228, 218, 216)",
        "sharp": "#e4dad8",
        "max": "rgb(250, 239, 238)"
    },
    "pearlescent_froglight.png": {
        "hsl": "hsl(338, 22%, 90%)",
        "rgb": "rgb(236, 225, 229)",
        "sharp": "#ece1e5",
        "max": "rgb(249, 244, 243)"
    },
    "resin_block.png": {
        "hsl": "hsl(23, 79%, 47%)",
        "rgb": "rgb(217, 99, 25)",
        "sharp": "#d96319",
        "max": "rgb(227, 98, 22)"
    },
    "resin_bricks.png": {
        "hsl": "hsl(21, 79%, 45%)",
        "rgb": "rgb(206, 89, 24)",
        "sharp": "#ce5918",
        "max": "rgb(199, 73, 10)"
    },
    "soul_sand.png": {
        "hsl": "hsl(22, 23%, 26%)",
        "rgb": "rgb(81, 62, 51)",
        "sharp": "#513e33",
        "max": "rgb(73, 55, 44)"
    },
    "stripped_pale_oak_log.png": {
        "hsl": "hsl(7, 18%, 90%)",
        "rgb": "rgb(235, 227, 226)",
        "sharp": "#ebe3e2",
        "max": "rgb(231, 227, 225)"
    },
    "tuff.png": {
        "hsl": "hsl(70, 3%, 42%)",
        "rgb": "rgb(108, 109, 103)",
        "sharp": "#6c6d67",
        "max": "rgb(106, 110, 111)"
    },
    "cherry_planks.png": {
        "hsl": "hsl(7, 49%, 78%)",
        "rgb": "rgb(227, 179, 173)",
        "sharp": "#e3b3ad",
        "max": "rgb(231, 194, 187)"
    },
    "prismarine_bricks.png": {
        "hsl": "hsl(168, 31%, 53%)",
        "rgb": "rgb(99, 172, 158)",
        "sharp": "#63ac9e",
        "max": "rgb(110, 185, 174)"
    },
    "dark_prismarine.png": {
        "hsl": "hsl(156, 28%, 28%)",
        "rgb": "rgb(52, 92, 76)",
        "sharp": "#345c4c",
        "max": "rgb(49, 80, 65)"
    },
    "snow.png": {
        "hsl": "hsl(180, 71%, 99%)",
        "rgb": "rgb(249, 254, 254)",
        "sharp": "#f9fefe",
        "max": "rgb(255, 255, 255)"
    },
    //V6
    "amethyst_block.png": {
        "hsl": "hsl(263, 42%, 57%)",
        "rgb": "rgb(134, 98, 191)",
        "sharp": "#8662bf",
        "max": "rgb(122, 91, 181)"
    },
    "blue_ice.png": {
        "hsl": "hsl(217, 97%, 72%)",
        "rgb": "rgb(116, 168, 253)",
        "sharp": "#74a8fd",
        "max": "rgb(108, 163, 253)"
    },
    "coal_ore.png": {
        "hsl": "hsl(60, 0%, 41%)",
        "rgb": "rgb(106, 106, 105)",
        "sharp": "#6a6a69",
        "max": "rgb(116, 116, 116)"
    },
    "crafting_table.png": {
        "hsl": "hsl(24, 48%, 32%)",
        "rgb": "rgb(120, 73, 42)",
        "sharp": "#78492a",
        "max": "rgb(174, 105, 60)"
    },
    "diamond_ore.png": {
        "hsl": "hsl(180, 8%, 51%)",
        "rgb": "rgb(121, 141, 141)",
        "sharp": "#798d8d",
        "max": "rgb(127, 127, 127)"
    },
    "emerald_ore.png": {
        "hsl": "hsl(137, 11%, 48%)",
        "rgb": "rgb(108, 136, 116)",
        "sharp": "#6c8874",
        "max": "rgb(127, 127, 127)"
    },
    "furnace.png": {
        "hsl": "hsl(0, 0%, 43%)",
        "rgb": "rgb(110, 110, 110)",
        "sharp": "#6e6e6e",
        "max": "rgb(145, 145, 145)"
    },
    "gilded_blackstone.png": {
        "hsl": "hsl(17, 19%, 18%)",
        "rgb": "rgb(56, 43, 38)",
        "sharp": "#382b26",
        "max": "rgb(39, 34, 28)"
    },
    "black_glazed_terracotta.png": {
        "hsl": "hsl(357, 39%, 19%)",
        "rgb": "rgb(68, 30, 32)",
        "sharp": "#441e20",
        "max": "rgb(142, 32, 32)"
    },
    "blue_glazed_terracotta.png": {
        "hsl": "hsl(228, 49%, 36%)",
        "rgb": "rgb(47, 65, 139)",
        "sharp": "#2f418b",
        "max": "rgb(44, 46, 143)"
    },
    "brown_glazed_terracotta.png": {
        "hsl": "hsl(35, 17%, 40%)",
        "rgb": "rgb(120, 106, 86)",
        "sharp": "#786a56",
        "max": "rgb(131, 84, 50)"
    },
    "cyan_glazed_terracotta.png": {
        "hsl": "hsl(185, 41%, 35%)",
        "rgb": "rgb(52, 119, 125)",
        "sharp": "#34777d",
        "max": "rgb(21, 119, 136)"
    },
    "gray_glazed_terracotta.png": {
        "hsl": "hsl(202, 6%, 35%)",
        "rgb": "rgb(83, 90, 94)",
        "sharp": "#535a5e",
        "max": "rgb(54, 57, 61)"
    },
    "green_glazed_terracotta.png": {
        "hsl": "hsl(80, 36%, 41%)",
        "rgb": "rgb(117, 142, 67)",
        "sharp": "#758e43",
        "max": "rgb(73, 91, 36)"
    },
    "light_blue_glazed_terracotta.png": {
        "hsl": "hsl(203, 55%, 60%)",
        "rgb": "rgb(95, 165, 209)",
        "sharp": "#5fa5d1",
        "max": "rgb(58, 179, 218)"
    },
    "lime_glazed_terracotta.png": {
        "hsl": "hsl(75, 57%, 50%)",
        "rgb": "rgb(163, 198, 55)",
        "sharp": "#a3c637",
        "max": "rgb(128, 199, 31)"
    },
    "magenta_glazed_terracotta.png": {
        "hsl": "hsl(309, 53%, 60%)",
        "rgb": "rgb(208, 100, 192)",
        "sharp": "#d064c0",
        "max": "rgb(199, 78, 189)"
    },
    "orange_glazed_terracotta.png": {
        "hsl": "hsl(52, 26%, 48%)",
        "rgb": "rgb(155, 147, 92)",
        "sharp": "#9b935c",
        "max": "rgb(249, 128, 29)"
    },
    "pink_glazed_terracotta.png": {
        "hsl": "hsl(340, 67%, 76%)",
        "rgb": "rgb(235, 155, 182)",
        "sharp": "#eb9bb6",
        "max": "rgb(244, 181, 203)"
    },
    "purple_glazed_terracotta.png": {
        "hsl": "hsl(276, 52%, 39%)",
        "rgb": "rgb(110, 48, 152)",
        "sharp": "#6e3098",
        "max": "rgb(137, 50, 184)"
    },
    "red_glazed_terracotta.png": {
        "hsl": "hsl(3, 55%, 46%)",
        "rgb": "rgb(182, 60, 53)",
        "sharp": "#b63c35",
        "max": "rgb(176, 46, 38)"
    },
    "silver_glazed_terracotta.png": {
        "hsl": "hsl(185, 12%, 61%)",
        "rgb": "rgb(144, 166, 168)",
        "sharp": "#90a6a8",
        "max": "rgb(204, 208, 210)"
    },
    "white_glazed_terracotta.png": {
        "hsl": "hsl(157, 21%, 79%)",
        "rgb": "rgb(189, 212, 203)",
        "sharp": "#bdd4cb",
        "max": "rgb(249, 255, 254)"
    },
    "yellow_glazed_terracotta.png": {
        "hsl": "hsl(43, 78%, 63%)",
        "rgb": "rgb(234, 192, 89)",
        "sharp": "#eac059",
        "max": "rgb(255, 236, 157)"
    },
    "purpur_block.png": {
        "hsl": "hsl(300, 21%, 58%)",
        "rgb": "rgb(170, 126, 170)",
        "sharp": "#aa7eaa",
        "max": "rgb(178, 134, 178)"
    },
    "quartz_ore.png": {
        "hsl": "hsl(4, 31%, 35%)",
        "rgb": "rgb(118, 66, 62)",
        "sharp": "#76423e",
        "max": "rgb(114, 50, 50)"
    },
    "raw_iron_block.png": {
        "hsl": "hsl(29, 25%, 54%)",
        "rgb": "rgb(166, 136, 107)",
        "sharp": "#a6886b",
        "max": "rgb(175, 142, 119)"
    },
    "respawn_anchor.png": {
        "hsl": "hsl(264, 41%, 15%)",
        "rgb": "rgb(34, 22, 52)",
        "sharp": "#221634",
        "max": "rgb(6, 3, 11)"
    },
    "sea_lantern.png": {
        "hsl": "hsl(159, 20%, 73%)",
        "rgb": "rgb(172, 200, 190)",
        "sharp": "#acc8be",
        "max": "rgb(227, 235, 228)"
    },
    "polished_andesite.png": {
        "hsl": "hsl(160, 1%, 52%)",
        "rgb": "rgb(132, 135, 134)",
        "sharp": "#848786",
        "max": "rgb(134, 136, 135)"
    },
    "polished_diorite.png": {
        "hsl": "hsl(240, 2%, 76%)",
        "rgb": "rgb(193, 193, 195)",
        "sharp": "#c1c1c3",
        "max": "rgb(200, 201, 200)"
    },
    "polished_granite.png": {
        "hsl": "hsl(17, 27%, 48%)",
        "rgb": "rgb(154, 107, 89)",
        "sharp": "#9a6b59",
        "max": "rgb(159, 107, 88)"
    },
    //V7
    "clay.png": {
        "hsl": "hsl(223, 11%, 67%)",
        "rgb": "rgb(161, 166, 179)",
        "sharp": "#a1a6b3",
        "max": "rgb(161, 167, 177)"
    },
    "muddy_mangrove_roots.png": {
        "hsl": "hsl(34, 22%, 23%)",
        "rgb": "rgb(70, 59, 45)",
        "sharp": "#463b2d",
        "max": "rgb(78, 63, 39)"
    },
    "pale_moss_block.png": {
        "hsl": "hsl(103, 3%, 43%)",
        "rgb": "rgb(107, 112, 105)",
        "sharp": "#6b7069",
        "max": "rgb(89, 94, 88)"
    },
    "nether_wart_block.png": {
        "hsl": "hsl(0, 95%, 23%)",
        "rgb": "rgb(115, 3, 3)",
        "sharp": "#730303",
        "max": "rgb(123, 0, 0)"
    },
    "deepslate.png": {
        "hsl": "hsl(240, 2%, 32%)",
        "rgb": "rgb(80, 80, 83)",
        "sharp": "#505053",
        "max": "rgb(81, 81, 81)"
    },
    "emerald_block.png": {
        "hsl": "hsl(137, 66%, 48%)",
        "rgb": "rgb(42, 203, 88)",
        "sharp": "#2acb58",
        "max": "rgb(23, 197, 68)"
    },
    "hay_block.png": {
        "hsl": "hsl(49, 87%, 35%)",
        "rgb": "rgb(166, 139, 12)",
        "sharp": "#a68b0c",
        "max": "rgb(172, 141, 8)"
    },
    "deepslate_coal_ore.png": {
        "hsl": "hsl(240, 1%, 29%)",
        "rgb": "rgb(74, 74, 76)",
        "sharp": "#4a4a4c",
        "max": "rgb(81, 81, 81)"
    },
    "deepslate_copper_ore.png": {
        "hsl": "hsl(75, 2%, 36%)",
        "rgb": "rgb(92, 93, 89)",
        "sharp": "#5c5d59",
        "max": "rgb(81, 81, 81)"
    },
    "deepslate_diamond_ore.png": {
        "hsl": "hsl(183, 13%, 37%)",
        "rgb": "rgb(83, 106, 107)",
        "sharp": "#536a6b",
        "max": "rgb(81, 81, 81)"
    },
    "deepslate_emerald_ore.png": {
        "hsl": "hsl(143, 14%, 36%)",
        "rgb": "rgb(78, 104, 88)",
        "sharp": "#4e6858",
        "max": "rgb(100, 100, 100)"
    },
    "deepslate_gold_ore.png": {
        "hsl": "hsl(41, 19%, 38%)",
        "rgb": "rgb(115, 103, 78)",
        "sharp": "#73674e",
        "max": "rgb(81, 81, 81)"
    },
    "deepslate_iron_ore.png": {
        "hsl": "hsl(25, 6%, 40%)",
        "rgb": "rgb(107, 100, 95)",
        "sharp": "#6b645f",
        "max": "rgb(61, 61, 67)"
    },
    "deepslate_lapis_ore.png": {
        "hsl": "hsl(221, 18%, 38%)",
        "rgb": "rgb(80, 91, 115)",
        "sharp": "#505b73",
        "max": "rgb(100, 100, 100)"
    },
    "deepslate_redstone_ore.png": {
        "hsl": "hsl(356, 18%, 35%)",
        "rgb": "rgb(105, 73, 75)",
        "sharp": "#69494b",
        "max": "rgb(81, 81, 81)"
    },
    //v8
    'cherry_log_pillar_axis_x.png': {
        "hsl": "hsl(330, 25%, 17%)",
        "rgb": "rgb(55, 33, 44)",
        "sharp": "#37212c",
        "max": "rgb(48, 29, 41)"
    },
    'crimson_stem_pillar_axis_x.png': {
        "hsl": "hsl(356, 56%, 23%)",
        "rgb": "rgb(93, 26, 30)",
        "sharp": "#5d1a1e",
        "max": "rgb(82, 24, 16)"
    },
    'acacia_log_pillar_axis_x.png': {
        "hsl": "hsl(37, 8%, 37%)",
        "rgb": "rgb(103, 97, 87)",
        "sharp": "#676157",
        "max": "rgb(105, 98, 89)"
    },
    'dark_oak_log_pillar_axis_x.png': {
        "hsl": "hsl(37, 40%, 17%)",
        "rgb": "rgb(60, 47, 26)",
        "sharp": "#3c2f1a",
        "max": "rgb(63, 49, 29)"
    },
    'birch_log_pillar_axis_x.png': {
        "hsl": "hsl(43, 8%, 84%)",
        "rgb": "rgb(217, 215, 210)",
        "sharp": "#d9d7d2",
        "max": "rgb(255, 255, 255)"
    },
    'jungle_log_pillar_axis_x.png': {
        "hsl": "hsl(43, 55%, 22%)",
        "rgb": "rgb(85, 68, 25)",
        "sharp": "#554419",
        "max": "rgb(89, 70, 26)"
    },
    'oak_log_pillar_axis_x.png': {
        "hsl": "hsl(35, 36%, 31%)",
        "rgb": "rgb(109, 85, 51)",
        "sharp": "#6d5533",
        "max": "rgb(116, 90, 54)"
    },
    'spruce_log_pillar_axis_x.png': {
        "hsl": "hsl(30, 55%, 15%)",
        "rgb": "rgb(59, 38, 17)",
        "sharp": "#3b2611",
        "max": "rgb(59, 39, 19)"
    },
    'mangrove_log_pillar_axis_x.png': {
        "hsl": "hsl(36, 34%, 25%)",
        "rgb": "rgb(84, 67, 41)",
        "sharp": "#544329",
        "max": "rgb(78, 63, 39)"
    },
    'pale_oak_log_pillar_axis_x.png': {
        "hsl": "hsl(14, 8%, 32%)",
        "rgb": "rgb(88, 78, 75)",
        "sharp": "#584e4b",
        "max": "rgb(94, 83, 80)"
    },
    'stripped_acacia_wood.png': {
        "hsl": "hsl(17, 49%, 46%)",
        "rgb": "rgb(175, 93, 60)",
        "sharp": "#af5d3c",
        "max": "rgb(178, 91, 59)"
    },
    'stripped_birch_wood.png': {
        "hsl": "hsl(44, 41%, 62%)",
        "rgb": "rgb(197, 176, 118)",
        "sharp": "#c5b076",
        "max": "rgb(196, 172, 114)"
    },
    'stripped_cherry_wood.png': {
        "hsl": "hsl(357, 47%, 71%)",
        "rgb": "rgb(215, 145, 149)",
        "sharp": "#d79195",
        "max": "rgb(217, 148, 153)"
    },
    'stripped_dark_oak_wood.png': {
        "hsl": "hsl(34, 34%, 21%)",
        "rgb": "rgb(73, 57, 36)",
        "sharp": "#493924",
        "max": "rgb(69, 54, 35)"
    },
    'stripped_jungle_wood.png': {
        "hsl": "hsl(33, 34%, 50%)",
        "rgb": "rgb(171, 133, 85)",
        "sharp": "#ab8555",
        "max": "rgb(180, 134, 90)"
    },
    'stripped_mangrove_wood.png': {
        "hsl": "hsl(5, 43%, 33%)",
        "rgb": "rgb(120, 54, 48)",
        "sharp": "#783630",
        "max": "rgb(122, 55, 49)"
    },
    'stripped_oak_wood.png': {
        "hsl": "hsl(38, 37%, 52%)",
        "rgb": "rgb(177, 144, 86)",
        "sharp": "#b19056",
        "max": "rgb(185, 149, 88)"
    },
    'stripped_pale_oak_wood.png': {
        "hsl": "hsl(7, 33%, 95%)",
        "rgb": "rgb(246, 238, 237)",
        "sharp": "#f6eeed",
        "max": "rgb(248, 240, 240)"
    },
    'stripped_spruce_wood.png': {
        "hsl": "hsl(36, 40%, 22%)",
        "rgb": "rgb(79, 61, 34)",
        "sharp": "#4f3d22",
        "max": "rgb(70, 58, 32)"
    }
}

async function imageFileToSummonCommand(input, color_template, options = {}, call_back = () => { }) {
    function compute3DDistances(p1, p2, p = 3) {
        const [x1, y1, z1] = p1, [x2, y2, z2] = p2;
        const dx = Math.abs(x1 - x2), dy = Math.abs(y1 - y2), dz = Math.abs(z1 - z2);
        const euclidean = Math.sqrt(dx * dx + dy * dy + dz * dz);
        const manhattan = dx + dy + dz;
        const chebyshev = Math.max(dx, dy, dz);
        const minkowski = Math.pow(Math.pow(dx, p) + Math.pow(dy, p) + Math.pow(dz, p), 1 / p);
        const canberra = (dx / ((Math.abs(x1) + Math.abs(x2)) || 1e-10) +
            dy / ((Math.abs(y1) + Math.abs(y2)) || 1e-10) +
            dz / ((Math.abs(z1) + Math.abs(z2)) || 1e-10));
        const brayCurtis = (dx + dy + dz) / (((Math.abs(x1) + Math.abs(x2)) + (Math.abs(y1) + Math.abs(y2)) + (Math.abs(z1) + Math.abs(z2))) || 1e-10);
        return { euclidean, manhattan, chebyshev, minkowski, canberra, brayCurtis };
    }
    function getClosestKey_local(targetRGB, colorData, judgeType) {
        const targetMatches = targetRGB.match(/rgb\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)/i);
        if (!targetMatches) throw new Error("Invalid targetRGB format");
        const targetR = parseInt(targetMatches[1], 10);
        const targetG = parseInt(targetMatches[2], 10);
        const targetB = parseInt(targetMatches[3], 10);
        let dtr = judgeType;
        if (!dtr) {
            const sel = document && document.getElementById && document.getElementById("color_judge_type");
            dtr = sel ? sel.value : "euclidean";
        }
        const mapKey = {
            's': 'manhattan',
            'c': 'euclidean',
            'a': 'minkowski'
        }[dtr] || dtr; // allow passing full names
        let closestKey = null;
        let minDistance = Infinity;
        for (const key in colorData) {
            if (!Object.prototype.hasOwnProperty.call(colorData, key)) continue;
            const rgbString = colorData[key].rgb;
            const matches = rgbString.match(/rgb\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)/i);
            if (!matches) continue;
            const r = parseInt(matches[1], 10);
            const g = parseInt(matches[2], 10);
            const b = parseInt(matches[3], 10);
            const distances = compute3DDistances([r, g, b], [targetR, targetG, targetB]);
            const distance = (distances[mapKey] ?? distances.euclidean) ?? 0;
            if (distance < minDistance) {
                minDistance = distance;
                closestKey = key;
            }
        }
        return closestKey;
    }
    let ab;
    if (input instanceof ArrayBuffer) ab = input;
    else if (input instanceof Uint8Array) ab = input.buffer;
    else if (input instanceof Blob || input instanceof File) ab = await input.arrayBuffer();
    else throw new Error('Unsupported input type: must be File/Blob/ArrayBuffer/Uint8Array');
    const blob = new Blob([ab]);
    const url = URL.createObjectURL(blob);
    const img = await new Promise((res, rej) => {
        const i = new Image();
        i.onload = () => res(i);
        i.onerror = (e) => rej(new Error("Image load error"));
        i.src = url;
        i.crossOrigin = "Anonymous";
    });
    URL.revokeObjectURL(url);

    const scale = (typeof options.scale === 'number' && options.scale > 0 && options.scale <= 1) ? options.scale : 1;
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.floor(img.width * scale));
    canvas.height = Math.max(1, Math.floor(img.height * scale));
    const ctx = canvas.getContext('2d');
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imageData.data;
    const finalObj = { pallet: {}, size: { w: canvas.width, h: canvas.height }, data: "" };

    let before_block = null;
    let before_block_num = 0;
    const colorJudgeType = options.colorJudgeType || (document && document.getElementById && document.getElementById("color_judge_type") ? document.getElementById("color_judge_type").value : "euclidean");

    let i = 0;
    let is_finish = false;
    return new Promise((resolve, reject) => {
        const frame = (() => {
            for (let k = 0; k < 128; k++) {
                if (i < data.length) {
                    call_back(Math.floor((i / data.length * 10000)) / 100, data.length);
                    const r = data[i], g = data[i + 1], b = data[i + 2];
                    const key = getClosestKey_local(`rgb(${r}, ${g}, ${b})`, color_template, colorJudgeType);
                    const block = (key || "unknown").replace(".png", "");

                    if (finalObj.pallet[block] == null) {
                        let n = 65 + Object.keys(finalObj.pallet).length;
                        if (n < 97 && n > 90) n += 7;
                        if (n < 12232 && n > 122) n += 12232;
                        finalObj.pallet[block] = String.fromCharCode(n);
                    }

                    if (before_block === finalObj.pallet[block]) {
                        before_block_num++;
                    } else {
                        if (before_block_num > 0) {
                            finalObj.data += String(before_block_num);
                            before_block_num = 0;
                        }
                        finalObj.data += `${finalObj.pallet[block]}`;
                        before_block = finalObj.pallet[block];
                    }
                } else {
                    is_finish = true;
                    if (before_block_num > 0) {
                        finalObj.data += String(before_block_num);
                        before_block_num = 0;
                    }
                    const txt = JSON.stringify(finalObj);
                    const escQuote = '|%+;|';
                    const escaped = (typeof txt.replaceAll === 'function') ? txt.replaceAll('"', escQuote) : txt.split('"').join(escQuote);
                    const command = `summon armor_stand ${options["x"] ?? "~"} ${options["y"] ?? "~"} ${options["z"] ?? "~"} ~~ name "${escaped}"`;
                    resolve(command);
                }
                i += 4;
            }
            if (i < data.length || !is_finish) {
                requestAnimationFrame(frame);
            }
        })
        frame();
    })
}