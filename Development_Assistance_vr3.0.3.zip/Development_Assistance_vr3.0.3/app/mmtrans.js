function readUint32BE(datav, offset) { return (datav.getUint8(offset) << 24) | (datav.getUint8(offset + 1) << 16) | (datav.getUint8(offset + 2) << 8) | datav.getUint8(offset + 3); }
function readUint16BE(datav, offset) { return (datav.getUint8(offset) << 8) | datav.getUint8(offset + 1); }
function readVarLen(datav, off) {
    let value = 0, i = 0, b;
    do {
        b = datav.getUint8(off + i);
        value = (value << 7) | (b & 0x7F);
        i++;
    } while (b & 0x80);
    return { value, bytes: i };
}

function mapProgramToInstrument(prog, channel, note) {
    if (channel === 9) { // MIDIはCh.10=ドラム
        // ノート番号で分岐
        if ([35, 36].includes(note)) return "bd";        // Bass Drum
        if ([38, 40].includes(note)) return "snare";     // Snare
        if ([42, 44, 46].includes(note)) return "hat";   // Hi-hat
        if ([41, 43, 45, 47].includes(note)) return "bassattack"; // Toms →近似
        if ([49, 57].includes(note)) return "bell";      // Crash / Cymbal
        if ([56].includes(note)) return "cow_bell";      // Cowbell
        return "pling"; // fallback
    }

    // メロディ楽器
    if (prog >= 0 && prog <= 7) return "harp";          // Piano → harp
    if (prog >= 24 && prog <= 31) return "guitar";      // Guitar
    if (prog === 105) return "banjo";                   // Banjo
    if (prog >= 73 && prog <= 80) return "flute";       // Flute, Piccolo, Recorder
    if (prog === 112) return "bit";                     // Tinkle Bell → bit
    if (prog === 11) return "chime";                    // Vibraphone → chime
    if (prog === 13) return "xylophone";                // Xylophone
    if (prog === 14) return "bell";                     // Tubular Bells
    if (prog === 118) return "didgeridoo";              // Shanai → Didgeridoo

    return "pling"; // デフォルト
}

function parseMIDI(arrayBuffer) {
    const datav = new DataView(arrayBuffer);
    let ptr = 0;
    const headerSig = String.fromCharCode(...new Uint8Array(arrayBuffer.slice(0, 4)));
    if (headerSig !== 'MThd') throw new Error('Not a standard MIDI file (no MThd).');

    const headerLen = readUint32BE(datav, 4);
    const format = readUint16BE(datav, 8);
    const ntrks = readUint16BE(datav, 10);
    const division = readUint16BE(datav, 12);
    ptr = 8 + headerLen;
    let ticksPerQuarter = division;
    let events = [];
    let tempos = [{ ticks: 0, tempo: 500000 }];

    let channelPrograms = new Array(16).fill(0); // 各チャンネルのプログラム番号を保持

    for (let t = 0; t < ntrks; t++) {
        const chunk = String.fromCharCode(...new Uint8Array(arrayBuffer.slice(ptr, ptr + 4)));
        if (chunk !== 'MTrk') throw new Error('Expected MTrk chunk but got ' + chunk);
        const trackLen = readUint32BE(datav, ptr + 4);
        let off = ptr + 8;
        const end = off + trackLen;
        let absTicks = 0;
        let lastStatus = null;
        while (off < end) {
            const vl = readVarLen(datav, off);
            absTicks += vl.value;
            off += vl.bytes;
            let status = datav.getUint8(off);
            if (status < 0x80) {
                if (lastStatus === null) throw new Error('Running status without prior status');
                status = lastStatus;
            } else {
                off++;
                lastStatus = status;
            }
            if (status === 0xFF) {
                const metaType = datav.getUint8(off); off++;
                const lenobj = readVarLen(datav, off);
                const mlen = lenobj.value; off += lenobj.bytes;
                if (metaType === 0x51 && mlen === 3) {
                    const tempo = (datav.getUint8(off) << 16) | (datav.getUint8(off + 1) << 8) | (datav.getUint8(off + 2));
                    tempos.push({ ticks: absTicks, tempo });
                }
                off += mlen;
            } else if (status === 0xF0 || status === 0xF7) {
                const lenobj = readVarLen(datav, off);
                off += lenobj.bytes + lenobj.value;
            } else {
                const hi = status & 0xF0;
                const channel = status & 0x0F;
                if (hi === 0x80 || hi === 0x90) {
                    const d1 = datav.getUint8(off); const d2 = datav.getUint8(off + 1); off += 2;
                    if (hi === 0x90) {
                        if (d2 !== 0) {
                            // NOTE: include both program number (programId) and mapped instrument string
                            const programId = channelPrograms[channel]; // 0-127; for drums we'll mark later by channel
                            const instStr = mapProgramToInstrument(programId, channel, d1);
                            events.push({
                                ticks: absTicks,
                                type: 'noteOn',
                                note: d1,
                                velocity: d2,
                                channel,
                                program: programId,
                                instrumentName: instStr
                            });
                        } else {
                            events.push({ ticks: absTicks, type: 'noteOff', note: d1, velocity: d2, channel });
                        }
                    } else if (hi === 0x80) {
                        events.push({ ticks: absTicks, type: 'noteOff', note: d1, velocity: d2, channel });
                    }
                } else if (hi === 0xC0) { // Program Change
                    const prog = datav.getUint8(off); off += 1;
                    channelPrograms[channel] = prog;
                } else if (hi === 0xD0) {
                    off += 1;
                } else if (hi === 0xA0 || hi === 0xB0 || hi === 0xE0) {
                    off += 2;
                }
            }
        }
        ptr = end;
    }

    tempos.sort((a, b) => a.ticks - b.ticks);
    events.sort((a, b) => a.ticks - b.ticks);

    let curTempoIndex = 0;
    let prevTicks = 0;
    let curTime = 0;
    for (let i = 0; i < events.length; i++) {
        const e = events[i];
        while (curTempoIndex + 1 < tempos.length && tempos[curTempoIndex + 1].ticks <= e.ticks) {
            const nextTempo = tempos[curTempoIndex + 1];
            const dtTicks = nextTempo.ticks - prevTicks;
            curTime += dtTicks * (tempos[curTempoIndex].tempo / 1e6) / ticksPerQuarter;
            prevTicks = nextTempo.ticks;
            curTempoIndex++;
        }
        const dtTicks = e.ticks - prevTicks;
        const dtSeconds = dtTicks * (tempos[curTempoIndex].tempo / 1e6) / ticksPerQuarter;
        const eventTime = curTime + dtSeconds;
        prevTicks = e.ticks;
        curTime = eventTime;
        e.time = eventTime;
    }

    return { events, ticksPerQuarter, tempos };
}

async function midiFileToDaCommand(input, options = { resolutionMs: 10 }) {
    let ab;
    if (input instanceof ArrayBuffer) ab = input;
    else if (input instanceof Uint8Array) ab = input.buffer;
    else if (input instanceof Blob || input instanceof File) ab = await input.arrayBuffer();
    else throw new Error('Unsupported input type: must be File/Blob/ArrayBuffer/Uint8Array');
    if (typeof parseMIDI !== 'function') {
        throw new Error('parseMIDI function not found in scope.');
    }
    const parsed = parseMIDI(ab);
    const events = parsed.events.filter(e => e.type === 'noteOn' || e.type === 'noteOff');
    const notes = [];
    for (let i = 0; i < events.length; i++) {
        const e = events[i];
        if (e.type === 'noteOn') {
            let endTime = null;
            for (let j = i + 1; j < events.length; j++) {
                const f = events[j];
                if (f.type === 'noteOff' && f.note === e.note && f.channel === e.channel) {
                    endTime = f.time;
                    break;
                }
            }
            if (endTime === null) endTime = e.time + 0.5;
            const start = e.time;
            const dur = Math.max(0.02, endTime - start);

            const instrumentId = (e.channel === 9) ? 128 : (typeof e.program === 'number' ? e.program : 0);
            const instrumentName = e.instrumentName || (typeof mapProgramToInstrument === 'function'
                ? mapProgramToInstrument(instrumentId, e.channel, e.note)
                : 'unknown');

            notes.push({
                note: e.note,
                start,
                dur,
                velocity: e.velocity,
                instrument: instrumentId,
                instrumentName
            });
        }
    }
    function writeVarUintToArray(val, arr) {
        while (true) {
            let byte = val & 0x7F;
            val >>>= 7;
            if (val !== 0) {
                arr.push(byte | 0x80);
            } else {
                arr.push(byte);
                break;
            }
        }
    }
    function uint8ToBase64(u8) {
        const CHUNK = 0x8000;
        let parts = [];
        for (let i = 0; i < u8.length; i += CHUNK) {
            const slice = u8.subarray(i, Math.min(i + CHUNK, u8.length));
            parts.push(String.fromCharCode.apply(null, slice));
        }
        return btoa(parts.join(''));
    }
    function compressNotesWithStartToBase64(notesArr, opts = {}) {
        const resolutionMs = opts.resolutionMs || 10;
        if (!notesArr || notesArr.length === 0) return { base64: '', resolutionMs };
        const arr = notesArr.slice().sort((a, b) => a.start - b.start);
        const msArray = arr.map(n => Math.round((n.start || 0) * 1000 / resolutionMs));
        const out = [];
        let prev = 0;
        for (let i = 0; i < arr.length; i++) {
            const cur = msArray[i];
            const delta = (i === 0) ? cur : (cur - prev);
            writeVarUintToArray(delta, out);
            out.push((arr[i].note & 0x7F));
            out.push(((arr[i].velocity || 0) & 0x7F));
            out.push((arr[i].instrument || 0) & 0xFF);
            prev = cur;
        }
        const u8 = new Uint8Array(out);
        const b64 = uint8ToBase64(u8);
        return { base64: b64, resolutionMs };
    }

    const compressed = compressNotesWithStartToBase64(notes, { resolutionMs: options.resolutionMs });
    const cmd = `da:d_midi "${compressed.base64}"`;
    return cmd;
}